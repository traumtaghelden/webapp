import { PostgrestError } from '@supabase/supabase-js';
import { logger } from './logger';

export interface SafeQueryResult<T> {
  data: T | null;
  error: PostgrestError | null;
  success: boolean;
}

export async function safeQuery<T>(
  queryFn: () => Promise<{ data: T | null; error: PostgrestError | null }>,
  context: string
): Promise<SafeQueryResult<T>> {
  try {
    const result = await queryFn();

    if (result.error) {
      logger.error(`Query error in ${context}`, 'safeQuery', result.error);
      return {
        data: null,
        error: result.error,
        success: false,
      };
    }

    return {
      data: result.data,
      error: null,
      success: true,
    };
  } catch (error) {
    logger.error(`Unexpected error in ${context}`, 'safeQuery', error);
    return {
      data: null,
      error: {
        message: error instanceof Error ? error.message : 'Unknown error',
        details: '',
        hint: '',
        code: 'UNKNOWN',
      } as PostgrestError,
      success: false,
    };
  }
}

export async function safeMutation<T>(
  mutationFn: () => Promise<{ data: T | null; error: PostgrestError | null }>,
  context: string,
  options?: {
    onSuccess?: (data: T) => void;
    onError?: (error: PostgrestError) => void;
  }
): Promise<SafeQueryResult<T>> {
  try {
    const result = await mutationFn();

    if (result.error) {
      logger.error(`Mutation error in ${context}`, 'safeMutation', result.error);

      if (options?.onError) {
        options.onError(result.error);
      }

      return {
        data: null,
        error: result.error,
        success: false,
      };
    }

    if (result.data && options?.onSuccess) {
      options.onSuccess(result.data);
    }

    return {
      data: result.data,
      error: null,
      success: true,
    };
  } catch (error) {
    const errorObj = {
      message: error instanceof Error ? error.message : 'Unknown error',
      details: '',
      hint: '',
      code: 'UNKNOWN',
    } as PostgrestError;

    logger.error(`Unexpected error in ${context}`, 'safeMutation', error);

    if (options?.onError) {
      options.onError(errorObj);
    }

    return {
      data: null,
      error: errorObj,
      success: false,
    };
  }
}

export function withRetry<T>(
  fn: () => Promise<T>,
  maxRetries: number = 3,
  delayMs: number = 1000
): Promise<T> {
  return new Promise(async (resolve, reject) => {
    let lastError: Error | null = null;

    for (let i = 0; i < maxRetries; i++) {
      try {
        const result = await fn();
        resolve(result);
        return;
      } catch (error) {
        lastError = error instanceof Error ? error : new Error(String(error));
        logger.warn(`Retry attempt ${i + 1}/${maxRetries}`, 'withRetry', { error: lastError.message });

        if (i < maxRetries - 1) {
          await new Promise((r) => setTimeout(r, delayMs * (i + 1)));
        }
      }
    }

    reject(lastError || new Error('Unknown error'));
  });
}
