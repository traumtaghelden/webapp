export const trackEvent = (eventName: string, properties?: Record<string, any>) => {
  if (typeof window === 'undefined') return;

  console.log('[Analytics]', eventName, properties);

  if ((window as any).gtag) {
    (window as any).gtag('event', eventName, properties);
  }

  if ((window as any).plausible) {
    (window as any).plausible(eventName, { props: properties });
  }
};

export const trackUpgradePromptView = (context: 'limit' | 'feature' | 'general', feature?: string) => {
  trackEvent('upgrade_prompt_viewed', {
    context,
    feature,
    timestamp: new Date().toISOString()
  });
};

export const trackUpgradePromptDismissed = (context: 'limit' | 'feature' | 'general', feature?: string) => {
  trackEvent('upgrade_prompt_dismissed', {
    context,
    feature,
    timestamp: new Date().toISOString()
  });
};

export const trackUpgradeButtonClicked = (context: 'limit' | 'feature' | 'general', feature?: string) => {
  trackEvent('upgrade_button_clicked', {
    context,
    feature,
    timestamp: new Date().toISOString()
  });
};

export const trackFeatureGateInteraction = (featureName: string, action: 'viewed' | 'clicked') => {
  trackEvent('feature_gate_interaction', {
    feature: featureName,
    action,
    timestamp: new Date().toISOString()
  });
};

export const trackLimitReached = (limitType: string, current: number, max: number) => {
  trackEvent('limit_reached', {
    limit_type: limitType,
    current_count: current,
    max_count: max,
    timestamp: new Date().toISOString()
  });
};

export const trackLimitWarningViewed = (limitType: string, percentage: number) => {
  trackEvent('limit_warning_viewed', {
    limit_type: limitType,
    percentage,
    timestamp: new Date().toISOString()
  });
};

export const trackPremiumFeatureUsed = (featureName: string) => {
  trackEvent('premium_feature_used', {
    feature: featureName,
    timestamp: new Date().toISOString()
  });
};

export const trackUpgradeSuccess = (tier: string, price?: number) => {
  trackEvent('upgrade_success', {
    tier,
    price,
    timestamp: new Date().toISOString()
  });
};

export const trackUpgradeCancelled = (step: string) => {
  trackEvent('upgrade_cancelled', {
    step,
    timestamp: new Date().toISOString()
  });
};
