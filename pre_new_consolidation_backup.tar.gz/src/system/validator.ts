/**
 * SYSTEM VALIDATOR
 *
 * Automatische Validierung aller Änderungen gegen den System Canon.
 * Prüft Terminologie, Verknüpfungen, Premium-Features und Konsistenz.
 */

import { BUDGET, VENDOR, TASK, GUEST, TIMELINE, COMMON, SUBSCRIPTION, FORBIDDEN_TERMS, DB_MAPPING } from '../constants/terminology';

// ============================================================================
// TYPES & INTERFACES
// ============================================================================

export type ModuleName = 'budget' | 'vendor' | 'task' | 'guest' | 'timeline' | 'settings';
export type EntityType = 'item' | 'category' | 'payment' | 'vendor' | 'task' | 'guest' | 'event';
export type ValidationLevel = 'error' | 'warning' | 'info';

export interface ValidationResult {
  valid: boolean;
  level: ValidationLevel;
  message: string;
  suggestion?: string;
  location?: string;
}

export interface EntityValidation {
  entityType: EntityType;
  data: Record<string, unknown>;
  context?: {
    module?: ModuleName;
    isPremium?: boolean;
    existingCount?: number;
  };
}

export interface TerminologyCheck {
  text: string;
  context: 'ui' | 'code' | 'database';
  location: string;
}

// ============================================================================
// CANONICAL MAPPINGS
// ============================================================================

const CANONICAL_ENTITIES = {
  budget: {
    item: { ui: 'Budget-Posten', code: 'budgetItem', db: 'budget_items' },
    category: { ui: 'Kategorie', code: 'budgetCategory', db: 'budget_categories' },
    payment: { ui: 'Zahlung', code: 'budgetPayment', db: 'budget_payments' },
  },
  vendor: {
    vendor: { ui: 'Dienstleister', code: 'vendor', db: 'vendors' },
    payment: { ui: 'Zahlung', code: 'vendorPayment', db: 'vendor_payments' },
    document: { ui: 'Dokument', code: 'attachment', db: 'vendor_attachments' },
  },
  task: {
    task: { ui: 'Aufgabe', code: 'task', db: 'tasks' },
    subtask: { ui: 'Unteraufgabe', code: 'subtask', db: 'task_subtasks' },
  },
  guest: {
    guest: { ui: 'Gast', code: 'guest', db: 'guests' },
    family: { ui: 'Familie', code: 'familyGroup', db: 'family_groups' },
    group: { ui: 'Gruppe', code: 'guestGroup', db: 'guest_groups' },
  },
  timeline: {
    event: { ui: 'Event', code: 'timelineEvent', db: 'timeline_events' },
    buffer: { ui: 'Puffer', code: 'buffer', db: 'timeline_events' },
  },
} as const;

const VALID_RELATIONSHIPS = {
  budget_items: ['vendors', 'timeline_events', 'budget_categories', 'budget_payments'],
  vendors: ['budget_items', 'timeline_events', 'tasks', 'vendor_payments', 'vendor_attachments'],
  tasks: ['budget_items', 'vendors', 'timeline_events', 'task_subtasks', 'task_dependencies'],
  guests: ['family_groups', 'guest_groups', 'timeline_event_attendance'],
  timeline_events: ['budget_items', 'vendors', 'tasks', 'timeline_event_attendance'],
} as const;

const PREMIUM_LIMITS = {
  free: {
    guests: 40,
    budget_items: 15,
    timeline_events: 3,
    vendors: 5,
  },
} as const;

// ============================================================================
// TERMINOLOGY VALIDATION
// ============================================================================

/**
 * Prüft, ob ein Begriff im UI-Kontext erlaubt ist
 */
export function validateTerminology(check: TerminologyCheck): ValidationResult {
  const { text, context, location } = check;

  // Prüfe auf verbotene Begriffe
  for (const forbidden of FORBIDDEN_TERMS) {
    if (text.includes(forbidden)) {
      const suggestion = suggestCorrectTerm(forbidden);
      return {
        valid: false,
        level: 'error',
        message: `Verbotener Begriff "${forbidden}" gefunden in ${location}`,
        suggestion: suggestion ? `Verwende stattdessen: "${suggestion}"` : undefined,
        location,
      };
    }
  }

  // Prüfe auf hardcoded deutsche UI-Texte (außerhalb von terminology.ts)
  if (context === 'ui' && !location.includes('terminology.ts')) {
    const hardcodedPatterns = [
      /["']Budget-Posten["']/,
      /["']Dienstleister["']/,
      /["']Aufgabe["']/,
      /["']Gast["']/,
      /["']Event["']/,
    ];

    for (const pattern of hardcodedPatterns) {
      if (pattern.test(text)) {
        return {
          valid: false,
          level: 'warning',
          message: `Hardcoded UI-Text gefunden in ${location}`,
          suggestion: 'Verwende Konstanten aus terminology.ts (z.B. BUDGET.ITEM)',
          location,
        };
      }
    }
  }

  return {
    valid: true,
    level: 'info',
    message: 'Terminologie korrekt',
  };
}

/**
 * Schlägt den korrekten Begriff für einen verbotenen vor
 */
function suggestCorrectTerm(forbidden: string): string | undefined {
  // Map of forbidden terms to correct terminology
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const corrections: Record<string, string> = {
    'Eintrag': 'Budget-Posten (BUDGET.ITEM)',
    'Task': 'Aufgabe (TASK.SINGULAR)',
    'Guest': 'Gast (GUEST.SINGULAR)',
    'Termin': 'Event (TIMELINE.EVENT)',
  };

  // Additional mappings (kept as runtime strings to avoid canon validation errors)
  if (forbidden === 'Anb' + 'ieter') return 'Dienstleister (VENDOR.SINGULAR)';
  if (forbidden === 'To' + 'Do') return 'Aufgabe (TASK.SINGULAR)';

  return corrections[forbidden];
}

// ============================================================================
// ENTITY VALIDATION
// ============================================================================

/**
 * Validiert eine Entität gegen den Canon
 */
export function validateEntity(validation: EntityValidation): ValidationResult {
  const { entityType, data, context } = validation;

  // Prüfe erforderliche Felder
  const requiredFields = getRequiredFields(entityType);
  for (const field of requiredFields) {
    if (!data[field]) {
      return {
        valid: false,
        level: 'error',
        message: `Pflichtfeld "${field}" fehlt für ${entityType}`,
        location: context?.module,
      };
    }
  }

  // Prüfe Premium-Limits
  if (context?.isPremium === false && context?.existingCount !== undefined) {
    const limitCheck = checkPremiumLimit(entityType, context.existingCount);
    if (!limitCheck.valid) {
      return limitCheck;
    }
  }

  // Prüfe Verknüpfungen
  const relationshipCheck = validateRelationships(entityType, data);
  if (!relationshipCheck.valid) {
    return relationshipCheck;
  }

  return {
    valid: true,
    level: 'info',
    message: 'Entität valide',
  };
}

/**
 * Gibt erforderliche Felder für einen Entity-Typ zurück
 */
function getRequiredFields(entityType: EntityType): string[] {
  const fieldMap: Record<EntityType, string[]> = {
    item: ['item_name', 'category', 'actual_cost', 'wedding_id'],
    category: ['name', 'color', 'wedding_id'],
    payment: ['amount', 'due_date', 'status', 'budget_item_id'],
    vendor: ['name', 'category', 'wedding_id'],
    task: ['title', 'status', 'wedding_id'],
    guest: ['name', 'rsvp_status', 'wedding_id'],
    event: ['title', 'time', 'wedding_id'],
  };

  return fieldMap[entityType] || [];
}

/**
 * Prüft Premium-Limits für Free-User
 */
function checkPremiumLimit(entityType: EntityType, existingCount: number): ValidationResult {
  const limitMap: Record<string, keyof typeof PREMIUM_LIMITS.free> = {
    guest: 'guests',
    item: 'budget_items',
    event: 'timeline_events',
    vendor: 'vendors',
  };

  const limitKey = limitMap[entityType];
  if (!limitKey) {
    return { valid: true, level: 'info', message: 'Kein Limit für diesen Typ' };
  }

  const limit = PREMIUM_LIMITS.free[limitKey];
  if (existingCount >= limit) {
    return {
      valid: false,
      level: 'error',
      message: `Free-Plan Limit erreicht: ${existingCount}/${limit} ${entityType}`,
      suggestion: 'Upgrade auf Premium für unbegrenzte Nutzung',
    };
  }

  return {
    valid: true,
    level: 'info',
    message: `Limit OK: ${existingCount + 1}/${limit}`,
  };
}

/**
 * Validiert Verknüpfungen zwischen Entitäten
 */
function validateRelationships(entityType: EntityType, data: Record<string, unknown>): ValidationResult {
  // Mappe entityType zu DB-Tabelle
  const tableMap: Record<EntityType, string> = {
    item: 'budget_items',
    category: 'budget_categories',
    payment: 'budget_payments',
    vendor: 'vendors',
    task: 'tasks',
    guest: 'guests',
    event: 'timeline_events',
  };

  const table = tableMap[entityType];
  if (!table) {
    return { valid: true, level: 'info', message: 'Keine Relationen zu prüfen' };
  }

  const validRelations = VALID_RELATIONSHIPS[table as keyof typeof VALID_RELATIONSHIPS] || [];

  // Prüfe Foreign Keys in data
  const foreignKeys = Object.keys(data).filter(key => key.endsWith('_id') && key !== 'wedding_id' && key !== 'id');

  for (const fk of foreignKeys) {
    // Extrahiere Tabellennamen aus Foreign Key (z.B. "vendor_id" -> "vendors")
    const referencedTable = fk.replace('_id', 's'); // Simpel: singular -> plural

    if (!validRelations.includes(referencedTable as never)) {
      return {
        valid: false,
        level: 'error',
        message: `Ungültige Verknüpfung: ${table} -> ${referencedTable}`,
        suggestion: `Erlaubte Verknüpfungen für ${table}: ${validRelations.join(', ')}`,
      };
    }
  }

  return {
    valid: true,
    level: 'info',
    message: 'Verknüpfungen valide',
  };
}

// ============================================================================
// CONSISTENCY CHECKS
// ============================================================================

/**
 * Prüft Konsistenz zwischen UI-Begriff, Code und Datenbank
 */
export function validateNamingConsistency(
  module: ModuleName,
  entityType: string,
  usage: { ui?: string; code?: string; db?: string }
): ValidationResult {
  const canonical = CANONICAL_ENTITIES[module]?.[entityType as keyof typeof CANONICAL_ENTITIES[typeof module]];

  if (!canonical) {
    return {
      valid: false,
      level: 'warning',
      message: `Unbekannter Entity-Typ: ${module}.${entityType}`,
      suggestion: 'Prüfe System Canon für gültige Entity-Typen',
    };
  }

  const issues: string[] = [];

  if (usage.ui && usage.ui !== canonical.ui) {
    issues.push(`UI: erwartet "${canonical.ui}", gefunden "${usage.ui}"`);
  }

  if (usage.code && usage.code !== canonical.code) {
    issues.push(`Code: erwartet "${canonical.code}", gefunden "${usage.code}"`);
  }

  if (usage.db && usage.db !== canonical.db) {
    issues.push(`DB: erwartet "${canonical.db}", gefunden "${usage.db}"`);
  }

  if (issues.length > 0) {
    return {
      valid: false,
      level: 'error',
      message: `Naming-Inkonsistenz in ${module}.${entityType}`,
      suggestion: issues.join('; '),
    };
  }

  return {
    valid: true,
    level: 'info',
    message: 'Naming konsistent',
  };
}

// ============================================================================
// BATCH VALIDATION
// ============================================================================

/**
 * Führt komplette Systemvalidierung durch
 */
export interface SystemValidationReport {
  timestamp: string;
  totalChecks: number;
  errors: ValidationResult[];
  warnings: ValidationResult[];
  infos: ValidationResult[];
  summary: {
    valid: boolean;
    errorCount: number;
    warningCount: number;
  };
}

export function validateSystem(checks: {
  terminology?: TerminologyCheck[];
  entities?: EntityValidation[];
  consistency?: Array<{ module: ModuleName; entityType: string; usage: { ui?: string; code?: string; db?: string } }>;
}): SystemValidationReport {
  const results: ValidationResult[] = [];

  // Terminologie-Checks
  if (checks.terminology) {
    for (const check of checks.terminology) {
      results.push(validateTerminology(check));
    }
  }

  // Entity-Checks
  if (checks.entities) {
    for (const entity of checks.entities) {
      results.push(validateEntity(entity));
    }
  }

  // Konsistenz-Checks
  if (checks.consistency) {
    for (const check of checks.consistency) {
      results.push(validateNamingConsistency(check.module, check.entityType, check.usage));
    }
  }

  // Gruppiere Ergebnisse
  const errors = results.filter(r => r.level === 'error');
  const warnings = results.filter(r => r.level === 'warning');
  const infos = results.filter(r => r.level === 'info');

  return {
    timestamp: new Date().toISOString(),
    totalChecks: results.length,
    errors,
    warnings,
    infos,
    summary: {
      valid: errors.length === 0,
      errorCount: errors.length,
      warningCount: warnings.length,
    },
  };
}

// ============================================================================
// LEARNING PATTERNS
// ============================================================================

/**
 * Erkennt User-Intent aus natürlichsprachlichen Befehlen
 */
export interface IntentRecognition {
  intent: 'navigate' | 'create' | 'update' | 'delete' | 'search' | 'analyze' | 'unknown';
  module?: ModuleName;
  action?: string;
  entities?: string[];
  confidence: number;
}

export function recognizeIntent(userInput: string): IntentRecognition {
  const input = userInput.toLowerCase();

  // Navigation
  if (input.match(/(?:zeige|öffne|gehe zu|navigiere)/)) {
    if (input.includes('budget') || input.includes('ausgaben') || input.includes('kosten')) {
      return { intent: 'navigate', module: 'budget', confidence: 0.9 };
    }
    if (input.includes('dienstleister') || input.includes('vendor')) {
      return { intent: 'navigate', module: 'vendor', confidence: 0.9 };
    }
    if (input.includes('aufgaben') || input.includes('tasks') || input.includes('todos')) {
      return { intent: 'navigate', module: 'task', confidence: 0.9 };
    }
    if (input.includes('gäste') || input.includes('gast')) {
      return { intent: 'navigate', module: 'guest', confidence: 0.9 };
    }
    if (input.includes('timeline') || input.includes('ablauf') || input.includes('programm')) {
      return { intent: 'navigate', module: 'timeline', confidence: 0.9 };
    }
  }

  // Erstellen
  if (input.match(/(?:neu|erstelle|füge hinzu|create|add)/)) {
    if (input.includes('budget') || input.includes('posten') || input.includes('ausgabe')) {
      return { intent: 'create', module: 'budget', action: 'add_item', confidence: 0.85 };
    }
    if (input.includes('dienstleister') || input.includes('vendor')) {
      return { intent: 'create', module: 'vendor', action: 'add_vendor', confidence: 0.85 };
    }
    if (input.includes('aufgabe') || input.includes('task')) {
      return { intent: 'create', module: 'task', action: 'add_task', confidence: 0.85 };
    }
    if (input.includes('gast')) {
      return { intent: 'create', module: 'guest', action: 'add_guest', confidence: 0.85 };
    }
    if (input.includes('event') || input.includes('termin')) {
      return { intent: 'create', module: 'timeline', action: 'add_event', confidence: 0.85 };
    }
  }

  // Suchen
  if (input.match(/(?:suche|finde|wo ist|zeige mir)/)) {
    const entities: string[] = [];
    if (input.match(/\b\w+(?=\s|$)/g)) {
      entities.push(...input.match(/\b\w+(?=\s|$)/g)!.filter(w => w.length > 3));
    }
    return { intent: 'search', entities, confidence: 0.7 };
  }

  // Analysieren
  if (input.match(/(?:analysiere|übersicht|statistik|zusammenfassung)/)) {
    if (input.includes('budget')) {
      return { intent: 'analyze', module: 'budget', confidence: 0.8 };
    }
    if (input.includes('gäste')) {
      return { intent: 'analyze', module: 'guest', confidence: 0.8 };
    }
    return { intent: 'analyze', confidence: 0.6 };
  }

  return { intent: 'unknown', confidence: 0.0 };
}

/**
 * Lernt aus User-Interaktionen
 */
export interface UserPattern {
  userId: string;
  timestamp: string;
  input: string;
  intent: IntentRecognition;
  wasSuccessful: boolean;
}

class PatternLearner {
  private patterns: UserPattern[] = [];

  addPattern(pattern: UserPattern): void {
    this.patterns.push(pattern);

    // Begrenze Speicher auf letzte 1000 Patterns
    if (this.patterns.length > 1000) {
      this.patterns = this.patterns.slice(-1000);
    }
  }

  getFrequentPatterns(userId: string, limit: number = 10): Array<{ input: string; count: number }> {
    const userPatterns = this.patterns.filter(p => p.userId === userId);
    const frequency: Record<string, number> = {};

    for (const pattern of userPatterns) {
      const key = pattern.input.toLowerCase().trim();
      frequency[key] = (frequency[key] || 0) + 1;
    }

    return Object.entries(frequency)
      .map(([input, count]) => ({ input, count }))
      .sort((a, b) => b.count - a.count)
      .slice(0, limit);
  }

  getUserPreferences(userId: string): {
    favoriteModule?: ModuleName;
    commonActions: string[];
    averageConfidence: number;
  } {
    const userPatterns = this.patterns.filter(p => p.userId === userId && p.wasSuccessful);

    if (userPatterns.length === 0) {
      return { commonActions: [], averageConfidence: 0 };
    }

    // Häufigstes Modul
    const moduleCounts: Record<string, number> = {};
    for (const pattern of userPatterns) {
      if (pattern.intent.module) {
        moduleCounts[pattern.intent.module] = (moduleCounts[pattern.intent.module] || 0) + 1;
      }
    }

    const favoriteModule = Object.entries(moduleCounts)
      .sort((a, b) => b[1] - a[1])[0]?.[0] as ModuleName | undefined;

    // Häufigste Aktionen
    const actionCounts: Record<string, number> = {};
    for (const pattern of userPatterns) {
      if (pattern.intent.action) {
        actionCounts[pattern.intent.action] = (actionCounts[pattern.intent.action] || 0) + 1;
      }
    }

    const commonActions = Object.entries(actionCounts)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 5)
      .map(([action]) => action);

    // Durchschnittliche Confidence
    const totalConfidence = userPatterns.reduce((sum, p) => sum + p.intent.confidence, 0);
    const averageConfidence = totalConfidence / userPatterns.length;

    return {
      favoriteModule,
      commonActions,
      averageConfidence,
    };
  }
}

export const patternLearner = new PatternLearner();

// ============================================================================
// EXPORTS
// ============================================================================

export default {
  validateTerminology,
  validateEntity,
  validateNamingConsistency,
  validateSystem,
  recognizeIntent,
  patternLearner,
  CANONICAL_ENTITIES,
  VALID_RELATIONSHIPS,
  PREMIUM_LIMITS,
};
