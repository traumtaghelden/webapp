import { useState } from 'react';
import { supabase } from '../lib/supabase';

export interface ContextualCreateOptions {
  weddingId: string;
  sourceType?: 'task' | 'budget' | 'vendor' | 'timeline';
  sourceId?: string;
  vendorId?: string;
  budgetItemId?: string;
  timelineEventId?: string;
  taskId?: string;
}

interface CreateTaskOptions {
  title: string;
  description?: string;
  due_date?: string;
  priority?: 'low' | 'medium' | 'high';
  category?: string;
}

interface CreateBudgetOptions {
  category: string;
  item_name: string;
  estimated_cost: number;
  actual_cost?: number;
  notes?: string;
}

interface CreatePaymentOptions {
  amount: number;
  due_date: string;
  payment_method?: string;
  notes?: string;
}

export function useContextualCreate(context: ContextualCreateOptions) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const logActivity = async (
    entityType: string,
    entityId: string,
    actionType: string,
    relatedEntityType?: string,
    relatedEntityId?: string,
    details?: any
  ) => {
    try {
      await supabase.rpc('log_activity', {
        p_wedding_id: context.weddingId,
        p_entity_type: entityType,
        p_entity_id: entityId,
        p_action_type: actionType,
        p_related_entity_type: relatedEntityType,
        p_related_entity_id: relatedEntityId,
        p_details: details || {}
      });
    } catch (err) {
      console.error('Error logging activity:', err);
    }
  };

  const createTask = async (options: CreateTaskOptions) => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: insertError } = await supabase
        .from('tasks')
        .insert([{
          wedding_id: context.weddingId,
          vendor_id: context.vendorId,
          timeline_event_id: context.timelineEventId,
          ...options
        }])
        .select()
        .single();

      if (insertError) throw insertError;

      await logActivity(
        'task',
        data.id,
        'created',
        context.sourceType,
        context.sourceId,
        {
          created_from: context.sourceType,
          vendor_linked: !!context.vendorId,
          timeline_linked: !!context.timelineEventId
        }
      );

      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const createBudgetItem = async (options: CreateBudgetOptions) => {
    setLoading(true);
    setError(null);

    try {
      const { data, error: insertError } = await supabase
        .from('budget_items')
        .insert([{
          wedding_id: context.weddingId,
          vendor_id: context.vendorId,
          timeline_event_id: context.timelineEventId,
          ...options
        }])
        .select()
        .single();

      if (insertError) throw insertError;

      await logActivity(
        'budget',
        data.id,
        'created',
        context.sourceType,
        context.sourceId,
        {
          created_from: context.sourceType,
          vendor_linked: !!context.vendorId
        }
      );

      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const createPayment = async (options: CreatePaymentOptions) => {
    setLoading(true);
    setError(null);

    try {
      if (!context.budgetItemId && !context.vendorId) {
        throw new Error('Budget-Item oder Vendor muss angegeben werden');
      }

      let budgetItemId = context.budgetItemId;

      if (!budgetItemId && context.vendorId) {
        const { data: budgetItem } = await supabase
          .from('budget_items')
          .select('id')
          .eq('vendor_id', context.vendorId)
          .maybeSingle();

        if (!budgetItem) {
          throw new Error('Kein Budget-Item für diesen Dienstleister gefunden');
        }

        budgetItemId = budgetItem.id;
      }

      const { data, error: insertError } = await supabase
        .from('budget_payments')
        .insert([{
          budget_item_id: budgetItemId,
          ...options,
          status: 'pending'
        }])
        .select()
        .single();

      if (insertError) throw insertError;

      await logActivity(
        'payment',
        data.id,
        'created',
        context.sourceType,
        context.sourceId,
        {
          created_from: context.sourceType,
          amount: options.amount
        }
      );

      return data;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  const linkEntities = async (
    targetType: 'task' | 'budget' | 'vendor' | 'timeline',
    targetId: string
  ) => {
    setLoading(true);
    setError(null);

    try {
      let updatePromise;

      if (context.sourceType === 'task' && targetType === 'vendor') {
        updatePromise = supabase
          .from('tasks')
          .update({ vendor_id: targetId })
          .eq('id', context.sourceId);
      } else if (context.sourceType === 'task' && targetType === 'timeline') {
        updatePromise = supabase
          .from('tasks')
          .update({ timeline_event_id: targetId })
          .eq('id', context.sourceId);
      } else if (context.sourceType === 'budget' && targetType === 'vendor') {
        updatePromise = supabase
          .from('budget_items')
          .update({ vendor_id: targetId })
          .eq('id', context.sourceId);
      } else if (context.sourceType === 'budget' && targetType === 'timeline') {
        updatePromise = supabase
          .from('budget_items')
          .update({ timeline_event_id: targetId })
          .eq('id', context.sourceId);
      } else {
        throw new Error('Diese Verknüpfung wird nicht unterstützt');
      }

      const { error: updateError } = await updatePromise;
      if (updateError) throw updateError;

      await logActivity(
        context.sourceType!,
        context.sourceId!,
        'linked',
        targetType,
        targetId
      );

      return true;
    } catch (err: any) {
      setError(err.message);
      throw err;
    } finally {
      setLoading(false);
    }
  };

  return {
    loading,
    error,
    createTask,
    createBudgetItem,
    createPayment,
    linkEntities
  };
}
