import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';

export interface LinkedEntities {
  tasks: Array<{ id: string; title: string }>;
  budgetItems: Array<{ id: string; item_name: string }>;
  timelineEvents: Array<{ id: string; title: string }>;
  payments: Array<{ id: string; amount: number }>;
}

export interface DeleteOptions {
  unlinkOnly?: boolean;
  cascadeDelete?: boolean;
}

export function useLinkProtection(
  entityType: 'task' | 'budget' | 'vendor' | 'timeline',
  entityId: string | null
) {
  const [linkedEntities, setLinkedEntities] = useState<LinkedEntities>({
    tasks: [],
    budgetItems: [],
    timelineEvents: [],
    payments: []
  });
  const [loading, setLoading] = useState(false);
  const [hasLinks, setHasLinks] = useState(false);

  useEffect(() => {
    if (entityId) {
      loadLinkedEntities();
    }
  }, [entityId, entityType]);

  const loadLinkedEntities = async () => {
    if (!entityId) return;

    setLoading(true);
    try {
      const links: LinkedEntities = {
        tasks: [],
        budgetItems: [],
        timelineEvents: [],
        payments: []
      };

      if (entityType === 'vendor') {
        const [tasksData, budgetData] = await Promise.all([
          supabase
            .from('tasks')
            .select('id, title')
            .eq('vendor_id', entityId),
          supabase
            .from('budget_items')
            .select('id, item_name')
            .eq('vendor_id', entityId)
        ]);

        if (tasksData.data) links.tasks = tasksData.data;
        if (budgetData.data) links.budgetItems = budgetData.data;

        if (budgetData.data && budgetData.data.length > 0) {
          const budgetIds = budgetData.data.map(b => b.id);
          const { data: paymentsData } = await supabase
            .from('budget_payments')
            .select('id, amount')
            .in('budget_item_id', budgetIds);

          if (paymentsData) links.payments = paymentsData;
        }
      } else if (entityType === 'budget') {
        const [paymentsData, tasksData] = await Promise.all([
          supabase
            .from('budget_payments')
            .select('id, amount')
            .eq('budget_item_id', entityId),
          supabase
            .from('tasks')
            .select('id, title, vendor_id')
            .not('vendor_id', 'is', null)
        ]);

        if (paymentsData.data) links.payments = paymentsData.data;
        if (tasksData.data) {
          const { data: budgetData } = await supabase
            .from('budget_items')
            .select('vendor_id')
            .eq('id', entityId)
            .single();

          if (budgetData?.vendor_id) {
            links.tasks = tasksData.data.filter(t => t.vendor_id === budgetData.vendor_id);
          }
        }
      } else if (entityType === 'timeline') {
        const [tasksData, budgetData] = await Promise.all([
          supabase
            .from('tasks')
            .select('id, title')
            .eq('timeline_event_id', entityId),
          supabase
            .from('budget_items')
            .select('id, item_name')
            .eq('timeline_event_id', entityId)
        ]);

        if (tasksData.data) links.tasks = tasksData.data;
        if (budgetData.data) links.budgetItems = budgetData.data;
      } else if (entityType === 'task') {
        const { data: taskData } = await supabase
          .from('tasks')
          .select('vendor_id, timeline_event_id')
          .eq('id', entityId)
          .single();

        if (taskData) {
          if (taskData.vendor_id) {
            const { data: vendorData } = await supabase
              .from('vendors')
              .select('id, name')
              .eq('id', taskData.vendor_id)
              .single();
            // Vendor info could be added here if needed
          }

          if (taskData.timeline_event_id) {
            const { data: timelineData } = await supabase
              .from('wedding_timeline')
              .select('id, title')
              .eq('id', taskData.timeline_event_id)
              .single();

            if (timelineData) links.timelineEvents = [timelineData];
          }
        }
      }

      setLinkedEntities(links);
      setHasLinks(
        links.tasks.length > 0 ||
        links.budgetItems.length > 0 ||
        links.timelineEvents.length > 0 ||
        links.payments.length > 0
      );
    } catch (error) {
      console.error('Error loading linked entities:', error);
    } finally {
      setLoading(false);
    }
  };

  const getDeleteMessage = (): string => {
    const parts = [];

    if (linkedEntities.tasks.length > 0) {
      parts.push(`${linkedEntities.tasks.length} Aufgabe${linkedEntities.tasks.length > 1 ? 'n' : ''}`);
    }
    if (linkedEntities.budgetItems.length > 0) {
      parts.push(`${linkedEntities.budgetItems.length} Budget-Posten`);
    }
    if (linkedEntities.payments.length > 0) {
      parts.push(`${linkedEntities.payments.length} Zahlung${linkedEntities.payments.length > 1 ? 'en' : ''}`);
    }
    if (linkedEntities.timelineEvents.length > 0) {
      parts.push(`${linkedEntities.timelineEvents.length} Timeline-Event${linkedEntities.timelineEvents.length > 1 ? 's' : ''}`);
    }

    if (parts.length === 0) {
      return 'Dieser Eintrag hat keine Verknüpfungen.';
    }

    return `Dieser Eintrag ist verknüpft mit: ${parts.join(', ')}. Wie möchten Sie fortfahren?`;
  };

  const performDelete = async (options: DeleteOptions = {}) => {
    if (!entityId) throw new Error('Keine Entity ID angegeben');

    try {
      if (options.unlinkOnly) {
        if (entityType === 'vendor') {
          await Promise.all([
            supabase.from('tasks').update({ vendor_id: null }).eq('vendor_id', entityId),
            supabase.from('budget_items').update({ vendor_id: null }).eq('vendor_id', entityId)
          ]);
        } else if (entityType === 'timeline') {
          await Promise.all([
            supabase.from('tasks').update({ timeline_event_id: null }).eq('timeline_event_id', entityId),
            supabase.from('budget_items').update({ timeline_event_id: null }).eq('timeline_event_id', entityId)
          ]);
        }

        return { success: true, unlinked: true };
      }

      const tableName = entityType === 'budget' ? 'budget_items' :
                       entityType === 'timeline' ? 'wedding_timeline' :
                       entityType === 'task' ? 'tasks' :
                       'vendors';

      const { error } = await supabase
        .from(tableName)
        .delete()
        .eq('id', entityId);

      if (error) throw error;

      return { success: true, deleted: true };
    } catch (error: any) {
      console.error('Error during delete:', error);
      throw error;
    }
  };

  return {
    linkedEntities,
    hasLinks,
    loading,
    getDeleteMessage,
    performDelete,
    reload: loadLinkedEntities
  };
}
