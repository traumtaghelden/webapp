import { useState, useCallback, useRef, useEffect } from 'react';
import { logger } from '../utils/logger';

interface UseSafeAsyncOptions<T> {
  onSuccess?: (result: T) => void;
  onError?: (error: Error) => void;
  preventDoubleExecution?: boolean;
}

export function useSafeAsync<T = void, Args extends any[] = []>(
  asyncFn: (...args: Args) => Promise<T>,
  options: UseSafeAsyncOptions<T> = {}
) {
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<Error | null>(null);
  const isMountedRef = useRef(true);
  const executionRef = useRef(false);

  useEffect(() => {
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  const execute = useCallback(
    async (...args: Args) => {
      if (options.preventDoubleExecution && executionRef.current) {
        logger.debug('Preventing double execution', 'useSafeAsync');
        return;
      }

      if (isLoading) {
        logger.debug('Already loading, skipping execution', 'useSafeAsync');
        return;
      }

      try {
        executionRef.current = true;
        setIsLoading(true);
        setError(null);

        const result = await asyncFn(...args);

        if (isMountedRef.current) {
          if (options.onSuccess) {
            options.onSuccess(result);
          }
        }

        return result;
      } catch (err) {
        const error = err instanceof Error ? err : new Error(String(err));

        logger.error('Async operation failed', 'useSafeAsync', error);

        if (isMountedRef.current) {
          setError(error);

          if (options.onError) {
            options.onError(error);
          }
        }

        throw error;
      } finally {
        if (isMountedRef.current) {
          setIsLoading(false);
        }
        executionRef.current = false;
      }
    },
    [asyncFn, isLoading, options]
  );

  const reset = useCallback(() => {
    setIsLoading(false);
    setError(null);
    executionRef.current = false;
  }, []);

  return {
    execute,
    isLoading,
    error,
    reset,
  };
}
