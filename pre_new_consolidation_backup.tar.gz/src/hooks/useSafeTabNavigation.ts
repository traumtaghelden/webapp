import { useState, useCallback, useEffect } from 'react';
import { logger } from '../utils/logger';

interface UseSafeTabNavigationOptions<T extends string> {
  defaultTab: T;
  onTabChange?: (tab: T) => void;
  validateTab?: (tab: T) => boolean;
  persistKey?: string;
}

export function useSafeTabNavigation<T extends string>(
  options: UseSafeTabNavigationOptions<T>
) {
  const [activeTab, setActiveTab] = useState<T>(() => {
    if (options.persistKey) {
      try {
        const stored = localStorage.getItem(options.persistKey);
        if (stored) {
          const parsedTab = stored as T;
          if (!options.validateTab || options.validateTab(parsedTab)) {
            return parsedTab;
          }
        }
      } catch (error) {
        logger.error('Error loading tab from localStorage', 'useSafeTabNavigation', error);
      }
    }
    return options.defaultTab;
  });

  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    if (options.persistKey && activeTab) {
      try {
        localStorage.setItem(options.persistKey, activeTab);
      } catch (error) {
        logger.error('Error saving tab to localStorage', 'useSafeTabNavigation', error);
      }
    }
  }, [activeTab, options.persistKey]);

  const changeTab = useCallback(
    (newTab: T) => {
      if (isTransitioning) {
        logger.debug('Tab transition in progress, ignoring request', 'useSafeTabNavigation');
        return;
      }

      if (options.validateTab && !options.validateTab(newTab)) {
        logger.warn('Invalid tab attempted', 'useSafeTabNavigation', { tab: newTab });
        return;
      }

      try {
        setIsTransitioning(true);
        setActiveTab(newTab);

        if (options.onTabChange) {
          options.onTabChange(newTab);
        }

        setTimeout(() => {
          setIsTransitioning(false);
        }, 100);
      } catch (error) {
        logger.error('Error changing tab', 'useSafeTabNavigation', error);
        setIsTransitioning(false);
      }
    },
    [isTransitioning, options]
  );

  return {
    activeTab,
    changeTab,
    isTransitioning,
  };
}
