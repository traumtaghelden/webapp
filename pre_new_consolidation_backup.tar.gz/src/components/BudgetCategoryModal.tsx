import { useState, useEffect } from 'react';
import { Save, Folder, Crown, Lock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { BUDGET, COMMON } from '../constants/terminology';
import StandardModal, { ModalFooter, ModalButton } from './StandardModal';

interface BudgetCategoryModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: () => void;
  weddingId: string;
  editingCategory?: {
    id: string;
    name: string;
    color: string;
    budget_limit: number;
  } | null;
  categoryCount: number;
}

const colorOptions = [
  '#d4af37', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6',
  '#ec4899', '#14b8a6', '#f97316', '#ef4444', '#06b6d4',
];

export default function BudgetCategoryModal({
  isOpen,
  onClose,
  onSave,
  weddingId,
  editingCategory,
  categoryCount
}: BudgetCategoryModalProps) {
  const [formData, setFormData] = useState({
    name: '',
    color: '#d4af37',
    budget_limit: 0,
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const canAddCategory = categoryCount < 6;

  useEffect(() => {
    if (isOpen) {
      if (editingCategory) {
        setFormData({
          name: editingCategory.name,
          color: editingCategory.color,
          budget_limit: editingCategory.budget_limit,
        });
      } else {
        setFormData({
          name: '',
          color: '#d4af37',
          budget_limit: 0,
        });
      }
      setError('');
    }
  }, [isOpen, editingCategory]);

  const handleSave = async () => {
    if (!formData.name.trim()) {
      setError('Bitte gib einen Namen ein');
      return;
    }

    if (!canAddCategory && !editingCategory) {
      setError('Free-Plan unterstützt maximal 6 Kategorien. Upgrade auf Premium für unbegrenzte Kategorien.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      if (editingCategory) {
        const { error: updateError } = await supabase
          .from('budget_categories')
          .update({
            name: formData.name,
            color: formData.color,
            budget_limit: formData.budget_limit,
            updated_at: new Date().toISOString(),
          })
          .eq('id', editingCategory.id);

        if (updateError) throw updateError;
      } else {
        const { data: existingCategories } = await supabase
          .from('budget_categories')
          .select('order_index')
          .eq('wedding_id', weddingId)
          .order('order_index', { ascending: false })
          .limit(1);

        const maxOrder = existingCategories && existingCategories.length > 0
          ? existingCategories[0].order_index
          : -1;

        const { error: insertError } = await supabase
          .from('budget_categories')
          .insert([{
            wedding_id: weddingId,
            name: formData.name,
            color: formData.color,
            budget_limit: formData.budget_limit,
            order_index: maxOrder + 1,
            is_default: false,
          }]);

        if (insertError) throw insertError;
      }

      onSave();
      onClose();
    } catch (err: any) {
      console.error('Error saving category:', err);
      setError(err.message || 'Fehler beim Speichern der Kategorie');
    } finally {
      setLoading(false);
    }
  };

  return (
    <StandardModal
      isOpen={isOpen}
      onClose={onClose}
      title={editingCategory ? 'Kategorie bearbeiten' : 'Neue Kategorie erstellen'}
      subtitle={editingCategory ? 'Kategorie-Details aktualisieren' : 'Budget-Kategorie mit eigenem Limit hinzufügen'}
      icon={Folder}
      maxWidth="2xl"
      footer={
        <ModalFooter>
          <ModalButton variant="secondary" onClick={onClose} disabled={loading}>
            Abbrechen
          </ModalButton>
          <ModalButton
            variant="primary"
            onClick={handleSave}
            disabled={loading || !formData.name.trim() || (!canAddCategory && !editingCategory)}
            icon={loading ? undefined : Save}
          >
            {loading ? 'Wird gespeichert...' : (editingCategory ? 'Änderungen speichern' : 'Kategorie erstellen')}
          </ModalButton>
        </ModalFooter>
      }
    >
      {!canAddCategory && !editingCategory && (
        <div className="p-5 bg-gradient-to-br from-yellow-500/20 to-orange-500/20 border-2 border-yellow-400/50 rounded-xl mb-6 backdrop-blur-sm animate-in fade-in slide-in-from-top-2">
          <div className="flex items-start gap-4">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] rounded-xl blur-md opacity-60 animate-pulse"></div>
              <div className="relative bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-12 h-12 rounded-xl flex items-center justify-center shadow-gold">
                <Crown className="w-6 h-6 text-white" />
              </div>
            </div>
            <div className="flex-1">
              <h4 className="font-bold text-white mb-2 flex items-center gap-2">
                <Lock className="w-4 h-4 text-[#d4af37]" />
                Limit erreicht
              </h4>
              <p className="text-sm text-white/80 mb-3">
                Im Free-Plan kannst du maximal <span className="font-bold text-white">6 Budget-Kategorien</span> erstellen. Du hast bereits <span className="font-bold text-[#d4af37]">{categoryCount} Kategorien</span> angelegt.
              </p>
              <p className="text-sm font-bold text-[#d4af37]">
                ✨ Upgrade auf Premium für unbegrenzte Kategorien!
              </p>
            </div>
          </div>
        </div>
      )}

      <div className="space-y-6">
        <div>
          <label className="block text-sm font-semibold text-white/90 mb-2">
            Kategorie-Name*
          </label>
          <input
            type="text"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
            placeholder="z.B. Location, Catering, Dekoration"
            disabled={!canAddCategory && !editingCategory}
          />
        </div>

        <div>
          <label className="block text-sm font-semibold text-white/90 mb-2">
            Geplantes Budget (€)
          </label>
          <input
            type="number"
            value={formData.budget_limit}
            onChange={(e) => setFormData({ ...formData, budget_limit: parseFloat(e.target.value) || 0 })}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
            placeholder="0.00"
            step="0.01"
            min="0"
            disabled={!canAddCategory && !editingCategory}
          />
          <p className="text-xs text-white/60 mt-1">
            Das maximale Budget für diese Kategorie
          </p>
        </div>

        <div>
          <label className="block text-sm font-semibold text-white/90 mb-3">
            Farbe wählen
          </label>
          <div className="flex gap-3 flex-wrap">
            {colorOptions.map(color => (
              <button
                key={color}
                type="button"
                onClick={() => setFormData({ ...formData, color })}
                disabled={!canAddCategory && !editingCategory}
                className={`w-12 h-12 rounded-xl transition-all ${
                  formData.color === color
                    ? 'ring-4 ring-offset-2 ring-[#d4af37] ring-offset-[#0a253c] scale-110'
                    : 'hover:scale-110'
                } ${!canAddCategory && !editingCategory ? 'opacity-50 cursor-not-allowed' : ''}`}
                style={{ backgroundColor: color }}
                title={color}
              />
            ))}
          </div>
        </div>

        {error && (
          <div className="p-4 bg-red-500/20 border-2 border-red-400/50 rounded-xl backdrop-blur-sm animate-in fade-in slide-in-from-top-2">
            <p className="text-sm font-semibold text-red-200">⚠️ {error}</p>
          </div>
        )}

        {formData.name && formData.budget_limit > 0 && (canAddCategory || editingCategory) && (
          <div className="p-5 bg-white/10 border-2 border-[#d4af37]/30 rounded-xl backdrop-blur-sm animate-in fade-in zoom-in-95 duration-300">
            <h4 className="text-sm font-semibold text-white/90 mb-4 flex items-center gap-2">
              <Folder className="w-4 h-4 text-[#d4af37]" />
              Vorschau
            </h4>
            <div className="bg-white/5 rounded-xl p-5 border-l-4 backdrop-blur-sm transition-all duration-300 hover:bg-white/10" style={{ borderColor: formData.color }}>
              <div className="flex items-center gap-4">
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center shadow-lg transition-transform hover:scale-105"
                  style={{ backgroundColor: `${formData.color}30` }}
                >
                  <Folder className="w-7 h-7" style={{ color: formData.color }} />
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-white mb-1">{formData.name}</h3>
                  <p className="text-sm text-white/70 flex items-center gap-1">
                    <span className="font-semibold">Budget:</span>
                    <span className="text-[#d4af37] font-bold">{formData.budget_limit.toLocaleString('de-DE')} €</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </StandardModal>
  );
}
