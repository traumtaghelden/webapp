import { useState, useEffect } from 'react';
import { Building2, Filter, DollarSign, FileText, Briefcase, FileCheck, Star, Users } from 'lucide-react';
import { supabase, type Vendor } from '../lib/supabase';
import TabContainer, { type Tab } from './common/TabContainer';
import PageHeaderWithStats, { type StatCard } from './common/PageHeaderWithStats';
import VendorAllTab from './Vendor/VendorAllTab';
import VendorCategoriesTab from './Vendor/VendorCategoriesTab';
import { VENDOR } from '../constants/terminology';

interface VendorManagerProps {
  weddingId: string;
}

export default function VendorManager({ weddingId }: VendorManagerProps) {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    loadVendors();
  }, [weddingId]);

  const loadVendors = async () => {
    try {
      const { data } = await supabase
        .from('vendors')
        .select('*')
        .eq('wedding_id', weddingId)
        .order('created_at', { ascending: false });

      if (data) setVendors(data);
    } catch (error) {
      console.error('Error loading vendors:', error);
    }
  };

  const totalVendors = vendors.length;
  const bookedVendors = vendors.filter(v => v.status === 'booked').length;
  const favorites = vendors.filter(v => v.is_favorite).length;
  const poolVendors = vendors.filter(v => v.status !== 'booked').length;
  const bookingRate = totalVendors > 0 ? Math.round((bookedVendors / totalVendors) * 100) : 0;

  const stats: StatCard[] = [
    {
      icon: <Briefcase className="w-6 h-6 text-white" />,
      label: `Gesamt ${VENDOR.PLURAL}`,
      value: totalVendors,
      subtitle: `${bookingRate}% gebucht`,
      color: 'yellow'
    },
    {
      icon: <FileCheck className="w-6 h-6 text-white" />,
      label: 'Gebucht',
      value: bookedVendors,
      subtitle: totalVendors > 0 ? `${bookingRate}% der ${VENDOR.PLURAL}` : '0%',
      color: 'green'
    },
    {
      icon: <Star className="w-6 h-6 text-white" />,
      label: 'Favoriten',
      value: favorites,
      subtitle: totalVendors > 0 ? `${Math.round((favorites/totalVendors)*100)}% markiert` : '0%',
      color: 'orange'
    },
    {
      icon: <Users className="w-6 h-6 text-white" />,
      label: 'Pool',
      value: poolVendors,
      subtitle: poolVendors > 0 ? 'Verfügbar' : 'Keine verfügbar',
      color: 'blue'
    }
  ];

  const bookedVendorsList = vendors.filter(v => v.contract_status === 'signed' || v.contract_status === 'completed');

  const tabs: Tab[] = [
    {
      id: 'all',
      label: 'Alle',
      icon: <Building2 className="w-4 h-4" />,
      badge: vendors.length,
      content: (
        <VendorAllTab
          weddingId={weddingId}
          vendors={vendors}
          onUpdate={loadVendors}
          onAddVendor={() => setShowAddForm(true)}
        />
      ),
    },
    {
      id: 'categories',
      label: 'Kategorien',
      icon: <Filter className="w-4 h-4" />,
      content: <VendorCategoriesTab vendors={vendors} />,
    },
    {
      id: 'comparison',
      label: 'Vergleich',
      icon: <FileText className="w-4 h-4" />,
      content: (
        <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-2xl p-8 text-center">
          <FileText className="w-20 h-20 text-[#d4af37] mx-auto mb-4" />
          <h4 className="text-2xl font-bold text-white mb-2">Dienstleister-Vergleich</h4>
          <p className="text-white/70 mb-6">
            Vergleiche bis zu 3 {VENDOR.PLURAL} direkt nebeneinander
          </p>
          <div className="inline-block px-6 py-3 bg-[#d4af37]/20 text-[#d4af37] rounded-xl font-bold">
            Premium Feature
          </div>
        </div>
      ),
    },
    {
      id: 'contracts',
      label: 'Verträge',
      icon: <FileText className="w-4 h-4" />,
      badge: bookedVendorsList.length,
      content: (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#0a253c]">Verträge & Dokumente</h3>
          {bookedVendorsList.length > 0 ? (
            <div className="grid gap-4">
              {bookedVendorsList.map(vendor => (
                <div key={vendor.id} className="bg-white rounded-xl p-6 shadow-lg">
                  <h4 className="font-bold text-[#0a253c] mb-2">{vendor.name}</h4>
                  <p className="text-sm text-[#666666]">{vendor.category}</p>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-[#f7f2eb] rounded-2xl">
              <p className="text-[#666666]">Noch keine gebuchten Dienstleister</p>
            </div>
          )}
        </div>
      ),
    },
    {
      id: 'payments',
      label: 'Zahlungen',
      icon: <DollarSign className="w-4 h-4" />,
      content: (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#0a253c]">Zahlungsübersicht</h3>
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <p className="text-[#666666]">Alle Zahlungen an Dienstleister</p>
          </div>
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeaderWithStats
        title={VENDOR.MODULE_NAME}
        subtitle="Verwalte deine Dienstleister"
        stats={stats}
      />

      <TabContainer
        tabs={tabs}
        defaultTab="all"
        storageKey={`vendor-tab-${weddingId}`}
        urlParam="vendorTab"
      />
    </div>
  );
}
