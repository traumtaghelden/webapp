import { Heart, User, Bell, Shield, CreditCard, Database } from 'lucide-react';
import TabContainer, { type Tab } from './common/TabContainer';
import SettingsHochzeitTab from './Settings/SettingsHochzeitTab';
import PrivacySettings from './PrivacySettings';
import DataExport from './DataExport';

interface WeddingSettingsProps {
  weddingId: string;
  onUpdate: () => void;
}

export default function WeddingSettings({ weddingId, onUpdate }: WeddingSettingsProps) {
  const tabs: Tab[] = [
    {
      id: 'hochzeit',
      label: 'Hochzeit',
      icon: <Heart className="w-4 h-4" />,
      content: <SettingsHochzeitTab weddingId={weddingId} onUpdate={onUpdate} />,
    },
    {
      id: 'profil',
      label: 'Profil',
      icon: <User className="w-4 h-4" />,
      content: (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#0a253c]">Profil & Account</h3>
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <p className="text-[#666666]">Partner-Daten und Account-Einstellungen</p>
          </div>
        </div>
      ),
    },
    {
      id: 'benachrichtigungen',
      label: 'Benachrichtigungen',
      icon: <Bell className="w-4 h-4" />,
      content: (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#0a253c]">Benachrichtigungen</h3>
          <div className="bg-white rounded-xl p-6 shadow-lg">
            <p className="text-[#666666]">Notification-Einstellungen verwalten</p>
          </div>
        </div>
      ),
    },
    {
      id: 'datenschutz',
      label: 'Datenschutz',
      icon: <Shield className="w-4 h-4" />,
      content: <PrivacySettings />,
    },
    {
      id: 'abo',
      label: 'Abonnement',
      icon: <CreditCard className="w-4 h-4" />,
      content: (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#0a253c]">Premium-Abonnement</h3>
          <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-2xl p-8 text-center">
            <CreditCard className="w-20 h-20 text-[#d4af37] mx-auto mb-4" />
            <h4 className="text-2xl font-bold text-white mb-2">Premium-Features</h4>
            <p className="text-white/70 mb-6">
              Unbegrenzte Gäste, Aufgaben, Dienstleister und mehr
            </p>
            <button className="px-8 py-4 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all">
              Jetzt upgraden
            </button>
          </div>
        </div>
      ),
    },
    {
      id: 'daten',
      label: 'Daten',
      icon: <Database className="w-4 h-4" />,
      content: (
        <div className="space-y-6">
          <h3 className="text-2xl font-bold text-[#0a253c]">Datenverwaltung</h3>
          <DataExport weddingId={weddingId} />
        </div>
      ),
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold text-[#0a253c]">Einstellungen</h2>
        <p className="text-[#666666] mt-1">Verwalte deine Hochzeitsplanung</p>
      </div>

      <TabContainer
        tabs={tabs}
        defaultTab="hochzeit"
        storageKey={`settings-tab-${weddingId}`}
        urlParam="settingsTab"
      />
    </div>
  );
}
