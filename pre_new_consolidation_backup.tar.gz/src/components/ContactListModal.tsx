import { X, Mail, Phone, MapPin, Plus, Printer, Download, User, Users as UsersIcon } from 'lucide-react';
import { type Guest, type FamilyGroup } from '../lib/supabase';

interface ContactListModalProps {
  guests: Guest[];
  familyGroups: FamilyGroup[];
  onClose: () => void;
  onEditGuest: (guestId: string) => void;
}

export default function ContactListModal({ guests, familyGroups, onClose, onEditGuest }: ContactListModalProps) {
  const handlePrint = () => {
    window.print();
  };

  const handleDownloadPDF = () => {
    window.print();
  };

  const sortedGuests = [...guests].sort((a, b) => {
    if (a.family_group_id && b.family_group_id && a.family_group_id === b.family_group_id) {
      return a.name.localeCompare(b.name);
    }
    if (a.family_group_id && !b.family_group_id) return -1;
    if (!a.family_group_id && b.family_group_id) return 1;
    return a.name.localeCompare(b.name);
  });

  const renderedFamilies = new Set<string>();

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-3xl shadow-2xl w-full max-w-6xl max-h-[90vh] flex flex-col">
        <div className="flex items-center justify-between p-6 border-b border-[#d4af37]/20 print:hidden">
          <div>
            <h2 className="text-2xl font-bold text-[#0a253c]">Kontaktdaten Übersicht</h2>
            <p className="text-sm text-[#666666] mt-1">Alle Gäste mit ihren Kontaktinformationen</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-4 py-2 bg-[#f7f2eb] text-[#0a253c] rounded-xl font-semibold hover:bg-[#d4af37]/20 transition-all"
              title="Drucken"
            >
              <Printer className="w-5 h-5" />
              Drucken
            </button>
            <button
              onClick={handleDownloadPDF}
              className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-[#0a253c] rounded-xl font-semibold hover:bg-[#d4af37]/90 transition-all"
              title="Als PDF speichern"
            >
              <Download className="w-5 h-5" />
              PDF
            </button>
            <button
              onClick={onClose}
              className="p-2 hover:bg-[#f7f2eb] rounded-xl transition-colors"
            >
              <X className="w-6 h-6 text-[#666666]" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="print:block hidden mb-6">
            <h1 className="text-3xl font-bold text-[#0a253c] mb-2">Kontaktdaten Übersicht</h1>
            <p className="text-[#666666]">Hochzeitsplanung - Gästeliste</p>
          </div>

          <div className="space-y-4">
            {sortedGuests.map((guest) => {
              if (guest.family_group_id && !renderedFamilies.has(guest.family_group_id)) {
                renderedFamilies.add(guest.family_group_id);
                const familyGroup = familyGroups.find(f => f.id === guest.family_group_id);
                const familyMembers = guests.filter(g => g.family_group_id === guest.family_group_id);

                // Sammle gemeinsame Kontaktdaten der Familie (nimm das erste Mitglied mit vollständiger Adresse)
                const familyContact = familyMembers.find(m => m.address) || familyMembers[0];
                const hasFamilyAddress = familyContact?.address;
                const familyEmails = familyMembers.filter(m => m.email).map(m => ({ name: m.name, email: m.email }));
                const familyPhones = familyMembers.filter(m => m.phone).map(m => ({ name: m.name, phone: m.phone }));
                const anyContactData = hasFamilyAddress || familyEmails.length > 0 || familyPhones.length > 0;

                return (
                  <div key={`family-${guest.family_group_id}`} className="border-2 border-[#d4af37] rounded-2xl p-5 bg-gradient-to-r from-[#f7f2eb]/50 to-white print:border print:border-[#d4af37] print:break-inside-avoid">
                    <div className="flex items-center gap-3 mb-4 pb-3 border-b border-[#d4af37]/30">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex items-center justify-center">
                        <UsersIcon className="w-6 h-6 text-white" />
                      </div>
                      <div>
                        <h3 className="text-xl font-bold text-[#0a253c]">{familyGroup?.family_name || 'Familie'}</h3>
                        <p className="text-sm text-[#666666]">{familyMembers.length} {familyMembers.length === 1 ? 'Person' : 'Personen'}</p>
                      </div>
                    </div>

                    {/* Familienmitglieder Namen */}
                    <div className="mb-4 bg-white rounded-xl p-4 border border-[#d4af37]/20">
                      <h4 className="font-semibold text-[#0a253c] mb-2 text-sm">Familienmitglieder:</h4>
                      <div className="flex flex-wrap gap-2">
                        {familyMembers.map((member) => (
                          <div key={member.id} className="flex items-center gap-2 px-3 py-1.5 bg-[#f7f2eb] rounded-lg">
                            <div className="w-6 h-6 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex items-center justify-center text-white font-bold text-xs flex-shrink-0">
                              {member.name.charAt(0).toUpperCase()}
                            </div>
                            <span className="text-sm text-[#0a253c] font-medium">{member.name}</span>
                            {member.age_group !== 'adult' && (
                              <span className="px-1.5 py-0.5 bg-purple-100 text-purple-700 text-xs rounded font-semibold">
                                {member.age_group === 'child' ? 'K' : 'Kl'}
                              </span>
                            )}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Gemeinsame Kontaktdaten */}
                    {anyContactData ? (
                      <div className="bg-white rounded-xl p-4 border border-[#d4af37]/20 space-y-3">
                        <h4 className="font-semibold text-[#0a253c] mb-3 text-sm">Kontaktdaten:</h4>

                        {familyEmails.length > 0 && (
                          <div className="space-y-2">
                            {familyEmails.map((contact, idx) => (
                              <div key={idx} className="flex items-center gap-2 text-sm text-[#666666]">
                                <Mail className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
                                <span className="font-medium text-[#0a253c] min-w-[100px]">{contact.name}:</span>
                                <a href={`mailto:${contact.email}`} className="hover:text-[#d4af37] transition-colors break-all print:text-black">
                                  {contact.email}
                                </a>
                              </div>
                            ))}
                          </div>
                        )}

                        {familyPhones.length > 0 && (
                          <div className="space-y-2">
                            {familyPhones.map((contact, idx) => (
                              <div key={idx} className="flex items-center gap-2 text-sm text-[#666666]">
                                <Phone className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
                                <span className="font-medium text-[#0a253c] min-w-[100px]">{contact.name}:</span>
                                <a href={`tel:${contact.phone}`} className="hover:text-[#d4af37] transition-colors print:text-black">
                                  {contact.phone}
                                </a>
                              </div>
                            ))}
                          </div>
                        )}

                        {hasFamilyAddress && (
                          <div className="flex items-start gap-2 text-sm text-[#666666] pt-2 border-t border-[#d4af37]/20">
                            <MapPin className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
                            <div className="print:text-black">
                              <p className="font-medium text-[#0a253c] mb-1">Adresse:</p>
                              <p>{familyContact.address}</p>
                              {(familyContact.postal_code || familyContact.city) && (
                                <p>{familyContact.postal_code} {familyContact.city}</p>
                              )}
                              {familyContact.country && <p>{familyContact.country}</p>}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="bg-white rounded-xl p-4 border border-[#d4af37]/20 print:hidden">
                        <button
                          onClick={() => {
                            onEditGuest(familyMembers[0].id);
                            onClose();
                          }}
                          className="flex items-center gap-2 px-4 py-2 bg-[#d4af37]/10 text-[#d4af37] rounded-xl font-semibold hover:bg-[#d4af37]/20 transition-all"
                        >
                          <Plus className="w-4 h-4" />
                          Kontaktdaten für Familie hinzufügen
                        </button>
                      </div>
                    )}
                  </div>
                );
              } else if (!guest.family_group_id) {
                const hasContact = guest.email || guest.phone || guest.address;

                return (
                  <div key={guest.id} className="border border-[#d4af37]/30 rounded-2xl p-5 bg-white hover:border-[#d4af37] transition-all print:border print:border-gray-300 print:break-inside-avoid">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex items-start gap-3 flex-1">
                        <div className="w-12 h-12 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex items-center justify-center text-white font-bold text-lg flex-shrink-0">
                          {guest.name.charAt(0).toUpperCase()}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-3">
                            <h3 className="text-lg font-bold text-[#0a253c]">{guest.name}</h3>
                            {guest.age_group !== 'adult' && (
                              <span className="px-2 py-0.5 bg-purple-100 text-purple-700 text-xs rounded-full font-semibold">
                                {guest.age_group === 'child' ? 'Kind' : 'Kleinkind'}
                              </span>
                            )}
                          </div>

                          {hasContact ? (
                            <div className="space-y-2 text-sm">
                              {guest.email && (
                                <div className="flex items-center gap-2 text-[#666666]">
                                  <Mail className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
                                  <a href={`mailto:${guest.email}`} className="hover:text-[#d4af37] transition-colors break-all print:text-black">
                                    {guest.email}
                                  </a>
                                </div>
                              )}
                              {guest.phone && (
                                <div className="flex items-center gap-2 text-[#666666]">
                                  <Phone className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
                                  <a href={`tel:${guest.phone}`} className="hover:text-[#d4af37] transition-colors print:text-black">
                                    {guest.phone}
                                  </a>
                                </div>
                              )}
                              {guest.address && (
                                <div className="flex items-start gap-2 text-[#666666]">
                                  <MapPin className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
                                  <div className="print:text-black">
                                    <p>{guest.address}</p>
                                    {(guest.postal_code || guest.city) && (
                                      <p>{guest.postal_code} {guest.city}</p>
                                    )}
                                    {guest.country && <p>{guest.country}</p>}
                                  </div>
                                </div>
                              )}
                            </div>
                          ) : (
                            <div className="print:hidden">
                              <button
                                onClick={() => {
                                  onEditGuest(guest.id);
                                  onClose();
                                }}
                                className="flex items-center gap-2 px-4 py-2 bg-[#d4af37]/10 text-[#d4af37] rounded-xl font-semibold hover:bg-[#d4af37]/20 transition-all"
                              >
                                <Plus className="w-4 h-4" />
                                Kontaktdaten hinzufügen
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  </div>
                );
              }
              return null;
            })}
          </div>
        </div>

        <div className="p-6 border-t border-[#d4af37]/20 bg-[#f7f2eb]/30 print:hidden">
          <div className="flex items-center justify-between">
            <p className="text-sm text-[#666666]">
              Gesamt: <span className="font-semibold text-[#0a253c]">{guests.length}</span> {guests.length === 1 ? 'Gast' : 'Gäste'}
            </p>
            <button
              onClick={onClose}
              className="px-6 py-2 bg-[#0a253c] text-white rounded-xl font-semibold hover:bg-[#0a253c]/90 transition-all"
            >
              Schließen
            </button>
          </div>
        </div>
      </div>

      <style>{`
        @media print {
          body * {
            visibility: hidden;
          }
          .fixed.inset-0 {
            position: static !important;
          }
          .fixed.inset-0, .fixed.inset-0 * {
            visibility: visible;
          }
          .print\\:hidden {
            display: none !important;
          }
          .print\\:block {
            display: block !important;
          }
          .bg-white {
            background-color: white !important;
          }
          .max-h-\\[90vh\\] {
            max-height: none !important;
          }
          .overflow-y-auto {
            overflow: visible !important;
          }
          .rounded-3xl {
            border-radius: 0 !important;
          }
          .shadow-2xl {
            box-shadow: none !important;
          }
        }
      `}</style>
    </div>
  );
}
