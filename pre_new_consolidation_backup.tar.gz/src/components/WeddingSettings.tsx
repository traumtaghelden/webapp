import { useState, useEffect } from 'react';
import { Save, X, ChevronLeft, ChevronRight } from 'lucide-react';
import { supabase, type Wedding, type WeddingTeamRole } from '../lib/supabase';
import CharacterSelector from './CharacterSelector';
import DataExport from './DataExport';
import { COMMON } from '../constants/terminology';

interface WeddingSettingsProps {
  weddingId: string;
  onUpdate: () => void;
}

export default function WeddingSettings({ weddingId, onUpdate }: WeddingSettingsProps) {
  const [wedding, setWedding] = useState<Wedding | null>(null);
  const [teamRoles, setTeamRoles] = useState<WeddingTeamRole[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');

  const witnessCharacters = [
    { id: 'trauzeuge', image: '/Trauzeuge.png', label: 'Trauzeuge' },
    { id: 'trauzeugin', image: '/Trauzeugin.png', label: 'Trauzeugin' },
  ];

  const parentCharacters = [
    { id: 'eltern1', image: '/Eltern Avatar 1.png', label: 'Eltern Avatar 1' },
    { id: 'eltern2', image: '/Eltern Avatar 2.png', label: 'Eltern Avatar 2' },
  ];

  const helperCharacters = [
    { id: 'helfer1', image: '/Helfer female 1.png', label: 'Helfer female' },
    { id: 'helfer2', image: '/Helfer Male 2.png', label: 'Helfer Male' },
  ];

  const [formData, setFormData] = useState({
    partner1Name: '',
    partner2Name: '',
    partner1Age: '',
    partner2Age: '',
    partner1HeroType: 'hero1',
    partner2HeroType: 'hero2',
    weddingDate: '',
    guestCount: '',
    ceremonyType: 'traditional',
    budget: '',
    witness1Name: '',
    witness2Name: '',
    parent1Name: '',
    parent2Name: '',
    helper1Name: '',
    helper2Name: '',
    witness1Character: 'trauzeuge',
    witness2Character: 'trauzeugin',
    parent1Character: 'eltern1',
    parent2Character: 'eltern2',
    helper1Character: 'helfer1',
    helper2Character: 'helfer2',
  });

  useEffect(() => {
    loadData();
  }, [weddingId]);

  const loadData = async () => {
    try {
      const [weddingData, teamData] = await Promise.all([
        supabase.from('weddings').select('*').eq('id', weddingId).maybeSingle(),
        supabase.from('wedding_team_roles').select('*').eq('wedding_id', weddingId),
      ]);

      if (weddingData.data) {
        setWedding(weddingData.data);
        setFormData({
          partner1Name: weddingData.data.partner_1_name,
          partner2Name: weddingData.data.partner_2_name,
          partner1Age: weddingData.data.partner_1_age?.toString() || '',
          partner2Age: weddingData.data.partner_2_age?.toString() || '',
          partner1HeroType: weddingData.data.partner_1_hero_type || 'hero1',
          partner2HeroType: weddingData.data.partner_2_hero_type || 'hero2',
          weddingDate: weddingData.data.wedding_date,
          guestCount: weddingData.data.guest_count.toString(),
          ceremonyType: weddingData.data.ceremony_type,
          budget: weddingData.data.total_budget.toString(),
          witness1Name: '',
          witness2Name: '',
          parent1Name: '',
          parent2Name: '',
          helper1Name: '',
          helper2Name: '',
          witness1Character: 'trauzeuge',
          witness2Character: 'trauzeugin',
          parent1Character: 'eltern1',
          parent2Character: 'eltern2',
          helper1Character: 'helfer1',
          helper2Character: 'helfer2',
        });
      }

      if (teamData.data) {
        setTeamRoles(teamData.data);
        teamData.data.forEach((role) => {
          if (role.role === 'trauzeuge' && role.partner_assignment === 'partner_1') {
            setFormData((prev) => ({ ...prev, witness1Name: role.name }));
          } else if (role.role === 'trauzeuge' && role.partner_assignment === 'partner_2') {
            setFormData((prev) => ({ ...prev, witness2Name: role.name }));
          } else if (role.role === 'eltern' && role.partner_assignment === 'partner_1') {
            setFormData((prev) => ({ ...prev, parent1Name: role.name }));
          } else if (role.role === 'eltern' && role.partner_assignment === 'partner_2') {
            setFormData((prev) => ({ ...prev, parent2Name: role.name }));
          } else if (role.role === 'helfer' && role.partner_assignment === 'partner_1') {
            setFormData((prev) => ({ ...prev, helper1Name: role.name }));
          } else if (role.role === 'helfer' && role.partner_assignment === 'partner_2') {
            setFormData((prev) => ({ ...prev, helper2Name: role.name }));
          }
        });
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);

      const { error: weddingError } = await supabase
        .from('weddings')
        .update({
          partner_1_name: formData.partner1Name,
          partner_2_name: formData.partner2Name,
          partner_1_age: formData.partner1Age ? parseInt(formData.partner1Age) : null,
          partner_2_age: formData.partner2Age ? parseInt(formData.partner2Age) : null,
          partner_1_hero_type: formData.partner1HeroType,
          partner_2_hero_type: formData.partner2HeroType,
          wedding_date: formData.weddingDate,
          guest_count: parseInt(formData.guestCount) || 0,
          ceremony_type: formData.ceremonyType,
          total_budget: parseFloat(formData.budget) || 0,
          updated_at: new Date().toISOString(),
        })
        .eq('id', weddingId);

      if (weddingError) throw weddingError;

      await supabase.from('wedding_team_roles').delete().eq('wedding_id', weddingId);

      const teamRolesData = [
        { name: formData.witness1Name, role: 'trauzeuge', partner: 'partner_1' },
        { name: formData.witness2Name, role: 'trauzeuge', partner: 'partner_2' },
        { name: formData.parent1Name, role: 'eltern', partner: 'partner_1' },
        { name: formData.parent2Name, role: 'eltern', partner: 'partner_2' },
        { name: formData.helper1Name, role: 'helfer', partner: 'partner_1' },
        { name: formData.helper2Name, role: 'helfer', partner: 'partner_2' },
      ].filter((role) => role.name.trim() !== '');

      if (teamRolesData.length > 0) {
        const teamRoleInserts = teamRolesData.map((role) => ({
          wedding_id: weddingId,
          name: role.name.trim(),
          role: role.role,
          partner_assignment: role.partner,
        }));

        const { error: teamError } = await supabase
          .from('wedding_team_roles')
          .insert(teamRoleInserts);

        if (teamError) throw teamError;
      }

      const { error: profileError } = await supabase
        .from('user_profiles')
        .update({
          event_name: `${formData.partner1Name} & ${formData.partner2Name}`,
          event_date: formData.weddingDate,
          event_type: formData.ceremonyType,
          updated_at: new Date().toISOString(),
        })
        .eq('id', (await supabase.auth.getUser()).data.user?.id);

      if (profileError) throw profileError;

      setSuccessMessage('Änderungen erfolgreich gespeichert!');
      setTimeout(() => setSuccessMessage(''), 3000);
      onUpdate();
    } catch (error) {
      console.error('Error saving changes:', error);
      alert('Fehler beim Speichern der Änderungen');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <p className="text-[#333333]">Lädt Einstellungen...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold text-[#0a253c]">Hochzeitsdetails bearbeiten</h2>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 transition-all transform hover:scale-105"
        >
          <Save className="w-5 h-5" />
          {saving ? 'Speichert...' : 'Speichern'}
        </button>
      </div>

      {successMessage && (
        <div className="bg-green-100 border-2 border-green-500 rounded-xl p-4 text-green-700 font-semibold text-center">
          {successMessage}
        </div>
      )}

      <div className="bg-white rounded-2xl p-8 shadow-lg space-y-8">
        <div>
          <h3 className="text-2xl font-bold text-[#0a253c] mb-6">Partner-Informationen</h3>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-[#0a253c] mb-4">Partner 1</h4>

              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <button
                    type="button"
                    onClick={() => {
                      const heroes = ['hero1', 'hero2'];
                      const currentIndex = heroes.indexOf(formData.partner1HeroType);
                      const newIndex = currentIndex > 0 ? currentIndex - 1 : heroes.length - 1;
                      setFormData({ ...formData, partner1HeroType: heroes[newIndex] });
                    }}
                    className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all"
                  >
                    <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
                  </button>
                  <div className="p-4 rounded-2xl bg-gradient-to-b from-[#f7f2eb] to-white">
                    <img
                      src={formData.partner1HeroType === 'hero1' ? '/Design ohne Titel (10).png' : '/Design ohne Titel (11).png'}
                      alt="Partner 1 Held"
                      className="w-32 h-32 object-contain mx-auto"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const heroes = ['hero1', 'hero2'];
                      const currentIndex = heroes.indexOf(formData.partner1HeroType);
                      const newIndex = (currentIndex + 1) % heroes.length;
                      setFormData({ ...formData, partner1HeroType: heroes[newIndex] });
                    }}
                    className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all"
                  >
                    <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                <input
                  type="text"
                  value={formData.partner1Name}
                  onChange={(e) => setFormData({ ...formData, partner1Name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Alter</label>
                <input
                  type="number"
                  value={formData.partner1Age}
                  onChange={(e) => setFormData({ ...formData, partner1Age: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  min="18"
                  max="120"
                />
              </div>
            </div>

            <div className="space-y-4">
              <h4 className="text-lg font-semibold text-[#0a253c] mb-4">Partner 2</h4>

              <div className="relative">
                <div className="flex items-center justify-between mb-3">
                  <button
                    type="button"
                    onClick={() => {
                      const heroes = ['hero1', 'hero2'];
                      const currentIndex = heroes.indexOf(formData.partner2HeroType);
                      const newIndex = currentIndex > 0 ? currentIndex - 1 : heroes.length - 1;
                      setFormData({ ...formData, partner2HeroType: heroes[newIndex] });
                    }}
                    className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all"
                  >
                    <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
                  </button>
                  <div className="p-4 rounded-2xl bg-gradient-to-b from-[#f7f2eb] to-white">
                    <img
                      src={formData.partner2HeroType === 'hero1' ? '/Design ohne Titel (10).png' : '/Design ohne Titel (11).png'}
                      alt="Partner 2 Held"
                      className="w-32 h-32 object-contain mx-auto"
                    />
                  </div>
                  <button
                    type="button"
                    onClick={() => {
                      const heroes = ['hero1', 'hero2'];
                      const currentIndex = heroes.indexOf(formData.partner2HeroType);
                      const newIndex = (currentIndex + 1) % heroes.length;
                      setFormData({ ...formData, partner2HeroType: heroes[newIndex] });
                    }}
                    className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all"
                  >
                    <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                <input
                  type="text"
                  value={formData.partner2Name}
                  onChange={(e) => setFormData({ ...formData, partner2Name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Alter</label>
                <input
                  type="number"
                  value={formData.partner2Age}
                  onChange={(e) => setFormData({ ...formData, partner2Age: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  min="18"
                  max="120"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="border-t-2 border-[#f7f2eb] pt-8">
          <h3 className="text-2xl font-bold text-[#0a253c] mb-6">Hochzeitsdetails</h3>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Hochzeitsdatum*</label>
              <input
                type="date"
                value={formData.weddingDate}
                onChange={(e) => setFormData({ ...formData, weddingDate: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Art der Trauung*</label>
              <select
                value={formData.ceremonyType}
                onChange={(e) => setFormData({ ...formData, ceremonyType: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
              >
                <option value="traditional">Traditionell</option>
                <option value="civil">Standesamtlich</option>
                <option value="religious">Kirchlich</option>
                <option value="outdoor">Im Freien</option>
                <option value="destination">Destination Wedding</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Gästezahl*</label>
              <input
                type="number"
                value={formData.guestCount}
                onChange={(e) => setFormData({ ...formData, guestCount: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                min="1"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Gesamtbudget (€)*</label>
              <input
                type="number"
                value={formData.budget}
                onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                min="0"
              />
            </div>
          </div>
        </div>

        <div className="border-t-2 border-[#f7f2eb] pt-8">
          <h3 className="text-2xl font-bold text-[#0a253c] mb-6">Euer Heldenteam</h3>
          <div className="space-y-6">
            <div className="bg-gradient-to-b from-[#0a253c] to-[#1a3a5c] rounded-2xl p-6">
              <h4 className="text-xl font-bold text-[#d4af37] mb-4 text-center">Trauzeugen</h4>
              <div className="grid md:grid-cols-2 gap-6">
                <CharacterSelector
                  characters={witnessCharacters}
                  selectedCharacterId={formData.witness1Character}
                  onSelect={(id) => setFormData({ ...formData, witness1Character: id })}
                  label={`Trauzeuge/in von ${formData.partner1Name || 'Partner 1'}`}
                  name={formData.witness1Name}
                  onNameChange={(name) => setFormData({ ...formData, witness1Name: name })}
                />
                <CharacterSelector
                  characters={witnessCharacters}
                  selectedCharacterId={formData.witness2Character}
                  onSelect={(id) => setFormData({ ...formData, witness2Character: id })}
                  label={`Trauzeuge/in von ${formData.partner2Name || 'Partner 2'}`}
                  name={formData.witness2Name}
                  onNameChange={(name) => setFormData({ ...formData, witness2Name: name })}
                />
              </div>
            </div>

            <div className="bg-gradient-to-b from-[#0a253c] to-[#1a3a5c] rounded-2xl p-6">
              <h4 className="text-xl font-bold text-[#d4af37] mb-4 text-center">Eltern</h4>
              <div className="grid md:grid-cols-2 gap-6">
                <CharacterSelector
                  characters={parentCharacters}
                  selectedCharacterId={formData.parent1Character}
                  onSelect={(id) => setFormData({ ...formData, parent1Character: id })}
                  label={`Eltern von ${formData.partner1Name || 'Partner 1'}`}
                  name={formData.parent1Name}
                  onNameChange={(name) => setFormData({ ...formData, parent1Name: name })}
                />
                <CharacterSelector
                  characters={parentCharacters}
                  selectedCharacterId={formData.parent2Character}
                  onSelect={(id) => setFormData({ ...formData, parent2Character: id })}
                  label={`Eltern von ${formData.partner2Name || 'Partner 2'}`}
                  name={formData.parent2Name}
                  onNameChange={(name) => setFormData({ ...formData, parent2Name: name })}
                />
              </div>
            </div>

            <div className="bg-gradient-to-b from-[#0a253c] to-[#1a3a5c] rounded-2xl p-6">
              <h4 className="text-xl font-bold text-[#d4af37] mb-4 text-center">Helfer</h4>
              <div className="grid md:grid-cols-2 gap-6">
                <CharacterSelector
                  characters={helperCharacters}
                  selectedCharacterId={formData.helper1Character}
                  onSelect={(id) => setFormData({ ...formData, helper1Character: id })}
                  label={`Helfer/in von ${formData.partner1Name || 'Partner 1'}`}
                  name={formData.helper1Name}
                  onNameChange={(name) => setFormData({ ...formData, helper1Name: name })}
                />
                <CharacterSelector
                  characters={helperCharacters}
                  selectedCharacterId={formData.helper2Character}
                  onSelect={(id) => setFormData({ ...formData, helper2Character: id })}
                  label={`Helfer/in von ${formData.partner2Name || 'Partner 2'}`}
                  name={formData.helper2Name}
                  onNameChange={(name) => setFormData({ ...formData, helper2Name: name })}
                />
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="flex justify-end">
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-8 py-4 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 transition-all transform hover:scale-105"
        >
          <Save className="w-5 h-5" />
          {saving ? 'Speichert...' : 'Alle Änderungen speichern'}
        </button>
      </div>

      <div className="mt-12 pt-12 border-t-2 border-[#d4af37]/20">
        <DataExport weddingId={weddingId} />
      </div>
    </div>
  );
}
