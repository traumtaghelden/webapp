import { useState, useEffect } from 'react';
import { Folder, TrendingUp, TrendingDown, DollarSign, Edit2, AlertTriangle, CheckCircle, Package } from 'lucide-react';
import { supabase, type BudgetItem, type BudgetCategory } from '../lib/supabase';
import { BUDGET, COMMON } from '../constants/terminology';
import StandardModal, { ModalFooter, ModalButton } from './StandardModal';

interface BudgetCategoryDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  categoryId: string;
  weddingId: string;
  onUpdate: () => void;
  onEditCategory: (category: BudgetCategory) => void;
}

export default function BudgetCategoryDetailModal({
  isOpen,
  onClose,
  categoryId,
  weddingId,
  onUpdate,
  onEditCategory,
}: BudgetCategoryDetailModalProps) {
  const [category, setCategory] = useState<BudgetCategory | null>(null);
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (isOpen && categoryId) {
      loadCategoryDetails();
    }
  }, [isOpen, categoryId]);

  const loadCategoryDetails = async () => {
    setLoading(true);
    try {
      const { data: categoryData } = await supabase
        .from('budget_categories')
        .select('*')
        .eq('id', categoryId)
        .single();

      if (categoryData) {
        setCategory(categoryData);

        const { data: itemsData } = await supabase
          .from('budget_items')
          .select('*')
          .eq('wedding_id', weddingId)
          .ilike('category', categoryData.name);

        if (itemsData) {
          setBudgetItems(itemsData);
        }
      }
    } catch (error) {
      console.error('Error loading category details:', error);
    } finally {
      setLoading(false);
    }
  };

  if (!category) return null;

  const totalPlanned = category.budget_limit;
  const totalEstimated = budgetItems.reduce((sum, item) => sum + (item.estimated_cost || 0), 0);
  const totalSpent = budgetItems.reduce((sum, item) => sum + (item.actual_cost || 0), 0);
  const remaining = totalPlanned - totalSpent;
  const percentage = totalPlanned > 0 ? (totalSpent / totalPlanned) * 100 : 0;
  const isOverBudget = totalSpent > totalPlanned;
  const isNearLimit = percentage >= 80 && percentage < 100;

  const paidItems = budgetItems.filter(item => item.payment_status === 'paid');
  const pendingItems = budgetItems.filter(item => item.payment_status === 'pending');
  const overdueItems = budgetItems.filter(item => item.payment_status === 'overdue');

  return (
    <StandardModal
      isOpen={isOpen}
      onClose={onClose}
      title={category.name}
      subtitle="Kategorie-Details und Budget-Übersicht"
      icon={Folder}
      maxWidth="4xl"
      footer={
        <ModalFooter>
          <ModalButton variant="secondary" onClick={onClose}>
            Schließen
          </ModalButton>
          <ModalButton
            variant="primary"
            onClick={() => {
              onEditCategory(category);
              onClose();
            }}
            icon={Edit2}
          >
            Kategorie bearbeiten
          </ModalButton>
        </ModalFooter>
      }
    >

        {loading ? (
          <div className="flex items-center justify-center p-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#d4af37]"></div>
          </div>
        ) : (
          <div>
            <div className="space-y-6">
              {/* Status Banner */}
              {isOverBudget && (
                <div className="p-5 bg-red-500/20 border-2 border-red-400/50 rounded-xl flex items-start gap-3 backdrop-blur-sm animate-in fade-in slide-in-from-top-2">
                  <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0" />
                  <div>
                    <h4 className="font-bold text-white mb-1">Budget überschritten!</h4>
                    <p className="text-sm text-red-200">
                      Diese Kategorie hat ihr geplantes Budget um{' '}
                      <span className="font-bold text-white">{Math.abs(remaining).toLocaleString('de-DE')} €</span> ({(percentage - 100).toFixed(1)}%) überschritten.
                    </p>
                  </div>
                </div>
              )}

              {isNearLimit && !isOverBudget && (
                <div className="p-5 bg-yellow-500/20 border-2 border-yellow-400/50 rounded-xl flex items-start gap-3 backdrop-blur-sm animate-in fade-in slide-in-from-top-2">
                  <AlertTriangle className="w-6 h-6 text-yellow-400 flex-shrink-0" />
                  <div>
                    <h4 className="font-bold text-white mb-1">Budget fast erreicht</h4>
                    <p className="text-sm text-yellow-200">
                      Noch <span className="font-bold text-white">{remaining.toLocaleString('de-DE')} €</span> verfügbar ({(100 - percentage).toFixed(1)}% des Budgets).
                    </p>
                  </div>
                </div>
              )}

              {/* Budget Übersicht */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-white/10 p-5 rounded-xl border-2 border-[#d4af37]/30 backdrop-blur-sm hover:border-[#d4af37]/50 transition-all">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="p-2 bg-[#d4af37]/20 rounded-lg">
                      <DollarSign className="w-4 h-4 text-[#d4af37]" />
                    </div>
                    <span className="text-xs font-semibold text-white/70 uppercase tracking-wide">Geplant</span>
                  </div>
                  <p className="text-2xl font-bold text-white">
                    {totalPlanned.toLocaleString('de-DE')} €
                  </p>
                </div>

                <div className={`p-5 rounded-xl border-2 backdrop-blur-sm hover:border-opacity-70 transition-all ${
                  isOverBudget
                    ? 'bg-red-500/20 border-red-400/50'
                    : 'bg-blue-500/20 border-blue-400/50'
                }`}>
                  <div className="flex items-center gap-2 mb-3">
                    <div className={`p-2 rounded-lg ${
                      isOverBudget ? 'bg-red-500/20' : 'bg-blue-500/20'
                    }`}>
                      {isOverBudget ? (
                        <TrendingDown className="w-4 h-4 text-red-400" />
                      ) : (
                        <TrendingUp className="w-4 h-4 text-blue-400" />
                      )}
                    </div>
                    <span className="text-xs font-semibold text-white/70 uppercase tracking-wide">Tatsächlich</span>
                  </div>
                  <p className={`text-2xl font-bold ${isOverBudget ? 'text-red-400' : 'text-blue-400'}`}>
                    {totalSpent.toLocaleString('de-DE')} €
                  </p>
                </div>

                <div className={`p-5 rounded-xl border-2 backdrop-blur-sm hover:border-opacity-70 transition-all ${
                  remaining >= 0
                    ? 'bg-green-500/20 border-green-400/50'
                    : 'bg-red-500/20 border-red-400/50'
                }`}>
                  <div className="flex items-center gap-2 mb-3">
                    <div className={`p-2 rounded-lg ${
                      remaining >= 0 ? 'bg-green-500/20' : 'bg-red-500/20'
                    }`}>
                      {remaining >= 0 ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : (
                        <AlertTriangle className="w-4 h-4 text-red-400" />
                      )}
                    </div>
                    <span className="text-xs font-semibold text-white/70 uppercase tracking-wide">
                      {remaining >= 0 ? 'Verbleibend' : 'Überschritten'}
                    </span>
                  </div>
                  <p className={`text-2xl font-bold ${remaining >= 0 ? 'text-green-400' : 'text-red-400'}`}>
                    {Math.abs(remaining).toLocaleString('de-DE')} €
                  </p>
                </div>

                <div className="bg-white/10 p-5 rounded-xl border-2 border-purple-400/50 backdrop-blur-sm hover:border-purple-400/70 transition-all">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="p-2 bg-purple-500/20 rounded-lg">
                      <Package className="w-4 h-4 text-purple-400" />
                    </div>
                    <span className="text-xs font-semibold text-white/70 uppercase tracking-wide">Einträge</span>
                  </div>
                  <p className="text-2xl font-bold text-purple-400">
                    {budgetItems.length}
                  </p>
                </div>
              </div>

              {/* Fortschrittsbalken */}
              <div className="p-5 bg-white/10 rounded-xl border-2 border-[#d4af37]/30 backdrop-blur-sm">
                <div className="flex justify-between items-center mb-3">
                  <span className="text-sm font-semibold text-white/70">Budget-Auslastung</span>
                  <span className={`text-2xl font-bold ${
                    isOverBudget ? 'text-red-400' : isNearLimit ? 'text-yellow-400' : 'text-green-400'
                  }`}>
                    {percentage.toFixed(1)}%
                  </span>
                </div>
                <div className="h-3 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className={`h-full transition-all duration-500 ${
                      isOverBudget
                        ? 'bg-red-500'
                        : isNearLimit
                        ? 'bg-yellow-500'
                        : 'bg-green-500'
                    }`}
                    style={{ width: `${Math.min(percentage, 100)}%` }}
                  />
                </div>
              </div>

              {/* Zahlungsstatus */}
              <div>
                <h3 className="text-lg font-bold text-white mb-4">Zahlungsstatus</h3>
                <div className="grid grid-cols-3 gap-3">
                  <div className="bg-green-500/20 p-4 rounded-xl border-2 border-green-400/50 backdrop-blur-sm hover:border-green-400/70 transition-all">
                    <p className="text-sm text-green-200 mb-2 font-semibold">Bezahlt</p>
                    <p className="text-3xl font-bold text-green-400">{paidItems.length}</p>
                  </div>
                  <div className="bg-yellow-500/20 p-4 rounded-xl border-2 border-yellow-400/50 backdrop-blur-sm hover:border-yellow-400/70 transition-all">
                    <p className="text-sm text-yellow-200 mb-2 font-semibold">Ausstehend</p>
                    <p className="text-3xl font-bold text-yellow-400">{pendingItems.length}</p>
                  </div>
                  <div className="bg-red-500/20 p-4 rounded-xl border-2 border-red-400/50 backdrop-blur-sm hover:border-red-400/70 transition-all">
                    <p className="text-sm text-red-200 mb-2 font-semibold">Überfällig</p>
                    <p className="text-3xl font-bold text-red-400">{overdueItems.length}</p>
                  </div>
                </div>
              </div>

              {/* Budget-Einträge Liste */}
              <div>
                <h3 className="text-lg font-bold text-white mb-4">Budget-Einträge ({budgetItems.length})</h3>
                {budgetItems.length > 0 ? (
                  <div className="space-y-3">
                    {budgetItems.map((item) => (
                      <div
                        key={item.id}
                        className="p-4 bg-white/10 border-2 border-[#d4af37]/30 rounded-xl hover:border-[#d4af37]/60 transition-all backdrop-blur-sm group"
                      >
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <h4 className="font-semibold text-white mb-2">{item.item_name}</h4>
                            <div className="flex flex-wrap gap-4 text-sm">
                              <span className="text-white/70">
                                Geplant: <span className="font-semibold text-yellow-400">
                                  {item.estimated_cost.toLocaleString('de-DE')} €
                                </span>
                              </span>
                              <span className="text-white/70">
                                Tatsächlich: <span className="font-semibold text-blue-400">
                                  {item.actual_cost.toLocaleString('de-DE')} €
                                </span>
                              </span>
                              <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                                item.payment_status === 'paid' ? 'bg-green-500/30 text-green-300' :
                                item.payment_status === 'overdue' ? 'bg-red-500/30 text-red-300' :
                                'bg-yellow-500/30 text-yellow-300'
                              }`}>
                                {item.payment_status === 'paid' ? '✓ Bezahlt' :
                                 item.payment_status === 'overdue' ? '⚠ Überfällig' :
                                 '○ Ausstehend'}
                              </span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12">
                    <Folder className="w-16 h-16 mx-auto mb-4 text-white/30" />
                    <p className="text-white/70">Noch keine Einträge in dieser Kategorie</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
    </StandardModal>
  );
}
