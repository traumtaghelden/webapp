import { useState, useEffect } from 'react';
import { Heart, Sparkles } from 'lucide-react';

interface OnboardingIntroProps {
  onComplete: () => void;
}

export default function OnboardingIntro({ onComplete }: OnboardingIntroProps) {
  const [currentPhase, setCurrentPhase] = useState(0);
  const [showSkip, setShowSkip] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => setShowSkip(true), 2000);
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const phases = [0, 1, 2, 3];
    if (currentPhase < phases.length - 1) {
      const timer = setTimeout(() => {
        setCurrentPhase(currentPhase + 1);
      }, 2000);
      return () => clearTimeout(timer);
    } else {
      const finalTimer = setTimeout(onComplete, 2000);
      return () => clearTimeout(finalTimer);
    }
  }, [currentPhase, onComplete]);

  const narrativeTexts = [
    {
      title: "Eure Geschichte beginnt...",
      subtitle: "Jede große Liebe verdient eine legendäre Feier"
    },
    {
      title: "Die Heldenreise wartet",
      subtitle: "Von der Vision zur perfekten Hochzeit"
    },
    {
      title: "Gemeinsam stark",
      subtitle: "Plant zusammen, feiert zusammen"
    },
    {
      title: "Lasst uns beginnen",
      subtitle: "Eure Traumhochzeit nimmt Gestalt an"
    }
  ];

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center overflow-hidden">
      <video
        autoPlay
        loop
        muted
        playsInline
        className="absolute inset-0 w-full h-full object-cover"
      >
        <source src="https://res.cloudinary.com/dvaha0i6v/video/upload/v1761904441/background_loading_screen_ugj7se.mp4" type="video/mp4" />
      </video>

      <div className="absolute inset-0 bg-black/40"></div>

      <div className="relative z-10 text-center px-6 sm:px-8 max-w-4xl flex flex-col justify-center min-h-screen py-safe">
        <div className="mb-6 sm:mb-8 md:mb-12 cinematic-zoom-in" style={{ animationDelay: '0.3s' }}>
          <Heart className="w-14 h-14 sm:w-18 sm:h-18 md:w-24 md:h-24 text-[#d4af37] mx-auto animate-pulse-glow fill-current" />
        </div>

        <div className="space-y-3 sm:space-y-4 md:space-y-6 cinematic-fade-up" style={{ animationDelay: '0.6s' }}>
          <h1 className="text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-2 sm:mb-3 shine-effect px-2 leading-tight">
            {narrativeTexts[currentPhase].title}
          </h1>
          <p className="text-lg sm:text-xl md:text-2xl text-[#f7f2eb] font-light px-2 leading-relaxed">
            {narrativeTexts[currentPhase].subtitle}
          </p>
        </div>

        <div className="mt-6 sm:mt-10 md:mt-16 flex justify-center gap-3 sm:gap-4 md:gap-6 cinematic-fade-up" style={{ animationDelay: '0.9s' }}>
          {[...Array(4)].map((_, i) => (
            <div
              key={i}
              className={`w-2.5 h-2.5 sm:w-3 sm:h-3 rounded-full transition-all duration-500 ${
                i <= currentPhase
                  ? 'bg-[#d4af37] scale-125 progress-milestone'
                  : 'bg-[#d4af37]/30'
              }`}
            />
          ))}
        </div>

        {showSkip && (
          <button
            onClick={onComplete}
            className="mt-6 sm:mt-10 mx-auto px-8 sm:px-10 py-3 sm:py-3.5 text-base sm:text-lg text-[#f7f2eb] hover:text-white transition-all duration-300 cinematic-fade-up border-2 border-[#d4af37]/50 hover:border-[#d4af37] rounded-full backdrop-blur-sm touch-manipulation"
          >
            Überspringen
          </button>
        )}
      </div>

    </div>
  );
}
