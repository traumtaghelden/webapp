import { X, Crown, CheckCircle, AlertTriangle, Info } from 'lucide-react';
import { useEffect, useState } from 'react';

export interface ToastProps {
  id: string;
  type: 'success' | 'error' | 'warning' | 'info' | 'premium';
  title: string;
  message: string;
  duration?: number;
  onClose: (id: string) => void;
  action?: {
    label: string;
    onClick: () => void;
  };
}

export default function Toast({
  id,
  type,
  title,
  message,
  duration = 5000,
  onClose,
  action
}: ToastProps) {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    if (duration > 0) {
      const timer = setTimeout(() => {
        handleClose();
      }, duration);

      return () => clearTimeout(timer);
    }
  }, [duration]);

  const handleClose = () => {
    setIsExiting(true);
    setTimeout(() => {
      onClose(id);
    }, 300);
  };

  const getIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case 'error':
        return <AlertTriangle className="w-5 h-5 text-red-600" />;
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-orange-600" />;
      case 'premium':
        return <Crown className="w-5 h-5 text-[#d4af37]" />;
      default:
        return <Info className="w-5 h-5 text-blue-600" />;
    }
  };

  const getColors = () => {
    switch (type) {
      case 'success':
        return 'bg-green-50 border-green-200';
      case 'error':
        return 'bg-red-50 border-red-200';
      case 'warning':
        return 'bg-orange-50 border-orange-200';
      case 'premium':
        return 'bg-gradient-to-r from-[#d4af37]/10 to-[#f4d03f]/10 border-[#d4af37]';
      default:
        return 'bg-blue-50 border-blue-200';
    }
  };

  const getTitleColor = () => {
    switch (type) {
      case 'success':
        return 'text-green-900';
      case 'error':
        return 'text-red-900';
      case 'warning':
        return 'text-orange-900';
      case 'premium':
        return 'text-[#0a253c]';
      default:
        return 'text-blue-900';
    }
  };

  const getMessageColor = () => {
    switch (type) {
      case 'success':
        return 'text-green-700';
      case 'error':
        return 'text-red-700';
      case 'warning':
        return 'text-orange-700';
      case 'premium':
        return 'text-[#333333]';
      default:
        return 'text-blue-700';
    }
  };

  return (
    <div
      className={`
        ${getColors()}
        border-2 rounded-xl p-4 shadow-lg
        transform transition-all duration-300
        ${isExiting ? 'translate-x-full opacity-0' : 'translate-x-0 opacity-100'}
      `}
    >
      <div className="flex items-start gap-3">
        <div className="flex-shrink-0 mt-0.5">{getIcon()}</div>
        <div className="flex-1 min-w-0">
          <h4 className={`font-bold text-sm ${getTitleColor()} mb-1`}>
            {title}
          </h4>
          <p className={`text-sm ${getMessageColor()}`}>
            {message}
          </p>
          {action && (
            <button
              onClick={() => {
                action.onClick();
                handleClose();
              }}
              className={`
                mt-2 px-3 py-1.5 rounded-lg text-xs font-bold
                transition-colors
                ${type === 'premium'
                  ? 'bg-[#d4af37] text-white hover:bg-[#c19a2e]'
                  : 'bg-gray-700 text-white hover:bg-gray-800'
                }
              `}
            >
              {action.label}
            </button>
          )}
        </div>
        <button
          onClick={handleClose}
          className="flex-shrink-0 text-gray-400 hover:text-gray-600 transition-colors"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
