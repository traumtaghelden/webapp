import { useState, useEffect } from 'react';
import { Circle, CheckCircle, Calendar, MessageSquare, Trash2, User, DollarSign, Building2 } from 'lucide-react';
import { supabase, type Task, type TaskSubtask, type BudgetItem, type Vendor, type WeddingTeamRole } from '../../lib/supabase';
import { TASK } from '../../constants/terminology';
import UnifiedTable from '../common/UnifiedTable';
import { logger } from '../../utils/logger';

interface TaskListViewProps {
  tasks: Task[];
  weddingId: string;
  onUpdate: () => void;
  subtasks?: TaskSubtask[];
  budgetItems?: BudgetItem[];
  vendors?: Vendor[];
  teamRoles?: WeddingTeamRole[];
  onTaskClick?: (task: Task) => void;
  onDeleteTask?: (taskId: string) => void;
  onStatusChange?: (taskId: string, newStatus: 'pending' | 'in_progress' | 'completed') => void;
}

const categories = [
  { value: 'general', label: 'Allgemein' },
  { value: 'venue', label: 'Location' },
  { value: 'catering', label: 'Catering' },
  { value: 'decoration', label: 'Dekoration' },
  { value: 'music', label: 'Musik' },
  { value: 'photography', label: 'Fotografie' },
  { value: 'invitations', label: 'Einladungen' },
  { value: 'flowers', label: 'Blumen' },
  { value: 'dress', label: 'Kleidung' },
  { value: 'other', label: 'Sonstiges' },
];

const getCategoryLabel = (categoryValue: string) => {
  const category = categories.find(cat => cat.value === categoryValue);
  return category ? category.label : categoryValue;
};

export default function TaskListView({
  tasks,
  weddingId,
  onUpdate,
  subtasks: providedSubtasks,
  budgetItems: providedBudgetItems,
  vendors: providedVendors,
  teamRoles: providedTeamRoles,
  onTaskClick,
  onDeleteTask,
  onStatusChange,
}: TaskListViewProps) {
  const [subtasks, setSubtasks] = useState<TaskSubtask[]>(providedSubtasks || []);
  const [teamRoles, setTeamRoles] = useState<WeddingTeamRole[]>(providedTeamRoles || []);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!providedSubtasks || !providedTeamRoles) {
      loadAdditionalData();
    }
  }, [weddingId]);

  const loadAdditionalData = async () => {
    if (loading) return;

    setLoading(true);
    try {
      const promises = [];

      if (!providedSubtasks) {
        promises.push(
          supabase
            .from('task_subtasks')
            .select('*')
            .in('task_id', tasks.map(t => t.id))
        );
      }

      if (!providedTeamRoles) {
        promises.push(
          supabase
            .from('wedding_team_roles')
            .select('*')
            .eq('wedding_id', weddingId)
        );
      }

      const results = await Promise.all(promises);

      let resultIndex = 0;
      if (!providedSubtasks && results[resultIndex]) {
        const { data, error } = results[resultIndex];
        if (error) {
          logger.error('Error loading subtasks', 'TaskListView', error);
        } else if (data) {
          setSubtasks(data);
        }
        resultIndex++;
      }

      if (!providedTeamRoles && results[resultIndex]) {
        const { data, error } = results[resultIndex];
        if (error) {
          logger.error('Error loading team roles', 'TaskListView', error);
        } else if (data) {
          setTeamRoles(data);
        }
      }
    } catch (error) {
      logger.error('Error in loadAdditionalData', 'TaskListView', error);
    } finally {
      setLoading(false);
    }
  };

  const handleTaskClick = (task: Task) => {
    if (onTaskClick) {
      onTaskClick(task);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    if (onDeleteTask) {
      onDeleteTask(taskId);
    } else {
      try {
        const { error } = await supabase
          .from('tasks')
          .delete()
          .eq('id', taskId);

        if (error) throw error;
        onUpdate();
      } catch (error) {
        logger.error('Error deleting task', 'TaskListView', error);
      }
    }
  };

  const handleStatusChange = async (taskId: string, newStatus: 'pending' | 'in_progress' | 'completed') => {
    if (onStatusChange) {
      onStatusChange(taskId, newStatus);
    } else {
      try {
        const { error } = await supabase
          .from('tasks')
          .update({ status: newStatus })
          .eq('id', taskId);

        if (error) throw error;
        onUpdate();
      } catch (error) {
        logger.error('Error updating task status', 'TaskListView', error);
      }
    }
  };

  const safeSubtasks = subtasks || [];
  const safeTeamRoles = teamRoles || [];

  const columns = [
    {
      key: 'title',
      label: 'Aufgabe',
      sortable: true,
      align: 'left' as const,
      render: (task: Task) => {
        const taskSubtasks = safeSubtasks.filter(s => s.task_id === task.id);
        return (
          <div>
            <p className={`font-semibold text-[#0a253c] ${task.status === 'completed' ? 'line-through' : ''}`}>
              {task.title}
            </p>
            {taskSubtasks.length > 0 && (
              <p className="text-xs text-[#d4af37] mt-1">
                {taskSubtasks.filter(s => s.is_completed).length}/{taskSubtasks.length} {TASK.SUBTASK_PLURAL}
              </p>
            )}
          </div>
        );
      },
    },
    {
      key: 'category',
      label: 'Kategorie',
      sortable: true,
      align: 'left' as const,
      render: (task: Task) => (
        <span className="px-3 py-1 bg-[#d4af37]/20 text-[#0a253c] rounded-full text-sm">
          {getCategoryLabel(task.category)}
        </span>
      ),
    },
    {
      key: 'priority',
      label: 'Priorität',
      sortable: true,
      align: 'left' as const,
      render: (task: Task) => (
        <span
          className={`px-3 py-1 rounded-full text-sm font-semibold ${
            task.priority === 'high'
              ? 'bg-red-100 text-red-600'
              : task.priority === 'medium'
              ? 'bg-yellow-100 text-yellow-600'
              : 'bg-green-100 text-green-600'
          }`}
        >
          {task.priority === 'high' ? 'Hoch' : task.priority === 'medium' ? 'Mittel' : 'Niedrig'}
        </span>
      ),
    },
    {
      key: 'due_date',
      label: 'Fällig am',
      sortable: true,
      align: 'left' as const,
      render: (task: Task) => {
        const isOverdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'completed';
        return task.due_date ? (
          <span className={isOverdue ? 'text-red-600 font-semibold' : 'text-[#333333]'}>
            {new Date(task.due_date).toLocaleDateString('de-DE')}
          </span>
        ) : (
          <span className="text-[#999999]">-</span>
        );
      },
    },
    {
      key: 'assigned_to',
      label: 'Zugewiesen',
      sortable: true,
      align: 'left' as const,
      render: (task: Task) => {
        const assignedRole = task.assigned_to ? safeTeamRoles.find(r => r.name === task.assigned_to) : null;
        return assignedRole ? (
          <div className="flex items-center gap-2">
            {assignedRole.character_image ? (
              <img
                src={assignedRole.character_image}
                alt={assignedRole.name}
                className="w-6 h-6 rounded-full object-cover"
              />
            ) : (
              <User className="w-4 h-4 text-blue-600" />
            )}
            <span className="text-[#333333]">{assignedRole.name}</span>
          </div>
        ) : (
          <span className="text-[#999999]">-</span>
        );
      },
    },
    {
      key: 'status',
      label: 'Status',
      sortable: true,
      align: 'left' as const,
      render: (task: Task) => (
        <select
          value={task.status}
          onChange={(e) => {
            e.stopPropagation();
            handleStatusChange(task.id, e.target.value as 'pending' | 'in_progress' | 'completed');
          }}
          onClick={(e) => e.stopPropagation()}
          className={`px-3 py-1 rounded-full text-sm font-semibold border-2 focus:outline-none focus:ring-2 focus:ring-[#d4af37] transition-all cursor-pointer ${
            task.status === 'completed'
              ? 'bg-green-100 text-green-600 border-green-200'
              : task.status === 'in_progress'
              ? 'bg-blue-100 text-blue-600 border-blue-200'
              : 'bg-gray-100 text-gray-600 border-gray-200'
          }`}
        >
          <option value="pending">Offen</option>
          <option value="in_progress">In Bearbeitung</option>
          <option value="completed">Erledigt</option>
        </select>
      ),
    },
    {
      key: 'actions',
      label: 'Aktionen',
      align: 'right' as const,
      render: (task: Task) => (
        <div className="flex items-center justify-end gap-2">
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleTaskClick(task);
            }}
            className="p-2 hover:bg-[#d4af37]/10 rounded-lg transition-colors"
            title="Details"
          >
            <MessageSquare className="w-4 h-4 text-[#d4af37]" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              handleDeleteTask(task.id);
            }}
            className="p-2 hover:bg-red-50 rounded-lg transition-colors"
            title="Löschen"
          >
            <Trash2 className="w-4 h-4 text-red-500" />
          </button>
        </div>
      ),
    },
  ];

  const emptyState = (
    <div className="text-center py-12">
      <p className="text-[#333333]">Keine Aufgaben gefunden</p>
    </div>
  );

  if (loading && tasks.length === 0) {
    return (
      <div className="bg-white rounded-2xl shadow-lg p-8 text-center">
        <p className="text-gray-500">Lade Aufgaben...</p>
      </div>
    );
  }

  return (
    <UnifiedTable
      data={tasks}
      columns={columns}
      getRowKey={(task) => task.id}
      onRowClick={handleTaskClick}
      emptyState={emptyState}
      striped={true}
      hoverable={true}
    />
  );
}
