import { useState, useMemo } from 'react';
import { Calendar, ChevronLeft, ChevronRight, Clock, AlertCircle } from 'lucide-react';
import { type Task } from '../../lib/supabase';
import TaskDetailModal from '../TaskDetailModal';

interface TaskCalendarTabProps {
  weddingId: string;
  tasks: Task[];
  onUpdate: () => void;
}

export default function TaskCalendarTab({ weddingId, tasks, onUpdate }: TaskCalendarTabProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);

  const daysInMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth() + 1,
    0
  ).getDate();

  const firstDayOfMonth = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth(),
    1
  ).getDay();

  const monthName = currentDate.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });

  const tasksByDate = useMemo(() => {
    const map = new Map<string, Task[]>();
    tasks.forEach(task => {
      if (task.due_date) {
        const dateKey = new Date(task.due_date).toDateString();
        if (!map.has(dateKey)) {
          map.set(dateKey, []);
        }
        map.get(dateKey)!.push(task);
      }
    });
    return map;
  }, [tasks]);

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const getDayTasks = (day: number) => {
    const date = new Date(currentDate.getFullYear(), currentDate.getMonth(), day);
    return tasksByDate.get(date.toDateString()) || [];
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-2xl font-bold text-[#0a253c] flex items-center gap-3">
            <Calendar className="w-6 h-6 text-[#d4af37]" />
            {monthName}
          </h3>
          <div className="flex gap-2">
            <button
              onClick={previousMonth}
              className="p-2 rounded-lg hover:bg-[#f7f2eb] transition-all"
            >
              <ChevronLeft className="w-5 h-5 text-[#0a253c]" />
            </button>
            <button
              onClick={nextMonth}
              className="p-2 rounded-lg hover:bg-[#f7f2eb] transition-all"
            >
              <ChevronRight className="w-5 h-5 text-[#0a253c]" />
            </button>
          </div>
        </div>

        <div className="grid grid-cols-7 gap-2">
          {['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map(day => (
            <div key={day} className="text-center font-bold text-[#666666] py-2">
              {day}
            </div>
          ))}

          {Array.from({ length: firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1 }).map((_, i) => (
            <div key={`empty-${i}`} className="aspect-square" />
          ))}

          {Array.from({ length: daysInMonth }).map((_, i) => {
            const day = i + 1;
            const dayTasks = getDayTasks(day);
            const isToday =
              day === new Date().getDate() &&
              currentDate.getMonth() === new Date().getMonth() &&
              currentDate.getFullYear() === new Date().getFullYear();

            return (
              <div
                key={day}
                className={`aspect-square p-2 rounded-xl border-2 transition-all ${
                  isToday
                    ? 'border-[#d4af37] bg-[#d4af37]/10'
                    : 'border-gray-200 hover:border-[#d4af37]/50'
                }`}
              >
                <div className="flex flex-col h-full">
                  <div className={`text-sm font-bold mb-1 ${isToday ? 'text-[#d4af37]' : 'text-[#0a253c]'}`}>
                    {day}
                  </div>
                  <div className="flex-1 space-y-1">
                    {dayTasks.slice(0, 3).map(task => (
                      <div
                        key={task.id}
                        onClick={() => setSelectedTask(task)}
                        className={`text-xs p-1 rounded cursor-pointer truncate ${
                          task.status === 'completed'
                            ? 'bg-green-100 text-green-700'
                            : task.priority === 'high'
                            ? 'bg-red-100 text-red-700'
                            : 'bg-blue-100 text-blue-700'
                        }`}
                        title={task.title}
                      >
                        {task.title}
                      </div>
                    ))}
                    {dayTasks.length > 3 && (
                      <div className="text-xs text-[#999999] text-center">
                        +{dayTasks.length - 3} mehr
                      </div>
                    )}
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-lg">
        <h4 className="font-bold text-[#0a253c] text-lg mb-4">Aufgaben ohne Datum</h4>
        <div className="space-y-2">
          {tasks.filter(t => !t.due_date).map(task => (
            <div
              key={task.id}
              onClick={() => setSelectedTask(task)}
              className="p-3 bg-[#f7f2eb] rounded-lg cursor-pointer hover:bg-[#d4af37]/10 transition-all"
            >
              <div className="flex items-center justify-between">
                <span className="font-semibold text-[#0a253c]">{task.title}</span>
                {task.priority === 'high' && (
                  <AlertCircle className="w-4 h-4 text-red-500" />
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedTask && (
        <TaskDetailModal
          isOpen={true}
          onClose={() => setSelectedTask(null)}
          taskId={selectedTask.id}
          weddingId={weddingId}
          onUpdate={onUpdate}
        />
      )}
    </div>
  );
}
