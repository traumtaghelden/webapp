import { ClipboardList, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { type Task } from '../../lib/supabase';
import KPICard from '../common/KPICard';
import { TASK } from '../../constants/terminology';

interface TaskKPIPanelProps {
  tasks: Task[];
  onFilterChange?: (filter: string | null) => void;
}

export default function TaskKPIPanel({ tasks, onFilterChange }: TaskKPIPanelProps) {
  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const pendingTasks = tasks.filter(t => t.status === 'pending' || t.status === 'in_progress').length;

  const overdueTasks = tasks.filter(t => {
    if (!t.due_date || t.status === 'completed') return false;
    return new Date(t.due_date) < new Date();
  }).length;

  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const metrics = [
    {
      icon: <ClipboardList className="w-6 h-6 text-[#d4af37]" />,
      label: `Gesamt ${TASK.PLURAL}`,
      value: totalTasks,
      subtitle: `${completionRate}% abgeschlossen`,
      color: 'border-[#d4af37]',
      delay: 0,
      filter: null
    },
    {
      icon: <CheckCircle className="w-6 h-6 text-green-600" />,
      label: 'Erledigt',
      value: completedTasks,
      subtitle: totalTasks > 0 ? `${completionRate}% der ${TASK.PLURAL}` : '0%',
      color: 'border-green-500',
      delay: 100,
      filter: 'completed'
    },
    {
      icon: <Clock className="w-6 h-6 text-blue-600" />,
      label: 'Offen',
      value: pendingTasks,
      subtitle: totalTasks > 0 ? `${Math.round((pendingTasks/totalTasks)*100)}% verbleibend` : '0%',
      color: 'border-blue-500',
      delay: 200,
      filter: 'pending'
    },
    {
      icon: <AlertTriangle className="w-6 h-6 text-red-600" />,
      label: 'Überfällig',
      value: overdueTasks,
      subtitle: overdueTasks > 0 ? 'Benötigt Aufmerksamkeit' : 'Keine überfälligen',
      color: 'border-red-500',
      delay: 300,
      filter: 'overdue'
    }
  ];

  return (
    <div className="space-y-4 mb-6">
      <div>
        <h1 className="text-4xl font-bold text-[#0a253c] mb-2 animate-[fadeInUp_0.6s_ease-out]">
          Aufgaben
        </h1>
        <p className="text-lg text-[#666666] animate-[fadeInUp_0.8s_ease-out]">
          Organisiere deine Hochzeitsplanung
        </p>
      </div>

      <div className="flex flex-wrap gap-4">
        {metrics.map((metric, index) => (
          <div key={index} className="w-full sm:w-[calc(50%-0.5rem)] lg:w-[calc(25%-0.75rem)]">
            <KPICard
              icon={metric.icon}
              label={metric.label}
              value={metric.value}
              subtitle={metric.subtitle}
              color={metric.color}
              delay={metric.delay}
              onClick={onFilterChange ? () => onFilterChange(metric.filter) : undefined}
            />
          </div>
        ))}
      </div>
    </div>
  );
}
