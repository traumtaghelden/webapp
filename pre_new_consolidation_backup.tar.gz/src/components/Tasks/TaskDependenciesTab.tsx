import { useState, useEffect } from 'react';
import { GitBranch, Link, AlertCircle, CheckCircle } from 'lucide-react';
import { supabase, type Task, type TaskDependency } from '../../lib/supabase';

interface TaskDependenciesTabProps {
  weddingId: string;
  tasks: Task[];
  onUpdate: () => void;
}

export default function TaskDependenciesTab({ weddingId, tasks, onUpdate }: TaskDependenciesTabProps) {
  const [dependencies, setDependencies] = useState<TaskDependency[]>([]);

  useEffect(() => {
    loadDependencies();
  }, [weddingId]);

  const loadDependencies = async () => {
    try {
      const { data } = await supabase
        .from('task_dependencies')
        .select('*')
        .in('task_id', tasks.map(t => t.id));

      if (data) {
        setDependencies(data);
      }
    } catch (error) {
      console.error('Error loading dependencies:', error);
    }
  };

  const getTaskById = (taskId: string) => {
    return tasks.find(t => t.id === taskId);
  };

  const tasksWithDependencies = tasks.filter(task =>
    dependencies.some(d => d.task_id === task.id)
  );

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-[#0a253c]">Aufgaben-Abhängigkeiten</h3>
        <p className="text-[#666666] mt-1">Verknüpfungen und Blocker</p>
      </div>

      {tasksWithDependencies.length > 0 ? (
        <div className="space-y-4">
          {tasksWithDependencies.map(task => {
            const taskDeps = dependencies.filter(d => d.task_id === task.id);
            const blockedBy = taskDeps.filter(d => {
              const depTask = getTaskById(d.depends_on_task_id);
              return depTask && depTask.status !== 'completed';
            });

            return (
              <div
                key={task.id}
                className="bg-white rounded-xl p-6 shadow-lg border-2 border-[#d4af37]/30"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="w-10 h-10 rounded-full bg-[#d4af37]/20 flex items-center justify-center flex-shrink-0">
                    <GitBranch className="w-5 h-5 text-[#d4af37]" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-bold text-[#0a253c] text-lg mb-1">{task.title}</h4>
                    <div className="flex items-center gap-2">
                      <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                        task.status === 'completed'
                          ? 'bg-green-100 text-green-700'
                          : task.status === 'in_progress'
                          ? 'bg-blue-100 text-blue-700'
                          : 'bg-gray-100 text-gray-700'
                      }`}>
                        {task.status === 'completed' ? 'Abgeschlossen' :
                         task.status === 'in_progress' ? 'In Bearbeitung' : 'Ausstehend'}
                      </span>
                      {blockedBy.length > 0 && (
                        <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-sm font-semibold flex items-center gap-1">
                          <AlertCircle className="w-4 h-4" />
                          Blockiert
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="space-y-3 ml-14">
                  <h5 className="text-sm font-semibold text-[#666666]">Hängt ab von:</h5>
                  {taskDeps.map(dep => {
                    const depTask = getTaskById(dep.depends_on_task_id);
                    if (!depTask) return null;

                    const isCompleted = depTask.status === 'completed';

                    return (
                      <div
                        key={dep.id}
                        className={`flex items-center gap-3 p-3 rounded-lg ${
                          isCompleted ? 'bg-green-50' : 'bg-red-50'
                        }`}
                      >
                        {isCompleted ? (
                          <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                        ) : (
                          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                        )}
                        <div className="flex-1">
                          <p className="font-semibold text-[#0a253c]">{depTask.title}</p>
                          <p className="text-sm text-[#666666]">
                            {isCompleted ? 'Abgeschlossen' : 'Noch nicht abgeschlossen'}
                          </p>
                        </div>
                        <Link className="w-5 h-5 text-[#d4af37]" />
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-2xl p-8 text-center">
          <GitBranch className="w-20 h-20 text-[#d4af37] mx-auto mb-4" />
          <h4 className="text-2xl font-bold text-white mb-2">Keine Abhängigkeiten</h4>
          <p className="text-white/70 mb-6">
            Erstelle Verknüpfungen zwischen Aufgaben um Abhängigkeiten zu tracken
          </p>
          <div className="inline-block px-6 py-3 bg-[#d4af37]/20 text-[#d4af37] rounded-xl font-bold">
            Premium Feature
          </div>
        </div>
      )}
    </div>
  );
}
