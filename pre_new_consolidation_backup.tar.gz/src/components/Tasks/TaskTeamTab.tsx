import { useState, useEffect } from 'react';
import { Users, User, CheckCircle, Clock, Circle } from 'lucide-react';
import { type Task, type WeddingTeamRole } from '../../lib/supabase';
import { supabase } from '../../lib/supabase';

interface TaskTeamTabProps {
  weddingId: string;
  tasks: Task[];
  onUpdate: () => void;
}

export default function TaskTeamTab({ weddingId, tasks, onUpdate }: TaskTeamTabProps) {
  const [teamRoles, setTeamRoles] = useState<WeddingTeamRole[]>([]);

  useEffect(() => {
    loadTeamRoles();
  }, [weddingId]);

  const loadTeamRoles = async () => {
    try {
      const { data } = await supabase
        .from('wedding_team_roles')
        .select('*')
        .eq('wedding_id', weddingId);

      if (data) {
        setTeamRoles(data);
      }
    } catch (error) {
      console.error('Error loading team roles:', error);
    }
  };

  const getTasksForPerson = (personName: string) => {
    return tasks.filter(t => t.assigned_to === personName);
  };

  const getPersonStats = (personName: string) => {
    const personTasks = getTasksForPerson(personName);
    return {
      total: personTasks.length,
      completed: personTasks.filter(t => t.status === 'completed').length,
      inProgress: personTasks.filter(t => t.status === 'in_progress').length,
      pending: personTasks.filter(t => t.status === 'pending').length,
    };
  };

  const unassignedTasks = tasks.filter(t => !t.assigned_to);

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-[#0a253c]">Team-Übersicht</h3>
        <p className="text-[#666666] mt-1">Aufgabenverteilung im Team</p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {teamRoles.map(role => {
          const stats = getPersonStats(role.name);
          const completionRate = stats.total > 0
            ? Math.round((stats.completed / stats.total) * 100)
            : 0;

          return (
            <div
              key={role.id}
              className="bg-white rounded-xl p-6 shadow-lg border-2 border-[#d4af37]/30"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="w-12 h-12 rounded-full bg-[#d4af37]/20 flex items-center justify-center">
                  <User className="w-6 h-6 text-[#d4af37]" />
                </div>
                <div>
                  <h4 className="font-bold text-[#0a253c]">{role.name}</h4>
                  <p className="text-sm text-[#666666]">{role.role}</p>
                </div>
              </div>

              <div className="space-y-3 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-[#666666]">Fortschritt</span>
                  <span className="font-bold text-[#d4af37]">{completionRate}%</span>
                </div>
                <div className="w-full bg-gray-200 rounded-full h-2">
                  <div
                    className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-2 rounded-full transition-all"
                    style={{ width: `${completionRate}%` }}
                  />
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2">
                <div className="text-center p-2 bg-green-50 rounded-lg">
                  <CheckCircle className="w-4 h-4 text-green-600 mx-auto mb-1" />
                  <div className="text-sm font-bold text-green-600">{stats.completed}</div>
                  <div className="text-xs text-[#666666]">Fertig</div>
                </div>
                <div className="text-center p-2 bg-blue-50 rounded-lg">
                  <Clock className="w-4 h-4 text-blue-600 mx-auto mb-1" />
                  <div className="text-sm font-bold text-blue-600">{stats.inProgress}</div>
                  <div className="text-xs text-[#666666]">Aktiv</div>
                </div>
                <div className="text-center p-2 bg-gray-50 rounded-lg">
                  <Circle className="w-4 h-4 text-gray-600 mx-auto mb-1" />
                  <div className="text-sm font-bold text-gray-600">{stats.pending}</div>
                  <div className="text-xs text-[#666666]">Offen</div>
                </div>
              </div>
            </div>
          );
        })}

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-gray-300">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-full bg-gray-200 flex items-center justify-center">
              <Users className="w-6 h-6 text-gray-500" />
            </div>
            <div>
              <h4 className="font-bold text-[#0a253c]">Nicht zugewiesen</h4>
              <p className="text-sm text-[#666666]">Ohne Verantwortlichen</p>
            </div>
          </div>

          <div className="text-center py-4">
            <div className="text-4xl font-bold text-gray-500 mb-2">
              {unassignedTasks.length}
            </div>
            <p className="text-sm text-[#666666]">Aufgaben</p>
          </div>
        </div>
      </div>

      {teamRoles.length === 0 && (
        <div className="bg-[#f7f2eb] rounded-2xl p-8 text-center">
          <Users className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
          <p className="text-[#666666] text-lg mb-2">Noch keine Team-Mitglieder</p>
          <p className="text-sm text-[#999999]">
            Füge Trauzeugen, Helfer und andere Team-Mitglieder in den Einstellungen hinzu
          </p>
        </div>
      )}
    </div>
  );
}
