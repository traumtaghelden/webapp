import { useState, useEffect } from 'react';
import { X, Calendar, DollarSign, CheckCircle, ArrowRight } from 'lucide-react';
import { supabase, type Vendor } from '../lib/supabase';

interface VendorBookingDialogProps {
  isOpen: boolean;
  onClose: () => void;
  vendor: Vendor;
  weddingId: string;
  onConfirm: (options: {
    linkToEvent: boolean;
    createBudgetItem: boolean;
    eventId?: string;
  }) => void;
}

export default function VendorBookingDialog({
  isOpen,
  onClose,
  vendor,
  weddingId,
  onConfirm
}: VendorBookingDialogProps) {
  const [linkToEvent, setLinkToEvent] = useState(false);
  const [createBudgetItem, setCreateBudgetItem] = useState(true);
  const [selectedEventId, setSelectedEventId] = useState('');
  const [timelineEvents, setTimelineEvents] = useState<any[]>([]);

  useEffect(() => {
    if (isOpen) {
      loadTimelineEvents();
    }
  }, [isOpen, weddingId]);

  const loadTimelineEvents = async () => {
    try {
      const { data, error } = await supabase
        .from('wedding_timeline')
        .select('id, title, time, event_type')
        .eq('wedding_id', weddingId)
        .order('time', { ascending: true });

      if (error) throw error;
      setTimelineEvents(data || []);
    } catch (error) {
      console.error('Error loading timeline events:', error);
    }
  };

  const handleConfirm = () => {
    onConfirm({
      linkToEvent,
      createBudgetItem,
      eventId: linkToEvent ? selectedEventId : undefined
    });
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9999] p-4">
      <div
        className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full max-h-[90vh] flex flex-col transform transition-all duration-300"
        style={{ animation: 'slideUp 0.3s ease-out' }}
      >
        <div className="p-6 border-b border-[#d4af37]/20">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold text-[#0a253c] mb-2">
                {vendor.name} buchen
              </h2>
              <p className="text-sm text-[#666666]">
                Möchtest du diesen Dienstleister mit einem Event oder Budget verknüpfen?
              </p>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-[#f7f2eb] rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-[#333333]" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-2xl p-5 border-2 border-[#d4af37]/30">
            <div className="flex items-start gap-4">
              <div className="flex-shrink-0 w-12 h-12 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] rounded-xl flex items-center justify-center shadow-lg">
                <CheckCircle className="w-6 h-6 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="font-bold text-[#0a253c] mb-1">{vendor.name}</h3>
                <p className="text-sm text-[#666666] mb-2">{vendor.category}</p>
                {vendor.estimated_cost && vendor.estimated_cost > 0 && (
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-green-600" />
                    <span className="text-lg font-bold text-green-600">
                      {vendor.estimated_cost.toLocaleString('de-DE')} €
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <label className="flex items-start gap-3 p-4 bg-white border-2 border-[#d4af37]/30 rounded-xl cursor-pointer hover:border-[#d4af37] hover:bg-[#f7f2eb]/30 transition-all">
              <input
                type="checkbox"
                checked={linkToEvent}
                onChange={(e) => setLinkToEvent(e.target.checked)}
                className="mt-1 w-5 h-5 rounded border-2 border-[#d4af37] text-[#d4af37] focus:ring-[#d4af37]"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <Calendar className="w-5 h-5 text-[#d4af37]" />
                  <span className="font-semibold text-[#0a253c]">Mit Timeline-Event verknüpfen</span>
                </div>
                <p className="text-sm text-[#666666]">
                  Weise diesen Dienstleister einem spezifischen Event in deiner Hochzeits-Timeline zu
                </p>
              </div>
            </label>

            {linkToEvent && (
              <div className="ml-8 space-y-2 animate-fadeIn">
                <label className="block text-sm font-semibold text-[#333333]">
                  Event auswählen
                </label>
                <select
                  value={selectedEventId}
                  onChange={(e) => setSelectedEventId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                >
                  <option value="">Bitte wählen...</option>
                  {timelineEvents.map(event => (
                    <option key={event.id} value={event.id}>
                      {event.time} - {event.title}
                    </option>
                  ))}
                </select>
                {timelineEvents.length === 0 && (
                  <p className="text-xs text-[#999999]">
                    Noch keine Timeline-Events vorhanden. Erstelle zuerst Events in der Timeline.
                  </p>
                )}
              </div>
            )}

            <label className="flex items-start gap-3 p-4 bg-white border-2 border-[#d4af37]/30 rounded-xl cursor-pointer hover:border-[#d4af37] hover:bg-[#f7f2eb]/30 transition-all">
              <input
                type="checkbox"
                checked={createBudgetItem}
                onChange={(e) => setCreateBudgetItem(e.target.checked)}
                className="mt-1 w-5 h-5 rounded border-2 border-[#d4af37] text-[#d4af37] focus:ring-[#d4af37]"
              />
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <DollarSign className="w-5 h-5 text-green-600" />
                  <span className="font-semibold text-[#0a253c]">Neuen Budgetposten anlegen</span>
                </div>
                <p className="text-sm text-[#666666]">
                  Erstellt automatisch einen Budget-Eintrag für diesen Dienstleister
                </p>
              </div>
            </label>
          </div>

          <div className="p-4 bg-blue-50 rounded-xl border-2 border-blue-200">
            <p className="text-sm text-blue-800">
              <strong>Tipp:</strong> Du kannst diese Verknüpfungen auch später noch in den Detailansichten bearbeiten.
            </p>
          </div>
        </div>

        <div className="p-6 border-t border-[#d4af37]/20 bg-[#f7f2eb]">
          <div className="flex gap-3">
            <button
              onClick={handleConfirm}
              disabled={linkToEvent && !selectedEventId}
              className="flex-1 flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#0a253c] rounded-xl font-bold hover:shadow-lg transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <CheckCircle className="w-5 h-5" />
              Dienstleister buchen
            </button>
            <button
              onClick={onClose}
              className="px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-bold hover:bg-[#d4af37]/10 transition-all"
            >
              Abbrechen
            </button>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
      `}</style>
    </div>
  );
}
