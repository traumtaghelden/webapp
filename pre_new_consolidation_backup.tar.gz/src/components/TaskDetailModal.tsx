import { useState, useEffect } from 'react';
import { X, MessageSquare, Paperclip, Send, Download, Trash2, Upload, Calendar, Info, Link as LinkIcon, Clock, MapPin, CheckCircle, Circle, AlertCircle, Edit, Save } from 'lucide-react';
import { supabase, type TaskComment, type TaskAttachment, type Task, type TimelineEvent, type TaskSubtask, type TaskDependency, type BudgetItem, type Vendor } from '../lib/supabase';
import { TASK, COMMON } from '../constants/terminology';

interface TaskDetailModalProps {
  isOpen?: boolean;
  taskId: string;
  taskTitle?: string;
  onClose: () => void;
  weddingId?: string;
  onUpdate?: () => void;
}

export default function TaskDetailModal({ isOpen = true, taskId, taskTitle, onClose, weddingId, onUpdate }: TaskDetailModalProps) {
  if (!isOpen) return null;
  const [activeTab, setActiveTab] = useState<'overview' | 'comments' | 'attachments' | 'timeline'>('overview');
  const [task, setTask] = useState<Task | null>(null);
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [editedTask, setEditedTask] = useState<Partial<Task>>({});
  const [teamRoles, setTeamRoles] = useState<any[]>([]);
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [linkedEvent, setLinkedEvent] = useState<TimelineEvent | null>(null);
  const [subtasks, setSubtasks] = useState<TaskSubtask[]>([]);
  const [dependencies, setDependencies] = useState<TaskDependency[]>([]);
  const [budgetItem, setBudgetItem] = useState<BudgetItem | null>(null);
  const [vendor, setVendor] = useState<Vendor | null>(null);
  const [showEventSelector, setShowEventSelector] = useState(false);
  const [comments, setComments] = useState<TaskComment[]>([]);
  const [attachments, setAttachments] = useState<TaskAttachment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [uploading, setUploading] = useState(false);
  const [userId, setUserId] = useState<string>('');

  useEffect(() => {
    loadData();
    getUserId();
    loadTaskDetails();
    if (weddingId) {
      loadTimelineEvents();
      loadTeamRoles();
      loadBudgetItems();
      loadVendors();
    }

    // ESC key handler
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.preventDefault();
        e.stopPropagation();
        onClose();
      }
    };

    document.addEventListener('keydown', handleEscape);
    return () => {
      document.removeEventListener('keydown', handleEscape);
    };
  }, [taskId, weddingId, onClose]);

  const getUserId = async () => {
    const { data } = await supabase.auth.getUser();
    if (data.user) {
      setUserId(data.user.id);
    }
  };

  const loadTaskDetails = async () => {
    try {
      const { data: taskData } = await supabase
        .from('tasks')
        .select('*')
        .eq('id', taskId)
        .maybeSingle();

      if (taskData) {
        setTask(taskData);

        const [subtasksData, dependenciesData] = await Promise.all([
          supabase.from('task_subtasks').select('*').eq('task_id', taskId).order('sort_order'),
          supabase.from('task_dependencies').select('*').eq('task_id', taskId),
        ]);

        if (subtasksData.data) setSubtasks(subtasksData.data);
        if (dependenciesData.data) setDependencies(dependenciesData.data);

        if (taskData.timeline_event_id) {
          const { data: eventData } = await supabase
            .from('wedding_timeline')
            .select('*')
            .eq('id', taskData.timeline_event_id)
            .maybeSingle();
          if (eventData) setLinkedEvent(eventData);
        }

        if (taskData.budget_item_id) {
          const { data: budgetData } = await supabase
            .from('budget_items')
            .select('*')
            .eq('id', taskData.budget_item_id)
            .maybeSingle();
          if (budgetData) setBudgetItem(budgetData);
        }

        if (taskData.vendor_id) {
          const { data: vendorData } = await supabase
            .from('vendors')
            .select('*')
            .eq('id', taskData.vendor_id)
            .maybeSingle();
          if (vendorData) setVendor(vendorData);
        }
      }
    } catch (error) {
      console.error('Error loading task details:', error);
    }
  };

  const loadTimelineEvents = async () => {
    try {
      const { data } = await supabase
        .from('wedding_timeline')
        .select('*')
        .eq('wedding_id', weddingId)
        .order('order_index');
      if (data) setTimelineEvents(data);
    } catch (error) {
      console.error('Error loading timeline events:', error);
    }
  };

  const loadTeamRoles = async () => {
    try {
      const { data } = await supabase
        .from('wedding_team_roles')
        .select('*')
        .eq('wedding_id', weddingId);
      if (data) setTeamRoles(data);
    } catch (error) {
      console.error('Error loading team roles:', error);
    }
  };

  const loadBudgetItems = async () => {
    try {
      const { data } = await supabase
        .from('budget_items')
        .select('*')
        .eq('wedding_id', weddingId);
      if (data) setBudgetItems(data);
    } catch (error) {
      console.error('Error loading budget items:', error);
    }
  };

  const loadVendors = async () => {
    try {
      const { data } = await supabase
        .from('vendors')
        .select('*')
        .eq('wedding_id', weddingId);
      if (data) setVendors(data);
    } catch (error) {
      console.error('Error loading vendors:', error);
    }
  };

  const handleStartEdit = () => {
    if (task) {
      setEditedTask({
        title: task.title,
        category: task.category,
        priority: task.priority,
        due_date: task.due_date,
        assigned_to: task.assigned_to,
        notes: task.notes,
        status: task.status,
        budget_item_id: task.budget_item_id,
        vendor_id: task.vendor_id,
        timeline_event_id: task.timeline_event_id,
      });
      setIsEditing(true);
    }
  };

  const handleSaveEdit = async () => {
    try {
      const { error } = await supabase
        .from('tasks')
        .update(editedTask)
        .eq('id', taskId);

      if (error) throw error;

      setIsEditing(false);
      await loadTaskDetails();
      onUpdate?.();
      onClose();
    } catch (error) {
      console.error('Error updating task:', error);
      alert('Fehler beim Speichern der Aufgabe');
    }
  };

  const handleCancelEdit = () => {
    setIsEditing(false);
    setEditedTask({});
  };

  const categories = [
    'general',
    'venue',
    'catering',
    'decoration',
    'music',
    'photography',
    'invitations',
    'flowers',
    'dress',
    'other',
  ];

  const loadData = async () => {
    const [commentsData, attachmentsData] = await Promise.all([
      supabase
        .from('task_comments')
        .select('*')
        .eq('task_id', taskId)
        .order('created_at', { ascending: true }),
      supabase
        .from('task_attachments')
        .select('*')
        .eq('task_id', taskId)
        .order('created_at', { ascending: false }),
    ]);

    if (commentsData.data) setComments(commentsData.data);
    if (attachmentsData.data) setAttachments(attachmentsData.data);
  };

  const handleLinkTimelineEvent = async (eventId: string | null) => {
    try {
      await supabase
        .from('tasks')
        .update({ timeline_event_id: eventId })
        .eq('id', taskId);

      if (eventId) {
        const { data: eventData } = await supabase
          .from('wedding_timeline')
          .select('*')
          .eq('id', eventId)
          .maybeSingle();
        if (eventData) setLinkedEvent(eventData);
      } else {
        setLinkedEvent(null);
      }

      setShowEventSelector(false);
      loadTaskDetails();
    } catch (error) {
      console.error('Error linking timeline event:', error);
    }
  };

  const formatTime = (timeString: string) => {
    return timeString.substring(0, 5);
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('de-DE', {
      day: '2-digit',
      month: 'short',
      year: 'numeric',
    });
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;

    try {
      await supabase.from('task_comments').insert([
        {
          task_id: taskId,
          user_id: userId,
          comment: newComment.trim(),
        },
      ]);

      setNewComment('');
      loadData();
    } catch (error) {
      console.error('Error adding comment:', error);
    }
  };

  const handleDeleteComment = async (commentId: string) => {
    if (!confirm('Möchtest du diesen Kommentar wirklich löschen?')) return;

    try {
      await supabase.from('task_comments').delete().eq('id', commentId);
      loadData();
    } catch (error) {
      console.error('Error deleting comment:', error);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploading(true);

    try {
      for (const file of Array.from(files)) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${taskId}-${Date.now()}.${fileExt}`;
        const filePath = `task-attachments/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('wedding-files')
          .upload(filePath, file);

        if (uploadError) throw uploadError;

        const { data: urlData } = supabase.storage
          .from('wedding-files')
          .getPublicUrl(filePath);

        await supabase.from('task_attachments').insert([
          {
            task_id: taskId,
            file_name: file.name,
            file_url: urlData.publicUrl,
            file_size: file.size,
            file_type: file.type,
            uploaded_by: userId,
          },
        ]);
      }

      loadData();
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Fehler beim Hochladen der Datei. Bitte versuche es erneut.');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteAttachment = async (attachmentId: string, fileUrl: string) => {
    if (!confirm('Möchtest du diese Datei wirklich löschen?')) return;

    try {
      const filePath = fileUrl.split('/').slice(-2).join('/');
      await supabase.storage.from('wedding-files').remove([filePath]);
      await supabase.from('task_attachments').delete().eq('id', attachmentId);
      loadData();
    } catch (error) {
      console.error('Error deleting attachment:', error);
    }
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(1) + ' MB';
  };

  const formatDateTime = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('de-DE', {
      day: '2-digit',
      month: 'short',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const handleBackdropClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-2 sm:p-4 animate-in fade-in duration-200"
      onClick={handleBackdropClick}
    >
      <div
        className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl max-w-4xl w-full max-h-[95vh] sm:max-h-[90vh] flex flex-col animate-in zoom-in-95 slide-in-from-bottom-4 duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-4 sm:p-6 border-b border-[#d4af37]/20">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 gap-3">
            <h2 className="text-xl sm:text-2xl font-bold text-[#0a253c] pr-8 sm:pr-0">{taskTitle || task?.title || 'Aufgabe'}</h2>
            <div className="flex items-center gap-2 flex-wrap">
              {!isEditing && activeTab === 'overview' && (
                <button
                  onClick={handleStartEdit}
                  className="flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all text-xs sm:text-sm"
                >
                  <Edit className="w-3 h-3 sm:w-4 sm:h-4" />
                  <span className="hidden xs:inline">Bearbeiten</span>
                </button>
              )}
              {isEditing && (
                <>
                  <button
                    onClick={handleSaveEdit}
                    className="flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all text-xs sm:text-sm"
                  >
                    <Save className="w-3 h-3 sm:w-4 sm:h-4" />
                    <span className="hidden xs:inline">Speichern</span>
                  </button>
                  <button
                    onClick={handleCancelEdit}
                    className="px-3 sm:px-4 py-2 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-bold hover:bg-[#d4af37]/10 transition-all text-xs sm:text-sm"
                  >
                    <span className="hidden xs:inline">Abbrechen</span>
                    <X className="w-3 h-3 xs:hidden" />
                  </button>
                </>
              )}
              <button
                onClick={onClose}
                className="p-1.5 sm:p-2 hover:bg-[#f7f2eb] rounded-full transition-colors absolute top-3 right-3 sm:static"
              >
                <X className="w-5 h-5 sm:w-6 sm:h-6 text-[#333333]" />
              </button>
            </div>
          </div>

          <div className="flex gap-1 sm:gap-2 flex-wrap overflow-x-auto">
            <button
              onClick={() => setActiveTab('overview')}
              className={`flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition-all text-xs sm:text-sm whitespace-nowrap ${
                activeTab === 'overview'
                  ? 'bg-[#d4af37] text-[#0a253c]'
                  : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
              }`}
            >
              <Info className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Übersicht</span>
            </button>
            <button
              onClick={() => setActiveTab('timeline')}
              className={`flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition-all text-xs sm:text-sm whitespace-nowrap ${
                activeTab === 'timeline'
                  ? 'bg-[#d4af37] text-[#0a253c]'
                  : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
              }`}
            >
              <LinkIcon className="w-3 h-3 sm:w-4 sm:h-4" />
              <span>Timeline</span> {linkedEvent && <span>✓</span>}
            </button>
            <button
              onClick={() => setActiveTab('comments')}
              className={`flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition-all text-xs sm:text-sm whitespace-nowrap ${
                activeTab === 'comments'
                  ? 'bg-[#d4af37] text-[#0a253c]'
                  : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
              }`}
            >
              <MessageSquare className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline">Kommentare</span>
              <span className="xs:hidden">({comments.length})</span>
              <span className="hidden xs:inline">({comments.length})</span>
            </button>
            <button
              onClick={() => setActiveTab('attachments')}
              className={`flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition-all text-xs sm:text-sm whitespace-nowrap ${
                activeTab === 'attachments'
                  ? 'bg-[#d4af37] text-[#0a253c]'
                  : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
              }`}
            >
              <Paperclip className="w-3 h-3 sm:w-4 sm:h-4" />
              <span className="hidden xs:inline">Anhänge</span>
              <span>({attachments.length})</span>
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {activeTab === 'overview' && task && (
            <div className="space-y-4 sm:space-y-6">
              {isEditing ? (
                <div className="bg-white border-2 border-[#d4af37] rounded-xl p-4 sm:p-6">
                  <h3 className="text-base sm:text-lg font-bold text-[#0a253c] mb-4">Aufgabe bearbeiten</h3>
                  <div className="grid sm:grid-cols-2 gap-3 sm:gap-4">
                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Titel*</label>
                      <input
                        type="text"
                        value={editedTask.title || ''}
                        onChange={(e) => setEditedTask({ ...editedTask, title: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Status</label>
                      <select
                        value={editedTask.status || 'pending'}
                        onChange={(e) => setEditedTask({ ...editedTask, status: e.target.value as any })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      >
                        <option value="pending">Offen</option>
                        <option value="in_progress">In Bearbeitung</option>
                        <option value="completed">Erledigt</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Priorität</label>
                      <select
                        value={editedTask.priority || 'medium'}
                        onChange={(e) => setEditedTask({ ...editedTask, priority: e.target.value as any })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      >
                        <option value="low">Niedrig</option>
                        <option value="medium">Mittel</option>
                        <option value="high">Hoch</option>
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Kategorie</label>
                      <select
                        value={editedTask.category || 'general'}
                        onChange={(e) => setEditedTask({ ...editedTask, category: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      >
                        {categories.map((cat) => (
                          <option key={cat} value={cat}>
                            {cat.charAt(0).toUpperCase() + cat.slice(1)}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Fällig am</label>
                      <input
                        type="date"
                        value={editedTask.due_date || ''}
                        onChange={(e) => setEditedTask({ ...editedTask, due_date: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Verantwortlich</label>
                      <select
                        value={editedTask.assigned_to || ''}
                        onChange={(e) => setEditedTask({ ...editedTask, assigned_to: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      >
                        <option value="">Nicht zugewiesen</option>
                        {teamRoles.map((role: any) => (
                          <option key={role.id} value={role.name}>
                            {role.name}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Budget-Posten</label>
                      <select
                        value={editedTask.budget_item_id || ''}
                        onChange={(e) => setEditedTask({ ...editedTask, budget_item_id: e.target.value || null })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      >
                        <option value="">Keine Verknüpfung</option>
                        {budgetItems.map((item) => (
                          <option key={item.id} value={item.id}>
                            {item.item_name} - {item.category}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Dienstleister</label>
                      <select
                        value={editedTask.vendor_id || ''}
                        onChange={(e) => setEditedTask({ ...editedTask, vendor_id: e.target.value || null })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      >
                        <option value="">Keine Verknüpfung</option>
                        {vendors.map((vendor) => (
                          <option key={vendor.id} value={vendor.id}>
                            {vendor.name} - {vendor.category}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Notizen</label>
                      <textarea
                        value={editedTask.notes || ''}
                        onChange={(e) => setEditedTask({ ...editedTask, notes: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                        rows={4}
                        placeholder="Zusätzliche Details..."
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Hauptinformationen */}
                  <div className="bg-gradient-to-br from-[#d4af37]/10 to-[#f7f2eb] rounded-xl p-4 sm:p-6 border-2 border-[#d4af37]/30">
                    <h3 className="text-lg sm:text-xl font-bold text-[#0a253c] mb-4 flex items-center gap-2">
                      <Info className="w-5 h-5 text-[#d4af37]" />
                      Aufgabendetails
                    </h3>
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <p className="text-xs text-[#666666] mb-1 uppercase tracking-wide">Status</p>
                        <div className="flex items-center gap-2">
                          {task.status === 'completed' ? (
                            <CheckCircle className="w-5 h-5 text-green-500 fill-current" />
                          ) : task.status === 'in_progress' ? (
                            <Clock className="w-5 h-5 text-blue-500" />
                          ) : (
                            <Circle className="w-5 h-5 text-gray-400" />
                          )}
                          <span className="font-semibold text-[#0a253c]">
                            {task.status === 'completed' ? 'Erledigt' : task.status === 'in_progress' ? 'In Bearbeitung' : 'Offen'}
                          </span>
                        </div>
                      </div>
                      <div>
                        <p className="text-xs text-[#666666] mb-1 uppercase tracking-wide">Priorität</p>
                        <span className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-bold ${
                          task.priority === 'high' ? 'bg-red-100 text-red-700' :
                          task.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                          'bg-green-100 text-green-700'
                        }`}>
                          {task.priority === 'high' && <AlertCircle className="w-4 h-4" />}
                          {task.priority === 'high' ? 'Hoch' : task.priority === 'medium' ? 'Mittel' : 'Niedrig'}
                        </span>
                      </div>
                      <div>
                        <p className="text-xs text-[#666666] mb-1 uppercase tracking-wide">Kategorie</p>
                        <span className="inline-block px-3 py-1.5 bg-[#d4af37]/20 text-[#0a253c] rounded-full text-sm font-bold">
                          {task.category}
                        </span>
                      </div>
                      {task.due_date && (
                        <div>
                          <p className="text-xs text-[#666666] mb-1 uppercase tracking-wide">Fälligkeitsdatum</p>
                          <div className="flex items-center gap-2">
                            <Calendar className="w-4 h-4 text-[#d4af37]" />
                            <span className="font-semibold text-[#0a253c]">{formatDate(task.due_date)}</span>
                            {new Date(task.due_date) < new Date() && task.status !== 'completed' && (
                              <span className="text-xs bg-red-500 text-white px-2 py-0.5 rounded-full">Überfällig</span>
                            )}
                          </div>
                        </div>
                      )}
                      {task.assigned_to && (
                        <div>
                          <p className="text-xs text-[#666666] mb-1 uppercase tracking-wide">Zugewiesen an</p>
                          <div className="flex items-center gap-2">
                            <div className="w-8 h-8 rounded-full bg-[#d4af37] flex items-center justify-center text-white font-bold">
                              {task.assigned_to.charAt(0).toUpperCase()}
                            </div>
                            <span className="font-semibold text-[#0a253c]">{task.assigned_to}</span>
                          </div>
                        </div>
                      )}
                      {task.created_at && (
                        <div>
                          <p className="text-xs text-[#666666] mb-1 uppercase tracking-wide">Erstellt am</p>
                          <span className="text-sm text-[#333333]">{new Date(task.created_at).toLocaleDateString('de-DE', { day: '2-digit', month: 'short', year: 'numeric' })}</span>
                        </div>
                      )}
                    </div>
                    {task.notes && (
                      <div className="mt-4 pt-4 border-t-2 border-[#d4af37]/20">
                        <p className="text-xs text-[#666666] mb-2 uppercase tracking-wide">Notizen</p>
                        <p className="text-[#0a253c] whitespace-pre-wrap bg-white rounded-lg p-3">{task.notes}</p>
                      </div>
                    )}
                  </div>

                  {/* Beschreibung, falls vorhanden */}
                  {task.description && (
                    <div className="bg-white rounded-xl p-4 sm:p-6 border-2 border-[#d4af37]/20">
                      <p className="text-xs text-[#666666] mb-2 uppercase tracking-wide">Beschreibung</p>
                      <p className="text-[#0a253c] leading-relaxed">{task.description}</p>
                    </div>
                  )}
                </div>
              )}

              {subtasks.length > 0 && (
                <div className="bg-white border-2 border-[#d4af37]/20 rounded-xl p-4 sm:p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h3 className="text-base sm:text-lg font-bold text-[#0a253c]">
                      Unteraufgaben
                    </h3>
                    <span className="text-sm font-bold text-[#d4af37]">
                      {subtasks.filter(s => s.completed).length}/{subtasks.length}
                    </span>
                  </div>

                  {/* Fortschrittsbalken */}
                  <div className="mb-4">
                    <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                      <div
                        className="bg-gradient-to-r from-[#d4af37] to-[#f4c430] h-full transition-all duration-500 ease-out rounded-full"
                        style={{ width: `${(subtasks.filter(s => s.completed).length / subtasks.length) * 100}%` }}
                      />
                    </div>
                    <p className="text-xs text-[#666666] mt-1">
                      {Math.round((subtasks.filter(s => s.completed).length / subtasks.length) * 100)}% abgeschlossen
                    </p>
                  </div>

                  <div className="space-y-2">
                    {subtasks.map(subtask => (
                      <div key={subtask.id} className="flex items-center gap-3 p-2 rounded-lg hover:bg-[#f7f2eb] transition-colors">
                        {subtask.completed ? (
                          <CheckCircle className="w-5 h-5 text-green-500 fill-current flex-shrink-0" />
                        ) : (
                          <Circle className="w-5 h-5 text-gray-400 flex-shrink-0" />
                        )}
                        <span className={`flex-1 ${subtask.completed ? 'line-through text-[#999999]' : 'text-[#333333] font-medium'}`}>
                          {subtask.title}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Verknüpfungen */}
              {(budgetItem || vendor) && (
                <div className="grid sm:grid-cols-2 gap-4">
                  {budgetItem && (
                    <div className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-300 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-full bg-green-500 flex items-center justify-center">
                          <span className="text-white text-lg">€</span>
                        </div>
                        <p className="text-xs text-green-700 font-bold uppercase tracking-wide">Budget-Posten</p>
                      </div>
                      <p className="text-lg font-bold text-green-900 mb-2">{budgetItem.item_name}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-sm text-green-700">Geschätzt:</span>
                        <span className="text-lg font-bold text-green-600">{budgetItem.estimated_cost}€</span>
                      </div>
                      {budgetItem.actual_cost && (
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-sm text-green-700">Tatsächlich:</span>
                          <span className="text-lg font-bold text-green-800">{budgetItem.actual_cost}€</span>
                        </div>
                      )}
                    </div>
                  )}
                  {vendor && (
                    <div className="bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-300 rounded-xl p-4 shadow-sm hover:shadow-md transition-shadow">
                      <div className="flex items-center gap-2 mb-2">
                        <div className="w-8 h-8 rounded-full bg-blue-500 flex items-center justify-center">
                          <span className="text-white text-lg">👤</span>
                        </div>
                        <p className="text-xs text-blue-700 font-bold uppercase tracking-wide">Dienstleister</p>
                      </div>
                      <p className="text-lg font-bold text-blue-900 mb-2">{vendor.name}</p>
                      <span className="inline-block px-3 py-1 bg-blue-200 text-blue-800 rounded-full text-xs font-semibold">
                        {vendor.category}
                      </span>
                      {vendor.email && (
                        <p className="text-xs text-blue-600 mt-2">{vendor.email}</p>
                      )}
                    </div>
                  )}
                </div>
              )}

              {dependencies.length > 0 && (
                <div className="bg-orange-50 border-2 border-orange-200 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertCircle className="w-5 h-5 text-orange-600" />
                    <p className="text-sm text-orange-700 font-semibold">Hat {dependencies.length} Abhängigkeit(en)</p>
                  </div>
                  <p className="text-xs text-orange-600">Diese Aufgabe hängt von anderen Aufgaben ab</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'timeline' && (
            <div className="space-y-4 sm:space-y-6">
              <div>
                <h3 className="text-base sm:text-lg font-bold text-[#0a253c] mb-4">Timeline-Verknüpfung</h3>
                {linkedEvent ? (
                  <div className="bg-[#f7f2eb] rounded-xl p-4 sm:p-6">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold" style={{ backgroundColor: linkedEvent.color || '#d4af37' }}>
                            {formatTime(linkedEvent.time)}
                          </div>
                          <div>
                            <h4 className="text-xl font-bold text-[#0a253c]">{linkedEvent.title}</h4>
                            {linkedEvent.description && (
                              <p className="text-sm text-[#333333] mt-1">{linkedEvent.description}</p>
                            )}
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-3 mt-3">
                          <div className="flex items-center gap-2 text-sm text-[#333333]">
                            <Clock className="w-4 h-4 text-[#d4af37]" />
                            <span>{linkedEvent.duration_minutes} Minuten</span>
                          </div>
                          {linkedEvent.location && (
                            <div className="flex items-center gap-2 text-sm text-[#333333]">
                              <MapPin className="w-4 h-4 text-[#d4af37]" />
                              <span>{linkedEvent.location}</span>
                            </div>
                          )}
                        </div>
                      </div>
                      <button
                        onClick={() => handleLinkTimelineEvent(null)}
                        className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                        title="Verknüpfung entfernen"
                      >
                        <X className="w-5 h-5 text-red-500" />
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="bg-[#f7f2eb] rounded-xl p-6 sm:p-8 text-center">
                    <Calendar className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
                    <p className="text-[#333333] mb-4">Keine Timeline-Verknüpfung</p>
                    <button
                      onClick={() => setShowEventSelector(true)}
                      className="px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all"
                    >
                      Event verknüpfen
                    </button>
                  </div>
                )}
              </div>

              {!linkedEvent && showEventSelector && timelineEvents.length > 0 && (
                <div className="bg-white border-2 border-[#d4af37] rounded-xl p-4 sm:p-6">
                  <h4 className="text-base sm:text-lg font-bold text-[#0a253c] mb-4">Timeline-Event auswählen</h4>
                  <div className="space-y-2 max-h-96 overflow-y-auto">
                    {timelineEvents.map(event => (
                      <button
                        key={event.id}
                        onClick={() => handleLinkTimelineEvent(event.id)}
                        className="w-full text-left p-4 rounded-xl hover:bg-[#f7f2eb] transition-all border-2 border-transparent hover:border-[#d4af37]"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-16 h-16 rounded-xl flex flex-col items-center justify-center text-white font-bold text-xs" style={{ backgroundColor: event.color || '#d4af37' }}>
                            <div>{formatTime(event.time)}</div>
                            <div className="text-xs opacity-75">{event.duration_minutes}m</div>
                          </div>
                          <div className="flex-1">
                            <h5 className="font-bold text-[#0a253c]">{event.title}</h5>
                            {event.description && (
                              <p className="text-sm text-[#333333] mt-1">{event.description}</p>
                            )}
                            {event.location && (
                              <div className="flex items-center gap-1 text-xs text-[#666666] mt-1">
                                <MapPin className="w-3 h-3" />
                                {event.location}
                              </div>
                            )}
                          </div>
                        </div>
                      </button>
                    ))}
                  </div>
                  <button
                    onClick={() => setShowEventSelector(false)}
                    className="mt-4 w-full px-4 py-2 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-semibold hover:bg-[#d4af37]/10 transition-all"
                  >
                    Abbrechen
                  </button>
                </div>
              )}

              {!linkedEvent && timelineEvents.length === 0 && (
                <div className="text-center py-8">
                  <p className="text-[#333333]">Keine Timeline-Events verfügbar</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'comments' && (
            <div className="space-y-4 sm:space-y-6">
              <div className="space-y-3 sm:space-y-4">
                {comments.map((comment) => (
                  <div
                    key={comment.id}
                    className="bg-[#f7f2eb] rounded-xl p-4 hover:bg-[#d4af37]/10 transition-all group"
                  >
                    <div className="flex items-start justify-between gap-3">
                      <div className="flex-1">
                        <p className="text-[#0a253c] whitespace-pre-wrap">{comment.comment}</p>
                        <p className="text-xs text-[#333333] mt-2">{formatDateTime(comment.created_at)}</p>
                      </div>
                      {comment.user_id === userId && (
                        <button
                          onClick={() => handleDeleteComment(comment.id)}
                          className="opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <Trash2 className="w-4 h-4 text-red-500 hover:text-red-700" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}

                {comments.length === 0 && (
                  <div className="text-center py-12">
                    <MessageSquare className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
                    <p className="text-[#333333]">Noch keine Kommentare vorhanden</p>
                  </div>
                )}
              </div>

              <div className="sticky bottom-0 bg-white pt-3 sm:pt-4 border-t border-[#d4af37]/20">
                <div className="flex flex-col sm:flex-row gap-2 sm:gap-3">
                  <textarea
                    value={newComment}
                    onChange={(e) => setNewComment(e.target.value)}
                    placeholder="Kommentar hinzufügen..."
                    className="flex-1 px-3 sm:px-4 py-2 sm:py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none resize-none text-sm"
                    rows={2}
                  />
                  <button
                    onClick={handleAddComment}
                    disabled={!newComment.trim()}
                    className="px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all sm:self-end text-sm"
                  >
                    <span className="sm:hidden">Senden</span>
                    <Send className="w-4 h-4 sm:w-5 sm:h-5 hidden sm:block" />
                  </button>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'attachments' && (
            <div className="space-y-4 sm:space-y-6">
              <div>
                <label className="flex flex-col items-center justify-center w-full h-32 border-2 border-dashed border-[#d4af37] rounded-xl cursor-pointer hover:bg-[#d4af37]/5 transition-all">
                  <div className="flex flex-col items-center justify-center pt-5 pb-6">
                    <Upload className="w-10 h-10 text-[#d4af37] mb-2" />
                    <p className="text-sm text-[#333333] font-semibold">
                      {uploading ? 'Lädt hoch...' : 'Dateien hochladen'}
                    </p>
                    <p className="text-xs text-[#333333] mt-1">Klicken oder Dateien hierher ziehen</p>
                  </div>
                  <input
                    type="file"
                    multiple
                    onChange={handleFileUpload}
                    disabled={uploading}
                    className="hidden"
                  />
                </label>
              </div>

              <div className="space-y-2 sm:space-y-3">
                {attachments.map((attachment) => (
                  <div
                    key={attachment.id}
                    className="flex items-center gap-4 p-4 bg-[#f7f2eb] rounded-xl hover:bg-[#d4af37]/10 transition-all group"
                  >
                    <div className="flex-shrink-0">
                      <Paperclip className="w-6 h-6 text-[#d4af37]" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-[#0a253c] truncate">{attachment.file_name}</p>
                      <div className="flex items-center gap-3 text-xs text-[#333333] mt-1">
                        <span>{formatFileSize(attachment.file_size)}</span>
                        <span>•</span>
                        <span>{formatDateTime(attachment.created_at)}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <a
                        href={attachment.file_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="p-2 hover:bg-white rounded-lg transition-colors"
                      >
                        <Download className="w-5 h-5 text-[#d4af37]" />
                      </a>
                      {attachment.uploaded_by === userId && (
                        <button
                          onClick={() => handleDeleteAttachment(attachment.id, attachment.file_url)}
                          className="p-2 hover:bg-white rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                        >
                          <Trash2 className="w-5 h-5 text-red-500" />
                        </button>
                      )}
                    </div>
                  </div>
                ))}

                {attachments.length === 0 && (
                  <div className="text-center py-12">
                    <Paperclip className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
                    <p className="text-[#333333]">Noch keine Anhänge vorhanden</p>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
