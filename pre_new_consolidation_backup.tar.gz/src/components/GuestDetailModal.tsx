import { useState, useEffect } from 'react';
import { X, User, Mail, Phone, Tag, MapPin, Calendar, Clock, Check, AlertCircle, ChevronDown, ChevronRight } from 'lucide-react';
import { supabase } from '../lib/supabase';
import DietaryRestrictionsSelector from './DietaryRestrictionsSelector';
import { GUEST, COMMON } from '../constants/terminology';

const getStatusLabel = (status: string): string => {
  switch (status) {
    case 'planned': return GUEST.RSVP_STATUS.PLANNED;
    case 'invited': return GUEST.RSVP_STATUS.INVITED;
    case 'accepted': return GUEST.RSVP_STATUS.ACCEPTED;
    case 'declined': return GUEST.RSVP_STATUS.DECLINED;
    default: return status;
  }
};

const getStatusColor = (status: string): string => {
  switch (status) {
    case 'planned': return 'bg-gray-100 text-gray-700';
    case 'invited': return 'bg-blue-100 text-blue-700';
    case 'accepted': return 'bg-green-100 text-green-700';
    case 'declined': return 'bg-red-100 text-red-700';
    default: return 'bg-gray-100 text-gray-700';
  }
};

interface Guest {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  rsvp_status: 'planned' | 'invited' | 'accepted' | 'declined';
  plus_one: boolean;
  plus_one_name: string | null;
  dietary_restrictions: string;
  table_number: number | null;
  group_id: string | null;
  age_group: 'adult' | 'child' | 'infant';
  relationship: string | null;
  invitation_status: 'not_sent' | 'save_the_date_sent' | 'invitation_sent' | 'reminder_sent';
  invitation_sent_date: string | null;
  rsvp_date: string | null;
  is_vip: boolean;
  special_needs: string | null;
  address: string | null;
  city: string | null;
  postal_code: string | null;
  country: string | null;
  notes: string | null;
  gift_received: boolean;
  gift_description: string | null;
  checked_in: boolean;
  checked_in_at: string | null;
}

interface GuestTag {
  id: string;
  name: string;
  color: string;
}

interface GuestDetailModalProps {
  guestId: string;
  weddingId: string;
  onClose: () => void;
  onUpdate: () => void;
}

type TabType = 'overview' | 'notes';

export default function GuestDetailModal({ guestId, weddingId, onClose, onUpdate }: GuestDetailModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [guest, setGuest] = useState<Guest | null>(null);
  const [availableTags, setAvailableTags] = useState<GuestTag[]>([]);
  const [assignedTags, setAssignedTags] = useState<string[]>([]);
  const [groups, setGroups] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editMode, setEditMode] = useState(false);
  const [editedGuest, setEditedGuest] = useState<Partial<Guest>>({});
  const [showAddress, setShowAddress] = useState(false);
  const [showDietary, setShowDietary] = useState(false);

  useEffect(() => {
    loadGuestData();
    loadTags();
    loadGroups();
  }, [guestId]);

  const loadGuestData = async () => {
    try {
      const { data, error } = await supabase
        .from('guests')
        .select('*')
        .eq('id', guestId)
        .maybeSingle();

      if (error) throw error;
      if (data) {
        setGuest(data);
        setEditedGuest(data);
      }
    } catch (error) {
      console.error('Error loading guest:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadTags = async () => {
    try {
      const [tagsData, assignmentsData] = await Promise.all([
        supabase.from('guest_tags').select('*').eq('wedding_id', weddingId),
        supabase.from('guest_tag_assignments').select('tag_id').eq('guest_id', guestId)
      ]);

      if (tagsData.data) setAvailableTags(tagsData.data);
      if (assignmentsData.data) setAssignedTags(assignmentsData.data.map(a => a.tag_id));
    } catch (error) {
      console.error('Error loading tags:', error);
    }
  };

  const loadGroups = async () => {
    try {
      const { data } = await supabase
        .from('guest_groups')
        .select('*')
        .eq('wedding_id', weddingId);

      if (data) setGroups(data);
    } catch (error) {
      console.error('Error loading groups:', error);
    }
  };

  const handleSave = async () => {
    try {
      const { error } = await supabase
        .from('guests')
        .update(editedGuest)
        .eq('id', guestId);

      if (error) throw error;

      setGuest({ ...guest!, ...editedGuest });
      setEditMode(false);
      onUpdate();
    } catch (error) {
      console.error('Error updating guest:', error);
      alert('Fehler beim Speichern');
    }
  };

  const handleToggleTag = async (tagId: string) => {
    try {
      if (assignedTags.includes(tagId)) {
        await supabase
          .from('guest_tag_assignments')
          .delete()
          .eq('guest_id', guestId)
          .eq('tag_id', tagId);
        setAssignedTags(assignedTags.filter(id => id !== tagId));
      } else {
        await supabase
          .from('guest_tag_assignments')
          .insert({ guest_id: guestId, tag_id: tagId });
        setAssignedTags([...assignedTags, tagId]);
      }
    } catch (error) {
      console.error('Error toggling tag:', error);
    }
  };

  const handleCheckIn = async () => {
    try {
      const { error } = await supabase
        .from('guests')
        .update({
          checked_in: true,
          checked_in_at: new Date().toISOString(),
        })
        .eq('id', guestId);

      if (error) throw error;
      loadGuestData();
      onUpdate();
    } catch (error) {
      console.error('Error checking in guest:', error);
    }
  };

  if (loading || !guest) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999]">
        <div className="bg-white rounded-3xl p-8">
          <p className="text-[#0a253c]">Lädt Gast-Details...</p>
        </div>
      </div>
    );
  }

  const currentGroup = groups.find(g => g.id === guest.group_id);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-3xl shadow-2xl max-w-4xl w-full max-h-[95vh] sm:max-h-[90vh] flex flex-col my-4 sm:my-8">
        <div className="p-4 sm:p-6 border-b border-[#d4af37]/20 flex items-start sm:items-center justify-between sticky top-0 bg-white z-10 rounded-t-3xl gap-3">
          <div className="flex items-center gap-2 sm:gap-4 min-w-0 flex-1">
            <div className="w-12 h-12 sm:w-16 sm:h-16 rounded-full flex items-center justify-center text-lg sm:text-2xl font-bold text-white bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex-shrink-0">
              {guest.name.charAt(0).toUpperCase()}
            </div>
            <div className="min-w-0 flex-1">
              <h2 className="text-lg sm:text-2xl font-bold text-[#0a253c] break-words">
                {guest.name}
              </h2>
              <div className="flex items-center gap-2 mt-1 flex-wrap">
                <span className={`px-2 sm:px-3 py-0.5 sm:py-1 rounded-full text-xs sm:text-sm font-semibold ${getStatusColor(guest.rsvp_status)}`}>
                  {getStatusLabel(guest.rsvp_status)}
                </span>
              </div>
            </div>
          </div>
          <div className="flex items-center gap-2 sm:gap-3 flex-shrink-0">
            {activeTab === 'overview' && (
              <button
                onClick={() => editMode ? handleSave() : setEditMode(true)}
                className="px-3 sm:px-4 py-1.5 sm:py-2 bg-[#d4af37] text-[#0a253c] rounded-xl text-sm sm:text-base font-semibold hover:bg-[#c19a2e] transition-all"
              >
                {editMode ? 'Speichern' : 'Bearbeiten'}
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 sm:p-2 hover:bg-[#f7f2eb] rounded-full transition-colors"
            >
              <X className="w-5 h-5 sm:w-6 sm:h-6 text-[#333333]" />
            </button>
          </div>
        </div>

        <div className="flex border-b border-[#d4af37]/20">
          {[
            { id: 'overview', label: 'Übersicht', icon: User },
            { id: 'notes', label: 'Notizen', icon: Tag },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as TabType)}
              className={`flex-1 px-4 py-3 font-semibold transition-all flex items-center justify-center gap-2 ${
                activeTab === tab.id
                  ? 'text-[#d4af37] border-b-4 border-[#d4af37] bg-[#d4af37]/5'
                  : 'text-[#333333] hover:bg-[#f7f2eb]'
              }`}
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'overview' && (
            <div className="space-y-4 sm:space-y-6">
              <h3 className="text-xl font-bold text-[#0a253c]">Persönliche Informationen</h3>

              <div className="grid sm:grid-cols-2 gap-4 sm:gap-6">
                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                  {editMode ? (
                    <input
                      type="text"
                      value={editedGuest.name || ''}
                      onChange={(e) => setEditedGuest({ ...editedGuest, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    />
                  ) : (
                    <p className="text-[#0a253c] font-medium py-3">{guest.name}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">E-Mail</label>
                  {editMode ? (
                    <input
                      type="email"
                      value={editedGuest.email || ''}
                      onChange={(e) => setEditedGuest({ ...editedGuest, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    />
                  ) : (
                    <p className="text-[#0a253c] font-medium py-3 flex items-center gap-2">
                      {guest.email ? (
                        <>
                          <Mail className="w-4 h-4 text-[#d4af37]" />
                          <a href={`mailto:${guest.email}`} className="hover:text-[#d4af37]">{guest.email}</a>
                        </>
                      ) : '-'}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Telefon</label>
                  {editMode ? (
                    <input
                      type="tel"
                      value={editedGuest.phone || ''}
                      onChange={(e) => setEditedGuest({ ...editedGuest, phone: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    />
                  ) : (
                    <p className="text-[#0a253c] font-medium py-3 flex items-center gap-2">
                      {guest.phone ? (
                        <>
                          <Phone className="w-4 h-4 text-[#d4af37]" />
                          <a href={`tel:${guest.phone}`} className="hover:text-[#d4af37]">{guest.phone}</a>
                        </>
                      ) : '-'}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Altersgruppe</label>
                  {editMode ? (
                    <select
                      value={editedGuest.age_group || 'adult'}
                      onChange={(e) => setEditedGuest({ ...editedGuest, age_group: e.target.value as any })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    >
                      <option value="adult">Erwachsener</option>
                      <option value="child">Kind</option>
                      <option value="infant">Kleinkind</option>
                    </select>
                  ) : (
                    <p className="text-[#0a253c] font-medium py-3">
                      {guest.age_group === 'adult' ? 'Erwachsener' :
                       guest.age_group === 'child' ? 'Kind' : 'Kleinkind'}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Beziehung</label>
                  {editMode ? (
                    <input
                      type="text"
                      value={editedGuest.relationship || ''}
                      onChange={(e) => setEditedGuest({ ...editedGuest, relationship: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      placeholder="z.B. Freund, Familie, Arbeitskollege"
                    />
                  ) : (
                    <p className="text-[#0a253c] font-medium py-3">{guest.relationship || '-'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Gruppe</label>
                  {editMode ? (
                    <select
                      value={editedGuest.group_id || ''}
                      onChange={(e) => setEditedGuest({ ...editedGuest, group_id: e.target.value || null })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    >
                      <option value="">Keine Gruppe</option>
                      {groups.map(group => (
                        <option key={group.id} value={group.id}>{group.name}</option>
                      ))}
                    </select>
                  ) : (
                    <p className="text-[#0a253c] font-medium py-3">
                      {currentGroup ? (
                        <span
                          className="px-3 py-1 rounded-full text-sm font-semibold"
                          style={{ backgroundColor: `${currentGroup.color}20`, color: currentGroup.color }}
                        >
                          {currentGroup.name}
                        </span>
                      ) : '-'}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Tischnummer</label>
                  {editMode ? (
                    <input
                      type="number"
                      value={editedGuest.table_number || ''}
                      onChange={(e) => setEditedGuest({ ...editedGuest, table_number: parseInt(e.target.value) || null })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    />
                  ) : (
                    <p className="text-[#0a253c] font-medium py-3">{guest.table_number || '-'}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Status</label>
                  {editMode ? (
                    <select
                      value={editedGuest.rsvp_status || 'planned'}
                      onChange={(e) => setEditedGuest({ ...editedGuest, rsvp_status: e.target.value as any })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    >
                      <option value="planned">Geplant</option>
                      <option value="invited">Einladung versendet</option>
                      <option value="accepted">Zugesagt</option>
                      <option value="declined">Abgesagt</option>
                    </select>
                  ) : (
                    <p className="text-[#0a253c] font-medium py-3">
                      <span className={`px-3 py-1 rounded-full text-sm font-semibold ${
                        getStatusColor(guest.rsvp_status)
                      }`}>
                        {getStatusLabel(guest.rsvp_status)}
                      </span>
                    </p>
                  )}
                </div>

                <div className="sm:col-span-2">
                  {editMode ? (
                    <>
                      <button
                        type="button"
                        onClick={() => setShowDietary(!showDietary)}
                        className="w-full flex items-center justify-between p-4 bg-[#f7f2eb] hover:bg-[#f0e8d5] rounded-xl transition-colors border-2 border-[#d4af37]/20 mb-2"
                      >
                        <span className="text-sm font-semibold text-[#0a253c]">Diätwünsche / Allergien</span>
                        {showDietary ? (
                          <ChevronDown className="w-5 h-5 text-[#d4af37]" />
                        ) : (
                          <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                        )}
                      </button>
                      {showDietary && (
                        <div className="p-4 bg-white rounded-xl border-2 border-[#d4af37]/20">
                          <DietaryRestrictionsSelector
                            value={editedGuest.dietary_restrictions || ''}
                            onChange={(value) => setEditedGuest({ ...editedGuest, dietary_restrictions: value })}
                          />
                        </div>
                      )}
                    </>
                  ) : (
                    <>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Diätwünsche / Allergien</label>
                      <div className="py-3">
                        {guest.dietary_restrictions ? (
                          <div className="flex flex-wrap gap-2">
                            {guest.dietary_restrictions.split(',').map((item, idx) => (
                              <span
                                key={idx}
                                className="px-3 py-1 bg-[#d4af37]/10 text-[#d4af37] rounded-full text-sm font-semibold"
                              >
                                {item.trim()}
                              </span>
                            ))}
                          </div>
                        ) : (
                          <p className="text-[#666666]">-</p>
                        )}
                      </div>
                    </>
                  )}
                </div>

              </div>

              <div className="border-t border-[#d4af37]/20 pt-4 sm:pt-6">
                {editMode ? (
                  <>
                    <button
                      type="button"
                      onClick={() => setShowAddress(!showAddress)}
                      className="w-full flex items-center justify-between p-4 bg-[#f7f2eb] hover:bg-[#f0e8d5] rounded-xl transition-colors border-2 border-[#d4af37]/20 mb-4"
                    >
                      <span className="text-lg font-bold text-[#0a253c]">Adresse für Einladungen</span>
                      {showAddress ? (
                        <ChevronDown className="w-5 h-5 text-[#d4af37]" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                      )}
                    </button>
                  </>
                ) : (
                  <h4 className="text-base sm:text-lg font-bold text-[#0a253c] mb-3 sm:mb-4">Adresse für Einladungen</h4>
                )}
                {(!editMode || showAddress) && (
                  <div className="grid sm:grid-cols-2 gap-4 sm:gap-6">
                  <div className="sm:col-span-2">
                    <label className="block text-sm font-semibold text-[#333333] mb-2">Straße & Hausnummer</label>
                    {editMode ? (
                      <input
                        type="text"
                        value={editedGuest.address || ''}
                        onChange={(e) => setEditedGuest({ ...editedGuest, address: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : (
                      <p className="text-[#0a253c] font-medium py-3 flex items-center gap-2">
                        {guest.address ? (
                          <>
                            <MapPin className="w-4 h-4 text-[#d4af37]" />
                            {guest.address}
                          </>
                        ) : '-'}
                      </p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#333333] mb-2">PLZ</label>
                    {editMode ? (
                      <input
                        type="text"
                        value={editedGuest.postal_code || ''}
                        onChange={(e) => setEditedGuest({ ...editedGuest, postal_code: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : (
                      <p className="text-[#0a253c] font-medium py-3">{guest.postal_code || '-'}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#333333] mb-2">Stadt</label>
                    {editMode ? (
                      <input
                        type="text"
                        value={editedGuest.city || ''}
                        onChange={(e) => setEditedGuest({ ...editedGuest, city: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : (
                      <p className="text-[#0a253c] font-medium py-3">{guest.city || '-'}</p>
                    )}
                  </div>

                  <div className="sm:col-span-2">
                    <label className="block text-sm font-semibold text-[#333333] mb-2">Land</label>
                    {editMode ? (
                      <input
                        type="text"
                        value={editedGuest.country || ''}
                        onChange={(e) => setEditedGuest({ ...editedGuest, country: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : (
                      <p className="text-[#0a253c] font-medium py-3">{guest.country || '-'}</p>
                    )}
                  </div>
                  </div>
                )}
              </div>

            </div>
          )}

          {activeTab === 'notes' && (
            <div className="space-y-4 sm:space-y-6">
              <h3 className="text-lg sm:text-xl font-bold text-[#0a253c]">Interne Notizen</h3>
              <div>
                <textarea
                  value={editedGuest.notes || guest.notes || ''}
                  onChange={(e) => setEditedGuest({ ...editedGuest, notes: e.target.value })}
                  onBlur={handleSave}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  rows={12}
                  placeholder="Interne Notizen zu diesem Gast (nur für das Organisationsteam sichtbar)..."
                />
              </div>
              <div className="bg-blue-50 rounded-xl p-4 flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-blue-900">
                  Diese Notizen sind nur für das Organisationsteam sichtbar und werden nicht mit dem Gast geteilt.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
