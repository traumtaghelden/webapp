import { Shield, Lock, Download, CheckCircle } from 'lucide-react';
import { emitModalEvent } from '../../lib/modalManager';

export default function PrivacyModal() {
  return (
    <div className="space-y-6">
      <div className="flex items-start gap-3 p-4 bg-gradient-to-r from-[#d4af37]/10 to-[#f4d03f]/10 rounded-xl border border-[#d4af37]/20">
        <Shield className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
        <div>
          <h3 className="font-bold text-[#0a253c] mb-1">Eure Daten sind bei uns sicher</h3>
          <p className="text-gray-700 text-sm leading-relaxed">
            Wir nehmen Datenschutz ernst und halten uns strikt an die DSGVO. Eure Hochzeitsdaten gehören euch – und nur euch.
          </p>
        </div>
      </div>

      <div className="space-y-4">
        <div>
          <h3 className="font-bold text-[#0a253c] mb-3 flex items-center gap-2">
            <Lock className="w-5 h-5 text-[#d4af37]" />
            Welche Daten wir erheben
          </h3>
          <div className="space-y-2 text-gray-700 text-sm">
            <p className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Account-Daten: E-Mail-Adresse und Passwort (verschlüsselt)</span>
            </p>
            <p className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Hochzeitsdaten: Namen, Datum, Budget, Gästeliste, Aufgaben</span>
            </p>
            <p className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
              <span>Nutzungsdaten: Login-Zeiten und verwendete Features (anonym)</span>
            </p>
          </div>
        </div>

        <div>
          <h3 className="font-bold text-[#0a253c] mb-3">Wie wir eure Daten nutzen</h3>
          <div className="space-y-2 text-gray-700 text-sm leading-relaxed">
            <p>
              Wir verwenden eure Daten ausschließlich, um euch die App-Funktionen bereitzustellen. Das bedeutet: Speicherung eurer Hochzeitsplanung, Synchronisation über Geräte und optionale E-Mail-Benachrichtigungen.
            </p>
            <p className="font-semibold text-[#0a253c]">
              Wir verkaufen niemals eure Daten. Niemals an Dritte. Niemals für Werbung.
            </p>
          </div>
        </div>

        <div>
          <h3 className="font-bold text-[#0a253c] mb-3">Wo eure Daten gespeichert werden</h3>
          <p className="text-gray-700 text-sm leading-relaxed">
            Alle Daten werden verschlüsselt auf sicheren Servern in der Europäischen Union gespeichert. Wir nutzen Supabase als DSGVO-konforme Datenbank-Infrastruktur mit Hosting in Deutschland.
          </p>
        </div>

        <div>
          <h3 className="font-bold text-[#0a253c] mb-3">Eure Rechte</h3>
          <div className="space-y-2 text-gray-700 text-sm">
            <p className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span><span className="font-semibold">Auskunft:</span> Ihr könnt jederzeit eine Übersicht eurer gespeicherten Daten anfordern</span>
            </p>
            <p className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span><span className="font-semibold">Export:</span> Alle Daten als PDF oder CSV herunterladen</span>
            </p>
            <p className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span><span className="font-semibold">Löschung:</span> Account und alle Daten mit einem Klick komplett löschen</span>
            </p>
            <p className="flex items-start gap-2">
              <CheckCircle className="w-4 h-4 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span><span className="font-semibold">Korrektur:</span> Jederzeit alle Daten selbst bearbeiten oder löschen</span>
            </p>
          </div>
        </div>

        <div>
          <h3 className="font-bold text-[#0a253c] mb-3">Cookies & Tracking</h3>
          <p className="text-gray-700 text-sm leading-relaxed">
            Wir verwenden nur technisch notwendige Cookies für Login und Session-Management. Keine Tracking-Cookies, keine Analytics-Tools von Drittanbietern, kein Profiling. Eure Privatsphäre bleibt geschützt.
          </p>
        </div>
      </div>

      <div className="bg-[#f7f2eb] rounded-xl p-6">
        <h3 className="font-bold text-[#0a253c] mb-3">Eure Daten exportieren</h3>
        <p className="text-gray-700 text-sm leading-relaxed mb-4">
          Ihr könnt jederzeit alle eure Daten als strukturierte Datei herunterladen. Diese enthält alle Informationen zu eurer Hochzeit, Gästen, Budget und Aufgaben.
        </p>
        <button
          onClick={() => emitModalEvent('modal:privacy:download')}
          className="flex items-center gap-2 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] hover:from-[#f4d03f] hover:to-[#d4af37] text-[#0a253c] px-6 py-3 rounded-full font-bold transition-all"
        >
          <Download className="w-5 h-5" />
          Datenexport anfordern
        </button>
      </div>

      <div className="border-t border-gray-200 pt-6">
        <p className="text-gray-600 text-xs leading-relaxed">
          Diese Zusammenfassung gibt einen Überblick über unsere Datenschutzpraktiken. Die vollständige Datenschutzerklärung mit allen rechtlichen Details findet ihr in den Einstellungen nach dem Login. Bei Fragen erreicht ihr uns unter: datenschutz@traumtag-helden.de
        </p>
      </div>
    </div>
  );
}
