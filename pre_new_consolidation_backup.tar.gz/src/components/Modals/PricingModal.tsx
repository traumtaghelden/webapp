import { Check, Crown, Sparkles } from 'lucide-react';
import { emitModalEvent, openModal } from '../../lib/modalManager';

export default function PricingModal() {
  return (
    <div className="space-y-6">
      <p className="text-gray-700 leading-relaxed">
        Wählt den Plan, der zu eurer Hochzeit passt. Beide Optionen bieten euch Struktur statt Stress – entscheidet selbst, wie viel Unterstützung ihr möchtet.
      </p>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="rounded-2xl border-2 border-gray-200 p-6 bg-white">
          <div className="mb-6">
            <h3 className="text-2xl font-bold text-[#0a253c] mb-2">Free</h3>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-4xl font-bold text-[#0a253c]">0€</span>
              <span className="text-gray-500">/ immer</span>
            </div>
            <p className="text-gray-600 text-sm">
              Perfekt für kleinere Hochzeiten und den Einstieg in die Planung.
            </p>
          </div>

          <ul className="space-y-3 mb-6">
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm">Bis zu 20 Aufgaben</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm">Bis zu 10 Budget-Einträge</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm">Bis zu 50 Gäste</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm">Bis zu 5 Dienstleister</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm">Basis-Timeline (5 Events)</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm">Dashboard & Fortschritts-Tracking</span>
            </li>
          </ul>

          <button
            onClick={() => openModal('start')}
            className="w-full border-2 border-[#d4af37] text-[#d4af37] px-6 py-3 rounded-full font-bold hover:bg-[#d4af37]/10 transition-all"
          >
            Kostenlos starten
          </button>
        </div>

        <div className="rounded-2xl border-2 border-[#d4af37] p-6 bg-gradient-to-br from-[#d4af37]/5 to-[#f4d03f]/5 relative overflow-hidden">
          <div className="absolute top-4 right-4">
            <div className="bg-[#d4af37] text-white text-xs font-bold px-3 py-1 rounded-full flex items-center gap-1">
              <Crown className="w-3 h-3" />
              PREMIUM
            </div>
          </div>

          <div className="mb-6">
            <h3 className="text-2xl font-bold text-[#0a253c] mb-2">Premium</h3>
            <div className="flex items-baseline gap-2 mb-4">
              <span className="text-4xl font-bold text-[#0a253c]">29,99€</span>
              <span className="text-gray-500">/ Monat</span>
            </div>
            <p className="text-gray-600 text-sm">
              Alles drin – kein Stress. Für große Hochzeiten und maximale Flexibilität.
            </p>
          </div>

          <ul className="space-y-3 mb-6">
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Unbegrenzte Aufgaben</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Unbegrenzte Budget-Einträge</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Unbegrenzte Gäste</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Unbegrenzte Dienstleister</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Unbegrenzte Timeline-Events</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Block-Planung für Timeline</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Erweiterte Budget-Analysen</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Zahlungspläne & Reminder</span>
            </li>
            <li className="flex items-start gap-3">
              <Check className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
              <span className="text-gray-700 text-sm font-semibold">Priority Support</span>
            </li>
          </ul>

          <button
            onClick={() => emitModalEvent('modal:pricing:upgrade')}
            className="w-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] hover:from-[#f4d03f] hover:to-[#d4af37] text-[#0a253c] px-6 py-3 rounded-full font-bold transition-all shadow-lg"
          >
            Jetzt upgraden
          </button>
        </div>
      </div>

      <div className="bg-[#f7f2eb] rounded-xl p-6">
        <div className="flex items-start gap-3">
          <Sparkles className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-1" />
          <div>
            <h4 className="font-bold text-[#0a253c] mb-2">Warum Premium?</h4>
            <p className="text-gray-700 text-sm leading-relaxed mb-3">
              Premium gibt euch die Freiheit, eure Hochzeit so zu planen, wie ihr es euch vorstellt – ohne Limits und mit allen Features. Ihr könnt jederzeit upgraden oder kündigen.
            </p>
            <button
              onClick={() => openModal('features')}
              className="text-[#d4af37] hover:text-[#c19a2e] font-semibold text-sm transition-colors"
            >
              Alle Features im Detail →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
