import { useState } from 'react';
import { Mail, Lock, User, LogIn, UserPlus, AlertCircle, Eye, EyeOff } from 'lucide-react';
import { openModal } from '../../lib/modalManager';

declare global {
  interface Window {
    auth?: {
      login?: (data: { email: string; password: string }) => Promise<void>;
      register?: (data: { email: string; password: string; name?: string }) => Promise<void>;
    };
  }
}

export default function LoginModal() {
  const [activeTab, setActiveTab] = useState<'login' | 'register'>('login');
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    acceptTerms: false,
  });
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const validateEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const validateForm = (): boolean => {
    const errors: Record<string, string> = {};

    if (!formData.email) {
      errors.email = 'E-Mail ist erforderlich';
    } else if (!validateEmail(formData.email)) {
      errors.email = 'Bitte gültige E-Mail-Adresse eingeben';
    }

    if (!formData.password) {
      errors.password = 'Passwort ist erforderlich';
    } else if (formData.password.length < 8) {
      errors.password = 'Passwort muss mindestens 8 Zeichen lang sein';
    }

    if (activeTab === 'register' && !formData.acceptTerms) {
      errors.acceptTerms = 'Bitte akzeptiere die AGB und Datenschutzerklärung';
    }

    setFieldErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setFieldErrors({});

    if (!validateForm()) {
      return;
    }

    setLoading(true);

    try {
      if (activeTab === 'login') {
        if (window.auth?.login) {
          await window.auth.login({
            email: formData.email,
            password: formData.password,
          });
        } else {
          window.dispatchEvent(
            new CustomEvent('auth:login', {
              detail: {
                email: formData.email,
                password: formData.password,
              },
            })
          );
        }
      } else {
        if (window.auth?.register) {
          await window.auth.register({
            email: formData.email,
            password: formData.password,
            name: formData.name || undefined,
          });
        } else {
          window.dispatchEvent(
            new CustomEvent('auth:register', {
              detail: {
                email: formData.email,
                password: formData.password,
                name: formData.name || undefined,
              },
            })
          );
        }
      }
    } catch (err) {
      setError(
        err instanceof Error ? err.message : 'Ein Fehler ist aufgetreten. Bitte versuche es erneut.'
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex gap-1 sm:gap-2 p-1 bg-gray-100 rounded-xl" role="tablist">
        <button
          role="tab"
          aria-selected={activeTab === 'login'}
          aria-controls="login-panel"
          onClick={() => {
            setActiveTab('login');
            setError('');
            setFieldErrors({});
          }}
          className={`flex-1 px-4 sm:px-6 py-2.5 sm:py-3 rounded-lg text-sm sm:text-base font-semibold transition-all touch-manipulation ${
            activeTab === 'login'
              ? 'bg-white text-[#0a253c] shadow-sm'
              : 'text-gray-600 hover:text-[#0a253c]'
          }`}
        >
          <LogIn className="w-4 h-4 inline-block mr-2" />
          Anmelden
        </button>
        <button
          role="tab"
          aria-selected={activeTab === 'register'}
          aria-controls="register-panel"
          onClick={() => {
            setActiveTab('register');
            setError('');
            setFieldErrors({});
          }}
          className={`flex-1 px-4 sm:px-6 py-2.5 sm:py-3 rounded-lg text-sm sm:text-base font-semibold transition-all touch-manipulation ${
            activeTab === 'register'
              ? 'bg-white text-[#0a253c] shadow-sm'
              : 'text-gray-600 hover:text-[#0a253c]'
          }`}
        >
          <UserPlus className="w-4 h-4 inline-block mr-2" />
          Registrieren
        </button>
      </div>

      <form
        onSubmit={handleSubmit}
        className="space-y-3 sm:space-y-4"
        role="tabpanel"
        id={activeTab === 'login' ? 'login-panel' : 'register-panel'}
        data-auth-form={activeTab}
      >
        {activeTab === 'register' && (
          <div>
            <label htmlFor="name" className="block text-sm sm:text-base font-semibold text-[#333333] mb-1.5 sm:mb-2">
              Name (optional)
            </label>
            <div className="relative">
              <User className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                id="name"
                name="name"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                data-auth-field="name"
                className="w-full pl-10 pr-4 py-3 sm:py-3.5 text-base rounded-xl border-2 border-gray-200 focus:border-[#d4af37] focus:outline-none transition-all touch-manipulation"
                placeholder="Euer Name"
              />
            </div>
          </div>
        )}

        <div>
          <label htmlFor="email" className="block text-sm sm:text-base font-semibold text-[#333333] mb-1.5 sm:mb-2">
            E-Mail *
          </label>
          <div className="relative">
            <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type="email"
              id="email"
              name="email"
              value={formData.email}
              onChange={(e) => {
                setFormData({ ...formData, email: e.target.value });
                if (fieldErrors.email) {
                  setFieldErrors({ ...fieldErrors, email: '' });
                }
              }}
              data-auth-field="email"
              aria-invalid={!!fieldErrors.email}
              aria-describedby={fieldErrors.email ? 'email-error' : undefined}
              className={`w-full pl-10 pr-4 py-3 sm:py-3.5 text-base rounded-xl border-2 ${
                fieldErrors.email ? 'border-red-500' : 'border-gray-200'
              } focus:border-[#d4af37] focus:outline-none transition-all`}
              placeholder="eure@email.de"
              required
            />
          </div>
          {fieldErrors.email && (
            <p id="email-error" className="mt-1 text-sm text-red-600 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" />
              {fieldErrors.email}
            </p>
          )}
        </div>

        <div>
          <label htmlFor="password" className="block text-sm sm:text-base font-semibold text-[#333333] mb-1.5 sm:mb-2">
            Passwort *
          </label>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
            <input
              type={showPassword ? 'text' : 'password'}
              id="password"
              name="password"
              value={formData.password}
              onChange={(e) => {
                setFormData({ ...formData, password: e.target.value });
                if (fieldErrors.password) {
                  setFieldErrors({ ...fieldErrors, password: '' });
                }
              }}
              data-auth-field="password"
              aria-invalid={!!fieldErrors.password}
              aria-describedby={fieldErrors.password ? 'password-error' : undefined}
              className={`w-full pl-10 pr-12 py-3 sm:py-3.5 text-base rounded-xl border-2 ${
                fieldErrors.password ? 'border-red-500' : 'border-gray-200'
              } focus:border-[#d4af37] focus:outline-none transition-all`}
              placeholder="Mindestens 8 Zeichen"
              required
              minLength={8}
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 active:text-gray-700 transition-colors touch-manipulation p-1"
              aria-label={showPassword ? 'Passwort verbergen' : 'Passwort anzeigen'}
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
          {fieldErrors.password && (
            <p id="password-error" className="mt-1 text-sm text-red-600 flex items-center gap-1">
              <AlertCircle className="w-4 h-4" />
              {fieldErrors.password}
            </p>
          )}
        </div>

        {activeTab === 'register' && (
          <div className="flex items-start gap-2 sm:gap-3">
            <input
              type="checkbox"
              id="acceptTerms"
              name="acceptTerms"
              checked={formData.acceptTerms}
              onChange={(e) => {
                setFormData({ ...formData, acceptTerms: e.target.checked });
                if (fieldErrors.acceptTerms) {
                  setFieldErrors({ ...fieldErrors, acceptTerms: '' });
                }
              }}
              data-auth-field="acceptTerms"
              aria-invalid={!!fieldErrors.acceptTerms}
              aria-describedby={fieldErrors.acceptTerms ? 'terms-error' : undefined}
              className="mt-1 w-5 h-5 sm:w-5 sm:h-5 rounded border-gray-300 text-[#d4af37] focus:ring-[#d4af37] touch-manipulation"
              required
            />
            <div className="flex-1">
              <label htmlFor="acceptTerms" className="text-sm sm:text-base text-gray-700 leading-relaxed">
                Ich akzeptiere die{' '}
                <button
                  type="button"
                  className="text-[#d4af37] hover:text-[#c19a2e] active:text-[#a88529] underline touch-manipulation inline-block py-0.5"
                  onClick={(e) => {
                    e.preventDefault();
                    openModal('terms');
                  }}
                >
                  AGB
                </button>{' '}
                und{' '}
                <button
                  type="button"
                  className="text-[#d4af37] hover:text-[#c19a2e] active:text-[#a88529] underline touch-manipulation inline-block py-0.5"
                  onClick={(e) => {
                    e.preventDefault();
                    openModal('privacy');
                  }}
                >
                  Datenschutzerklärung
                </button>
              </label>
              {fieldErrors.acceptTerms && (
                <p id="terms-error" className="mt-1 text-sm text-red-600 flex items-center gap-1">
                  <AlertCircle className="w-4 h-4" />
                  {fieldErrors.acceptTerms}
                </p>
              )}
            </div>
          </div>
        )}

        {error && (
          <div className="flex items-start gap-2 sm:gap-3 p-3 sm:p-4 bg-red-50 border border-red-200 rounded-xl" role="alert">
            <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
            <p className="text-red-800 text-sm">{error}</p>
          </div>
        )}

        <button
          type="submit"
          disabled={loading}
          data-auth-action={activeTab}
          className="w-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] hover:from-[#f4d03f] hover:to-[#d4af37] active:scale-98 text-[#0a253c] px-6 py-4 sm:py-4.5 rounded-xl text-base sm:text-lg font-bold transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed touch-manipulation"
        >
          {loading ? (
            <span className="flex items-center justify-center gap-2">
              <span className="w-5 h-5 border-2 border-[#0a253c] border-t-transparent rounded-full animate-spin"></span>
              {activeTab === 'login' ? 'Wird eingeloggt...' : 'Wird erstellt...'}
            </span>
          ) : activeTab === 'login' ? (
            <>
              <LogIn className="w-5 h-5 inline-block mr-2" />
              Jetzt anmelden
            </>
          ) : (
            <>
              <UserPlus className="w-5 h-5 inline-block mr-2" />
              Account erstellen
            </>
          )}
        </button>
      </form>

      {activeTab === 'login' && (
        <div className="text-center">
          <button
            type="button"
            className="text-[#d4af37] hover:text-[#c19a2e] active:text-[#a88529] text-sm sm:text-base font-semibold transition-colors touch-manipulation py-2"
            onClick={(e) => {
              e.preventDefault();
              window.dispatchEvent(new CustomEvent('auth:password-reset'));
            }}
          >
            Passwort vergessen?
          </button>
        </div>
      )}

      <div className="bg-[#f7f2eb] rounded-xl p-3 sm:p-4">
        <p className="text-gray-600 text-xs sm:text-sm text-center leading-relaxed">
          {activeTab === 'login'
            ? 'Noch kein Account? Wechsle zum Tab "Registrieren" oben.'
            : 'Deine Daten werden verschlüsselt und sicher in der EU gespeichert. DSGVO-konform.'}
        </p>
      </div>
    </div>
  );
}
