import { ReactNode, useEffect, useRef } from 'react';
import { X } from 'lucide-react';
import { handleModalKeyDown } from '../../lib/modalManager';
import { scrollToShowModal, disableBodyScroll, enableBodyScroll } from '../../utils/modalHelpers';

interface ModalContainerProps {
  children: ReactNode;
  onClose: () => void;
  title: string;
  maxWidth?: 'sm' | 'md' | 'lg' | 'xl' | '2xl';
}

export default function ModalContainer({ children, onClose, title, maxWidth = 'lg' }: ModalContainerProps) {
  const modalRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (modalRef.current) {
        handleModalKeyDown(e, modalRef.current);
      }
    };

    document.addEventListener('keydown', handleKeyDown);

    // Ensure modal is fully visible
    scrollToShowModal();
    disableBodyScroll();

    return () => {
      document.removeEventListener('keydown', handleKeyDown);
      enableBodyScroll();
    };
  }, []);

  const maxWidthClasses = {
    sm: 'max-w-sm',
    md: 'max-w-md',
    lg: 'max-w-lg',
    xl: 'max-w-xl',
    '2xl': 'max-w-2xl',
  };

  return (
    <div
      ref={modalRef}
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className={`fixed inset-0 sm:left-1/2 sm:top-1/2 sm:-translate-x-1/2 sm:-translate-y-1/2 w-full sm:w-auto ${maxWidthClasses[maxWidth]} sm:mx-auto p-0 sm:p-4 md:p-6 z-[9999]`}
    >
      <div className="bg-white h-full sm:h-auto sm:rounded-2xl shadow-2xl sm:max-h-[90vh] overflow-hidden modal-modern" style={{ willChange: 'transform' }}>
        <div className="flex items-center justify-between p-4 sm:p-6 border-b border-gray-200 sticky top-0 bg-white z-10" style={{ backfaceVisibility: 'hidden' }}>
          <h2 id="modal-title" className="text-lg sm:text-xl md:text-2xl font-bold text-[#0a253c] pr-2">
            {title}
          </h2>
          <button
            onClick={onClose}
            className="p-2 sm:p-2.5 rounded-full hover:bg-gray-100 active:bg-gray-200 transition-colors touch-manipulation flex-shrink-0"
            aria-label="Modal schließen"
          >
            <X className="w-6 h-6 sm:w-6 sm:h-6 text-gray-600" />
          </button>
        </div>

        <div className="overflow-y-auto h-[calc(100vh-4.5rem)] sm:h-auto sm:max-h-[calc(90vh-5rem)] p-4 sm:p-6" style={{ WebkitOverflowScrolling: 'touch', overscrollBehavior: 'contain' }}>
          {children}
        </div>
      </div>
    </div>
  );
}
