import { useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface CharacterSelectorProps {
  characters: { id: string; image: string; label: string }[];
  selectedCharacterId: string;
  onSelect: (characterId: string) => void;
  label: string;
  name: string;
  onNameChange: (name: string) => void;
}

export default function CharacterSelector({
  characters,
  selectedCharacterId,
  onSelect,
  label,
  name,
  onNameChange,
}: CharacterSelectorProps) {
  const [showSelector, setShowSelector] = useState(false);
  const currentIndex = characters.findIndex((c) => c.id === selectedCharacterId);
  const selectedCharacter = characters[currentIndex] || characters[0];

  const handlePrevious = () => {
    const newIndex = currentIndex > 0 ? currentIndex - 1 : characters.length - 1;
    onSelect(characters[newIndex].id);
  };

  const handleNext = () => {
    const newIndex = (currentIndex + 1) % characters.length;
    onSelect(characters[newIndex].id);
  };

  return (
    <div className="space-y-3">
      <label className="block text-sm font-semibold text-[#f7f2eb] mb-2">{label}</label>

      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={handlePrevious}
          className="p-2 rounded-full bg-[#d4af37]/20 hover:bg-[#d4af37]/30 transition-all flex-shrink-0"
        >
          <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
        </button>

        <div className="flex-1 relative">
          <div
            onClick={() => setShowSelector(!showSelector)}
            className="cursor-pointer p-4 rounded-xl bg-white hover:bg-[#f7f2eb] transition-all border-2 border-[#d4af37]/30"
          >
            <div className="flex items-center gap-4">
              <img
                src={selectedCharacter.image}
                alt={selectedCharacter.label}
                className="w-16 h-16 object-contain"
              />
              <div className="flex-1">
                <p className="text-sm font-semibold text-[#d4af37]">{selectedCharacter.label}</p>
                <input
                  type="text"
                  value={name}
                  onChange={(e) => onNameChange(e.target.value)}
                  onClick={(e) => e.stopPropagation()}
                  className="w-full mt-1 px-3 py-2 rounded-lg border border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c]"
                  placeholder="Name eingeben (optional)"
                />
              </div>
            </div>
          </div>

          {showSelector && (
            <div className="absolute z-10 mt-2 w-full bg-white rounded-xl shadow-2xl border-2 border-[#d4af37] p-4 max-h-80 overflow-y-auto">
              <div className="grid grid-cols-2 gap-3">
                {characters.map((character) => (
                  <button
                    key={character.id}
                    type="button"
                    onClick={() => {
                      onSelect(character.id);
                      setShowSelector(false);
                    }}
                    className={`p-3 rounded-xl transition-all ${
                      selectedCharacterId === character.id
                        ? 'bg-[#d4af37] ring-2 ring-[#d4af37]'
                        : 'bg-[#f7f2eb] hover:bg-[#d4af37]/20'
                    }`}
                  >
                    <img
                      src={character.image}
                      alt={character.label}
                      className="w-20 h-20 object-contain mx-auto mb-2"
                    />
                    <p className={`text-xs font-semibold text-center ${
                      selectedCharacterId === character.id ? 'text-white' : 'text-[#0a253c]'
                    }`}>
                      {character.label}
                    </p>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>

        <button
          type="button"
          onClick={handleNext}
          className="p-2 rounded-full bg-[#d4af37]/20 hover:bg-[#d4af37]/30 transition-all flex-shrink-0"
        >
          <ChevronRight className="w-5 h-5 text-[#d4af37]" />
        </button>
      </div>
    </div>
  );
}
