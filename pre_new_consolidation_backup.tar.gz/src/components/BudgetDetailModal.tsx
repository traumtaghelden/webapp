import { useState, useEffect } from 'react';
import { createPortal } from 'react-dom';
import { DollarSign, Calendar, FileText, Upload, Download, Trash2, Plus, Edit2, Check, Users, Building2, Percent, Tag, CreditCard, Receipt, CheckCircle, Clock, Save, History, X } from 'lucide-react';
import { supabase, type BudgetItem, type BudgetPayment, type BudgetAttachment, type BudgetPartnerSplit, type BudgetTag, type Vendor } from '../lib/supabase';
import StandardModal, { ModalFooter, ModalButton } from './StandardModal';
import ModalInput from './ModalInput';
import ModalConfirm from './ModalConfirm';
import BudgetItemProKopfForm from './BudgetItemProKopfForm';
import PaymentPlanModal from './PaymentPlanModal';
import ManualPaymentToggle from './ManualPaymentToggle';
import { BUDGET, COMMON } from '../constants/terminology';

interface BudgetDetailModalProps {
  isOpen: boolean;
  budgetItemId: string;
  weddingId: string;
  onClose: () => void;
  onUpdate: () => void;
}

type TabType = 'overview' | 'payments' | 'attachments' | 'splits' | 'tags' | 'history';

const getCategoryTranslation = (category: string): string => {
  const translations: Record<string, string> = {
    venue: 'Location',
    catering: 'Catering',
    decoration: 'Dekoration',
    music: 'Musik',
    photography: 'Fotografie',
    flowers: 'Blumen',
    dress: 'Kleid',
    rings: 'Ringe',
    invitations: 'Einladungen',
    other: 'Sonstiges',
  };
  return translations[category.toLowerCase()] || category;
};

interface TimelineEvent {
  id: string;
  title: string;
  time: string;
  event_type: string;
}

export default function BudgetDetailModal({ isOpen, budgetItemId, weddingId, onClose, onUpdate }: BudgetDetailModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [budgetItem, setBudgetItem] = useState<BudgetItem | null>(null);
  const [payments, setPayments] = useState<BudgetPayment[]>([]);
  const [attachments, setAttachments] = useState<BudgetAttachment[]>([]);
  const [partnerSplits, setPartnerSplits] = useState<BudgetPartnerSplit[]>([]);
  const [itemTags, setItemTags] = useState<string[]>([]);
  const [availableTags, setAvailableTags] = useState<BudgetTag[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([]);
  const [historyEntries, setHistoryEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [editMode, setEditMode] = useState(false);
  const [uploading, setUploading] = useState(false);

  const [editedItem, setEditedItem] = useState<Partial<BudgetItem>>({});
  const [showAddPaymentModal, setShowAddPaymentModal] = useState(false);
  const [showDeletePaymentConfirm, setShowDeletePaymentConfirm] = useState<string | null>(null);
  const [showDeleteAttachmentConfirm, setShowDeleteAttachmentConfirm] = useState<{ id: string; url: string } | null>(null);
  const [animatingPayment, setAnimatingPayment] = useState<string | null>(null);
  const [showPaymentPlanModal, setShowPaymentPlanModal] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen, budgetItemId]);

  const updateBudgetItemPaymentStatus = async () => {
    try {
      const { data: paymentsData } = await supabase
        .from('budget_payments')
        .select('*')
        .eq('budget_item_id', budgetItemId);

      if (paymentsData && budgetItem) {
        const totalPaid = paymentsData
          .filter(p => p.status === 'paid')
          .reduce((sum, p) => sum + p.amount, 0);

        let newPaymentStatus: 'pending' | 'partial' | 'paid' | 'overdue' = 'pending';

        if (totalPaid >= budgetItem.actual_cost) {
          newPaymentStatus = 'paid';
        } else if (totalPaid > 0) {
          newPaymentStatus = 'partial';
        } else {
          const hasOverduePayments = paymentsData.some(p => p.status === 'overdue');
          newPaymentStatus = hasOverduePayments ? 'overdue' : 'pending';
        }

        await supabase
          .from('budget_items')
          .update({
            payment_status: newPaymentStatus,
            paid: newPaymentStatus === 'paid'
          })
          .eq('id', budgetItemId);
      }
    } catch (error) {
      console.error('Error updating budget item payment status:', error);
    }
  };

  const loadData = async () => {
    try {
      const [itemData, paymentsData, attachmentsData, splitsData, tagsData, vendorsData, timelineData, historyData] = await Promise.all([
        supabase.from('budget_items').select('*').eq('id', budgetItemId).maybeSingle(),
        supabase.from('budget_payments').select('*').eq('budget_item_id', budgetItemId).order('due_date', { ascending: true }),
        supabase.from('budget_attachments').select('*').eq('budget_item_id', budgetItemId).order('created_at', { ascending: false }),
        supabase.from('budget_partner_splits').select('*').eq('budget_item_id', budgetItemId),
        supabase.from('budget_tags').select('*').eq('wedding_id', weddingId),
        supabase.from('vendors').select('*').eq('wedding_id', weddingId),
        supabase.from('wedding_timeline').select('id, title, time, event_type').eq('wedding_id', weddingId).order('time', { ascending: true }),
        supabase.from('budget_history').select('*').eq('budget_item_id', budgetItemId).order('created_at', { ascending: false }).limit(50),
      ]);

      if (itemData.data) {
        setBudgetItem(itemData.data);
        setEditedItem(itemData.data);
      }
      if (paymentsData.data) setPayments(paymentsData.data);
      if (attachmentsData.data) setAttachments(attachmentsData.data);
      if (splitsData.data) setPartnerSplits(splitsData.data);
      if (tagsData.data) setAvailableTags(tagsData.data);
      if (vendorsData.data) setVendors(vendorsData.data);
      if (timelineData.data) setTimelineEvents(timelineData.data);
      if (historyData.data) setHistoryEntries(historyData.data);

      const { data: itemTagsData } = await supabase
        .from('budget_item_tags')
        .select('tag_id')
        .eq('budget_item_id', budgetItemId);

      if (itemTagsData) {
        setItemTags(itemTagsData.map(t => t.tag_id));
      }
    } catch (error) {
      console.error('Error loading budget details:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleProKopfChange = (data: {
    is_per_person: boolean;
    cost_per_person: number | null;
    use_confirmed_guests_only: boolean;
    guest_count_override: number | null;
  }) => {
    setEditedItem({
      ...editedItem,
      is_per_person: data.is_per_person,
      cost_per_person: data.cost_per_person,
      use_confirmed_guests_only: data.use_confirmed_guests_only,
      guest_count_override: data.guest_count_override,
    });
  };

  const handleSave = async () => {
    if (!budgetItem) return;

    try {
      await supabase
        .from('budget_items')
        .update(editedItem)
        .eq('id', budgetItemId);

      setBudgetItem({ ...budgetItem, ...editedItem });
      setEditMode(false);
      onUpdate();
    } catch (error) {
      console.error('Error updating budget item:', error);
    }
  };

  const handleAddPayment = async (amount: string) => {
    if (!amount) return;

    try {
      await supabase.from('budget_payments').insert([{
        budget_item_id: budgetItemId,
        amount: parseFloat(amount),
        status: 'pending',
        payment_method: 'bank_transfer',
      }]);
      loadData();
    } catch (error) {
      console.error('Error adding payment:', error);
    }
  };

  const handleUpdatePaymentStatus = async (paymentId: string, status: string) => {
    try {
      await supabase
        .from('budget_payments')
        .update({
          status,
          payment_date: status === 'paid' ? new Date().toISOString().split('T')[0] : null
        })
        .eq('id', paymentId);

      await updateBudgetItemPaymentStatus();
      loadData();
      onUpdate();
    } catch (error) {
      console.error('Error updating payment:', error);
    }
  };

  const handleDeletePayment = async () => {
    if (!showDeletePaymentConfirm) return;

    try {
      await supabase.from('budget_payments').delete().eq('id', showDeletePaymentConfirm);
      loadData();
    } catch (error) {
      console.error('Error deleting payment:', error);
    }
  };

  const handlePaymentPlanConfirm = async (installments: Array<{ id: string; amount: string; dueDate: string; description: string }>) => {
    try {
      await supabase.from('budget_payments').delete().eq('budget_item_id', budgetItemId);

      const paymentsToInsert = installments.map(inst => ({
        budget_item_id: budgetItemId,
        amount: parseFloat(inst.amount),
        due_date: inst.dueDate,
        payment_method: 'bank_transfer',
        status: 'pending' as const,
        notes: inst.description,
      }));

      await supabase.from('budget_payments').insert(paymentsToInsert);

      await loadData();
      await updateBudgetItemPaymentStatus();
    } catch (error) {
      console.error('Error saving payment plan:', error);
      alert('Fehler beim Speichern des Zahlungsplans');
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const fileExt = file.name.split('.').pop();
      const fileName = `${budgetItemId}/${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('budget-attachments')
        .upload(fileName, file);

      if (uploadError) {
        if (uploadError.message?.includes('Bucket not found')) {
          alert('Der Datei-Upload ist noch nicht konfiguriert. Bitte erstellen Sie den Storage-Bucket "budget-attachments" in Ihrem Supabase Dashboard.');
          return;
        }
        throw uploadError;
      }

      const { data: { publicUrl } } = supabase.storage
        .from('budget-attachments')
        .getPublicUrl(fileName);

      const { data: { user } } = await supabase.auth.getUser();

      await supabase.from('budget_attachments').insert([{
        budget_item_id: budgetItemId,
        file_name: file.name,
        file_url: publicUrl,
        file_size: file.size,
        file_type: file.type,
        attachment_type: 'other',
        uploaded_by: user?.id,
      }]);

      loadData();
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Fehler beim Hochladen der Datei');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteAttachment = async () => {
    if (!showDeleteAttachmentConfirm) return;

    try {
      const fileName = showDeleteAttachmentConfirm.url.split('/').slice(-2).join('/');
      await supabase.storage.from('budget-attachments').remove([fileName]);
      await supabase.from('budget_attachments').delete().eq('id', showDeleteAttachmentConfirm.id);
      loadData();
    } catch (error) {
      console.error('Error deleting attachment:', error);
    }
  };

  const handleToggleTag = async (tagId: string) => {
    try {
      if (itemTags.includes(tagId)) {
        await supabase
          .from('budget_item_tags')
          .delete()
          .eq('budget_item_id', budgetItemId)
          .eq('tag_id', tagId);
        setItemTags(itemTags.filter(t => t !== tagId));
      } else {
        await supabase
          .from('budget_item_tags')
          .insert([{ budget_item_id: budgetItemId, tag_id: tagId }]);
        setItemTags([...itemTags, tagId]);
      }
    } catch (error) {
      console.error('Error toggling tag:', error);
    }
  };

  const handleUpdateSplit = async (splitId: string, field: string, value: number) => {

    try {
      await supabase
        .from('budget_partner_splits')
        .update({ [field]: value })
        .eq('id', splitId);
      loadData();
    } catch (error) {
      console.error('Error updating split:', error);
    }
  };

  const handleCreateSplits = async () => {

    if (!budgetItem) return;

    const totalCost = budgetItem.actual_cost || budgetItem.estimated_cost;

    try {
      await supabase.from('budget_partner_splits').insert([
        {
          budget_item_id: budgetItemId,
          partner_type: 'partner_1',
          amount: totalCost / 2,
          percentage: 50,
          paid_amount: 0,
        },
        {
          budget_item_id: budgetItemId,
          partner_type: 'partner_2',
          amount: totalCost / 2,
          percentage: 50,
          paid_amount: 0,
        },
      ]);
      loadData();
    } catch (error) {
      console.error('Error creating splits:', error);
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999]">
        <div className="bg-white rounded-3xl p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#d4af37] mx-auto"></div>
        </div>
      </div>
    );
  }

  if (!budgetItem) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999]">
        <div className="bg-white rounded-3xl p-8">
          <p className="text-white">Budget-Posten nicht gefunden</p>
        </div>
      </div>
    );
  }

  const totalPaid = payments.filter(p => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0);
  const totalPending = payments.filter(p => p.status === 'pending' || p.status === 'overdue').reduce((sum, p) => sum + p.amount, 0);
  const remainingBalance = budgetItem.actual_cost - totalPaid;
  const selectedVendor = vendors.find(v => v.id === budgetItem.vendor_id);

  const calculateFinancials = (item: BudgetItem) => {
    const baseCost = item.actual_cost || item.estimated_cost;
    const taxAmount = baseCost * (item.tax_rate / 100);
    const totalWithTax = baseCost + taxAmount;

    return {
      baseCost,
      taxAmount,
      totalWithTax,
      netCost: baseCost,
      grossCost: totalWithTax
    };
  };

  const financials = calculateFinancials(budgetItem);

  const modalContent = (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-[9999] p-2 sm:p-4">
      <div className="bg-gradient-to-b from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-2xl sm:rounded-3xl shadow-gold-lg border-2 border-[#d4af37]/30 max-w-6xl w-full max-h-[95vh] sm:max-h-[90vh] flex flex-col relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyMTIsIDE3NSwgNTUsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20"></div>
        <div className="relative z-10 p-4 sm:p-6 border-b border-[#d4af37]/30">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 gap-3">
            <div className="flex items-center gap-2 sm:gap-3 pr-8 sm:pr-0">
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] rounded-xl blur-md opacity-60 animate-pulse"></div>
                <div className="relative bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center shadow-gold flex-shrink-0">
                  <DollarSign className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
                </div>
              </div>
              <div className="min-w-0">
                <h2 className="text-xl sm:text-2xl font-bold text-white">{budgetItem.item_name}</h2>
                <p className="text-xs sm:text-sm text-white/70">Kategorie: {getCategoryTranslation(budgetItem.category)}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!editMode && (
                <button
                  onClick={() => setEditMode(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c19a2e] transition-all shadow-lg"
                >
                  <Edit2 className="w-4 h-4" />
                  Bearbeiten
                </button>
              )}
              {editMode && (
                <>
                  <button
                    onClick={handleSave}
                    className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 transition-all"
                  >
                    <Save className="w-4 h-4" />
                    Speichern
                  </button>
                  <button
                    onClick={() => {
                      setEditMode(false);
                      setEditedItem(budgetItem);
                    }}
                    className="px-4 py-2 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-bold hover:bg-[#d4af37]/10 transition-all"
                  >
                    Abbrechen
                  </button>
                </>
              )}
              <button
                onClick={onClose}
                className="p-1.5 sm:p-2 hover:bg-white/10 rounded-full transition-all hover:scale-110 absolute top-3 right-3 sm:static"
              >
                <X className="w-5 h-5 sm:w-6 sm:h-6 text-white/80 hover:text-white" />
              </button>
            </div>
          </div>

          <div className="flex gap-1 sm:gap-2 overflow-x-auto -mx-4 px-4 sm:mx-0 sm:px-0 scrollbar-hide">
            {[
              { id: 'overview', label: 'Übersicht', icon: FileText },
              { id: 'payments', label: 'Zahlungen', icon: CreditCard },
              { id: 'attachments', label: 'Anhänge', icon: Upload },
              { id: 'splits', label: 'Kostenteilung', icon: Users },
              { id: 'tags', label: 'Tags', icon: Tag },
              { id: 'history', label: 'Verlauf', icon: History },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as TabType)}
                className={`flex items-center gap-1 sm:gap-2 px-3 sm:px-4 py-2 rounded-xl font-bold transition-all whitespace-nowrap text-xs sm:text-sm ${
                  activeTab === tab.id
                    ? 'bg-[#d4af37] text-white shadow-lg'
                    : 'bg-white/10 text-white/70 hover:bg-white/20 hover:text-white'
                }`}
              >
                <tab.icon className="w-3 h-3 sm:w-4 sm:h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        <div className="relative z-10 flex-1 overflow-y-auto p-4 sm:p-6">
          {activeTab === 'overview' && (
            <div className="space-y-4 sm:space-y-6">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                <div className="bg-gradient-to-br from-[#d4af37]/10 to-[#f4d03f]/10 rounded-2xl p-5 border-2 border-[#d4af37]/30 hover:shadow-lg transition-all">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className="p-2 bg-[#d4af37]/20 rounded-lg">
                        <DollarSign className="w-5 h-5 text-[#d4af37]" />
                      </div>
                      <span className="text-xs font-bold text-white/60 uppercase tracking-wide">Kosten</span>
                    </div>
                  </div>
                  {editMode ? (
                    <div className="relative">
                      <input
                        type="number"
                        value={editedItem.actual_cost || 0}
                        onChange={(e) => {
                          const value = parseFloat(e.target.value) || 0;
                          setEditedItem({ ...editedItem, actual_cost: value, estimated_cost: value });
                        }}
                        className="w-full px-4 py-2 text-2xl font-bold text-white bg-white rounded-xl border-2 border-[#d4af37]/50 focus:border-[#d4af37] focus:outline-none transition-all"
                        step="0.01"
                        min="0"
                      />
                      <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white/60 font-semibold">€</span>
                    </div>
                  ) : (
                    <p className="text-3xl font-bold text-white">
                      {budgetItem.actual_cost.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {budgetItem.currency}
                    </p>
                  )}
                </div>

                <div className={`bg-gradient-to-br rounded-2xl p-5 border-2 hover:shadow-lg transition-all ${
                  budgetItem.payment_status === 'paid' ? 'from-green-50 to-green-100 border-green-300' :
                  budgetItem.payment_status === 'overdue' ? 'from-red-50 to-red-100 border-red-300' :
                  budgetItem.payment_status === 'partial' ? 'from-blue-50 to-blue-100 border-blue-300' :
                  'from-yellow-50 to-yellow-100 border-yellow-300'
                }`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-lg ${
                        budgetItem.payment_status === 'paid' ? 'bg-green-200' :
                        budgetItem.payment_status === 'overdue' ? 'bg-red-200' :
                        budgetItem.payment_status === 'partial' ? 'bg-blue-200' :
                        'bg-yellow-200'
                      }`}>
                        <CheckCircle className={`w-5 h-5 ${
                          budgetItem.payment_status === 'paid' ? 'text-green-700' :
                          budgetItem.payment_status === 'overdue' ? 'text-red-700' :
                          budgetItem.payment_status === 'partial' ? 'text-blue-700' :
                          'text-yellow-700'
                        }`} />
                      </div>
                      <span className="text-xs font-bold text-white/60 uppercase tracking-wide">Bezahlt</span>
                    </div>
                    <span className={`px-2 py-1 rounded-full text-xs font-bold ${
                      budgetItem.payment_status === 'paid' ? 'bg-green-200 text-green-800' :
                      budgetItem.payment_status === 'overdue' ? 'bg-red-200 text-red-800' :
                      budgetItem.payment_status === 'partial' ? 'bg-blue-200 text-blue-800' :
                      'bg-yellow-200 text-yellow-800'
                    }`}>
                      {budgetItem.payment_status === 'paid' ? 'Vollständig' :
                       budgetItem.payment_status === 'overdue' ? 'Überfällig' :
                       budgetItem.payment_status === 'partial' ? 'Teilweise' : 'Ausstehend'}
                    </span>
                  </div>
                  <p className="text-3xl font-bold text-white">
                    {totalPaid.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {budgetItem.currency}
                  </p>
                  <div className="mt-2 w-full bg-white/50 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        budgetItem.payment_status === 'paid' ? 'bg-green-500' :
                        budgetItem.payment_status === 'overdue' ? 'bg-red-500' :
                        budgetItem.payment_status === 'partial' ? 'bg-blue-500' :
                        'bg-yellow-500'
                      }`}
                      style={{ width: `${Math.min((totalPaid / budgetItem.actual_cost) * 100, 100)}%` }}
                    />
                  </div>
                </div>

                <div className={`bg-gradient-to-br rounded-2xl p-5 border-2 hover:shadow-lg transition-all ${
                  remainingBalance === 0 ? 'from-green-50 to-green-100 border-green-300' :
                  remainingBalance < 0 ? 'from-blue-50 to-blue-100 border-blue-300' :
                  'from-red-50 to-red-100 border-red-300'
                }`}>
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center gap-2">
                      <div className={`p-2 rounded-lg ${
                        remainingBalance === 0 ? 'bg-green-200' :
                        remainingBalance < 0 ? 'bg-blue-200' :
                        'bg-red-200'
                      }`}>
                        <DollarSign className={`w-5 h-5 ${
                          remainingBalance === 0 ? 'text-green-700' :
                          remainingBalance < 0 ? 'text-blue-700' :
                          'text-red-700'
                        }`} />
                      </div>
                      <span className="text-xs font-bold text-white/60 uppercase tracking-wide">
                        {remainingBalance < 0 ? 'Überzahlt' : 'Restbetrag'}
                      </span>
                    </div>
                  </div>
                  <p className={`text-3xl font-bold ${
                    remainingBalance === 0 ? 'text-green-600' :
                    remainingBalance < 0 ? 'text-blue-600' :
                    'text-red-600'
                  }`}>
                    {Math.abs(remainingBalance).toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {budgetItem.currency}
                  </p>
                  {remainingBalance !== 0 && (
                    <p className="text-xs text-white/60 mt-2">
                      {remainingBalance < 0
                        ? `${Math.abs(remainingBalance).toLocaleString('de-DE', { minimumFractionDigits: 2 })} € zu viel gezahlt`
                        : `${Math.round((remainingBalance / budgetItem.actual_cost) * 100)}% noch offen`
                      }
                    </p>
                  )}
                </div>
              </div>

              <ManualPaymentToggle
                budgetItemId={budgetItem.id}
                isManuallyPaid={budgetItem.is_manually_paid || false}
                actualCost={budgetItem.actual_cost || 0}
                estimatedCost={budgetItem.estimated_cost || 0}
                onUpdate={async (isManuallyPaid) => {
                  await loadData();
                  onUpdate();
                }}
              />

              <div className="grid md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-sm font-semibold text-white/70 mb-2">Bezeichnung</label>
                  {editMode ? (
                    <input
                      type="text"
                      value={editedItem.item_name || ''}
                      onChange={(e) => setEditedItem({ ...editedItem, item_name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    />
                  ) : (
                    <p className="text-white font-semibold">{budgetItem.item_name}</p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-white/70 mb-2">Dienstleister</label>
                  {editMode ? (
                    <select
                      value={editedItem.vendor_id || ''}
                      onChange={(e) => setEditedItem({ ...editedItem, vendor_id: e.target.value || null })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    >
                      <option value="">Kein Dienstleister</option>
                      {vendors.map(v => (
                        <option key={v.id} value={v.id}>{v.name} - {v.category}</option>
                      ))}
                    </select>
                  ) : (
                    <p className="text-white">
                      {selectedVendor ? (
                        <span className="flex items-center gap-2">
                          <Building2 className="w-4 h-4 text-[#d4af37]" />
                          {selectedVendor.name}
                        </span>
                      ) : (
                        'Nicht zugewiesen'
                      )}
                    </p>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-white/70 mb-2 flex items-center gap-2">
                    <Clock className="w-4 h-4 text-[#d4af37]" />
                    Timeline-Event
                  </label>
                  {editMode ? (
                    <select
                      value={editedItem.timeline_event_id || ''}
                      onChange={(e) => setEditedItem({ ...editedItem, timeline_event_id: e.target.value || null })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    >
                      <option value="">Kein Event</option>
                      {timelineEvents.map(event => (
                        <option key={event.id} value={event.id}>
                          {event.time} - {event.title}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <p className="text-white">
                      {budgetItem?.timeline_event_id ? (
                        <span className="flex items-center gap-2">
                          <Clock className="w-4 h-4 text-[#d4af37]" />
                          {timelineEvents.find(e => e.id === budgetItem.timeline_event_id)?.title || 'Event nicht gefunden'}
                        </span>
                      ) : (
                        'Nicht verknüpft'
                      )}
                    </p>
                  )}
                </div>

                <div>
                  {(() => {
                    const nextPayment = payments
                      .filter(p => p.status !== 'paid')
                      .sort((a, b) => new Date(a.due_date).getTime() - new Date(b.due_date).getTime())[0];

                    const allPaid = payments.length > 0 && payments.every(p => p.status === 'paid');

                    return (
                      <>
                        <label className="block text-sm font-semibold text-white/70 mb-2">
                          {allPaid ? 'Zahlungsstatus' : 'Nächste Zahlung'}
                        </label>
                        {allPaid ? (
                          <div className="flex items-center gap-2">
                            <CheckCircle className="w-5 h-5 text-green-600" />
                            <p className="text-green-600 font-bold">Vollständig bezahlt</p>
                          </div>
                        ) : nextPayment ? (
                          <div className="space-y-1">
                            <p className="text-white font-bold">
                              {nextPayment.amount.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {budgetItem.currency}
                            </p>
                            <p className="text-sm text-white/60 flex items-center gap-1">
                              <Calendar className="w-3 h-3" />
                              Fällig am: {new Date(nextPayment.due_date).toLocaleDateString('de-DE')}
                            </p>
                            {nextPayment.notes && (
                              <p className="text-xs text-white/60">{nextPayment.notes}</p>
                            )}
                          </div>
                        ) : (
                          <p className="text-white/60">Keine offenen Zahlungen</p>
                        )}
                      </>
                    );
                  })()}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-white/70 mb-2">Notizen</label>
                {editMode ? (
                  <textarea
                    value={editedItem.notes || ''}
                    onChange={(e) => setEditedItem({ ...editedItem, notes: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    rows={4}
                    placeholder="Zusätzliche Informationen..."
                  />
                ) : (
                  <p className="text-white whitespace-pre-wrap">{budgetItem.notes || 'Keine Notizen'}</p>
                )}
              </div>

              {editMode && (
                <div className="relative">
                  <label className="block text-sm font-semibold text-white/70 mb-2">Pro-Kopf-Kalkulation</label>
                  <BudgetItemProKopfForm
                    weddingId={weddingId}
                    isPerPerson={editedItem.is_per_person || false}
                    costPerPerson={editedItem.cost_per_person || null}
                    useConfirmedGuestsOnly={editedItem.use_confirmed_guests_only || false}
                    guestCountOverride={editedItem.guest_count_override || null}
                    onChange={handleProKopfChange}
                  />
                </div>
              )}

              {!editMode && budgetItem.is_per_person && (
                <div className="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-200 rounded-xl p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Users className="w-5 h-5 text-purple-600" />
                    <h3 className="font-semibold text-white">Pro-Kopf-Kalkulation aktiv</h3>
                  </div>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div>
                      <p className="text-gray-600">Kosten pro Gast:</p>
                      <p className="font-bold text-white">{budgetItem.cost_per_person?.toFixed(2) || '0.00'}€</p>
                    </div>
                    <div>
                      <p className="text-gray-600">Gästeanzahl-Basis:</p>
                      <p className="font-bold text-white">
                        {budgetItem.guest_count_override
                          ? `${budgetItem.guest_count_override} (überschrieben)`
                          : budgetItem.use_confirmed_guests_only
                          ? 'Bestätigte Gäste'
                          : 'Geplante Gäste'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

            </div>
          )}

          {activeTab === 'payments' && (
            <div className="space-y-6 relative">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-white">Zahlungsplan</h3>
                  <p className="text-sm text-white/60 mt-1">
                    Erstelle individuelle Zahlungspläne mit Vorlagen
                  </p>
                </div>
                <button
                  onClick={() => setShowPaymentPlanModal(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c19a2e] transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                  {payments.length > 0 ? 'Zahlungsplan bearbeiten' : 'Zahlungsplan erstellen'}
                </button>
              </div>

              {payments.length > 0 && (
                <>
                  <div className="grid md:grid-cols-4 gap-4">
                    <div className="bg-green-50 rounded-xl p-4 border-2 border-green-200">
                      <p className="text-sm text-green-700 mb-1">Bezahlt</p>
                      <p className="text-2xl font-bold text-green-600">
                        {totalPaid.toLocaleString('de-DE')} {budgetItem.currency}
                      </p>
                    </div>
                    <div className="bg-yellow-50 rounded-xl p-4 border-2 border-yellow-200">
                      <p className="text-sm text-yellow-700 mb-1">Ausstehend</p>
                      <p className="text-2xl font-bold text-yellow-600">
                        {totalPending.toLocaleString('de-DE')} {budgetItem.currency}
                      </p>
                    </div>
                    <div className="bg-red-50 rounded-xl p-4 border-2 border-red-200">
                      <p className="text-sm text-red-700 mb-1">Restbetrag</p>
                      <p className="text-2xl font-bold text-red-600">
                        {remainingBalance.toLocaleString('de-DE', { maximumFractionDigits: 2 })} {budgetItem.currency}
                      </p>
                    </div>
                    <div className="bg-blue-50 rounded-xl p-4 border-2 border-blue-200">
                      <p className="text-sm text-blue-700 mb-1">Gesamt</p>
                      <p className="text-2xl font-bold text-blue-600">
                        {(totalPaid + totalPending).toLocaleString('de-DE')} {budgetItem.currency}
                      </p>
                    </div>
                  </div>

                  <div className="bg-white rounded-xl p-4 border-2 border-[#d4af37]/30">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-white/70 font-semibold">Zahlungsfortschritt</span>
                      <span className="text-[#d4af37] font-bold">
                        {Math.round((totalPaid / budgetItem.actual_cost) * 100)}%
                      </span>
                    </div>
                    <div className="w-full bg-white/10 rounded-full h-4 overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          (totalPaid / budgetItem.actual_cost) * 100 >= 100 ? 'bg-green-500' :
                          (totalPaid / budgetItem.actual_cost) * 100 >= 50 ? 'bg-yellow-500' :
                          'bg-red-500'
                        }`}
                        style={{ width: `${Math.min((totalPaid / budgetItem.actual_cost) * 100, 100)}%` }}
                      />
                    </div>
                  </div>
                </>
              )}

              <div className="space-y-3">
                {payments.map(payment => (
                  <div
                    key={payment.id}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      payment.status === 'paid' ? 'bg-green-50 border-green-200' :
                      payment.status === 'overdue' ? 'bg-red-50 border-red-200' :
                      'bg-white/10 border-[#d4af37]/30'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <p className="text-2xl font-bold text-white">
                            {payment.amount.toLocaleString('de-DE')} {budgetItem.currency}
                          </p>
                          {payment.due_date && (
                            <div className="flex items-center gap-1 text-sm text-white/70">
                              <Calendar className="w-4 h-4" />
                              {new Date(payment.due_date).toLocaleDateString('de-DE')}
                            </div>
                          )}
                        </div>
                        {payment.payment_date && (
                          <div className="text-sm">
                            <span className="text-green-600 flex items-center gap-1">
                              <CheckCircle className="w-4 h-4" />
                              Bezahlt am {new Date(payment.payment_date).toLocaleDateString('de-DE')}
                            </span>
                          </div>
                        )}
                        {payment.notes && (
                          <p className="text-sm text-white/60 mt-2">{payment.notes}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => {
                            const newStatus = payment.status === 'paid' ? 'pending' : 'paid';
                            setAnimatingPayment(payment.id);
                            handleUpdatePaymentStatus(payment.id, newStatus);
                            setTimeout(() => setAnimatingPayment(null), 600);
                          }}
                          disabled={animatingPayment === payment.id}
                          className={`px-6 py-2 rounded-lg font-semibold transition-all duration-200 flex items-center gap-2 ${
                            payment.status === 'paid'
                              ? 'bg-green-500 text-white hover:bg-green-600 shadow-md'
                              : payment.status === 'overdue'
                              ? 'bg-red-100 text-red-700 hover:bg-red-200 border-2 border-red-300'
                              : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200 border-2 border-yellow-300'
                          } ${
                            animatingPayment === payment.id ? 'payment-button-click payment-success-pulse' : ''
                          }`}
                        >
                          {payment.status === 'paid' ? (
                            <>
                              <Check className="w-4 h-4" />
                              Bezahlt
                            </>
                          ) : (
                            'Als bezahlt markieren'
                          )}
                        </button>
                        <button
                          onClick={() => setShowDeletePaymentConfirm(payment.id)}
                          className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {payments.length === 0 && (
                  <div className="text-center py-12">
                    <Receipt className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
                    <p className="text-white/70">Noch keine Zahlungen erfasst</p>
                  </div>
                )}
              </div>
            </div>
          )}

          {activeTab === 'attachments' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-white">Dokumente & Anhänge</h3>
                <label className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c19a2e] transition-all cursor-pointer">
                  <Upload className="w-4 h-4" />
                  {uploading ? 'Wird hochgeladen...' : 'Datei hochladen'}
                  <input
                    type="file"
                    onChange={handleFileUpload}
                    className="hidden"
                    accept=".pdf,.jpg,.jpeg,.png,.doc,.docx"
                    disabled={uploading}
                  />
                </label>
              </div>

              <div className="grid md:grid-cols-2 gap-4">
                {attachments.map(attachment => (
                  <div
                    key={attachment.id}
                    className="p-4 rounded-xl bg-white/10 border-2 border-[#d4af37]/30 hover:border-[#d4af37] transition-all group"
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <FileText className="w-5 h-5 text-[#d4af37] flex-shrink-0" />
                          <p className="font-semibold text-white truncate">{attachment.file_name}</p>
                        </div>
                        <div className="flex items-center gap-3 text-xs text-white/60">
                          <span>{(attachment.file_size / 1024).toFixed(0)} KB</span>
                          <span>{attachment.attachment_type}</span>
                          <span>{new Date(attachment.created_at).toLocaleDateString('de-DE')}</span>
                        </div>
                      </div>
                      <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <a
                          href={attachment.file_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="p-2 hover:bg-[#d4af37]/20 rounded-lg transition-colors"
                        >
                          <Download className="w-4 h-4 text-[#d4af37]" />
                        </a>
                        <button
                          onClick={() => setShowDeleteAttachmentConfirm({ id: attachment.id, url: attachment.file_url })}
                          className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {attachments.length === 0 && (
                <div className="text-center py-12">
                  <Upload className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
                  <p className="text-white/70">Noch keine Dateien hochgeladen</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'splits' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                    <h3 className="text-xl font-bold text-white">Kostenteilung zwischen Partnern</h3>
                    {partnerSplits.length === 0 && (
                      <button
                        onClick={handleCreateSplits}
                        className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c19a2e] transition-all"
                      >
                        <Plus className="w-4 h-4" />
                        50/50 Aufteilung erstellen
                      </button>
                    )}
                  </div>

                  {partnerSplits.length > 0 && (
                <div className="space-y-4">
                  {partnerSplits.map(split => (
                    <div
                      key={split.id}
                      className="p-6 rounded-xl bg-white/10 border-2 border-[#d4af37]/30"
                    >
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="text-lg font-bold text-white">
                          {split.partner_type === 'partner_1' ? 'Partner 1' : 'Partner 2'}
                        </h4>
                        <div className="flex items-center gap-2">
                          <Percent className="w-5 h-5 text-[#d4af37]" />
                          <span className="text-2xl font-bold text-white">{split.percentage}%</span>
                        </div>
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div>
                          <label className="block text-sm font-semibold text-white/70 mb-2">Anteil (€)</label>
                          <input
                            type="number"
                            value={split.amount}
                            onChange={(e) => handleUpdateSplit(split.id, 'amount', parseFloat(e.target.value))}
                            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                            step="0.01"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-white/70 mb-2">Prozentsatz (%)</label>
                          <input
                            type="number"
                            value={split.percentage}
                            onChange={(e) => handleUpdateSplit(split.id, 'percentage', parseFloat(e.target.value))}
                            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                            step="0.1"
                            max="100"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-white/70 mb-2">Bereits bezahlt (€)</label>
                          <input
                            type="number"
                            value={split.paid_amount}
                            onChange={(e) => handleUpdateSplit(split.id, 'paid_amount', parseFloat(e.target.value))}
                            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                            step="0.01"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-white/70 mb-2">Verbleibend (€)</label>
                          <p className="text-2xl font-bold text-red-600">
                            {(split.amount - split.paid_amount).toLocaleString('de-DE')} {budgetItem.currency}
                          </p>
                        </div>
                      </div>

                      <div className="mt-4">
                        <div className="w-full bg-white rounded-full h-4 overflow-hidden">
                          <div
                            className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-full rounded-full transition-all duration-500"
                            style={{ width: `${Math.min((split.paid_amount / split.amount) * 100, 100)}%` }}
                          />
                        </div>
                        <p className="text-sm text-white/70 mt-1 text-center">
                          {Math.round((split.paid_amount / split.amount) * 100)}% bezahlt
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {partnerSplits.length === 0 && (
                    <div className="text-center py-12">
                      <Users className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
                      <p className="text-white/70">Noch keine Kostenteilung konfiguriert</p>
                    </div>
                  )}
            </div>
          )}

          {activeTab === 'tags' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold text-white">Tags & Labels</h3>
              </div>

              <div className="flex flex-wrap gap-3">
                {availableTags.map(tag => (
                  <button
                    key={tag.id}
                    onClick={() => handleToggleTag(tag.id)}
                    className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
                      itemTags.includes(tag.id)
                        ? 'text-white shadow-lg'
                        : 'bg-white/10 text-white/70 hover:bg-[#d4af37]/20'
                    }`}
                    style={{
                      backgroundColor: itemTags.includes(tag.id) ? tag.color : undefined,
                    }}
                  >
                    {itemTags.includes(tag.id) && <Check className="w-4 h-4" />}
                    {tag.name}
                  </button>
                ))}
              </div>

              {availableTags.length === 0 && (
                <div className="text-center py-12">
                  <Tag className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
                  <p className="text-white/70">Noch keine Tags erstellt</p>
                  <p className="text-sm text-white/60 mt-2">Erstelle Tags im Budget-Manager</p>
                </div>
              )}
            </div>
          )}

          {activeTab === 'history' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold text-white">Änderungsverlauf</h3>
                  <p className="text-sm text-white/60 mt-1">Alle Änderungen an diesem Budget-Posten</p>
                </div>
              </div>

              {historyEntries.length > 0 ? (
                <div className="space-y-3">
                  {historyEntries.map((entry, index) => {
                    const changes = entry.changes ? JSON.parse(entry.changes) : {};
                    const isFirst = index === 0;

                    return (
                      <div
                        key={entry.id}
                        className={`p-4 rounded-xl border-2 transition-all ${
                          isFirst ? 'bg-blue-50 border-blue-200' : 'bg-white border-gray-200'
                        }`}
                      >
                        <div className="flex items-start gap-3">
                          <div className={`p-2 rounded-lg ${isFirst ? 'bg-blue-200' : 'bg-gray-200'}`}>
                            <History className={`w-4 h-4 ${isFirst ? 'text-blue-700' : 'text-gray-600'}`} />
                          </div>
                          <div className="flex-1">
                            <div className="flex items-center justify-between mb-2">
                              <p className="font-bold text-white">
                                {entry.operation === 'INSERT' ? 'Erstellt' :
                                 entry.operation === 'UPDATE' ? 'Bearbeitet' :
                                 entry.operation === 'DELETE' ? 'Gelöscht' : entry.operation}
                              </p>
                              <span className="text-xs text-white/60">
                                {new Date(entry.changed_at).toLocaleString('de-DE', {
                                  day: '2-digit',
                                  month: '2-digit',
                                  year: 'numeric',
                                  hour: '2-digit',
                                  minute: '2-digit'
                                })}
                              </span>
                            </div>

                            {entry.operation === 'UPDATE' && Object.keys(changes).length > 0 && (
                              <div className="space-y-2 text-sm">
                                {Object.entries(changes).map(([field, change]: [string, any]) => {
                                  const fieldNames: Record<string, string> = {
                                    item_name: 'Bezeichnung',
                                    actual_cost: 'Kosten',
                                    estimated_cost: 'Geschätzte Kosten',
                                    notes: 'Notizen',
                                    category: 'Kategorie',
                                    payment_status: 'Zahlungsstatus',
                                    paid: 'Bezahlt',
                                    vendor_id: 'Dienstleister'
                                  };

                                  return (
                                    <div key={field} className="flex items-start gap-2 p-2 bg-white/50 rounded-lg">
                                      <span className="text-white/60 font-semibold min-w-[120px]">
                                        {fieldNames[field] || field}:
                                      </span>
                                      <div className="flex-1">
                                        <div className="flex items-center gap-2">
                                          <span className="text-red-600 line-through">
                                            {typeof change.old === 'number' && field.includes('cost')
                                              ? `${change.old.toFixed(2)} €`
                                              : String(change.old || '-')}
                                          </span>
                                          <span className="text-white/60">→</span>
                                          <span className="text-green-600 font-semibold">
                                            {typeof change.new === 'number' && field.includes('cost')
                                              ? `${change.new.toFixed(2)} €`
                                              : String(change.new || '-')}
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            )}

                            {entry.operation === 'INSERT' && (
                              <p className="text-sm text-white/60">
                                Budget-Posten wurde erstellt mit {entry.actual_cost?.toFixed(2) || '0.00'} €
                              </p>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <div className="text-center py-12">
                  <History className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
                  <p className="text-white/70">Noch keine Änderungen protokolliert</p>
                  <p className="text-sm text-white/60 mt-2">Der Verlauf wird automatisch erfasst</p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      <ModalInput
        isOpen={showAddPaymentModal}
        onClose={() => setShowAddPaymentModal(false)}
        onConfirm={handleAddPayment}
        title="Zahlung hinzufügen"
        placeholder="Zahlungsbetrag (€)"
        type="number"
        required
      />

      <ModalConfirm
        isOpen={showDeletePaymentConfirm !== null}
        onClose={() => setShowDeletePaymentConfirm(null)}
        onConfirm={handleDeletePayment}
        title="Zahlung löschen"
        message="Möchtest du diese Zahlung wirklich löschen? Diese Aktion kann nicht rückgängig gemacht werden."
        confirmText={COMMON.DELETE}
        type="danger"
      />

      <ModalConfirm
        isOpen={showDeleteAttachmentConfirm !== null}
        onClose={() => setShowDeleteAttachmentConfirm(null)}
        onConfirm={handleDeleteAttachment}
        title="Anhang löschen"
        message="Möchtest du diesen Anhang wirklich löschen? Die Datei wird dauerhaft entfernt."
        confirmText={COMMON.DELETE}
        type="danger"
      />

      <PaymentPlanModal
        isOpen={showPaymentPlanModal}
        onClose={() => setShowPaymentPlanModal(false)}
        onConfirm={handlePaymentPlanConfirm}
        totalAmount={budgetItem?.actual_cost || 0}
        currency={budgetItem?.currency || 'EUR'}
        existingPayments={payments}
      />
    </div>
  );

  return createPortal(modalContent, document.body);
}
