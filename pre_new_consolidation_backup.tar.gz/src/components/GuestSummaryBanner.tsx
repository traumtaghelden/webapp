import { useState, useEffect } from 'react';
import { Users, Check, X, AlertCircle, Home, Mail } from 'lucide-react';
import { type Guest, type FamilyGroup } from '../lib/supabase';

interface GuestSummaryBannerProps {
  guests: Guest[];
  familyGroups: FamilyGroup[];
}

interface MetricCardProps {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  subtitle?: string;
  color: string;
  delay: number;
}

function MetricCard({ icon, label, value, subtitle, color, delay }: MetricCardProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay);

    return () => clearTimeout(timer);
  }, [delay]);

  useEffect(() => {
    if (!isVisible) return;

    const numericValue = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(numericValue)) {
      setDisplayValue(numericValue);
      return;
    }

    const duration = 1000;
    const steps = 30;
    const increment = numericValue / steps;
    let current = 0;
    let step = 0;

    const counter = setInterval(() => {
      step++;
      current = Math.min(current + increment, numericValue);
      setDisplayValue(Math.round(current));

      if (step >= steps) {
        setDisplayValue(numericValue);
        clearInterval(counter);
      }
    }, duration / steps);

    return () => clearInterval(counter);
  }, [isVisible, value]);

  return (
    <div
      className={`transform transition-all duration-700 ${
        isVisible
          ? 'opacity-100 translate-y-0'
          : 'opacity-0 translate-y-8'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div className={`bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all duration-300 border-l-4 ${color} h-full`}>
        <div className="flex items-start justify-between mb-3">
          <div className={`p-3 rounded-xl ${color.replace('border-', 'bg-')}/10`}>
            {icon}
          </div>
        </div>
        <div className="space-y-1">
          <p className="text-sm font-semibold text-[#666666] uppercase tracking-wide">
            {label}
          </p>
          <p className={`text-4xl font-bold ${color.replace('border-', 'text-')}`}>
            {typeof value === 'string' && value.includes('%')
              ? `${displayValue}%`
              : displayValue}
          </p>
          {subtitle && (
            <p className="text-xs text-[#999999] mt-1">{subtitle}</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default function GuestSummaryBanner({ guests, familyGroups }: GuestSummaryBannerProps) {
  const totalGuests = guests.length;
  const acceptedGuests = guests.filter(g => g.rsvp_status === 'accepted').length;
  const declinedGuests = guests.filter(g => g.rsvp_status === 'declined').length;

  const acceptanceRate = totalGuests > 0 ? Math.round((acceptedGuests / totalGuests) * 100) : 0;

  const childrenCount = guests.filter(g => g.age_group === 'child' || g.age_group === 'infant').length;
  const adultsCount = guests.filter(g => g.age_group === 'adult').length;

  const dietaryCount = guests.filter(g => g.dietary_restrictions && g.dietary_restrictions.trim() !== '').length;
  const dietaryPercentage = totalGuests > 0 ? Math.round((dietaryCount / totalGuests) * 100) : 0;

  const familyGuestCount = guests.filter(g => g.family_group_id).length;

  const invitedGuests = guests.filter(g => g.rsvp_status === 'invited').length;
  const invitedPercentage = totalGuests > 0 ? Math.round((invitedGuests / totalGuests) * 100) : 0;

  const metrics = [
    {
      icon: <Users className="w-6 h-6 text-[#d4af37]" />,
      label: 'Gesamt Gäste',
      value: totalGuests,
      subtitle: `${adultsCount} Erwachsene, ${childrenCount} Kinder`,
      color: 'border-[#d4af37]',
      delay: 0
    },
    {
      icon: <Mail className="w-6 h-6 text-blue-600" />,
      label: 'Einladungen versendet',
      value: invitedGuests,
      subtitle: `${invitedPercentage}% versendet`,
      color: 'border-blue-500',
      delay: 100
    },
    {
      icon: <Check className="w-6 h-6 text-green-600" />,
      label: 'Zugesagt',
      value: acceptedGuests,
      subtitle: `${acceptanceRate}% Zusagerate`,
      color: 'border-green-500',
      delay: 200
    },
    {
      icon: <X className="w-6 h-6 text-red-600" />,
      label: 'Abgesagt',
      value: declinedGuests,
      subtitle: totalGuests > 0 ? `${Math.round((declinedGuests/totalGuests)*100)}% Absagerate` : '0%',
      color: 'border-red-500',
      delay: 300
    },
    {
      icon: <Home className="w-6 h-6 text-[#d4af37]" />,
      label: 'Familien',
      value: familyGroups.length,
      subtitle: `${familyGuestCount} Personen gesamt`,
      color: 'border-[#d4af37]',
      delay: 400
    },
    {
      icon: <AlertCircle className="w-6 h-6 text-orange-600" />,
      label: 'Diät-Restriktionen',
      value: dietaryCount,
      subtitle: `${dietaryPercentage}% der Gäste`,
      color: 'border-orange-500',
      delay: 500
    }
  ];

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-[#f7f2eb] via-white to-[#f7f2eb] rounded-3xl shadow-xl mb-8">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNkNGFmMzciIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djItaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>

      <div className="relative p-8">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-[#0a253c] mb-2">
            Übersicht
          </h2>
          <p className="text-[#666666]">
            Alle wichtigen Kennzahlen auf einen Blick
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
          {metrics.map((metric, index) => (
            <MetricCard key={index} {...metric} />
          ))}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#d4af37] via-blue-500 to-green-500"></div>
    </div>
  );
}
