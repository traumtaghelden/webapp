import { useState, useEffect } from 'react';
import { Plus, Clock, MapPin, Users, DollarSign, Building2, Receipt, Timer, Edit2, Trash2, LayoutGrid } from 'lucide-react';
import { supabase, type TimelineEvent } from '../../lib/supabase';
import BlockPlanningModal from '../BlockPlanningModal';
import EventGuestManagementModal from '../EventGuestManagementModal';
import { TIMELINE, COMMON } from '../../constants/terminology';
import { DndContext, closestCenter, DragEndEvent, PointerSensor, KeyboardSensor, useSensor, useSensors } from '@dnd-kit/core';
import { arrayMove, SortableContext, verticalListSortingStrategy, useSortable, sortableKeyboardCoordinates } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface TimelineHochzeitstagTabProps {
  weddingId: string;
  events: TimelineEvent[];
  onUpdate: () => void;
  onAddEvent: () => void;
}

interface SortableEventProps {
  event: TimelineEvent;
  onEdit: (event: TimelineEvent) => void;
  onDelete: (id: string) => void;
  onOpenPlanning: (event: TimelineEvent) => void;
  onManageGuests: (event: TimelineEvent) => void;
  attendingCount: number;
  totalGuestCount: number;
  budgetCost: number;
  vendorCost: number;
  vendorCount: number;
  totalCost: number;
}

function SortableEvent({ event, onEdit, onDelete, onOpenPlanning, onManageGuests, attendingCount, totalGuestCount, budgetCost, vendorCost, vendorCount, totalCost }: SortableEventProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: event.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const formatTime = (timeString: string) => {
    return timeString.substring(0, 5);
  };

  const calculateEndTime = (startTime: string, durationMinutes: number, endTime: string | null) => {
    if (endTime) {
      return formatTime(endTime);
    }
    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + durationMinutes;
    const endHours = Math.floor(totalMinutes / 60) % 24;
    const endMinutes = totalMinutes % 60;
    return `${String(endHours).padStart(2, '0')}:${String(endMinutes).padStart(2, '0')}`;
  };

  const isBuffer = event.event_type === 'buffer';
  const displayTitle = isBuffer && event.buffer_label ? event.buffer_label : event.title;
  const eventColor = event.color || '#d4af37';

  const lightenColor = (hex: string, opacity: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
  };

  return (
    <div ref={setNodeRef} style={style} className="relative pl-4 sm:pl-32 mb-6">
      <div className="absolute left-0 top-2 flex items-center gap-2 sm:gap-4">
        <div
          className="text-white px-2 py-1 sm:px-3 sm:py-2 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm min-w-[70px] sm:min-w-[100px] text-center shadow-lg"
          style={{
            background: `linear-gradient(135deg, ${eventColor} 0%, ${eventColor}dd 100%)`
          }}
        >
          <div className="leading-tight">
            {formatTime(event.time)}
            <div className="text-[10px] sm:text-xs opacity-90">bis</div>
            {calculateEndTime(event.time, event.duration_minutes, event.end_time)}
          </div>
        </div>
        <div
          className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-white shadow-lg border-2 sm:border-4"
          style={{ borderColor: eventColor }}
        ></div>
      </div>

      <div
        className={`rounded-xl p-3 sm:p-6 transition-all group relative ${isBuffer ? 'border-2 border-dashed' : ''}`}
        style={{
          backgroundColor: lightenColor(eventColor, 0.08),
          borderColor: isBuffer ? lightenColor(eventColor, 0.3) : 'transparent',
        }}
      >
        <div
          className="absolute left-0 top-0 bottom-0 w-1 rounded-l-xl"
          style={{
            background: `repeating-linear-gradient(
              to bottom,
              ${eventColor} 0px,
              ${eventColor} 8px,
              transparent 8px,
              transparent 16px
            )`
          }}
        ></div>
        <div className="flex flex-col sm:flex-row items-start gap-3 sm:gap-4">
          <div
            {...attributes}
            {...listeners}
            className="cursor-grab active:cursor-grabbing p-2 sm:p-3 -ml-1 sm:-ml-2 rounded-lg transition-colors flex-shrink-0 self-start"
            style={{ backgroundColor: lightenColor(eventColor, 0.15) }}
          >
            <svg className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: eventColor }} fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8h16M4 16h16" />
            </svg>
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              {isBuffer && (
                <>
                  <Timer className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                  <span className="px-2 py-0.5 bg-gray-200 text-gray-700 text-xs font-bold rounded-full uppercase">
                    Puffer
                  </span>
                </>
              )}
              <h3 className="text-lg sm:text-xl font-bold text-[#0a253c] break-words">{displayTitle}</h3>
            </div>
            {event.description && <p className="text-sm sm:text-base text-[#333333] mb-3 break-words">{event.description}</p>}
            <div className="flex flex-wrap gap-2 sm:gap-4 text-xs sm:text-sm">
              <div className="flex items-center gap-1.5 sm:gap-2 text-[#333333]">
                <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" style={{ color: eventColor }} />
                <span className="whitespace-nowrap">{event.duration_minutes} Min.</span>
              </div>
              {!isBuffer && (
                <>
                  <div
                    className={`flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm ${
                      attendingCount < totalGuestCount
                        ? 'bg-orange-100 text-orange-700'
                        : 'bg-green-100 text-green-700'
                    }`}
                    title={`${attendingCount} von ${totalGuestCount} Gästen nehmen teil`}
                  >
                    <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="whitespace-nowrap">{attendingCount}/{totalGuestCount}</span>
                  </div>
                  {budgetCost > 0 && (
                    <div className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm bg-blue-100 text-blue-700">
                      <DollarSign className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                      <span className="whitespace-nowrap">{budgetCost.toLocaleString('de-DE')} €</span>
                    </div>
                  )}
                  {vendorCount > 0 && (
                    <div className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm bg-cyan-100 text-cyan-700">
                      <Building2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                      <span className="whitespace-nowrap">{vendorCount}</span>
                    </div>
                  )}
                  {totalCost > 0 && (
                    <div className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm bg-green-100 text-green-700">
                      <Receipt className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                      <span className="whitespace-nowrap">{totalCost.toLocaleString('de-DE')} €</span>
                    </div>
                  )}
                </>
              )}
              {event.location && (
                <div className="flex items-center gap-1.5 sm:gap-2 text-[#333333]">
                  <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" style={{ color: eventColor }} />
                  <span className="break-words">{event.location}</span>
                </div>
              )}
            </div>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-1.5 sm:gap-2 opacity-100 transition-opacity mt-3 sm:mt-0">
            {!isBuffer && (
              <>
                <button
                  onClick={() => onManageGuests(event)}
                  className="p-2 sm:p-3 rounded-lg transition-all active:scale-95 sm:hover:scale-110"
                  style={{ backgroundColor: lightenColor(eventColor, 0.15) }}
                  title="Gäste verwalten"
                >
                  <Users className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: eventColor }} />
                </button>
                <button
                  onClick={() => onOpenPlanning(event)}
                  className="p-2 sm:p-3 rounded-lg transition-all active:scale-95 sm:hover:scale-110"
                  style={{ backgroundColor: lightenColor(eventColor, 0.15) }}
                  title="Detailplanung öffnen"
                >
                  <LayoutGrid className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: eventColor }} />
                </button>
              </>
            )}
            <button
              onClick={() => onEdit(event)}
              className="p-3 rounded-lg transition-all hover:scale-110"
              style={{ backgroundColor: lightenColor(eventColor, 0.15) }}
            >
              <Edit2 className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: eventColor }} />
            </button>
            <button
              onClick={() => onDelete(event.id)}
              className="p-3 rounded-lg transition-all hover:scale-110"
              style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}
            >
              <Trash2 className="w-5 h-5 sm:w-6 sm:h-6 text-red-500" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function TimelineHochzeitstagTab({ weddingId, events, onUpdate, onAddEvent }: TimelineHochzeitstagTabProps) {
  const [planningEvent, setPlanningEvent] = useState<TimelineEvent | null>(null);
  const [managingGuestsEvent, setManagingGuestsEvent] = useState<TimelineEvent | null>(null);
  const [guestAttendanceCounts, setGuestAttendanceCounts] = useState<Record<string, { attending: number; total: number }>>({});
  const [eventCosts, setEventCosts] = useState<Record<string, { budget: number; vendors: number; total: number; vendorCount: number }>>({});

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    loadGuestCounts();
    loadEventCosts();
  }, [weddingId, events]);

  const loadGuestCounts = async () => {
    try {
      const { data: guestsData } = await supabase
        .from('guests')
        .select('id')
        .eq('wedding_id', weddingId);

      const totalGuestCount = guestsData?.length || 0;
      const counts: Record<string, { attending: number; total: number }> = {};

      for (const event of events) {
        const { data: attendanceData } = await supabase
          .from('timeline_event_guest_attendance')
          .select('is_attending')
          .eq('timeline_event_id', event.id);

        const attendingCount = attendanceData?.filter(a => a.is_attending).length || totalGuestCount;
        counts[event.id] = {
          attending: attendingCount,
          total: totalGuestCount
        };
      }

      setGuestAttendanceCounts(counts);
    } catch (error) {
      console.error('Error loading guest counts:', error);
    }
  };

  const loadEventCosts = async () => {
    try {
      const costs: Record<string, { budget: number; vendors: number; total: number; vendorCount: number }> = {};

      for (const event of events) {
        const [budgetRes, vendorRes] = await Promise.all([
          supabase
            .from('budget_items')
            .select('actual_cost')
            .eq('timeline_event_id', event.id),
          supabase
            .from('vendor_event_assignments')
            .select('allocated_cost')
            .eq('timeline_event_id', event.id)
        ]);

        const budgetTotal = budgetRes.data?.reduce((sum, item) => sum + (item.actual_cost || 0), 0) || 0;
        const vendorTotal = vendorRes.data?.reduce((sum, item) => sum + (item.allocated_cost || 0), 0) || 0;
        const vendorCount = vendorRes.data?.length || 0;

        costs[event.id] = {
          budget: budgetTotal,
          vendors: vendorTotal,
          total: budgetTotal + vendorTotal,
          vendorCount
        };
      }

      setEventCosts(costs);
    } catch (error) {
      console.error('Error loading event costs:', error);
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = events.findIndex((e) => e.id === active.id);
      const newIndex = events.findIndex((e) => e.id === over.id);

      const reordered = arrayMove(events, oldIndex, newIndex);
      const withUpdatedIndices = reordered.map((e, index) => ({
        ...e,
        order_index: index,
      }));

      for (const event of withUpdatedIndices) {
        await supabase
          .from('wedding_timeline')
          .update({ order_index: event.order_index })
          .eq('id', event.id);
      }

      onUpdate();
    }
  };

  const handleDelete = async (eventId: string) => {
    if (!confirm('Möchtest du diesen Timeline-Punkt wirklich löschen?')) return;

    try {
      await supabase.from('wedding_timeline').delete().eq('id', eventId);
      onUpdate();
    } catch (error) {
      console.error('Error deleting event:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold text-[#0a253c]">Hochzeitstag-Timeline</h3>
          <p className="text-[#666666] mt-1">Minutengenauer Ablauf des großen Tages</p>
        </div>
        <button
          onClick={onAddEvent}
          className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all"
        >
          <Plus className="w-5 h-5" />
          Event hinzufügen
        </button>
      </div>

      <div className="bg-white rounded-2xl p-4 sm:p-8 shadow-lg">
        {events.length === 0 ? (
          <div className="text-center py-12">
            <Clock className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
            <p className="text-[#333333] text-lg">Noch keine Timeline-Events erstellt</p>
          </div>
        ) : (
          <div className="relative">
            <div className="hidden sm:block absolute left-[118px] top-0 bottom-0 w-1 bg-gradient-to-b from-[#d4af37] via-[#f4d03f] to-[#d4af37]/30 rounded-full"></div>

            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={events.map((e) => e.id)}
                strategy={verticalListSortingStrategy}
              >
                {events.map((event) => {
                  const counts = guestAttendanceCounts[event.id] || { attending: 0, total: 0 };
                  const costs = eventCosts[event.id] || { budget: 0, vendors: 0, total: 0, vendorCount: 0 };
                  return (
                    <SortableEvent
                      key={event.id}
                      event={event}
                      onEdit={() => {}}
                      onDelete={handleDelete}
                      onOpenPlanning={(e) => setPlanningEvent(e)}
                      onManageGuests={(e) => setManagingGuestsEvent(e)}
                      attendingCount={counts.attending}
                      totalGuestCount={counts.total}
                      budgetCost={costs.budget}
                      vendorCost={costs.vendors}
                      vendorCount={costs.vendorCount}
                      totalCost={costs.total}
                    />
                  );
                })}
              </SortableContext>
            </DndContext>
          </div>
        )}
      </div>

      {planningEvent && (
        <BlockPlanningModal
          event={planningEvent}
          weddingId={weddingId}
          onClose={() => setPlanningEvent(null)}
          onUpdate={() => {
            onUpdate();
            loadEventCosts();
          }}
        />
      )}

      {managingGuestsEvent && (
        <EventGuestManagementModal
          eventId={managingGuestsEvent.id}
          eventTitle={managingGuestsEvent.title}
          weddingId={weddingId}
          onClose={() => setManagingGuestsEvent(null)}
          onUpdate={() => {
            loadGuestCounts();
            setManagingGuestsEvent(null);
          }}
        />
      )}
    </div>
  );
}
