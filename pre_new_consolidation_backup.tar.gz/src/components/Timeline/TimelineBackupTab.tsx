import { Cloud, AlertTriangle, CheckCircle, FileText, Clock } from 'lucide-react';

export default function TimelineBackupTab() {
  const backupScenarios = [
    {
      scenario: 'Schlechtes Wetter',
      icon: Cloud,
      color: 'blue',
      plans: [
        'Indoor-Alternative vorbereitet',
        'Zelte und Pavillons organisiert',
        'Regenschirme für Gäste bereithalten',
        'Fotografie-Backup-Locations',
      ],
    },
    {
      scenario: 'Technische Probleme',
      icon: AlertTriangle,
      color: 'orange',
      plans: [
        'Backup-Soundsystem',
        'Zusätzliche Mikrofone',
        'Notfall-Playlist auf mehreren Geräten',
        'Kontakt zum technischen Support',
      ],
    },
    {
      scenario: 'Dienstleister-Ausfall',
      icon: AlertTriangle,
      color: 'red',
      plans: [
        'Backup-DJ/Band kontaktiert',
        'Alternative Catering-Option',
        'Notfall-Fotograf-Liste',
        'Plan B für Transport',
      ],
    },
    {
      scenario: 'Zeitverzögerungen',
      icon: Clock,
      color: 'yellow',
      plans: [
        'Pufferzeiten eingeplant',
        'Flexible Event-Reihenfolge',
        'Kommunikationsplan mit Team',
        'Verkürzte Programmpunkte vorbereitet',
      ],
    },
  ];

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-[#0a253c]">Notfall- & Backup-Pläne</h3>
        <p className="text-[#666666] mt-1">Vorbereitet für alle Eventualitäten</p>
      </div>

      <div className="bg-gradient-to-br from-orange-50 to-white rounded-2xl p-6 shadow-lg border-2 border-orange-200">
        <div className="flex items-center gap-3 mb-4">
          <AlertTriangle className="w-8 h-8 text-orange-600" />
          <div>
            <h4 className="text-xl font-bold text-[#0a253c]">Wichtige Notfallkontakte</h4>
            <p className="text-sm text-[#666666]">Immer griffbereit haben</p>
          </div>
        </div>

        <div className="grid md:grid-cols-2 gap-4">
          {[
            { role: 'Location Manager', number: '+49 XXX XXXXXXX' },
            { role: 'Catering', number: '+49 XXX XXXXXXX' },
            { role: 'DJ/Band', number: '+49 XXX XXXXXXX' },
            { role: 'Fotograf', number: '+49 XXX XXXXXXX' },
            { role: 'Florist', number: '+49 XXX XXXXXXX' },
            { role: 'Transport', number: '+49 XXX XXXXXXX' },
          ].map((contact, idx) => (
            <div key={idx} className="bg-white p-4 rounded-lg">
              <p className="font-semibold text-[#0a253c]">{contact.role}</p>
              <p className="text-sm text-[#666666]">{contact.number}</p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        {backupScenarios.map((scenario, idx) => {
          const Icon = scenario.icon;
          return (
            <div
              key={idx}
              className={`bg-white rounded-xl p-6 shadow-lg border-2 border-${scenario.color}-200`}
            >
              <div className="flex items-center gap-3 mb-4">
                <div className={`w-12 h-12 rounded-full bg-${scenario.color}-100 flex items-center justify-center`}>
                  <Icon className={`w-6 h-6 text-${scenario.color}-600`} />
                </div>
                <h4 className="font-bold text-[#0a253c] text-lg">{scenario.scenario}</h4>
              </div>

              <div className="space-y-2">
                {scenario.plans.map((plan, planIdx) => (
                  <div key={planIdx} className="flex items-start gap-2 p-2 bg-[#f7f2eb] rounded-lg">
                    <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0 mt-0.5" />
                    <span className="text-sm text-[#333333]">{plan}</span>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      <div className="bg-white rounded-xl p-6 shadow-lg">
        <div className="flex items-center gap-3 mb-4">
          <FileText className="w-6 h-6 text-[#d4af37]" />
          <h4 className="font-bold text-[#0a253c] text-lg">Notfall-Kit Checkliste</h4>
        </div>

        <div className="grid md:grid-cols-3 gap-4">
          {[
            'Erste-Hilfe-Set',
            'Nähzeug',
            'Fleckenentferner',
            'Schmerzmittel',
            'Taschentücher',
            'Sicherheitsnadeln',
            'Deo & Parfum',
            'Handy-Ladegeräte',
            'Regenschirme',
            'Notfall-Snacks',
            'Wasserfla schen',
            'Ersatz-Strumpfhosen',
          ].map((item, idx) => (
            <div key={idx} className="flex items-center gap-2 p-2 bg-[#f7f2eb] rounded-lg">
              <CheckCircle className="w-4 h-4 text-green-600 flex-shrink-0" />
              <span className="text-sm text-[#333333]">{item}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-2xl p-8 text-center">
        <FileText className="w-20 h-20 text-[#d4af37] mx-auto mb-4" />
        <h4 className="text-2xl font-bold text-white mb-2">Erweiterte Notfallplanung</h4>
        <p className="text-white/70 mb-6">
          Erstelle detaillierte Backup-Pläne für jedes Szenario
        </p>
        <div className="inline-block px-6 py-3 bg-[#d4af37]/20 text-[#d4af37] rounded-xl font-bold">
          Premium Feature
        </div>
      </div>
    </div>
  );
}
