import { useState, useEffect } from 'react';
import { Calendar, Clock, Target, CheckCircle, TrendingUp } from 'lucide-react';

interface TimelineCountdownTabProps {
  weddingDate: string;
}

export default function TimelineCountdownTab({ weddingDate }: TimelineCountdownTabProps) {
  const [timeUntilWedding, setTimeUntilWedding] = useState({
    months: 0,
    weeks: 0,
    days: 0,
    hours: 0,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const calculateTimeLeft = () => {
      const wedding = new Date(weddingDate);
      const now = new Date();
      const difference = wedding.getTime() - now.getTime();

      if (difference > 0) {
        const months = Math.floor(difference / (1000 * 60 * 60 * 24 * 30));
        const weeks = Math.floor((difference % (1000 * 60 * 60 * 24 * 30)) / (1000 * 60 * 60 * 24 * 7));
        const days = Math.floor((difference % (1000 * 60 * 60 * 24 * 7)) / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        const minutes = Math.floor((difference % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((difference % (1000 * 60)) / 1000);

        setTimeUntilWedding({ months, weeks, days, hours, minutes, seconds });
      }
    };

    calculateTimeLeft();
    const interval = setInterval(calculateTimeLeft, 1000);

    return () => clearInterval(interval);
  }, [weddingDate]);

  const milestones = [
    { months: 12, title: '1 Jahr vorher', tasks: ['Location buchen', 'Gästeliste erstellen', 'Budget planen'] },
    { months: 9, title: '9 Monate vorher', tasks: ['Catering auswählen', 'Fotograf buchen', 'Musik organisieren'] },
    { months: 6, title: '6 Monate vorher', tasks: ['Einladungen versenden', 'Dekoration planen', 'Hochzeitstorte bestellen'] },
    { months: 3, title: '3 Monate vorher', tasks: ['Letzte Details klären', 'Zeitplan finalisieren', 'Probe-Events'] },
    { months: 1, title: '1 Monat vorher', tasks: ['Finale Absprachen', 'Letzte Zahlungen', 'Ablauf durchgehen'] },
    { weeks: 1, title: '1 Woche vorher', tasks: ['Entspannen', 'Notfall-Kit vorbereiten', 'Team briefen'] },
  ];

  const wedding = new Date(weddingDate);
  const now = new Date();
  const totalDays = Math.ceil((wedding.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-[#0a253c]">Countdown zur Hochzeit</h3>
        <p className="text-[#666666] mt-1">Meilensteine und Zeitübersicht</p>
      </div>

      <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-3xl p-8 text-center relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyMTIsIDE3NSwgNTUsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')]"></div>
        </div>

        <div className="relative z-10">
          <Calendar className="w-20 h-20 text-[#d4af37] mx-auto mb-6 animate-pulse" />
          <h4 className="text-4xl font-bold text-white mb-8">Noch</h4>

          <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-8">
            {[
              { value: timeUntilWedding.months, label: 'Monate' },
              { value: timeUntilWedding.weeks, label: 'Wochen' },
              { value: timeUntilWedding.days, label: 'Tage' },
              { value: timeUntilWedding.hours, label: 'Stunden' },
              { value: timeUntilWedding.minutes, label: 'Minuten' },
              { value: timeUntilWedding.seconds, label: 'Sekunden' },
            ].map(({ value, label }) => (
              <div key={label} className="bg-white/10 backdrop-blur-sm rounded-xl p-4">
                <div className="text-4xl font-bold text-[#d4af37] mb-1">{value}</div>
                <div className="text-sm text-white/70">{label}</div>
              </div>
            ))}
          </div>

          <div className="text-2xl text-white/90">
            bis zu eurem großen Tag! 💍
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-lg">
        <h4 className="font-bold text-[#0a253c] text-lg mb-4 flex items-center gap-2">
          <Target className="w-5 h-5 text-[#d4af37]" />
          Meilenstein-Übersicht
        </h4>
        <div className="space-y-4">
          {milestones.map((milestone, idx) => {
            const isPast = (milestone.months && totalDays < milestone.months * 30) ||
                          (milestone.weeks && totalDays < milestone.weeks * 7);

            return (
              <div
                key={idx}
                className={`p-4 rounded-xl border-2 transition-all ${
                  isPast
                    ? 'bg-gray-50 border-gray-200 opacity-50'
                    : 'bg-[#f7f2eb] border-[#d4af37]/30'
                }`}
              >
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    {isPast ? (
                      <CheckCircle className="w-5 h-5 text-green-600" />
                    ) : (
                      <Clock className="w-5 h-5 text-[#d4af37]" />
                    )}
                    <h5 className="font-bold text-[#0a253c]">{milestone.title}</h5>
                  </div>
                  <span className={`px-3 py-1 rounded-full text-sm font-bold ${
                    isPast ? 'bg-green-100 text-green-700' : 'bg-[#d4af37]/20 text-[#0a253c]'
                  }`}>
                    {isPast ? 'Erreicht' : 'Bevorstehend'}
                  </span>
                </div>
                <ul className="space-y-1 ml-8">
                  {milestone.tasks.map((task, taskIdx) => (
                    <li key={taskIdx} className="text-sm text-[#666666] flex items-center gap-2">
                      <span className="w-1.5 h-1.5 rounded-full bg-[#d4af37]"></span>
                      {task}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
