import { Calendar, CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface TimelinePlanungsphasenTabProps {
  weddingDate: string;
}

const planungsphasen = [
  {
    phase: 'Vorplanung',
    timeframe: '12-9 Monate vorher',
    color: '#8b5cf6',
    tasks: [
      'Hochzeitstermin festlegen',
      'Budget definieren',
      'Gästeliste erstellen',
      'Location recherchieren und buchen',
      'Stil und Motto festlegen',
      'Trauzeugen auswählen',
    ],
  },
  {
    phase: 'Hauptplanung',
    timeframe: '9-6 Monate vorher',
    color: '#3b82f6',
    tasks: [
      'Catering auswählen und buchen',
      'Fotograf und Videograf buchen',
      'DJ oder Band engagieren',
      'Kleidung aussuchen (Brautkleid, Anzug)',
      'Hochzeitstorte bestellen',
      'Florist beauftragen',
    ],
  },
  {
    phase: 'Detailplanung',
    timeframe: '6-3 Monate vorher',
    color: '#10b981',
    tasks: [
      'Einladungen gestalten und versenden',
      'Dekoration planen und bestellen',
      'Sitzordnung erstellen',
      'Trauung detailliert planen',
      'Hochzeitsreise buchen',
      'Unterkünfte für Gäste organisieren',
    ],
  },
  {
    phase: 'Feinschliff',
    timeframe: '3-1 Monat vorher',
    color: '#f59e0b',
    tasks: [
      'Finale Abstimmung mit Dienstleistern',
      'Zeitplan finalisieren',
      'Probeessen mit Catering',
      'Musik-Playlist erstellen',
      'Geschenke für Gäste besorgen',
      'Notfall-Kit zusammenstellen',
    ],
  },
  {
    phase: 'Endphase',
    timeframe: '1 Monat bis Hochzeit',
    color: '#ef4444',
    tasks: [
      'RSVP-Deadline setzen und nachfassen',
      'Finale Zahlungen leisten',
      'Letzte Anproben',
      'Ablaufplan mit Team durchgehen',
      'Entspannen und genießen',
      'Beauty-Termine wahrnehmen',
    ],
  },
];

export default function TimelinePlanungsphasenTab({ weddingDate }: TimelinePlanungsphasenTabProps) {
  const wedding = new Date(weddingDate);
  const now = new Date();
  const monthsUntilWedding = Math.ceil((wedding.getTime() - now.getTime()) / (1000 * 60 * 60 * 24 * 30));

  const getCurrentPhase = () => {
    if (monthsUntilWedding >= 9) return 0;
    if (monthsUntilWedding >= 6) return 1;
    if (monthsUntilWedding >= 3) return 2;
    if (monthsUntilWedding >= 1) return 3;
    return 4;
  };

  const currentPhaseIndex = getCurrentPhase();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-[#0a253c]">Planungsphasen</h3>
        <p className="text-[#666666] mt-1">Strukturierter Überblick über alle Planungsschritte</p>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-lg">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h4 className="text-lg font-bold text-[#0a253c]">Aktuelle Phase</h4>
            <p className="text-[#666666]">{monthsUntilWedding} Monate bis zur Hochzeit</p>
          </div>
          <div
            className="px-6 py-3 rounded-xl font-bold text-white"
            style={{ backgroundColor: planungsphasen[currentPhaseIndex].color }}
          >
            {planungsphasen[currentPhaseIndex].phase}
          </div>
        </div>

        <div className="relative">
          <div className="absolute left-4 top-0 bottom-0 w-1 bg-gradient-to-b from-[#d4af37] to-gray-300"></div>
          <div className="space-y-6">
            {planungsphasen.map((phase, idx) => {
              const isCompleted = idx < currentPhaseIndex;
              const isCurrent = idx === currentPhaseIndex;
              const isUpcoming = idx > currentPhaseIndex;

              return (
                <div
                  key={idx}
                  className={`relative pl-12 transition-all ${
                    isCurrent ? 'scale-105' : ''
                  }`}
                >
                  <div
                    className={`absolute left-0 w-8 h-8 rounded-full flex items-center justify-center ${
                      isCompleted
                        ? 'bg-green-500'
                        : isCurrent
                        ? 'bg-[#d4af37] animate-pulse'
                        : 'bg-gray-300'
                    }`}
                  >
                    {isCompleted ? (
                      <CheckCircle className="w-5 h-5 text-white" />
                    ) : isCurrent ? (
                      <Clock className="w-5 h-5 text-white" />
                    ) : (
                      <AlertCircle className="w-5 h-5 text-white" />
                    )}
                  </div>

                  <div
                    className={`rounded-xl p-6 border-2 ${
                      isCurrent
                        ? 'border-[#d4af37] bg-[#f7f2eb]'
                        : isCompleted
                        ? 'border-green-200 bg-green-50'
                        : 'border-gray-200 bg-gray-50'
                    }`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h5 className="text-xl font-bold text-[#0a253c] mb-1">{phase.phase}</h5>
                        <p className="text-sm text-[#666666] flex items-center gap-2">
                          <Calendar className="w-4 h-4" />
                          {phase.timeframe}
                        </p>
                      </div>
                      <span
                        className={`px-3 py-1 rounded-full text-sm font-bold ${
                          isCompleted
                            ? 'bg-green-100 text-green-700'
                            : isCurrent
                            ? 'bg-[#d4af37] text-white'
                            : 'bg-gray-200 text-gray-600'
                        }`}
                      >
                        {isCompleted ? 'Abgeschlossen' : isCurrent ? 'Aktuell' : 'Bevorstehend'}
                      </span>
                    </div>

                    <div className="grid md:grid-cols-2 gap-3">
                      {phase.tasks.map((task, taskIdx) => (
                        <div
                          key={taskIdx}
                          className={`flex items-start gap-2 p-3 rounded-lg ${
                            isCompleted
                              ? 'bg-white/50'
                              : isCurrent
                              ? 'bg-white'
                              : 'bg-white/30'
                          }`}
                        >
                          <div
                            className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                              isCompleted ? 'bg-green-500' : 'bg-gray-300'
                            }`}
                          >
                            {isCompleted && <CheckCircle className="w-3 h-3 text-white" />}
                          </div>
                          <span className={`text-sm ${isCompleted ? 'line-through text-[#999999]' : 'text-[#333333]'}`}>
                            {task}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
