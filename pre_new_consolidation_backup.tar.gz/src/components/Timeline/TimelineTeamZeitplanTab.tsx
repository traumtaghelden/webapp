import { Users, User, Clock } from 'lucide-react';
import { type TimelineEvent, type WeddingTeamRole } from '../../lib/supabase';

interface TimelineTeamZeitplanTabProps {
  events: TimelineEvent[];
  teamRoles: WeddingTeamRole[];
}

export default function TimelineTeamZeitplanTab({ events, teamRoles }: TimelineTeamZeitplanTabProps) {
  const getEventsForPerson = (personName: string) => {
    return events.filter(e => e.assigned_to === personName);
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-[#0a253c]">Team-Zeitplan</h3>
        <p className="text-[#666666] mt-1">Zuweisungen und Verantwortlichkeiten pro Zeitslot</p>
      </div>

      {teamRoles.length > 0 ? (
        <div className="grid md:grid-cols-2 gap-6">
          {teamRoles.map(role => {
            const assignedEvents = getEventsForPerson(role.name);

            return (
              <div key={role.id} className="bg-white rounded-xl p-6 shadow-lg border-2 border-[#d4af37]/30">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-[#d4af37]/20 flex items-center justify-center">
                    <User className="w-6 h-6 text-[#d4af37]" />
                  </div>
                  <div>
                    <h4 className="font-bold text-[#0a253c] text-lg">{role.name}</h4>
                    <p className="text-sm text-[#666666]">{role.role}</p>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-[#666666]">Zugewiesene Events</span>
                    <span className="font-bold text-[#d4af37]">{assignedEvents.length}</span>
                  </div>
                </div>

                {assignedEvents.length > 0 ? (
                  <div className="space-y-2">
                    {assignedEvents.map(event => (
                      <div
                        key={event.id}
                        className="p-3 bg-[#f7f2eb] rounded-lg"
                      >
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <p className="font-semibold text-[#0a253c] mb-1">{event.title}</p>
                            <div className="flex items-center gap-2 text-sm text-[#666666]">
                              <Clock className="w-4 h-4" />
                              {event.time.substring(0, 5)} ({event.duration_minutes} Min.)
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-6 bg-[#f7f2eb] rounded-lg">
                    <p className="text-sm text-[#999999]">Noch keine Events zugewiesen</p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      ) : (
        <div className="bg-[#f7f2eb] rounded-2xl p-8 text-center">
          <Users className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
          <p className="text-[#666666] text-lg mb-2">Noch keine Team-Mitglieder</p>
          <p className="text-sm text-[#999999]">
            Füge Trauzeugen, Helfer und andere Team-Mitglieder in den Einstellungen hinzu
          </p>
        </div>
      )}
    </div>
  );
}
