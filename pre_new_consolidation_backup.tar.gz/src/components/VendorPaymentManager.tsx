import { useState, useEffect } from 'react';
import { Plus, Calendar, DollarSign, Trash2, CreditCard as Edit2, Save, X, CheckCircle, Crown } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface VendorPayment {
  id: string;
  vendor_id: string;
  amount: number;
  due_date: string;
  payment_date: string | null;
  status: string;
  payment_type: string;
  payment_method: string;
  notes: string;
  percentage_of_total: number | null;
}

interface VendorPaymentManagerProps {
  vendorId: string;
  totalCost: number | null;
  onUpdate: () => void;
}

export default function VendorPaymentManager({ vendorId, totalCost, onUpdate }: VendorPaymentManagerProps) {
  const [payments, setPayments] = useState<VendorPayment[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingPayment, setEditingPayment] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [newPayment, setNewPayment] = useState({
    amount: '',
    due_date: '',
    payment_type: 'milestone' as const,
    payment_method: 'bank_transfer',
    notes: '',
    percentage_of_total: '',
  });

  const paymentTypes = [
    { value: 'deposit', label: 'Anzahlung' },
    { value: 'milestone', label: 'Teilzahlung' },
    { value: 'final', label: 'Restzahlung' },
    { value: 'monthly', label: 'Monatlich' },
  ];

  const paymentMethods = [
    { value: 'bank_transfer', label: 'Überweisung' },
    { value: 'cash', label: 'Bar' },
    { value: 'credit_card', label: 'Kreditkarte' },
    { value: 'paypal', label: 'PayPal' },
    { value: 'other', label: 'Sonstiges' },
  ];

  useEffect(() => {
    loadPayments();
  }, [vendorId]);

  const loadPayments = async () => {
    try {
      setLoading(true);
      const { data } = await supabase
        .from('vendor_payments')
        .select('*')
        .eq('vendor_id', vendorId)
        .order('due_date', { ascending: true });

      if (data) setPayments(data);
    } catch (error) {
      console.error('Error loading payments:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddPayment = async () => {
    if (!newPayment.amount || !newPayment.due_date) {
      alert('Bitte Betrag und Fälligkeitsdatum eingeben');
      return;
    }

    // Premium check for milestone and monthly payment types

    try {
      const amount = parseFloat(newPayment.amount);
      const percentage = newPayment.percentage_of_total
        ? parseFloat(newPayment.percentage_of_total)
        : totalCost
        ? (amount / totalCost) * 100
        : null;

      await supabase.from('vendor_payments').insert([{
        vendor_id: vendorId,
        amount,
        due_date: newPayment.due_date,
        payment_type: newPayment.payment_type,
        payment_method: newPayment.payment_method,
        notes: newPayment.notes,
        percentage_of_total: percentage,
        status: 'pending',
      }]);

      setNewPayment({
        amount: '',
        due_date: '',
        payment_type: 'milestone',
        payment_method: 'bank_transfer',
        notes: '',
        percentage_of_total: '',
      });
      setShowAddForm(false);
      loadPayments();
      onUpdate();
    } catch (error) {
      console.error('Error adding payment:', error);
      alert('Fehler beim Hinzufügen der Zahlung');
    }
  };

  const handleMarkAsPaid = async (paymentId: string) => {
    try {
      await supabase
        .from('vendor_payments')
        .update({
          status: 'paid',
          payment_date: new Date().toISOString().split('T')[0],
        })
        .eq('id', paymentId);

      loadPayments();
      onUpdate();
    } catch (error) {
      console.error('Error marking payment as paid:', error);
    }
  };

  const handleDeletePayment = async (paymentId: string) => {
    if (!confirm('Zahlung wirklich löschen?')) return;

    try {
      await supabase.from('vendor_payments').delete().eq('id', paymentId);
      loadPayments();
      onUpdate();
    } catch (error) {
      console.error('Error deleting payment:', error);
    }
  };

  const useTemplate = (template: 'deposit_rest' | 'three_parts' | 'monthly') => {
    if (!totalCost) {
      alert('Bitte zuerst Gesamtkosten für den Dienstleister eingeben');
      return;
    }

    const today = new Date();
    const templates: { amount: number; type: string; daysOffset: number }[][] = {
      deposit_rest: [
        { amount: totalCost * 0.3, type: 'deposit', daysOffset: 0 },
        { amount: totalCost * 0.7, type: 'final', daysOffset: 60 },
      ],
      three_parts: [
        { amount: totalCost / 3, type: 'milestone', daysOffset: 0 },
        { amount: totalCost / 3, type: 'milestone', daysOffset: 30 },
        { amount: totalCost / 3, type: 'final', daysOffset: 60 },
      ],
      monthly: Array.from({ length: 6 }, (_, i) => ({
        amount: totalCost / 6,
        type: 'monthly',
        daysOffset: i * 30,
      })),
    };

    const templatePayments = templates[template];
    const batch = templatePayments.map((p) => {
      const dueDate = new Date(today);
      dueDate.setDate(dueDate.getDate() + p.daysOffset);
      return {
        vendor_id: vendorId,
        amount: p.amount,
        due_date: dueDate.toISOString().split('T')[0],
        payment_type: p.type,
        payment_method: 'bank_transfer',
        notes: 'Automatisch aus Vorlage erstellt',
        percentage_of_total: (p.amount / totalCost) * 100,
        status: 'pending',
      };
    });

    supabase
      .from('vendor_payments')
      .insert(batch)
      .then(() => {
        loadPayments();
        onUpdate();
      })
      .catch((error) => {
        console.error('Error creating template payments:', error);
        alert('Fehler beim Erstellen der Zahlungen');
      });
  };

  const totalScheduled = payments.reduce((sum, p) => sum + p.amount, 0);
  const totalPaid = payments.filter((p) => p.status === 'paid').reduce((sum, p) => sum + p.amount, 0);
  const totalPending = payments.filter((p) => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#d4af37]"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Summary Cards */}
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 border-2 border-blue-200">
          <p className="text-sm text-blue-700 font-semibold mb-1">Geplante Zahlungen</p>
          <p className="text-2xl font-bold text-blue-900">{totalScheduled.toFixed(2)} €</p>
        </div>
        <div className="bg-gradient-to-br from-green-50 to-green-100 rounded-xl p-4 border-2 border-green-200">
          <p className="text-sm text-green-700 font-semibold mb-1">Bereits bezahlt</p>
          <p className="text-2xl font-bold text-green-900">{totalPaid.toFixed(2)} €</p>
        </div>
        <div className="bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl p-4 border-2 border-orange-200">
          <p className="text-sm text-orange-700 font-semibold mb-1">Ausstehend</p>
          <p className="text-2xl font-bold text-orange-900">{totalPending.toFixed(2)} €</p>
        </div>
      </div>

      {/* Templates */}
      {payments.length === 0 && totalCost && (
        <div className="bg-gradient-to-r from-[#d4af37]/10 to-[#f4d03f]/10 rounded-xl p-6 border-2 border-[#d4af37]/30">
          <h4 className="font-bold text-[#0a253c] mb-4">Zahlungsplan-Vorlagen</h4>
            <div className="grid md:grid-cols-3 gap-3">
              <button
                onClick={() => useTemplate('deposit_rest')}
                className="p-4 bg-white rounded-lg hover:shadow-md transition-all border-2 border-gray-200 hover:border-[#d4af37] text-left"
              >
                <p className="font-semibold text-[#0a253c] mb-1">30% Anzahlung + Rest</p>
                <p className="text-sm text-gray-600">2 Zahlungen</p>
              </button>
              <button
                onClick={() => useTemplate('three_parts')}
                className="p-4 bg-white rounded-lg hover:shadow-md transition-all border-2 border-gray-200 hover:border-[#d4af37] text-left"
              >
                <p className="font-semibold text-[#0a253c] mb-1">3 gleiche Raten</p>
                <p className="text-sm text-gray-600">Alle 30 Tage</p>
              </button>
              <button
                onClick={() => useTemplate('monthly')}
                className="p-4 bg-white rounded-lg hover:shadow-md transition-all border-2 border-gray-200 hover:border-[#d4af37] text-left"
              >
                <p className="font-semibold text-[#0a253c] mb-1">6 monatliche Raten</p>
                <p className="text-sm text-gray-600">Gleichmäßige Verteilung</p>
              </button>
            </div>
          </div>
      )}

      {/* Add Payment Button */}
      <div className="flex items-center justify-between">
          <h3 className="text-lg font-bold text-[#0a253c]">Zahlungen ({payments.length})</h3>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-[#0a253c] rounded-xl font-semibold hover:bg-[#c19a2e] transition-all"
          >
            <Plus className="w-4 h-4" />
            Zahlung hinzufügen
          </button>
      </div>

      {/* Add Payment Form */}
      {showAddForm && (
        <div className="bg-gray-50 rounded-xl p-6 border-2 border-[#d4af37]/30">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Betrag (€)*</label>
              <input
                type="number"
                step="0.01"
                value={newPayment.amount}
                onChange={(e) => setNewPayment({ ...newPayment, amount: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
                placeholder="0.00"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Fälligkeitsdatum*</label>
              <input
                type="date"
                value={newPayment.due_date}
                onChange={(e) => setNewPayment({ ...newPayment, due_date: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Zahlungsart</label>
              <select
                value={newPayment.payment_type}
                onChange={(e) => setNewPayment({ ...newPayment, payment_type: e.target.value as any })}
                className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
              >
                {paymentTypes.map((type) => (
                  <option key={type.value} value={type.value}>
                    {type.label}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-2">Zahlungsmethode</label>
              <select
                value={newPayment.payment_method}
                onChange={(e) => setNewPayment({ ...newPayment, payment_method: e.target.value })}
                className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
              >
                {paymentMethods.map((method) => (
                  <option key={method.value} value={method.value}>
                    {method.label}
                  </option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-semibold text-gray-700 mb-2">Notizen</label>
              <textarea
                value={newPayment.notes}
                onChange={(e) => setNewPayment({ ...newPayment, notes: e.target.value })}
                rows={2}
                className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
                placeholder="Optional..."
              />
            </div>
          </div>
          <div className="flex gap-3 mt-4">
            <button
              onClick={handleAddPayment}
              className="flex-1 px-4 py-2 bg-[#d4af37] text-[#0a253c] rounded-lg font-semibold hover:bg-[#c19a2e] transition-all"
            >
              Hinzufügen
            </button>
            <button
              onClick={() => setShowAddForm(false)}
              className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg font-semibold hover:bg-gray-300 transition-all"
            >
              Abbrechen
            </button>
          </div>
        </div>
      )}

      {/* Payments List */}
      { (
        <div className="space-y-3">
        {payments.map((payment) => (
          <div
            key={payment.id}
            className={`bg-white rounded-xl p-4 border-2 transition-all ${
              payment.status === 'paid'
                ? 'border-green-200 bg-green-50'
                : payment.status === 'overdue'
                ? 'border-red-200 bg-red-50'
                : 'border-gray-200 hover:border-[#d4af37]'
            }`}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-bold ${
                      payment.status === 'paid'
                        ? 'bg-green-100 text-green-700'
                        : payment.status === 'overdue'
                        ? 'bg-red-100 text-red-700'
                        : 'bg-yellow-100 text-yellow-700'
                    }`}
                  >
                    {payment.status === 'paid'
                      ? 'Bezahlt'
                      : payment.status === 'overdue'
                      ? 'Überfällig'
                      : 'Ausstehend'}
                  </span>
                  <span className="text-sm text-gray-600 capitalize">
                    {paymentTypes.find((t) => t.value === payment.payment_type)?.label}
                  </span>
                </div>
                <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                  <span className="flex items-center gap-1">
                    <Calendar className="w-4 h-4" />
                    Fällig: {new Date(payment.due_date).toLocaleDateString('de-DE')}
                  </span>
                  {payment.payment_date && (
                    <span className="flex items-center gap-1 text-green-600">
                      <CheckCircle className="w-4 h-4" />
                      Bezahlt: {new Date(payment.payment_date).toLocaleDateString('de-DE')}
                    </span>
                  )}
                </div>
                {payment.notes && <p className="text-sm text-gray-600">{payment.notes}</p>}
              </div>
              <div className="text-right ml-4">
                <p className="text-2xl font-bold text-[#0a253c] mb-2">{payment.amount.toFixed(2)} €</p>
                {payment.percentage_of_total && (
                  <p className="text-sm text-gray-600">{payment.percentage_of_total.toFixed(1)}%</p>
                )}
                <div className="flex gap-2 mt-2">
                  {payment.status !== 'paid' && (
                    <button
                      onClick={() => handleMarkAsPaid(payment.id)}
                      className="px-3 py-1 bg-green-500 text-white rounded-lg text-xs font-semibold hover:bg-green-600 transition-all"
                    >
                      Als bezahlt markieren
                    </button>
                  )}
                  <button
                    onClick={() => handleDeletePayment(payment.id)}
                    className="p-1 hover:bg-red-100 rounded-lg transition-colors"
                  >
                    <Trash2 className="w-4 h-4 text-red-500" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}

          {payments.length === 0 && (
            <div className="text-center py-12 bg-gray-50 rounded-xl">
              <DollarSign className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-600">Noch keine Zahlungen erfasst</p>
              <p className="text-sm text-gray-500 mt-2">
                {totalCost
                  ? 'Verwenden Sie eine Vorlage oder fügen Sie manuell Zahlungen hinzu'
                  : 'Bitte zuerst Gesamtkosten für den Dienstleister eingeben'}
              </p>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
