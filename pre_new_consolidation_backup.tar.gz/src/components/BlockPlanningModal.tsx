import { useState, useEffect } from 'react';
import {
  X,
  Clock,
  MapPin,
  User,
  BarChart3,
  CheckSquare,
  Users,
  Package,
  FileText,
  ClipboardList,
  Briefcase,
  Printer,
  DollarSign,
  Lock,
  Crown,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { TimelineEvent } from '../lib/supabase';
import OverviewTab from './BlockPlanning/OverviewTab';
import SubTimelineTab from './BlockPlanning/SubTimelineTab';
import LinkedTasksTab from './BlockPlanning/LinkedTasksTab';
import LinkedVendorsTab from './BlockPlanning/LinkedVendorsTab';
import ChecklistTab from './BlockPlanning/ChecklistTab';
import ItemsTab from './BlockPlanning/ItemsTab';
import NotesTab from './BlockPlanning/NotesTab';
import PrintViewTab from './BlockPlanning/PrintViewTab';
import BudgetCostsTab from './BlockPlanning/BudgetCostsTab';

interface BlockPlanningModalProps {
  event: TimelineEvent;
  weddingId: string;
  onClose: () => void;
  onUpdate: () => void;
}

type TabType = 'overview' | 'subtimeline' | 'tasks' | 'vendors' | 'checklist' | 'items' | 'notes' | 'budget' | 'print';

export default function BlockPlanningModal({
  event,
  weddingId,
  onClose,
  onUpdate,
}: BlockPlanningModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('overview');
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [attendingCount, setAttendingCount] = useState(0);
  const [totalGuestCount, setTotalGuestCount] = useState(0);

  useEffect(() => {
    loadGuestCounts();
  }, [event.id, weddingId]);

  const loadGuestCounts = async () => {
    try {
      const { data: guestsData } = await supabase
        .from('guests')
        .select('id')
        .eq('wedding_id', weddingId);

      const totalCount = guestsData?.length || 0;
      setTotalGuestCount(totalCount);

      const { data: attendanceData } = await supabase
        .from('timeline_event_guest_attendance')
        .select('is_attending')
        .eq('timeline_event_id', event.id);

      const attendingGuestCount = attendanceData?.filter(a => a.is_attending).length || totalCount;
      setAttendingCount(attendingGuestCount);
    } catch (error) {
      console.error('Error loading guest counts:', error);
    }
  };

  const formatTime = (time: string) => {
    return new Date(`2000-01-01T${time}`).toLocaleTimeString('de-DE', {
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const formatDuration = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    if (hours > 0 && mins > 0) return `${hours}h ${mins}min`;
    if (hours > 0) return `${hours}h`;
    return `${mins}min`;
  };

  const handleClose = () => {
    if (hasUnsavedChanges) {
      if (
        confirm(
          'Sie haben ungespeicherte Änderungen. Möchten Sie wirklich schließen?'
        )
      ) {
        onClose();
      }
    } else {
      onClose();
    }
  };

  const tabs = [
    {
      id: 'overview' as TabType,
      name: 'Übersicht',
      icon: BarChart3,
    },
    {
      id: 'subtimeline' as TabType,
      name: 'Sub-Timeline',
      icon: Clock,
    },
    {
      id: 'tasks' as TabType,
      name: 'Aufgaben',
      icon: CheckSquare,
    },
    {
      id: 'vendors' as TabType,
      name: 'Dienstleister',
      icon: Briefcase,
    },
    {
      id: 'budget' as TabType,
      name: 'Budget & Kosten',
      icon: DollarSign,
    },
    {
      id: 'checklist' as TabType,
      name: 'Checkliste',
      icon: ClipboardList,
    },
    {
      id: 'items' as TabType,
      name: 'Utensilien',
      icon: Package,
    },
    {
      id: 'notes' as TabType,
      name: 'Notizen',
      icon: FileText,
    },
    {
      id: 'print' as TabType,
      name: 'Druckansicht',
      icon: Printer,
    },
  ];

  const eventColor = event.color || '#d4af37';

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] p-2 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-6xl h-[95vh] sm:h-[90vh] flex flex-col">
        <div
          className="sticky top-0 z-10 text-white px-4 sm:px-6 py-3 sm:py-4 rounded-t-2xl"
          style={{
            background: `linear-gradient(135deg, ${eventColor} 0%, ${eventColor}dd 100%)`
          }}
        >
          <div className="flex items-center justify-between mb-2 sm:mb-3">
            <div className="flex items-center gap-3">
              <h2 className="text-lg sm:text-2xl font-bold break-words pr-2">{event.title}</h2>
            </div>
            <button
              onClick={handleClose}
              className="p-1.5 sm:p-2 hover:bg-white hover:bg-opacity-20 rounded-lg transition-colors flex-shrink-0"
            >
              <X className="w-5 h-5 sm:w-6 sm:h-6" />
            </button>
          </div>

          <div className="flex flex-wrap gap-2 sm:gap-4 text-xs sm:text-sm text-white/90">
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span>
                {formatTime(event.time)} - {event.end_time && formatTime(event.end_time)}
              </span>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2">
              <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span>{formatDuration(event.duration_minutes)}</span>
            </div>
            <div className="flex items-center gap-1.5 sm:gap-2 bg-white/20 px-2 sm:px-3 py-1 rounded-full">
              <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
              <span className="font-semibold">{attendingCount}/{totalGuestCount} Gäste</span>
            </div>
            {event.location && (
              <div className="flex items-center gap-1.5 sm:gap-2">
                <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span>{event.location}</span>
              </div>
            )}
            {event.assigned_to && (
              <div className="flex items-center gap-1.5 sm:gap-2">
                <User className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                <span>{event.assigned_to}</span>
              </div>
            )}
          </div>
        </div>

        <div className="border-b border-gray-200 bg-gray-50 px-2 sm:px-6">
          <div className="flex space-x-1 overflow-x-auto scrollbar-hide">
            {tabs.map((tab) => {
              const Icon = tab.icon;
              const isLocked = false;
              return (
                <button
                  key={tab.id}
                  onClick={() => {
                    if (isLocked) {
                      setShowPremiumModal(true);
                    } else {
                      setActiveTab(tab.id);
                    }
                  }}
                  disabled={isLocked && activeTab !== tab.id}
                  className={`flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2.5 sm:py-3 font-medium text-xs sm:text-sm whitespace-nowrap border-b-2 transition-colors ${
                    activeTab === tab.id
                      ? 'bg-white border-transparent'
                      : isLocked
                      ? 'border-transparent text-gray-400 cursor-not-allowed'
                      : 'border-transparent text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                  style={activeTab === tab.id ? { borderBottomColor: eventColor, color: eventColor } : {}}
                  title={isLocked ? 'Premium-Feature' : ''}
                >
                  <Icon className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                  {tab.name}
                  {isLocked && <Lock className="w-3 h-3" />}
                </button>
              );
            })}
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {activeTab === 'overview' && (
            <OverviewTab
              event={event}
              weddingId={weddingId}
              onTabChange={setActiveTab}
            />
          )}
          {activeTab === 'subtimeline' && (
            <SubTimelineTab
              event={event}
              onUpdate={onUpdate}
              onUnsavedChanges={setHasUnsavedChanges}
            />
          )}
          {activeTab === 'tasks' && (
            <LinkedTasksTab
              eventId={event.id}
              weddingId={weddingId}
              onUpdate={onUpdate}
            />
          )}
          {activeTab === 'vendors' && (
            <LinkedVendorsTab
              eventId={event.id}
              weddingId={weddingId}
              onUpdate={onUpdate}
            />
          )}
          {activeTab === 'budget' && (
            <BudgetCostsTab
              eventId={event.id}
              weddingId={weddingId}
            />
          )}
          {activeTab === 'checklist' && (
            <ChecklistTab
              eventId={event.id}
              weddingId={weddingId}
              onUpdate={onUpdate}
            />
          )}
          {activeTab === 'items' && (
            <ItemsTab
              eventId={event.id}
              weddingId={weddingId}
              onUpdate={onUpdate}
            />
          )}
          {activeTab === 'notes' && (
            <NotesTab
              eventId={event.id}
              onUnsavedChanges={setHasUnsavedChanges}
            />
          )}
          {activeTab === 'print' && (
            <PrintViewTab
              event={event}
              weddingId={weddingId}
            />
          )}
        </div>
      </div>
    </div>
  );
}
