import { useState, useEffect, useRef } from 'react';
import { Menu, X, Sparkles, CheckCircle, DollarSign, Users, Building2, Clock, Settings, Shield, Crown } from 'lucide-react';
import { TASK, BUDGET, GUEST, VENDOR, TIMELINE, NAV } from '../constants/terminology';

type Tab = 'overview' | 'tasks' | 'budget' | 'guests' | 'vendors' | 'timeline' | 'settings' | 'privacy' | 'subscription';

interface MobileNavDropdownProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

interface NavItem {
  id: Tab;
  icon: React.ElementType;
  label: string;
  isMain?: boolean;
}

const navItems: NavItem[] = [
  { id: 'overview', icon: Sparkles, label: NAV.OVERVIEW, isMain: true },
  { id: 'tasks', icon: CheckCircle, label: TASK.MODULE_NAME, isMain: true },
  { id: 'budget', icon: DollarSign, label: BUDGET.MODULE_NAME, isMain: true },
  { id: 'guests', icon: Users, label: GUEST.MODULE_NAME, isMain: true },
  { id: 'vendors', icon: Building2, label: VENDOR.MODULE_NAME, isMain: true },
  { id: 'timeline', icon: Clock, label: TIMELINE.MODULE_NAME, isMain: true },
  { id: 'settings', icon: Settings, label: NAV.SETTINGS, isMain: false },
  { id: 'privacy', icon: Shield, label: NAV.PRIVACY, isMain: false },
  { id: 'subscription', icon: Crown, label: NAV.SUBSCRIPTION, isMain: false },
];

export default function MobileNavDropdown({ activeTab, onTabChange }: MobileNavDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleTabSelect = (tab: Tab) => {
    onTabChange(tab);
    setIsOpen(false);
  };

  const activeItem = navItems.find(item => item.id === activeTab);
  const mainItems = navItems.filter(item => item.isMain);
  const secondaryItems = navItems.filter(item => !item.isMain);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-white font-semibold shadow-lg hover:shadow-xl transition-all duration-300 active:scale-95"
        aria-label="Navigation öffnen"
      >
        {isOpen ? (
          <X className="w-5 h-5" />
        ) : (
          <Menu className="w-5 h-5" />
        )}
        <span className="text-sm">{activeItem?.label}</span>
      </button>

      {isOpen && (
        <>
          <div className="fixed inset-0 bg-black/20 backdrop-blur-sm z-[60]" onClick={() => setIsOpen(false)} />

          <div className="absolute top-full right-0 mt-2 w-64 bg-white/98 backdrop-blur-xl rounded-2xl shadow-2xl border-2 border-[#d4af37]/30 overflow-hidden animate-dropdown-in z-[70]">
            <div className="p-2">
              <div className="mb-2">
                <div className="px-3 py-2 text-xs font-bold text-[#0a253c]/60 uppercase tracking-wider">
                  Hauptmenü
                </div>
                <div className="space-y-1">
                  {mainItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleTabSelect(item.id)}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                          isActive
                            ? 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-white shadow-md'
                            : 'text-[#0a253c] hover:bg-[#f7f2eb] active:scale-98'
                        }`}
                      >
                        <Icon className={`w-5 h-5 ${isActive ? 'animate-pulse' : ''}`} />
                        <span className="font-semibold text-sm">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="border-t border-[#d4af37]/20 pt-2 mt-2">
                <div className="px-3 py-2 text-xs font-bold text-[#0a253c]/60 uppercase tracking-wider">
                  Weitere
                </div>
                <div className="space-y-1">
                  {secondaryItems.map((item) => {
                    const Icon = item.icon;
                    const isActive = activeTab === item.id;
                    return (
                      <button
                        key={item.id}
                        onClick={() => handleTabSelect(item.id)}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
                          isActive
                            ? 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-white shadow-md'
                            : 'text-[#0a253c] hover:bg-[#f7f2eb] active:scale-98'
                        }`}
                      >
                        <Icon className={`w-5 h-5 ${isActive ? 'animate-pulse' : ''}`} />
                        <span className="font-semibold text-sm">{item.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}
