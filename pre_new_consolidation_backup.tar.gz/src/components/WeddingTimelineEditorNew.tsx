import { useState, useEffect } from 'react';
import { Clock, Calendar, Target, Users, Cloud, CalendarDays, Heart, Timer, CalendarCheck } from 'lucide-react';
import { supabase, type TimelineEvent, type WeddingTeamRole } from '../lib/supabase';
import TabContainer, { type Tab } from './common/TabContainer';
import PageHeaderWithStats, { type StatCard } from './common/PageHeaderWithStats';
import TimelineHochzeitstagTab from './Timeline/TimelineHochzeitstagTab';
import TimelineCountdownTab from './Timeline/TimelineCountdownTab';
import TimelinePlanungsphasenTab from './Timeline/TimelinePlanungsphasenTab';
import TimelineTeamZeitplanTab from './Timeline/TimelineTeamZeitplanTab';
import TimelineBackupTab from './Timeline/TimelineBackupTab';
import { TIMELINE } from '../constants/terminology';

interface WeddingTimelineEditorProps {
  weddingId: string;
}

export default function WeddingTimelineEditor({ weddingId }: WeddingTimelineEditorProps) {
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [teamRoles, setTeamRoles] = useState<WeddingTeamRole[]>([]);
  const [weddingDate, setWeddingDate] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);

  useEffect(() => {
    loadData();
  }, [weddingId]);

  const loadData = async () => {
    try {
      const [eventsData, rolesData, weddingData] = await Promise.all([
        supabase
          .from('wedding_timeline')
          .select('*')
          .eq('wedding_id', weddingId)
          .order('order_index', { ascending: true }),
        supabase
          .from('wedding_team_roles')
          .select('*')
          .eq('wedding_id', weddingId),
        supabase
          .from('weddings')
          .select('wedding_date')
          .eq('id', weddingId)
          .maybeSingle(),
      ]);

      if (eventsData.data) setEvents(eventsData.data);
      if (rolesData.data) setTeamRoles(rolesData.data);
      if (weddingData.data) setWeddingDate(weddingData.data.wedding_date);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const getDaysUntilWedding = () => {
    if (!weddingDate) return 0;
    const today = new Date();
    const wedding = new Date(weddingDate);
    const diffTime = wedding.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const getEventsThisWeek = () => {
    const today = new Date();
    const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);
    return events.filter(e => {
      if (!e.date) return false;
      const eventDate = new Date(e.date);
      return eventDate >= today && eventDate <= nextWeek;
    }).length;
  };

  const getEventsToday = () => {
    const today = new Date();
    return events.filter(e => {
      if (!e.date) return false;
      const eventDate = new Date(e.date);
      return eventDate.toDateString() === today.toDateString();
    }).length;
  };

  const daysUntil = getDaysUntilWedding();
  const eventsToday = getEventsToday();
  const eventsThisWeek = getEventsThisWeek();

  const stats: StatCard[] = [
    {
      icon: <CalendarDays className="w-6 h-6 text-white" />,
      label: 'Gesamt Events',
      value: events.length,
      subtitle: `${teamRoles.length} Team-Mitglieder`,
      color: 'yellow'
    },
    {
      icon: <CalendarCheck className="w-6 h-6 text-white" />,
      label: 'Heute',
      value: eventsToday,
      subtitle: eventsToday > 0 ? 'Events heute' : 'Keine Events',
      color: 'green'
    },
    {
      icon: <Timer className="w-6 h-6 text-white" />,
      label: 'Diese Woche',
      value: eventsThisWeek,
      subtitle: eventsThisWeek > 0 ? 'Events anstehend' : 'Keine Events',
      color: 'blue'
    },
    {
      icon: <Heart className="w-6 h-6 text-white" />,
      label: 'Tage bis Hochzeit',
      value: daysUntil,
      subtitle: daysUntil > 0 ? 'Noch etwas Zeit' : 'Der große Tag!',
      color: 'red'
    }
  ];

  const tabs: Tab[] = [
    {
      id: 'hochzeitstag',
      label: 'Hochzeitstag',
      icon: <Clock className="w-4 h-4" />,
      badge: events.length,
      content: (
        <TimelineHochzeitstagTab
          weddingId={weddingId}
          events={events}
          onUpdate={loadData}
          onAddEvent={() => setShowAddForm(true)}
        />
      ),
    },
    {
      id: 'countdown',
      label: 'Countdown',
      icon: <Calendar className="w-4 h-4" />,
      content: <TimelineCountdownTab weddingDate={weddingDate} />,
    },
    {
      id: 'planungsphasen',
      label: 'Planungsphasen',
      icon: <Target className="w-4 h-4" />,
      content: <TimelinePlanungsphasenTab weddingDate={weddingDate} />,
    },
    {
      id: 'team',
      label: 'Team-Zeitplan',
      icon: <Users className="w-4 h-4" />,
      badge: teamRoles.length,
      content: <TimelineTeamZeitplanTab events={events} teamRoles={teamRoles} />,
    },
    {
      id: 'backup',
      label: 'Notfallpläne',
      icon: <Cloud className="w-4 h-4" />,
      content: <TimelineBackupTab />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeaderWithStats
        title={TIMELINE.MODULE_NAME}
        subtitle="Plane den Ablauf eures großen Tages"
        stats={stats}
      />

      <TabContainer
        tabs={tabs}
        defaultTab="hochzeitstag"
        storageKey={`timeline-tab-${weddingId}`}
        urlParam="timelineTab"
      />
    </div>
  );
}
