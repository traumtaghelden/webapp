import { useState, useEffect } from 'react';
import { X, Edit2, Save, Building2, Mail, Phone, Globe, MapPin, Star, Calendar, DollarSign, FileText, Activity, Link as LinkIcon, CheckCircle } from 'lucide-react';
import { supabase } from '../lib/supabase';
import VendorPaymentManager from './VendorPaymentManager';
import VendorDocumentManager from './VendorDocumentManager';
import { VENDOR, COMMON } from '../constants/terminology';

interface Vendor {
  id: string;
  wedding_id: string;
  name: string;
  category: string;
  contact_name: string | null;
  email: string | null;
  phone: string | null;
  address: string | null;
  website: string | null;
  contract_status: string;
  total_cost: number | null;
  paid_amount: number;
  payment_due_date: string | null;
  rating: number | null;
  notes: string | null;
  created_at: string;
}

interface VendorPayment {
  id: string;
  vendor_id: string;
  amount: number;
  due_date: string;
  payment_date: string | null;
  status: string;
  payment_type: string;
  payment_method: string;
  notes: string;
}

interface VendorAttachment {
  id: string;
  vendor_id: string;
  file_name: string;
  file_url: string;
  file_size: number;
  file_type: string;
  category: string;
  created_at: string;
}

interface ActivityLogEntry {
  id: string;
  action_type: string;
  description: string;
  created_at: string;
  user_id: string | null;
}

interface BudgetItem {
  id: string;
  item_name: string;
  actual_cost: number;
  payment_status: string;
  category: string;
}

interface VendorDetailModalProps {
  vendorId: string;
  onClose: () => void;
  onUpdate: () => void;
}

export default function VendorDetailModal({ vendorId, onClose, onUpdate }: VendorDetailModalProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'finances' | 'documents'>('overview');
  const [vendor, setVendor] = useState<Vendor | null>(null);
  const [payments, setPayments] = useState<VendorPayment[]>([]);
  const [attachments, setAttachments] = useState<VendorAttachment[]>([]);
  const [activityLog, setActivityLog] = useState<ActivityLogEntry[]>([]);
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [isEditing, setIsEditing] = useState(false);
  const [loading, setLoading] = useState(true);
  const [editedVendor, setEditedVendor] = useState<Partial<Vendor>>({});

  const categories = [
    { value: 'location', label: 'Location', icon: '🏛️' },
    { value: 'catering', label: 'Catering', icon: '🍽️' },
    { value: 'photography', label: 'Fotografie', icon: '📷' },
    { value: 'videography', label: 'Videografie', icon: '🎥' },
    { value: 'music', label: 'Musik/DJ', icon: '🎵' },
    { value: 'flowers', label: 'Floristik', icon: '💐' },
    { value: 'decoration', label: 'Dekoration', icon: '🎨' },
    { value: 'dress', label: 'Brautmode', icon: '👗' },
    { value: 'hair_makeup', label: 'Frisur & Make-up', icon: '💄' },
    { value: 'transportation', label: 'Transport', icon: '🚗' },
    { value: 'cake', label: 'Hochzeitstorte', icon: '🎂' },
    { value: 'invitations', label: 'Einladungen', icon: '💌' },
    { value: 'other', label: 'Sonstiges', icon: '📦' },
  ];

  const contractStatuses = [
    { value: 'inquiry', label: 'Anfrage', color: 'bg-gray-100 text-gray-700' },
    { value: 'pending', label: 'In Verhandlung', color: 'bg-yellow-100 text-yellow-700' },
    { value: 'signed', label: 'Vertrag unterschrieben', color: 'bg-blue-100 text-blue-700' },
    { value: 'completed', label: 'Abgeschlossen', color: 'bg-green-100 text-green-700' },
    { value: 'cancelled', label: 'Storniert', color: 'bg-red-100 text-red-700' },
  ];

  useEffect(() => {
    if (vendorId) {
      loadData();
    }
  }, [vendorId, activeTab]);

  const loadData = async () => {
    try {
      setLoading(true);

      const { data: vendorData } = await supabase
        .from('vendors')
        .select('*')
        .eq('id', vendorId)
        .single();

      if (vendorData) {
        setVendor(vendorData);
        setEditedVendor(vendorData);
      }

      // Load all data for finances tab (payments + budget)
      if (activeTab === 'finances') {
        const [paymentsResult, budgetResult] = await Promise.all([
          supabase
            .from('vendor_payments')
            .select('*')
            .eq('vendor_id', vendorId)
            .order('due_date', { ascending: true }),
          supabase
            .from('budget_items')
            .select('id, item_name, actual_cost, payment_status, category')
            .eq('vendor_id', vendorId)
        ]);
        if (paymentsResult.data) setPayments(paymentsResult.data);
        if (budgetResult.data) setBudgetItems(budgetResult.data);
      }

      if (activeTab === 'documents') {
        const { data: attachmentsData } = await supabase
          .from('vendor_attachments')
          .select('*')
          .eq('vendor_id', vendorId)
          .order('created_at', { ascending: false });
        if (attachmentsData) setAttachments(attachmentsData);
      }

      // Always load activity log for sidebar
      const { data: activityData } = await supabase
        .from('vendor_activity_log')
        .select('*')
        .eq('vendor_id', vendorId)
        .order('created_at', { ascending: false })
        .limit(10);
      if (activityData) setActivityLog(activityData);
    } catch (error) {
      console.error('Error loading vendor data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    try {
      const { error } = await supabase
        .from('vendors')
        .update(editedVendor)
        .eq('id', vendorId);

      if (error) throw error;

      setIsEditing(false);
      onUpdate();
      loadData();
    } catch (error) {
      console.error('Error updating vendor:', error);
      alert('Fehler beim Speichern der Änderungen');
    }
  };

  const handleRatingChange = async (newRating: number) => {
    try {
      await supabase
        .from('vendors')
        .update({ rating: newRating })
        .eq('id', vendorId);
      loadData();
      onUpdate();
    } catch (error) {
      console.error('Error updating rating:', error);
    }
  };

  if (!vendor || loading) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999]">
        <div className="bg-white rounded-3xl shadow-2xl max-w-6xl w-full max-h-[90vh] flex flex-col p-6">
          <div className="animate-pulse space-y-4">
            <div className="h-8 bg-gray-200 rounded w-1/3"></div>
            <div className="h-64 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  const category = categories.find(c => c.value === vendor.category);
  const statusInfo = contractStatuses.find(s => s.value === vendor.contract_status);
  const paymentProgress = vendor.total_cost ? (vendor.paid_amount / vendor.total_cost) * 100 : 0;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-6xl w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-6 border-b border-gray-200">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-[#d4af37] to-[#f4d03f] flex items-center justify-center text-2xl">
                {category?.icon || '📦'}
              </div>
              <div>
                <h2 className="text-2xl font-bold text-[#0a253c]">{vendor.name}</h2>
                <p className="text-sm text-gray-600">{category?.label}</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              {!isEditing ? (
                <button
                  onClick={() => setIsEditing(true)}
                  className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-[#0a253c] rounded-xl font-semibold hover:bg-[#c19a2e] transition-all"
                >
                  <Edit2 className="w-4 h-4" />
                  Bearbeiten
                </button>
              ) : (
                <button
                  onClick={handleSave}
                  className="flex items-center gap-2 px-4 py-2 bg-green-500 text-white rounded-xl font-semibold hover:bg-green-600 transition-all"
                >
                  <Save className="w-4 h-4" />
                  Speichern
                </button>
              )}
              <button
                onClick={onClose}
                className="p-2 hover:bg-gray-100 rounded-xl transition-colors"
              >
                <X className="w-6 h-6 text-gray-600" />
              </button>
            </div>
          </div>

          {/* Tab Navigation - Simplified to 3 Tabs */}
          <div className="flex gap-2 border-b border-gray-200 -mb-[1px]">
            {[
              { id: 'overview', label: 'Übersicht', icon: Building2 },
              { id: 'finances', label: 'Finanzen', icon: DollarSign },
              { id: 'documents', label: 'Dokumente', icon: FileText },
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-3 font-semibold border-b-2 transition-all ${
                  activeTab === tab.id
                    ? 'border-[#d4af37] text-[#d4af37]'
                    : 'border-transparent text-gray-600 hover:text-gray-900'
                }`}
              >
                <tab.icon className="w-4 h-4" />
                {tab.label}
              </button>
            ))}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'overview' && (
            <div className="space-y-6">
              {/* Status and Rating */}
              <div className="grid md:grid-cols-2 gap-4">
                <div className="bg-gray-50 rounded-xl p-4">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Vertragsstatus</label>
                  {isEditing ? (
                    <select
                      value={editedVendor.contract_status || vendor.contract_status}
                      onChange={(e) => setEditedVendor({ ...editedVendor, contract_status: e.target.value })}
                      className={`w-full px-3 py-2 rounded-lg text-sm font-semibold border-2 ${statusInfo?.color}`}
                    >
                      {contractStatuses.map((status) => (
                        <option key={status.value} value={status.value}>
                          {status.label}
                        </option>
                      ))}
                    </select>
                  ) : (
                    <span className={`inline-block px-3 py-2 rounded-lg text-sm font-semibold ${statusInfo?.color}`}>
                      {statusInfo?.label}
                    </span>
                  )}
                </div>

                <div className="bg-gray-50 rounded-xl p-4">
                  <label className="block text-sm font-semibold text-gray-700 mb-2">Bewertung</label>
                  <div className="flex gap-1">
                    {[1, 2, 3, 4, 5].map((star) => (
                      <button
                        key={star}
                        onClick={() => !isEditing && handleRatingChange(star)}
                        disabled={isEditing}
                        className={`transition-all ${isEditing ? 'cursor-not-allowed opacity-50' : 'hover:scale-110'}`}
                      >
                        <Star
                          className={`w-6 h-6 ${
                            vendor.rating && vendor.rating >= star
                              ? 'text-[#d4af37] fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-lg font-bold text-[#0a253c] mb-4">Kontaktinformationen</h3>
                <div className="grid md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Ansprechpartner</label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editedVendor.contact_name || ''}
                        onChange={(e) => setEditedVendor({ ...editedVendor, contact_name: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : (
                      <p className="text-gray-900">{vendor.contact_name || '-'}</p>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                      <Mail className="w-4 h-4" />
                      E-Mail
                    </label>
                    {isEditing ? (
                      <input
                        type="email"
                        value={editedVendor.email || ''}
                        onChange={(e) => setEditedVendor({ ...editedVendor, email: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : (
                      <a href={`mailto:${vendor.email}`} className="text-[#d4af37] hover:underline">
                        {vendor.email || '-'}
                      </a>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                      <Phone className="w-4 h-4" />
                      Telefon
                    </label>
                    {isEditing ? (
                      <input
                        type="tel"
                        value={editedVendor.phone || ''}
                        onChange={(e) => setEditedVendor({ ...editedVendor, phone: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : (
                      <a href={`tel:${vendor.phone}`} className="text-[#d4af37] hover:underline">
                        {vendor.phone || '-'}
                      </a>
                    )}
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                      <Globe className="w-4 h-4" />
                      Website
                    </label>
                    {isEditing ? (
                      <input
                        type="url"
                        value={editedVendor.website || ''}
                        onChange={(e) => setEditedVendor({ ...editedVendor, website: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : vendor.website ? (
                      <a href={vendor.website} target="_blank" rel="noopener noreferrer" className="text-[#d4af37] hover:underline">
                        {vendor.website}
                      </a>
                    ) : (
                      <p className="text-gray-500">-</p>
                    )}
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                      <MapPin className="w-4 h-4" />
                      Adresse
                    </label>
                    {isEditing ? (
                      <input
                        type="text"
                        value={editedVendor.address || ''}
                        onChange={(e) => setEditedVendor({ ...editedVendor, address: e.target.value })}
                        className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
                      />
                    ) : (
                      <p className="text-gray-900">{vendor.address || '-'}</p>
                    )}
                  </div>
                </div>
              </div>

              {/* Financial Information */}
              {vendor.total_cost && (
                <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border-2 border-green-200">
                  <h3 className="text-lg font-bold text-[#0a253c] mb-4">Finanzübersicht</h3>
                  <div className="grid md:grid-cols-3 gap-4 mb-4">
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Gesamtkosten</p>
                      <p className="text-2xl font-bold text-[#0a253c]">{vendor.total_cost.toLocaleString('de-DE')} €</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Bezahlt</p>
                      <p className="text-2xl font-bold text-green-600">{vendor.paid_amount.toLocaleString('de-DE')} €</p>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-1">Offen</p>
                      <p className="text-2xl font-bold text-orange-600">
                        {(vendor.total_cost - vendor.paid_amount).toLocaleString('de-DE')} €
                      </p>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-3">
                    <div
                      className="bg-gradient-to-r from-green-500 to-emerald-500 h-full rounded-full transition-all"
                      style={{ width: `${Math.min(paymentProgress, 100)}%` }}
                    />
                  </div>
                  <p className="text-sm text-gray-600 mt-2 text-center">{paymentProgress.toFixed(0)}% bezahlt</p>
                </div>
              )}

              {/* Notes */}
              <div className="bg-gray-50 rounded-xl p-6">
                <h3 className="text-lg font-bold text-[#0a253c] mb-4">Notizen</h3>
                {isEditing ? (
                  <textarea
                    value={editedVendor.notes || ''}
                    onChange={(e) => setEditedVendor({ ...editedVendor, notes: e.target.value })}
                    rows={6}
                    className="w-full px-3 py-2 rounded-lg border-2 border-gray-300 focus:border-[#d4af37] focus:outline-none"
                    placeholder="Notizen zum Dienstleister..."
                  />
                ) : (
                  <p className="text-gray-700 whitespace-pre-wrap">{vendor.notes || 'Keine Notizen vorhanden'}</p>
                )}
              </div>
            </div>
          )}

          {activeTab === 'finances' && (
            <div className="space-y-6">
              {/* Payments Section */}
              <div>
                <h3 className="text-lg font-bold text-[#0a253c] mb-4 flex items-center gap-2">
                  <DollarSign className="w-5 h-5 text-[#d4af37]" />
                  Zahlungsplan
                </h3>
                <VendorPaymentManager
                  vendorId={vendorId}
                  totalCost={vendor.total_cost}
                  onUpdate={() => {
                    loadData();
                    onUpdate();
                  }}
                />
              </div>

              {/* Budget Items Section */}
              <div className="mt-8 pt-6 border-t-2 border-gray-200">
                <h3 className="text-lg font-bold text-[#0a253c] mb-4 flex items-center gap-2">
                  <LinkIcon className="w-5 h-5 text-[#d4af37]" />
                  Verknüpfte Budget-Positionen
                </h3>
                {budgetItems.length === 0 ? (
                  <div className="text-center py-8 bg-gray-50 rounded-xl">
                    <LinkIcon className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                    <p className="text-gray-600 text-sm">Keine Budget-Positionen verknüpft</p>
                    <p className="text-gray-500 text-xs mt-1">Verknüpfe diesen Dienstleister mit Budget-Positionen im Budget-Manager</p>
                  </div>
                ) : (
                  <div className="space-y-3">
                    {budgetItems.map((item) => (
                      <div key={item.id} className="bg-gradient-to-r from-white to-gray-50 border-2 border-gray-200 rounded-xl p-4 hover:border-[#d4af37] transition-all">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <h4 className="font-bold text-[#0a253c] mb-1">{item.item_name}</h4>
                            <div className="flex items-center gap-2">
                              <span className="text-xs text-gray-600 capitalize bg-gray-100 px-2 py-0.5 rounded">{item.category}</span>
                              <span className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                                item.payment_status === 'paid' ? 'bg-green-100 text-green-700' :
                                item.payment_status === 'partial' ? 'bg-yellow-100 text-yellow-700' :
                                item.payment_status === 'overdue' ? 'bg-red-100 text-red-700' :
                                'bg-gray-100 text-gray-700'
                              }`}>
                                {item.payment_status === 'paid' ? 'Bezahlt' :
                                 item.payment_status === 'partial' ? 'Teilweise' :
                                 item.payment_status === 'overdue' ? 'Überfällig' : 'Ausstehend'}
                              </span>
                            </div>
                          </div>
                          <div className="text-right">
                            <p className="text-xl font-bold text-[#0a253c]">{item.actual_cost.toFixed(2)} €</p>
                          </div>
                        </div>
                      </div>
                    ))}
                    <div className="bg-gradient-to-r from-green-50 to-emerald-50 rounded-xl p-4 border-2 border-green-200">
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-[#0a253c]">Gesamtsumme Budget-Positionen</span>
                        <span className="text-2xl font-bold text-green-600">
                          {budgetItems.reduce((sum, item) => sum + item.actual_cost, 0).toFixed(2)} €
                        </span>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Recent Activity in Finances Tab */}
              {activityLog.length > 0 && (
                <div className="mt-6 pt-6 border-t border-gray-200">
                  <h3 className="text-sm font-bold text-gray-700 mb-3 flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    Letzte Aktivitäten
                  </h3>
                  <div className="space-y-2">
                    {activityLog.slice(0, 3).map((log) => (
                      <div key={log.id} className="flex gap-3 p-3 bg-gray-50 rounded-lg text-xs">
                        <div className="w-6 h-6 rounded-full bg-[#d4af37]/20 flex items-center justify-center flex-shrink-0">
                          <Activity className="w-3 h-3 text-[#d4af37]" />
                        </div>
                        <div className="flex-1">
                          <p className="font-semibold text-[#0a253c]">{log.description}</p>
                          <p className="text-gray-500 mt-0.5">
                            {new Date(log.created_at).toLocaleString('de-DE')}
                          </p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}

          {activeTab === 'documents' && (
            <VendorDocumentManager
              vendorId={vendorId}
              onUpdate={() => {
                loadData();
                onUpdate();
              }}
            />
          )}
        </div>
      </div>
    </div>
  );
}
