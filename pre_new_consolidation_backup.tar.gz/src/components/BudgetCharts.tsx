import { X, PieChart, BarChart3, TrendingUp } from 'lucide-react';
import { useState } from 'react';
import { type BudgetItem } from '../lib/supabase';

interface BudgetChartsProps {
  budgetItems: BudgetItem[];
  totalBudget: number;
  onClose: () => void;
}

export default function BudgetCharts({ budgetItems, totalBudget, onClose }: BudgetChartsProps) {
  const safeBudgetItems = budgetItems || [];

  const groupedByCategory = safeBudgetItems.reduce((acc, item) => {
    if (!acc[item.category]) {
      acc[item.category] = { actual: 0, count: 0 };
    }
    acc[item.category].actual += item.actual_cost || 0;
    acc[item.category].count += 1;
    return acc;
  }, {} as Record<string, { actual: number; count: number }>);

  const categories = Object.entries(groupedByCategory);
  const totalActual = safeBudgetItems.reduce((sum, item) => sum + (item.actual_cost || 0), 0);

  const categoryColors = [
    '#d4af37', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6',
    '#ec4899', '#14b8a6', '#f97316', '#ef4444', '#06b6d4',
  ];

  const pieChartData = categories.map(([category, data], index) => ({
    category,
    value: data.actual,
    percentage: totalActual > 0 ? (data.actual / totalActual) * 100 : 0,
    color: categoryColors[index % categoryColors.length],
  }));

  const totalPercentage = pieChartData.reduce((sum, d) => sum + d.percentage, 0);
  let currentAngle = 0;

  if (safeBudgetItems.length === 0) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
        <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full p-8 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-[#f7f2eb] rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-[#333333]" />
          </button>
          <div className="text-center">
            <PieChart className="w-16 h-16 text-[#d4af37] mx-auto mb-4" />
            <h2 className="text-2xl font-bold text-[#0a253c] mb-2">Keine Budget-Daten</h2>
            <p className="text-[#666666] mb-6">
              Füge Budget-Posten hinzu, um die Visualisierung zu sehen.
            </p>
            <button
              onClick={onClose}
              className="px-6 py-3 bg-[#d4af37] text-white font-semibold rounded-lg hover:bg-[#c19a2e] transition-all"
            >
              Schließen
            </button>
          </div>
        </div>
      </div>
    );
  }

  const svgPaths = pieChartData.map((data) => {
    const startAngle = currentAngle;
    const angle = (data.percentage / 100) * 360;
    currentAngle += angle;

    const startRad = (startAngle - 90) * (Math.PI / 180);
    const endRad = (currentAngle - 90) * (Math.PI / 180);

    const x1 = 50 + 45 * Math.cos(startRad);
    const y1 = 50 + 45 * Math.sin(startRad);
    const x2 = 50 + 45 * Math.cos(endRad);
    const y2 = 50 + 45 * Math.sin(endRad);

    const largeArcFlag = angle > 180 ? 1 : 0;

    const pathData = [
      `M 50 50`,
      `L ${x1} ${y1}`,
      `A 45 45 0 ${largeArcFlag} 1 ${x2} ${y2}`,
      `Z`,
    ].join(' ');

    return {
      path: pathData,
      color: data.color,
      category: data.category,
      percentage: data.percentage,
      value: data.value,
    };
  });

  const maxValue = Math.max(...categories.map(([, data]) => data.actual));

  const chartContent = (
    <div className="flex-1 overflow-y-auto p-6">
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-2xl p-6 border-2 border-[#d4af37]/30">
                <div className="flex items-center gap-2 mb-6">
                  <PieChart className="w-6 h-6 text-[#d4af37]" />
                  <h3 className="text-xl font-bold text-[#0a253c]">Budget-Verteilung</h3>
                </div>

                <div className="flex items-center justify-center">
                  <svg viewBox="0 0 100 100" className="w-64 h-64">
                    {svgPaths.map((segment, index) => (
                      <g key={index} className="group cursor-pointer">
                        <path
                          d={segment.path}
                          fill={segment.color}
                          className="transition-all duration-300 hover:opacity-80"
                        />
                        <title>
                          {segment.category}: {segment.value.toLocaleString('de-DE')} € ({segment.percentage.toFixed(1)}%)
                        </title>
                      </g>
                    ))}
                    <circle cx="50" cy="50" r="20" fill="white" />
                    <text
                      x="50"
                      y="48"
                      textAnchor="middle"
                      className="text-xs font-bold fill-[#0a253c]"
                    >
                      {totalActual.toLocaleString('de-DE', { maximumFractionDigits: 0 })}
                    </text>
                    <text
                      x="50"
                      y="56"
                      textAnchor="middle"
                      className="text-[0.5rem] fill-[#666666]"
                    >
                      Euro
                    </text>
                  </svg>
                </div>

                <div className="space-y-2 mt-6">
                  {pieChartData.map((data, index) => (
                    <div key={index} className="flex items-center justify-between p-3 rounded-xl bg-white hover:bg-[#f7f2eb] transition-colors">
                      <div className="flex items-center gap-3">
                        <div
                          className="w-4 h-4 rounded-full"
                          style={{ backgroundColor: data.color }}
                        />
                        <span className="text-sm font-semibold text-[#0a253c] capitalize">{data.category}</span>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-bold text-[#0a253c]">
                          {data.value.toLocaleString('de-DE')} €
                        </p>
                        <p className="text-xs text-[#666666]">{data.percentage.toFixed(1)}%</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-white rounded-2xl p-6 border-2 border-blue-300">
                <div className="flex items-center gap-2 mb-4">
                  <TrendingUp className="w-6 h-6 text-blue-600" />
                  <h3 className="text-xl font-bold text-[#0a253c]">Budget-Statistiken</h3>
                </div>

                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-white rounded-xl">
                    <span className="text-sm text-[#666666]">Gesamtbudget</span>
                    <span className="text-lg font-bold text-[#0a253c]">{totalBudget.toLocaleString('de-DE')} €</span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white rounded-xl">
                    <span className="text-sm text-[#666666]">Tatsächliche Kosten</span>
                    <span className="text-lg font-bold text-blue-600">{totalActual.toLocaleString('de-DE')} €</span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white rounded-xl">
                    <span className="text-sm text-[#666666]">Verbleibend</span>
                    <span className={`text-lg font-bold ${totalBudget - totalActual >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {(totalBudget - totalActual).toLocaleString('de-DE')} €
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white rounded-xl">
                    <span className="text-sm text-[#666666]">Anzahl Posten</span>
                    <span className="text-lg font-bold text-[#0a253c]">{safeBudgetItems.length}</span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white rounded-xl">
                    <span className="text-sm text-[#666666]">Durchschn. Kosten pro Posten</span>
                    <span className="text-lg font-bold text-[#0a253c]">
                      {safeBudgetItems.length > 0 ? (totalActual / safeBudgetItems.length).toLocaleString('de-DE', { maximumFractionDigits: 0 }) : 0} €
                    </span>
                  </div>

                  <div className="flex items-center justify-between p-4 bg-white rounded-xl">
                    <span className="text-sm text-[#666666]">Budget-Ausschöpfung</span>
                    <span className={`text-lg font-bold ${totalBudget > 0 && (totalActual / totalBudget) * 100 > 90 ? 'text-red-600' : 'text-green-600'}`}>
                      {totalBudget > 0 ? Math.round((totalActual / totalBudget) * 100) : 0}%
                    </span>
                  </div>
                </div>
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-2xl p-6 border-2 border-[#d4af37]/30">
                <div className="flex items-center gap-2 mb-6">
                  <BarChart3 className="w-6 h-6 text-[#d4af37]" />
                  <h3 className="text-xl font-bold text-[#0a253c]">Kosten nach Kategorie</h3>
                </div>

                <div className="space-y-6">
                  {categories.map(([category, data], index) => {
                    const actualWidth = (data.actual / maxValue) * 100;

                    return (
                      <div key={category}>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-semibold text-[#0a253c] capitalize">{category}</span>
                          <span className="text-xs text-[#666666]">{data.count} Posten</span>
                        </div>

                        <div className="space-y-2">
                          <div className="relative">
                            <div className="flex items-center justify-between text-xs text-[#666666] mb-1">
                              <span>Kosten</span>
                              <span className="font-semibold text-[#0a253c]">
                                {data.actual.toLocaleString('de-DE')} €
                              </span>
                            </div>
                            <div className="w-full bg-[#f7f2eb] rounded-full h-3 overflow-hidden">
                              <div
                                className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-full rounded-full transition-all duration-500"
                                style={{ width: `${actualWidth}%` }}
                              />
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              <div className="bg-gradient-to-br from-green-50 to-white rounded-2xl p-6 border-2 border-green-300">
                <h3 className="text-xl font-bold text-[#0a253c] mb-4">Top 5 Ausgaben</h3>
                <div className="space-y-3">
                  {[...safeBudgetItems]
                    .sort((a, b) => (b.actual_cost || 0) - (a.actual_cost || 0))
                    .slice(0, 5)
                    .map((item, index) => (
                      <div
                        key={item.id}
                        className="flex items-center justify-between p-4 bg-white rounded-xl hover:shadow-md transition-all"
                      >
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-full bg-[#d4af37]/20 flex items-center justify-center">
                            <span className="text-sm font-bold text-[#d4af37]">#{index + 1}</span>
                          </div>
                          <div>
                            <p className="font-semibold text-[#0a253c]">{item.item_name}</p>
                            <p className="text-xs text-[#666666] capitalize">{item.category}</p>
                          </div>
                        </div>
                        <p className="text-lg font-bold text-green-600">
                          {(item.actual_cost || 0).toLocaleString('de-DE')} €
                        </p>
                      </div>
                    ))}
                </div>
              </div>

              <div className="bg-gradient-to-br from-yellow-50 to-white rounded-2xl p-6 border-2 border-yellow-300">
                <h3 className="text-xl font-bold text-[#0a253c] mb-4">Budget-Warnungen</h3>
                <div className="space-y-3">
                  {categories
                    .filter(([, data]) => data.actual > data.estimated)
                    .map(([category, data]) => (
                      <div
                        key={category}
                        className="p-4 bg-red-50 rounded-xl border-2 border-red-200"
                      >
                        <div className="flex items-center gap-2 mb-2">
                          <TrendingUp className="w-5 h-5 text-red-600" />
                          <span className="font-semibold text-red-600 capitalize">{category}</span>
                        </div>
                        <p className="text-sm text-[#666666]">
                          Überschreitung: {(data.actual - data.estimated).toLocaleString('de-DE')} €
                          ({((data.actual - data.estimated) / data.estimated * 100).toFixed(1)}%)
                        </p>
                      </div>
                    ))}

                  {categories.every(([, data]) => data.actual <= data.estimated) && (
                    <div className="p-4 bg-green-50 rounded-xl border-2 border-green-200 text-center">
                      <p className="text-green-600 font-semibold">Alle Kategorien im Budget!</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
    </div>
  );

  return (
    <>
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
        <div className="bg-white rounded-3xl shadow-2xl max-w-6xl w-full max-h-[90vh] flex flex-col">
          <div className="p-6 border-b border-[#d4af37]/20">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-12 h-12 rounded-xl flex items-center justify-center shadow-lg">
                  <PieChart className="w-6 h-6 text-white" />
                </div>
                <div className="flex items-center gap-3">
                  <div>
                    <h2 className="text-2xl font-bold text-[#0a253c]">Budget-Visualisierung</h2>
                    <p className="text-sm text-[#666666]">Detaillierte Übersicht & Diagramme</p>
                  </div>
                  { <PremiumBadge size="small" />}
                </div>
              </div>
              <button
                onClick={onClose}
                className="p-2 hover:bg-[#f7f2eb] rounded-full transition-colors"
              >
                <X className="w-6 h-6 text-[#333333]" />
              </button>
            </div>
          </div>

          {chartContent}
        </div>
      </div>

      </>
  );
}
