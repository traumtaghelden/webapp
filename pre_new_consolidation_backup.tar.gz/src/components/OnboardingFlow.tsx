import { useState, useEffect, useRef } from 'react';
import { Heart, ArrowRight, ArrowLeft, Sparkles, Star, Calendar, Users, Coins, ChevronLeft, ChevronRight, Mail, Phone, User, LogOut } from 'lucide-react';
import { supabase } from '../lib/supabase';
import OnboardingIntro from './OnboardingIntro';
import CharacterSelector from './CharacterSelector';

interface OnboardingFlowProps {
  onComplete: (data: {
    weddingId: string;
    partner1Name: string;
    partner2Name: string;
    partner1HeroType: string;
    partner2HeroType: string;
    weddingDate: string;
    ceremonyType: string;
  }) => void;
}

interface FormData {
  partner1Name: string;
  partner2Name: string;
  partner1Age: string;
  partner2Age: string;
  partner1HeroType: string;
  partner2HeroType: string;
  weddingDate: string;
  guestCount: string;
  ceremonyType: string;
  budget: string;
  witness1Name: string;
  witness2Name: string;
  witness1Email: string;
  witness2Email: string;
  witness1Phone: string;
  witness2Phone: string;
  parent1Name: string;
  parent2Name: string;
  parent1Email: string;
  parent2Email: string;
  parent1Phone: string;
  parent2Phone: string;
  helper1Name: string;
  helper2Name: string;
  helper1Email: string;
  helper2Email: string;
  helper1Phone: string;
  helper2Phone: string;
  witness1Character: string;
  witness2Character: string;
  parent1Character: string;
  parent2Character: string;
  helper1Character: string;
  helper2Character: string;
}

export default function OnboardingFlow({ onComplete }: OnboardingFlowProps) {
  const [showIntro, setShowIntro] = useState(true);
  const [step, setStep] = useState(0);
  const [direction, setDirection] = useState<'forward' | 'backward'>('forward');
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number }>>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const formRef = useRef<HTMLDivElement>(null);

  const witnessCharacters = [
    { id: 'trauzeuge', image: '/Trauzeuge.png', label: 'Trauzeuge' },
    { id: 'trauzeugin', image: '/Trauzeugin.png', label: 'Trauzeugin' },
  ];

  const parentCharacters = [
    { id: 'eltern1', image: '/Eltern Avatar 1.png', label: 'Eltern Avatar 1' },
    { id: 'eltern2', image: '/Eltern Avatar 2.png', label: 'Eltern Avatar 2' },
  ];

  const helperCharacters = [
    { id: 'helfer1', image: '/Helfer female 1.png', label: 'Helfer female' },
    { id: 'helfer2', image: '/Helfer Male 2.png', label: 'Helfer Male' },
  ];
  const [formData, setFormData] = useState<FormData>({
    partner1Name: '',
    partner2Name: '',
    partner1Age: '',
    partner2Age: '',
    partner1HeroType: 'hero1',
    partner2HeroType: 'hero2',
    weddingDate: '',
    guestCount: '',
    ceremonyType: 'traditional',
    budget: '',
    witness1Name: '',
    witness2Name: '',
    witness1Email: '',
    witness2Email: '',
    witness1Phone: '',
    witness2Phone: '',
    parent1Name: '',
    parent2Name: '',
    parent1Email: '',
    parent2Email: '',
    parent1Phone: '',
    parent2Phone: '',
    helper1Name: '',
    helper2Name: '',
    helper1Email: '',
    helper2Email: '',
    helper1Phone: '',
    helper2Phone: '',
    witness1Character: 'trauzeuge',
    witness2Character: 'trauzeugin',
    parent1Character: 'eltern1',
    parent2Character: 'eltern2',
    helper1Character: 'helfer1',
    helper2Character: 'helfer2',
  });

  const totalSteps = 8;
  const progress = ((step + 1) / totalSteps) * 100;

  useEffect(() => {
    if (showCelebration) {
      const timer = setTimeout(() => setShowCelebration(false), 1000);
      return () => clearTimeout(timer);
    }
  }, [showCelebration]);

  const createParticles = () => {
    const newParticles = Array.from({ length: 20 }, (_, i) => ({
      id: Date.now() + i,
      x: Math.random() * 200 - 100,
      y: Math.random() * 200 - 100,
    }));
    setParticles(newParticles);
    setTimeout(() => setParticles([]), 1500);
  };

  const handleNext = () => {
    if (step < totalSteps - 1) {
      setShowCelebration(true);
      createParticles();
      setIsTransitioning(true);
      setDirection('forward');
      setTimeout(() => {
        setStep(step + 1);
        setIsTransitioning(false);
      }, 400);
    } else {
      handleSubmit();
    }
  };

  const handleBack = () => {
    if (step > 0) {
      setIsTransitioning(true);
      setDirection('backward');
      setTimeout(() => {
        setStep(step - 1);
        setIsTransitioning(false);
      }, 400);
    }
  };

  const handleSubmit = async () => {
    if (isSubmitting) return;
    setIsSubmitting(true);

    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) {
        setIsSubmitting(false);
        return;
      }

      const { error: profileError } = await supabase
        .from('user_profiles')
        .upsert({
          id: user.id,
          email: user.email!,
          event_name: `${formData.partner1Name} & ${formData.partner2Name}`,
          event_date: formData.weddingDate,
          event_type: formData.ceremonyType,
          onboarding_completed: true,
          updated_at: new Date().toISOString(),
        });

      if (profileError) throw profileError;

      const { data, error } = await supabase
        .from('weddings')
        .insert([
          {
            user_id: user.id,
            partner_1_name: formData.partner1Name,
            partner_2_name: formData.partner2Name,
            wedding_date: formData.weddingDate,
            guest_count: parseInt(formData.guestCount) || 0,
            ceremony_type: formData.ceremonyType,
            total_budget: parseFloat(formData.budget) || 0,
            is_premium: false,
          },
        ])
        .select()
        .single();

      if (error) throw error;

      if (data) {
        const getCharacterImage = (characterId: string, characters: any[]) => {
          const character = characters.find(c => c.id === characterId);
          return character ? character.image : null;
        };

        const teamRoles = [
          {
            name: formData.witness1Name,
            email: formData.witness1Email,
            phone: formData.witness1Phone,
            character_id: formData.witness1Character,
            avatar_url: getCharacterImage(formData.witness1Character, witnessCharacters),
            role: 'trauzeuge',
            partner: 'partner_1'
          },
          {
            name: formData.witness2Name,
            email: formData.witness2Email,
            phone: formData.witness2Phone,
            character_id: formData.witness2Character,
            avatar_url: getCharacterImage(formData.witness2Character, witnessCharacters),
            role: 'trauzeuge',
            partner: 'partner_2'
          },
          {
            name: formData.parent1Name,
            email: formData.parent1Email,
            phone: formData.parent1Phone,
            character_id: formData.parent1Character,
            avatar_url: getCharacterImage(formData.parent1Character, parentCharacters),
            role: 'eltern',
            partner: 'partner_1'
          },
          {
            name: formData.parent2Name,
            email: formData.parent2Email,
            phone: formData.parent2Phone,
            character_id: formData.parent2Character,
            avatar_url: getCharacterImage(formData.parent2Character, parentCharacters),
            role: 'eltern',
            partner: 'partner_2'
          },
          {
            name: formData.helper1Name,
            email: formData.helper1Email,
            phone: formData.helper1Phone,
            character_id: formData.helper1Character,
            avatar_url: getCharacterImage(formData.helper1Character, helperCharacters),
            role: 'helfer',
            partner: 'partner_1'
          },
          {
            name: formData.helper2Name,
            email: formData.helper2Email,
            phone: formData.helper2Phone,
            character_id: formData.helper2Character,
            avatar_url: getCharacterImage(formData.helper2Character, helperCharacters),
            role: 'helfer',
            partner: 'partner_2'
          },
        ].filter(role => role.name.trim() !== '');

        const defaultGroups = [
          { name: 'A-Liste', color: '#10b981', description: 'Primäre Gästeliste', wedding_id: data.id },
          { name: 'B-Liste', color: '#3b82f6', description: 'Sekundäre Gästeliste', wedding_id: data.id },
          { name: 'C-Liste', color: '#8b5cf6', description: 'Tertiäre Gästeliste', wedding_id: data.id }
        ];

        const { error: groupsError } = await supabase
          .from('guest_groups')
          .insert(defaultGroups);

        if (groupsError) {
          console.error('Error creating default groups:', groupsError);
        }

        if (teamRoles.length > 0) {
          const teamRoleInserts = teamRoles.map(role => ({
            wedding_id: data.id,
            name: role.name.trim(),
            email: role.email.trim() || null,
            phone: role.phone.trim() || null,
            character_id: role.character_id,
            avatar_url: role.avatar_url,
            role: role.role,
            partner_assignment: role.partner,
          }));

          const { error: teamError } = await supabase
            .from('wedding_team_roles')
            .insert(teamRoleInserts);

          if (teamError) {
            console.error('Error saving team roles:', teamError);
          }
        }

        onComplete({
          weddingId: data.id,
          partner1Name: formData.partner1Name,
          partner2Name: formData.partner2Name,
          partner1HeroType: formData.partner1HeroType,
          partner2HeroType: formData.partner2HeroType,
          weddingDate: formData.weddingDate,
          ceremonyType: formData.ceremonyType,
        });
      }
    } catch (error) {
      console.error('Error creating wedding:', error);
      setIsSubmitting(false);
    }
  };

  const isStepValid = () => {
    switch (step) {
      case 0:
        return formData.partner1Name.trim() !== '';
      case 1:
        return formData.partner2Name.trim() !== '';
      case 2:
        return formData.weddingDate !== '';
      case 3:
        return formData.guestCount !== '';
      case 4:
        return formData.budget !== '';
      case 5:
      case 6:
      case 7:
        return true;
      default:
        return false;
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  if (showIntro) {
    return <OnboardingIntro onComplete={() => setShowIntro(false)} />;
  }

  const stepIcons = [
    { icon: Heart, label: 'Eure Namen' },
    { icon: Calendar, label: 'Der große Tag' },
    { icon: Users, label: 'Eure Gäste' },
    { icon: Coins, label: 'Euer Budget' },
    { icon: Users, label: 'Trauzeugen' },
    { icon: Heart, label: 'Eltern' },
    { icon: Users, label: 'Helfer' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center p-4 sm:p-6 relative overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: 'url(https://res.cloudinary.com/dvaha0i6v/image/upload/v1761905970/Background_onboarding_1_jcn71r.png)' }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/20 to-black/40"></div>

      {step === 0 && (
        <button
          onClick={handleLogout}
          className="absolute top-3 right-3 sm:top-6 sm:right-6 z-20 flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-1.5 sm:py-2 text-[#f7f2eb] hover:text-white transition-all duration-300 border-2 border-[#d4af37]/50 hover:border-[#d4af37] rounded-full backdrop-blur-sm hover:bg-[#d4af37]/10"
        >
          <LogOut className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
          <span className="text-xs sm:text-sm font-medium hidden sm:inline">Abmelden</span>
        </button>
      )}

      {particles.map((particle) => (
        <div
          key={particle.id}
          className="particle"
          style={{
            left: '50%',
            top: '50%',
            // @ts-ignore
            '--tx': `${particle.x}px`,
            '--ty': `${particle.y}px`,
          }}
        />
      ))}

      {showCelebration && (
        <div className="fixed inset-0 pointer-events-none z-[9999] flex items-center justify-center">
          <Star className="w-32 h-32 text-[#d4af37] celebrate-bounce fill-current" />
        </div>
      )}
      <div className="max-w-2xl w-full relative z-10">
        <div className="text-center mb-4 sm:mb-6 cinematic-fade-up">
          <div className="flex justify-center mb-3 sm:mb-4">
            <div className="relative">
              <Heart className="w-10 h-10 sm:w-14 sm:h-14 text-[#d4af37] animate-float fill-current" />
              <Sparkles className="w-4 h-4 sm:w-5 sm:h-5 text-[#f4d03f] absolute -top-1 -right-1 animate-sparkle" />
            </div>
          </div>
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-2 sm:mb-3 shine-effect px-2 leading-tight">
            Eure Heldenreise zur Traumhochzeit
          </h1>
          <p className="text-base sm:text-lg text-[#f7f2eb] px-2">
            Schritt für Schritt zum perfekten Tag
          </p>
        </div>

        <div className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl p-5 sm:p-8 card-3d-float max-h-[85vh] overflow-y-auto" ref={formRef}>
          <div className="mb-4 sm:mb-6">
            <div className="flex items-center justify-between mb-3 sm:mb-4 gap-1.5 sm:gap-2 overflow-x-auto scrollbar-hide px-1">
              {stepIcons.map((item, idx) => {
                const Icon = item.icon;
                let actualStep;
                if (step <= 1) {
                  actualStep = 0;
                } else if (step === 2 || step === 3) {
                  actualStep = 1;
                } else if (step === 4) {
                  actualStep = 2;
                } else if (step === 5) {
                  actualStep = 3;
                } else if (step === 6) {
                  actualStep = 4;
                } else if (step === 7) {
                  actualStep = 5;
                } else {
                  actualStep = 6;
                }
                const isActive = idx === actualStep;
                const isCompleted = idx < actualStep;
                return (
                  <div key={idx} className="flex flex-col items-center gap-1 flex-shrink-0">
                    <div
                      className={`w-9 h-9 sm:w-11 sm:h-11 rounded-full flex items-center justify-center transition-all duration-500 ${
                        isActive
                          ? 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f] scale-110 step-celebration'
                          : isCompleted
                          ? 'bg-[#d4af37]'
                          : 'bg-[#f7f2eb]'
                      }`}
                    >
                      <Icon
                        className={`w-4 h-4 sm:w-5 sm:h-5 ${
                          isActive || isCompleted ? 'text-white' : 'text-[#d4af37]/50'
                        }`}
                      />
                    </div>
                    <span className="text-[10px] sm:text-xs text-[#0a253c] font-medium hidden md:block">
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </div>
            <div className="w-full bg-[#f7f2eb] rounded-full h-2 sm:h-3 overflow-hidden relative">
              <div
                className={`bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-full rounded-full transition-all duration-500 ease-out ${
                  showCelebration ? 'progress-milestone' : ''
                }`}
                style={{ width: `${progress}%` }}
              />
            </div>
            <div className="flex items-center justify-between mt-1.5 sm:mt-2">
              <span className="text-xs sm:text-sm font-semibold text-[#0a253c]">
                Schritt {step + 1} von {totalSteps}
              </span>
              <span className="text-xs sm:text-sm font-semibold text-[#d4af37]">{Math.round(progress)}%</span>
            </div>
          </div>

          <div className="min-h-[250px] sm:min-h-[300px] overflow-hidden relative">
            {step === 0 && (
              <div className={`${!isTransitioning ? (direction === 'forward' ? 'slide-enter-from-right' : 'slide-enter-from-left') : (direction === 'forward' ? 'slide-exit-to-left' : 'slide-exit-to-right')}`}>
                <div className="flex items-center justify-center gap-2 mb-8">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                  <h2 className="text-xl sm:text-2xl font-bold text-[#0a253c]">Wer seid ihr?</h2>
                </div>

                <div className="flex flex-col items-center space-y-6">
                  <div className="relative w-full flex items-center justify-center">
                    <button
                      type="button"
                      onClick={() => {
                        const heroes = ['hero1', 'hero2'];
                        const currentIndex = heroes.indexOf(formData.partner1HeroType);
                        const newIndex = currentIndex > 0 ? currentIndex - 1 : heroes.length - 1;
                        setFormData({ ...formData, partner1HeroType: heroes[newIndex] });
                      }}
                      className="p-2 sm:p-3 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute left-2 sm:left-4 md:left-12"
                    >
                      <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-[#d4af37]" />
                    </button>

                    <img
                      src={formData.partner1HeroType === 'hero1' ? '/Design ohne Titel (10).png' : '/Design ohne Titel (11).png'}
                      alt="Partner 1 Held"
                      className="w-32 h-32 sm:w-40 sm:h-40 md:w-48 md:h-48 lg:w-56 lg:h-56 object-contain animate-float"
                    />

                    <button
                      type="button"
                      onClick={() => {
                        const heroes = ['hero1', 'hero2'];
                        const currentIndex = heroes.indexOf(formData.partner1HeroType);
                        const newIndex = (currentIndex + 1) % heroes.length;
                        setFormData({ ...formData, partner1HeroType: heroes[newIndex] });
                      }}
                      className="p-2 sm:p-3 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute right-2 sm:right-4 md:right-12"
                    >
                      <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-[#d4af37]" />
                    </button>
                  </div>

                  <div className="w-full max-w-md space-y-3 sm:space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">
                        Name
                      </label>
                      <input
                        type="text"
                        value={formData.partner1Name}
                        onChange={(e) => setFormData({ ...formData, partner1Name: e.target.value })}
                        className="w-full px-3 sm:px-4 py-3 sm:py-4 rounded-xl text-base sm:text-lg border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] transition-all input-glow-focus ripple-effect"
                        placeholder="z.B. Alex"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">
                        Alter <span className="text-[#666] font-normal text-xs">(optional)</span>
                      </label>
                      <input
                        type="number"
                        value={formData.partner1Age}
                        onChange={(e) => setFormData({ ...formData, partner1Age: e.target.value })}
                        className="w-full px-3 sm:px-4 py-3 sm:py-4 rounded-xl text-base sm:text-lg border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] transition-all input-glow-focus ripple-effect"
                        placeholder="z.B. 28"
                        min="18"
                        max="120"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {step === 1 && (
              <div className={`${!isTransitioning ? (direction === 'forward' ? 'slide-enter-from-right' : 'slide-enter-from-left') : (direction === 'forward' ? 'slide-exit-to-left' : 'slide-exit-to-right')}`}>
                <div className="flex items-center justify-center gap-2 mb-8">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                  <h2 className="text-xl sm:text-2xl font-bold text-[#0a253c]">Wer seid ihr?</h2>
                </div>

                <div className="flex flex-col items-center space-y-6">
                  <div className="relative w-full flex items-center justify-center">
                    <button
                      type="button"
                      onClick={() => {
                        const heroes = ['hero1', 'hero2'];
                        const currentIndex = heroes.indexOf(formData.partner2HeroType);
                        const newIndex = currentIndex > 0 ? currentIndex - 1 : heroes.length - 1;
                        setFormData({ ...formData, partner2HeroType: heroes[newIndex] });
                      }}
                      className="p-2 sm:p-3 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute left-2 sm:left-4 md:left-12"
                    >
                      <ChevronLeft className="w-5 h-5 sm:w-6 sm:h-6 text-[#d4af37]" />
                    </button>

                    <img
                      src={formData.partner2HeroType === 'hero1' ? '/Design ohne Titel (10).png' : '/Design ohne Titel (11).png'}
                      alt="Partner 2 Held"
                      className="w-48 h-48 md:w-56 md:h-56 object-contain animate-float-delayed"
                    />

                    <button
                      type="button"
                      onClick={() => {
                        const heroes = ['hero1', 'hero2'];
                        const currentIndex = heroes.indexOf(formData.partner2HeroType);
                        const newIndex = (currentIndex + 1) % heroes.length;
                        setFormData({ ...formData, partner2HeroType: heroes[newIndex] });
                      }}
                      className="p-2 sm:p-3 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute right-2 sm:right-4 md:right-12"
                    >
                      <ChevronRight className="w-5 h-5 sm:w-6 sm:h-6 text-[#d4af37]" />
                    </button>
                  </div>

                  <div className="w-full max-w-md space-y-3 sm:space-y-4">
                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">
                        Name
                      </label>
                      <input
                        type="text"
                        value={formData.partner2Name}
                        onChange={(e) => setFormData({ ...formData, partner2Name: e.target.value })}
                        className="w-full px-3 sm:px-4 py-3 sm:py-4 rounded-xl text-base sm:text-lg border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] transition-all input-glow-focus ripple-effect"
                        placeholder="z.B. Sam"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">
                        Alter <span className="text-[#666] font-normal text-xs">(optional)</span>
                      </label>
                      <input
                        type="number"
                        value={formData.partner2Age}
                        onChange={(e) => setFormData({ ...formData, partner2Age: e.target.value })}
                        className="w-full px-3 sm:px-4 py-3 sm:py-4 rounded-xl text-base sm:text-lg border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] transition-all input-glow-focus ripple-effect"
                        placeholder="z.B. 30"
                        min="18"
                        max="120"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div className={`space-y-6 ${!isTransitioning ? (direction === 'forward' ? 'slide-enter-from-right' : 'slide-enter-from-left') : (direction === 'forward' ? 'slide-exit-to-left' : 'slide-exit-to-right')}`}>
                <div className="flex items-center gap-2 mb-6">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                  <h2 className="text-2xl font-bold text-[#0a253c]">Der große Tag</h2>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">
                    Hochzeitsdatum
                  </label>
                  <input
                    type="date"
                    value={formData.weddingDate}
                    onChange={(e) => setFormData({ ...formData, weddingDate: e.target.value })}
                    className="w-full px-4 py-4 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] text-lg transition-all input-glow-focus"
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">
                    Art der Trauung
                  </label>
                  <select
                    value={formData.ceremonyType}
                    onChange={(e) => setFormData({ ...formData, ceremonyType: e.target.value })}
                    className="w-full px-4 py-4 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] text-lg transition-all input-glow-focus"
                  >
                    <option value="traditional">Traditionell</option>
                    <option value="civil">Standesamtlich</option>
                    <option value="religious">Kirchlich</option>
                    <option value="outdoor">Im Freien</option>
                    <option value="destination">Destination Wedding</option>
                  </select>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className={`space-y-6 ${!isTransitioning ? (direction === 'forward' ? 'slide-enter-from-right' : 'slide-enter-from-left') : (direction === 'forward' ? 'slide-exit-to-left' : 'slide-exit-to-right')}`}>
                <div className="flex items-center gap-2 mb-6">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                  <h2 className="text-2xl font-bold text-[#0a253c]">Eure Gäste</h2>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">
                    Erwartete Gästezahl
                  </label>
                  <input
                    type="number"
                    value={formData.guestCount}
                    onChange={(e) => setFormData({ ...formData, guestCount: e.target.value })}
                    className="w-full px-4 py-4 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] text-lg transition-all input-glow-focus ripple-effect"
                    placeholder="z.B. 100"
                    min="1"
                  />
                </div>
                <div className="bg-[#f7f2eb] rounded-xl p-6">
                  <p className="text-[#333333] leading-relaxed">
                    💡 Tipp: Die Gästezahl hilft uns, euch die passenden Empfehlungen für Location, Catering und mehr zu geben.
                  </p>
                </div>
              </div>
            )}

            {step === 4 && (
              <div className={`space-y-6 ${!isTransitioning ? (direction === 'forward' ? 'slide-enter-from-right' : 'slide-enter-from-left') : (direction === 'forward' ? 'slide-exit-to-left' : 'slide-exit-to-right')}`}>
                <div className="flex items-center gap-2 mb-6">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                  <h2 className="text-2xl font-bold text-[#0a253c]">Euer Budget</h2>
                </div>
                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">
                    Gesamtbudget (€)
                  </label>
                  <input
                    type="number"
                    value={formData.budget}
                    onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                    className="w-full px-4 py-4 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] text-lg transition-all input-glow-focus ripple-effect"
                    placeholder="z.B. 15000"
                    min="0"
                  />
                </div>
                <div className="bg-[#f7f2eb] rounded-xl p-6">
                  <p className="text-[#333333] leading-relaxed">
                    💰 Keine Sorge: Ihr könnt euer Budget jederzeit anpassen. Wir helfen euch, den Überblick zu behalten.
                  </p>
                </div>
              </div>
            )}

            {step === 5 && (
              <div className={`space-y-6 ${!isTransitioning ? (direction === 'forward' ? 'slide-enter-from-right' : 'slide-enter-from-left') : (direction === 'forward' ? 'slide-exit-to-left' : 'slide-exit-to-right')}`}>
                <div className="flex items-center justify-center gap-2 mb-6">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                  <h2 className="text-2xl font-bold text-[#0a253c]">Eure Trauzeugen</h2>
                </div>

                <div className="grid sm:grid-cols-2 gap-4 sm:gap-6 md:gap-8">
                  <div className="space-y-4">
                    <h3 className="text-base sm:text-lg font-semibold text-[#0a253c] text-center">
                      Trauzeuge/in von {formData.partner1Name || 'Partner 1'}
                    </h3>

                    <div className="relative w-full flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = witnessCharacters.findIndex(c => c.id === formData.witness1Character);
                          const newIndex = currentIndex > 0 ? currentIndex - 1 : witnessCharacters.length - 1;
                          setFormData({ ...formData, witness1Character: witnessCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute left-0 z-10"
                      >
                        <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
                      </button>

                      <img
                        src={witnessCharacters.find(c => c.id === formData.witness1Character)?.image}
                        alt="Trauzeuge 1"
                        className="w-32 h-32 md:w-40 md:h-40 object-contain animate-float"
                      />

                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = witnessCharacters.findIndex(c => c.id === formData.witness1Character);
                          const newIndex = (currentIndex + 1) % witnessCharacters.length;
                          setFormData({ ...formData, witness1Character: witnessCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute right-0 z-10"
                      >
                        <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                      </button>
                    </div>

                    <div className="space-y-2 sm:space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <User className="w-4 h-4" />
                          Name <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="text"
                          value={formData.witness1Name}
                          onChange={(e) => setFormData({ ...formData, witness1Name: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="z.B. Max Mustermann"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          E-Mail <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="email"
                          value={formData.witness1Email}
                          onChange={(e) => setFormData({ ...formData, witness1Email: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="max@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          Telefon <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="tel"
                          value={formData.witness1Phone}
                          onChange={(e) => setFormData({ ...formData, witness1Phone: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="+49 123 456789"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-base sm:text-lg font-semibold text-[#0a253c] text-center">
                      Trauzeuge/in von {formData.partner2Name || 'Partner 2'}
                    </h3>

                    <div className="relative w-full flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = witnessCharacters.findIndex(c => c.id === formData.witness2Character);
                          const newIndex = currentIndex > 0 ? currentIndex - 1 : witnessCharacters.length - 1;
                          setFormData({ ...formData, witness2Character: witnessCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute left-0 z-10"
                      >
                        <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
                      </button>

                      <img
                        src={witnessCharacters.find(c => c.id === formData.witness2Character)?.image}
                        alt="Trauzeuge 2"
                        className="w-32 h-32 md:w-40 md:h-40 object-contain animate-float-delayed"
                      />

                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = witnessCharacters.findIndex(c => c.id === formData.witness2Character);
                          const newIndex = (currentIndex + 1) % witnessCharacters.length;
                          setFormData({ ...formData, witness2Character: witnessCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute right-0 z-10"
                      >
                        <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                      </button>
                    </div>

                    <div className="space-y-2 sm:space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <User className="w-4 h-4" />
                          Name <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="text"
                          value={formData.witness2Name}
                          onChange={(e) => setFormData({ ...formData, witness2Name: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="z.B. Lisa Schmidt"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          E-Mail <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="email"
                          value={formData.witness2Email}
                          onChange={(e) => setFormData({ ...formData, witness2Email: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="lisa@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          Telefon <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="tel"
                          value={formData.witness2Phone}
                          onChange={(e) => setFormData({ ...formData, witness2Phone: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="+49 123 456789"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#f7f2eb] rounded-xl p-4">
                  <p className="text-[#333333] text-sm leading-relaxed text-center">
                    ✨ Alle Felder sind optional und können später ergänzt werden.
                  </p>
                </div>
              </div>
            )}

            {step === 6 && (
              <div className={`space-y-6 ${!isTransitioning ? (direction === 'forward' ? 'slide-enter-from-right' : 'slide-enter-from-left') : (direction === 'forward' ? 'slide-exit-to-left' : 'slide-exit-to-right')}`}>
                <div className="flex items-center justify-center gap-2 mb-6">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                  <h2 className="text-2xl font-bold text-[#0a253c]">Eure Eltern</h2>
                </div>

                <div className="grid sm:grid-cols-2 gap-4 sm:gap-6 md:gap-8">
                  <div className="space-y-4">
                    <h3 className="text-base sm:text-lg font-semibold text-[#0a253c] text-center">
                      Eltern von {formData.partner1Name || 'Partner 1'}
                    </h3>

                    <div className="relative w-full flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = parentCharacters.findIndex(c => c.id === formData.parent1Character);
                          const newIndex = currentIndex > 0 ? currentIndex - 1 : parentCharacters.length - 1;
                          setFormData({ ...formData, parent1Character: parentCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute left-0 z-10"
                      >
                        <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
                      </button>

                      <img
                        src={parentCharacters.find(c => c.id === formData.parent1Character)?.image}
                        alt="Eltern 1"
                        className="w-32 h-32 md:w-40 md:h-40 object-contain animate-float"
                      />

                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = parentCharacters.findIndex(c => c.id === formData.parent1Character);
                          const newIndex = (currentIndex + 1) % parentCharacters.length;
                          setFormData({ ...formData, parent1Character: parentCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute right-0 z-10"
                      >
                        <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                      </button>
                    </div>

                    <div className="space-y-2 sm:space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <User className="w-4 h-4" />
                          Name <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="text"
                          value={formData.parent1Name}
                          onChange={(e) => setFormData({ ...formData, parent1Name: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="z.B. Maria & Peter"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          E-Mail <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="email"
                          value={formData.parent1Email}
                          onChange={(e) => setFormData({ ...formData, parent1Email: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="maria@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          Telefon <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="tel"
                          value={formData.parent1Phone}
                          onChange={(e) => setFormData({ ...formData, parent1Phone: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="+49 123 456789"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-base sm:text-lg font-semibold text-[#0a253c] text-center">
                      Eltern von {formData.partner2Name || 'Partner 2'}
                    </h3>

                    <div className="relative w-full flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = parentCharacters.findIndex(c => c.id === formData.parent2Character);
                          const newIndex = currentIndex > 0 ? currentIndex - 1 : parentCharacters.length - 1;
                          setFormData({ ...formData, parent2Character: parentCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute left-0 z-10"
                      >
                        <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
                      </button>

                      <img
                        src={parentCharacters.find(c => c.id === formData.parent2Character)?.image}
                        alt="Eltern 2"
                        className="w-32 h-32 md:w-40 md:h-40 object-contain animate-float-delayed"
                      />

                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = parentCharacters.findIndex(c => c.id === formData.parent2Character);
                          const newIndex = (currentIndex + 1) % parentCharacters.length;
                          setFormData({ ...formData, parent2Character: parentCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute right-0 z-10"
                      >
                        <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                      </button>
                    </div>

                    <div className="space-y-2 sm:space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <User className="w-4 h-4" />
                          Name <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="text"
                          value={formData.parent2Name}
                          onChange={(e) => setFormData({ ...formData, parent2Name: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="z.B. Anna & Klaus"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          E-Mail <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="email"
                          value={formData.parent2Email}
                          onChange={(e) => setFormData({ ...formData, parent2Email: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="anna@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          Telefon <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="tel"
                          value={formData.parent2Phone}
                          onChange={(e) => setFormData({ ...formData, parent2Phone: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="+49 123 456789"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#f7f2eb] rounded-xl p-4">
                  <p className="text-[#333333] text-sm leading-relaxed text-center">
                    ✨ Alle Felder sind optional und können später ergänzt werden.
                  </p>
                </div>
              </div>
            )}

            {step === 7 && (
              <div className={`space-y-6 ${!isTransitioning ? (direction === 'forward' ? 'slide-enter-from-right' : 'slide-enter-from-left') : (direction === 'forward' ? 'slide-exit-to-left' : 'slide-exit-to-right')}`}>
                <div className="flex items-center justify-center gap-2 mb-6">
                  <Sparkles className="w-6 h-6 text-[#d4af37]" />
                  <h2 className="text-2xl font-bold text-[#0a253c]">Eure Helfer</h2>
                </div>

                <div className="grid sm:grid-cols-2 gap-4 sm:gap-6 md:gap-8">
                  <div className="space-y-4">
                    <h3 className="text-base sm:text-lg font-semibold text-[#0a253c] text-center">
                      Helfer/in
                    </h3>

                    <div className="relative w-full flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = helperCharacters.findIndex(c => c.id === formData.helper1Character);
                          const newIndex = currentIndex > 0 ? currentIndex - 1 : helperCharacters.length - 1;
                          setFormData({ ...formData, helper1Character: helperCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute left-0 z-10"
                      >
                        <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
                      </button>

                      <img
                        src={helperCharacters.find(c => c.id === formData.helper1Character)?.image}
                        alt="Helfer 1"
                        className="w-32 h-32 md:w-40 md:h-40 object-contain animate-float"
                      />

                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = helperCharacters.findIndex(c => c.id === formData.helper1Character);
                          const newIndex = (currentIndex + 1) % helperCharacters.length;
                          setFormData({ ...formData, helper1Character: helperCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute right-0 z-10"
                      >
                        <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                      </button>
                    </div>

                    <div className="space-y-2 sm:space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <User className="w-4 h-4" />
                          Name <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="text"
                          value={formData.helper1Name}
                          onChange={(e) => setFormData({ ...formData, helper1Name: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="z.B. Julia Meier"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          E-Mail <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="email"
                          value={formData.helper1Email}
                          onChange={(e) => setFormData({ ...formData, helper1Email: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="julia@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          Telefon <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="tel"
                          value={formData.helper1Phone}
                          onChange={(e) => setFormData({ ...formData, helper1Phone: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="+49 123 456789"
                        />
                      </div>
                    </div>
                  </div>

                  <div className="space-y-4">
                    <h3 className="text-base sm:text-lg font-semibold text-[#0a253c] text-center">
                      Helfer/in
                    </h3>

                    <div className="relative w-full flex items-center justify-center">
                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = helperCharacters.findIndex(c => c.id === formData.helper2Character);
                          const newIndex = currentIndex > 0 ? currentIndex - 1 : helperCharacters.length - 1;
                          setFormData({ ...formData, helper2Character: helperCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute left-0 z-10"
                      >
                        <ChevronLeft className="w-5 h-5 text-[#d4af37]" />
                      </button>

                      <img
                        src={helperCharacters.find(c => c.id === formData.helper2Character)?.image}
                        alt="Helfer 2"
                        className="w-32 h-32 md:w-40 md:h-40 object-contain animate-float-delayed"
                      />

                      <button
                        type="button"
                        onClick={() => {
                          const currentIndex = helperCharacters.findIndex(c => c.id === formData.helper2Character);
                          const newIndex = (currentIndex + 1) % helperCharacters.length;
                          setFormData({ ...formData, helper2Character: helperCharacters[newIndex].id });
                        }}
                        className="p-2 rounded-full bg-[#d4af37]/10 hover:bg-[#d4af37]/20 transition-all absolute right-0 z-10"
                      >
                        <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                      </button>
                    </div>

                    <div className="space-y-2 sm:space-y-3">
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <User className="w-4 h-4" />
                          Name <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="text"
                          value={formData.helper2Name}
                          onChange={(e) => setFormData({ ...formData, helper2Name: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="z.B. Tom Wagner"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          E-Mail <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="email"
                          value={formData.helper2Email}
                          onChange={(e) => setFormData({ ...formData, helper2Email: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="tom@example.com"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-semibold text-[#333333] mb-1.5 flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          Telefon <span className="text-[#666] font-normal">(optional)</span>
                        </label>
                        <input
                          type="tel"
                          value={formData.helper2Phone}
                          onChange={(e) => setFormData({ ...formData, helper2Phone: e.target.value })}
                          className="w-full px-3 py-2 sm:py-3 rounded-xl text-sm sm:text-base border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-[#0a253c] bg-white/5 backdrop-blur-sm transition-all input-glow-focus"
                          placeholder="+49 123 456789"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#f7f2eb] rounded-xl p-4">
                  <p className="text-[#333333] text-sm leading-relaxed text-center">
                    ✨ Alle Felder sind optional und können später ergänzt werden.
                  </p>
                </div>
              </div>
            )}
          </div>

          <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 mt-6 sm:mt-8">
            <button
              onClick={handleBack}
              disabled={step === 0}
              className={`flex items-center justify-center gap-2 px-4 sm:px-6 py-3 sm:py-4 rounded-xl text-sm sm:text-base border-2 transition-all ${
                step === 0
                  ? 'border-[#d4af37]/20 text-[#d4af37]/30 cursor-not-allowed opacity-50'
                  : 'border-[#d4af37] text-[#d4af37] font-semibold hover:bg-[#d4af37]/10 hover:scale-105 ripple-effect'
              }`}
            >
              <ArrowLeft className="w-4 h-4 sm:w-5 sm:h-5" />
              Zurück
            </button>
            <button
              onClick={handleNext}
              disabled={!isStepValid() || isSubmitting}
              className="flex-1 flex items-center justify-center gap-2 px-4 sm:px-6 py-3 sm:py-4 rounded-xl text-sm sm:text-base bg-[#d4af37] text-[#0a253c] font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all transform hover:scale-105 ripple-effect shine-effect"
            >
              {isSubmitting ? 'Wird erstellt...' : step < totalSteps - 1 ? 'Weiter' : 'Los geht\'s!'}
              <ArrowRight className="w-4 h-4 sm:w-5 sm:h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
