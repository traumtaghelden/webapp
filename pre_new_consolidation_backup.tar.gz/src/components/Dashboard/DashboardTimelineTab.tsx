import { Clock, MapPin, Users, Sparkles } from 'lucide-react';
import type { TimelineEvent } from '../../lib/supabase';

interface DashboardTimelineTabProps {
  weddingId: string;
  timelineEvents: TimelineEvent[];
  onNavigate: (tab: string) => void;
}

export default function DashboardTimelineTab({
  timelineEvents,
  onNavigate
}: DashboardTimelineTabProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold text-[#0a253c]">Timeline Übersicht</h3>
          <p className="text-[#666666] mt-1">Dein Hochzeitstag im Detail</p>
        </div>
        <button
          onClick={() => onNavigate('timeline')}
          className="px-6 py-3 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] hover:from-[#f4d03f] hover:to-[#d4af37] text-white rounded-xl font-bold shadow-lg transition-all"
        >
          Timeline bearbeiten
        </button>
      </div>

      {timelineEvents.length > 0 ? (
        <div className="relative bg-gradient-to-br from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-3xl p-8 shadow-2xl border-2 border-[#d4af37]/50 overflow-hidden">
          <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#d4af37]/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
          <div className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-[#f4d03f]/10 to-transparent rounded-full blur-3xl animate-pulse"></div>

          <div className="relative z-10">
            <div className="flex items-center gap-3 mb-8">
              <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-12 h-12 rounded-2xl flex items-center justify-center shadow-lg">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h2 className="text-2xl font-bold text-white">Hochzeitstag Timeline</h2>
              <Sparkles className="w-5 h-5 text-[#f4d03f] animate-sparkle" />
            </div>

            <div className="space-y-4 max-h-[600px] overflow-y-auto pr-2">
              {timelineEvents.map((event, index) => (
                <div
                  key={event.id}
                  className={`relative ${event.event_type === 'buffer' ? 'pl-0' : 'pl-16'}`}
                >
                  {event.event_type === 'event' && (
                    <>
                      <div className="absolute left-3 top-3 w-5 h-5 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] ring-4 ring-[#d4af37]/20 shadow-lg flex items-center justify-center">
                        <div className="w-2 h-2 bg-white rounded-full"></div>
                      </div>
                      {index !== timelineEvents.length - 1 && (
                        <div className="absolute left-5 top-8 bottom-0 w-0.5 bg-gradient-to-b from-[#d4af37] to-[#d4af37]/20"></div>
                      )}
                    </>
                  )}

                  <div className={`group bg-white rounded-xl p-5 shadow-md hover:shadow-xl transition-all border-2 ${
                    event.event_type === 'buffer'
                      ? 'border-dashed border-gray-300 bg-gray-50/50'
                      : 'border-[#d4af37]/30 hover:border-[#d4af37]/50'
                  }`}>
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        {event.event_type === 'buffer' ? (
                          <div className="flex items-center gap-2 text-gray-500">
                            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent"></div>
                            <span className="text-sm font-semibold px-3 py-1 bg-gray-100 rounded-full">
                              {event.buffer_label || 'Pause'}
                            </span>
                            <div className="h-px flex-1 bg-gradient-to-r from-transparent via-gray-300 to-transparent"></div>
                          </div>
                        ) : (
                          <>
                            <div className="flex items-center gap-3 mb-2">
                              <div className="flex items-center gap-2 text-[#d4af37] font-bold text-lg">
                                <Clock className="w-5 h-5" />
                                <span>{event.time}</span>
                                {event.end_time && (
                                  <span className="text-gray-400">- {event.end_time}</span>
                                )}
                              </div>
                              <span className="text-xs bg-[#d4af37]/10 text-[#d4af37] px-2 py-1 rounded-full font-semibold">
                                {event.duration_minutes} Min
                              </span>
                            </div>
                            <h3 className="text-[#0a253c] font-bold text-xl mb-2 group-hover:text-[#d4af37] transition-colors">
                              {event.title}
                            </h3>
                            {event.description && (
                              <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                                {event.description}
                              </p>
                            )}
                            <div className="flex flex-wrap gap-3 text-sm">
                              {event.location && (
                                <div className="flex items-center gap-1 text-gray-700">
                                  <MapPin className="w-4 h-4 text-[#d4af37]" />
                                  <span>{event.location}</span>
                                </div>
                              )}
                              {event.assigned_to && (
                                <div className="flex items-center gap-1 text-gray-700">
                                  <Users className="w-4 h-4 text-[#d4af37]" />
                                  <span>{event.assigned_to}</span>
                                </div>
                              )}
                            </div>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      ) : (
        <div className="text-center py-16 bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-3xl shadow-2xl border-2 border-[#d4af37]/50">
          <div className="w-20 h-20 bg-gradient-to-br from-[#d4af37]/20 to-[#f4d03f]/20 rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
            <Clock className="w-10 h-10 text-[#d4af37]" />
          </div>
          <p className="text-white/80 text-lg mb-2 font-semibold">Noch keine Timeline erstellt</p>
          <p className="text-white/50 text-sm mb-6">Erstelle deine Hochzeitstimeline um hier einen Überblick zu sehen</p>
          <button
            onClick={() => onNavigate('timeline')}
            className="px-6 py-3 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] hover:from-[#f4d03f] hover:to-[#d4af37] text-white rounded-xl font-bold shadow-lg transition-all"
          >
            Timeline erstellen
          </button>
        </div>
      )}
    </div>
  );
}
