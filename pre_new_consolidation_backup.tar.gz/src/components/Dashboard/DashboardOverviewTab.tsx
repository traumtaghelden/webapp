import { Calendar, TrendingUp, DollarSign, Users, Target, Sparkles, Star, Heart } from 'lucide-react';
import type { Task, BudgetItem, Guest, Wedding } from '../../lib/supabase';

interface DashboardOverviewTabProps {
  wedding: Wedding;
  tasks: Task[];
  budgetItems: BudgetItem[];
  guests: Guest[];
  onNavigate: (tab: string) => void;
}

export default function DashboardOverviewTab({
  wedding,
  tasks,
  budgetItems,
  guests,
  onNavigate
}: DashboardOverviewTabProps) {
  const getDaysUntilWedding = () => {
    const today = new Date();
    const weddingDate = new Date(wedding.wedding_date);
    const diffTime = weddingDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  const getCompletionPercentage = () => {
    if (tasks.length === 0) return 0;
    const completed = tasks.filter((t) => t.status === 'completed').length;
    return Math.round((completed / tasks.length) * 100);
  };

  const getSpentBudget = () => {
    return budgetItems.reduce((sum, item) => sum + (item.actual_cost || 0), 0);
  };

  const getRSVPCount = () => {
    return guests.filter((g) => g.rsvp_status === 'accepted').length;
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <div className="relative inline-block mb-4">
          <Heart className="w-20 h-20 text-[#d4af37] fill-current animate-float mx-auto" />
          <Sparkles className="w-8 h-8 text-[#f4d03f] absolute -top-2 -right-2 animate-sparkle" />
        </div>
        <h2 className="text-4xl font-bold text-[#0a253c] mb-2">
          {wedding.partner_1_name} & {wedding.partner_2_name}
        </h2>
        <p className="text-xl text-[#666666]">
          {new Date(wedding.wedding_date).toLocaleDateString('de-DE', {
            day: 'numeric',
            month: 'long',
            year: 'numeric'
          })}
        </p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="group relative bg-gradient-to-br from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-3xl p-8 shadow-2xl border-2 border-[#d4af37]/50 overflow-hidden hover-lift">
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#d4af37]/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
          <div className="relative z-10">
            <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-gold group-hover:scale-110 transition-all duration-300">
              <Calendar className="w-8 h-8 text-white" />
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-5xl font-bold gradient-text-gold">{getDaysUntilWedding()}</span>
              <Sparkles className="w-5 h-5 text-[#f4d03f] animate-sparkle" />
            </div>
            <h3 className="text-white/90 font-bold text-lg">Tage verbleibend</h3>
          </div>
        </div>

        <div className="group relative bg-gradient-to-br from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-3xl p-8 shadow-2xl border-2 border-[#d4af37]/50 overflow-hidden hover-lift">
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#d4af37]/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
          <div className="relative z-10">
            <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-gold group-hover:scale-110 transition-all duration-300">
              <TrendingUp className="w-8 h-8 text-white" />
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-5xl font-bold gradient-text-gold">{getCompletionPercentage()}%</span>
              <Star className="w-5 h-5 text-[#f4d03f] animate-pulse fill-current" />
            </div>
            <h3 className="text-white/90 font-bold text-lg">Fortschritt</h3>
          </div>
        </div>

        <div className="group relative bg-gradient-to-br from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-3xl p-8 shadow-2xl border-2 border-[#d4af37]/50 overflow-hidden hover-lift">
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#d4af37]/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
          <div className="relative z-10">
            <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-gold group-hover:scale-110 transition-all duration-300">
              <DollarSign className="w-8 h-8 text-white" />
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-5xl font-bold gradient-text-gold">
                {Math.round((getSpentBudget() / wedding.total_budget) * 100)}%
              </span>
            </div>
            <h3 className="text-white/90 font-bold text-lg">Budget genutzt</h3>
            <div className="mt-3 w-full bg-white/10 rounded-full h-3 overflow-hidden">
              <div
                className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-full rounded-full transition-all duration-1000"
                style={{ width: `${Math.min(Math.round((getSpentBudget() / wedding.total_budget) * 100), 100)}%` }}
              />
            </div>
          </div>
        </div>

        <div className="group relative bg-gradient-to-br from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-3xl p-8 shadow-2xl border-2 border-[#d4af37]/50 overflow-hidden hover-lift">
          <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#d4af37]/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
          <div className="relative z-10">
            <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-16 h-16 rounded-2xl flex items-center justify-center mb-4 shadow-gold group-hover:scale-110 transition-all duration-300">
              <Users className="w-8 h-8 text-white" />
            </div>
            <div className="flex items-baseline gap-2 mb-2">
              <span className="text-5xl font-bold gradient-text-gold">{getRSVPCount()}</span>
              <span className="text-xl text-white/70 font-semibold">/ {wedding.guest_count}</span>
            </div>
            <h3 className="text-white/90 font-bold text-lg">Bestätigte Gäste</h3>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <button
          onClick={() => onNavigate('tasks')}
          className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all border-2 border-transparent hover:border-[#d4af37]/50 text-left group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="bg-orange-100 w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-all">
              <Target className="w-6 h-6 text-orange-600" />
            </div>
            <span className="text-3xl font-bold text-orange-600">
              {tasks.filter(t => t.status !== 'completed').length}
            </span>
          </div>
          <h3 className="text-lg font-bold text-[#0a253c] mb-1">Offene Aufgaben</h3>
          <p className="text-sm text-[#666666]">
            {tasks.filter(t => t.status === 'completed').length} von {tasks.length} erledigt
          </p>
        </button>

        <button
          onClick={() => onNavigate('budget')}
          className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all border-2 border-transparent hover:border-[#d4af37]/50 text-left group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="bg-green-100 w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-all">
              <DollarSign className="w-6 h-6 text-green-600" />
            </div>
            <span className="text-3xl font-bold text-green-600">
              {getSpentBudget().toLocaleString('de-DE')} €
            </span>
          </div>
          <h3 className="text-lg font-bold text-[#0a253c] mb-1">Ausgegeben</h3>
          <p className="text-sm text-[#666666]">
            von {wedding.total_budget.toLocaleString('de-DE')} € Budget
          </p>
        </button>

        <button
          onClick={() => onNavigate('guests')}
          className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all border-2 border-transparent hover:border-[#d4af37]/50 text-left group"
        >
          <div className="flex items-center justify-between mb-4">
            <div className="bg-blue-100 w-12 h-12 rounded-xl flex items-center justify-center group-hover:scale-110 transition-all">
              <Users className="w-6 h-6 text-blue-600" />
            </div>
            <span className="text-3xl font-bold text-blue-600">
              {guests.filter(g => g.rsvp_status === 'invited' || g.rsvp_status === 'planned').length}
            </span>
          </div>
          <h3 className="text-lg font-bold text-[#0a253c] mb-1">Ausstehende RSVPs</h3>
          <p className="text-sm text-[#666666]">
            {guests.length} Gäste insgesamt
          </p>
        </button>
      </div>
    </div>
  );
}
