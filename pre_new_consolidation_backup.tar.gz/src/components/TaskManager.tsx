import { useState, useEffect } from 'react';
import { Plus, CheckCircle, Circle, Trash2, Calendar, Filter, X, MessageSquare, FileText, Search, List, Grid, ChevronDown, ChevronRight, ChevronLeft, Link as LinkIcon, AlertCircle, Clock, DollarSign, Building2, MoreVertical, CalendarClock, ArrowUpDown, ArrowUp, ArrowDown, User, Crown, GripVertical } from 'lucide-react';
import { supabase, type Task, type WeddingTeamRole, type TaskSubtask, type TaskDependency, type BudgetItem, type Vendor, type TimelineEvent } from '../lib/supabase';
import TaskDetailModal from './TaskDetailModal';
import TaskTemplateSelector from './TaskTemplateSelector';
import TaskAddModal from './TaskAddModal';
import TaskListView from './Tasks/TaskListView';
import TaskKPIPanel from './Tasks/TaskKPIPanel';
import { useConfirmDialog } from '../hooks/useConfirmDialog';
import { DndContext, closestCenter, KeyboardSensor, PointerSensor, useSensor, useSensors, DragEndEvent, DragStartEvent, DragOverEvent, useDroppable, DragOverlay } from '@dnd-kit/core';
import { arrayMove, SortableContext, sortableKeyboardCoordinates, verticalListSortingStrategy, useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { TASK, COMMON } from '../constants/terminology';
import { useToast } from '../contexts/ToastContext';

const categories = [
  { value: 'general', label: 'Allgemein' },
  { value: 'venue', label: 'Location' },
  { value: 'catering', label: 'Catering' },
  { value: 'decoration', label: 'Dekoration' },
  { value: 'music', label: 'Musik' },
  { value: 'photography', label: 'Fotografie' },
  { value: 'invitations', label: 'Einladungen' },
  { value: 'flowers', label: 'Blumen' },
  { value: 'dress', label: 'Kleidung' },
  { value: 'other', label: 'Sonstiges' },
];

const getCategoryLabel = (categoryValue: string) => {
  const category = categories.find(cat => cat.value === categoryValue);
  return category ? category.label : categoryValue;
};

interface TaskManagerProps {
  weddingId: string;
  tasks: Task[];
  onUpdate: () => void;
}

type ViewMode = 'kanban' | 'list' | 'calendar';

interface FilterState {
  categories: string[];
  priorities: string[];
  dueDateRange: 'all' | 'overdue' | 'today' | 'week' | 'month';
  assignedTo: string;
  searchQuery: string;
}

interface SortableTaskProps {
  task: Task;
  subtasks: TaskSubtask[];
  dependencies: TaskDependency[];
  allTasks: Task[];
  onToggleTask: (task: Task) => void;
  onDeleteTask: (taskId: string) => void;
  onSelectTask: (task: Task) => void;
  onToggleExpand: (taskId: string) => void;
  expandedTasks: Set<string>;
  onAddSubtask: (taskId: string) => void;
  onToggleSubtask: (subtaskId: string, isCompleted: boolean) => void;
  budgetItems: BudgetItem[];
  vendors: Vendor[];
  teamRoles: WeddingTeamRole[];
  isDragging: boolean;
  activeId: string | null;
}

interface DroppableColumnProps {
  id: string;
  children: React.ReactNode;
}

function DroppableColumn({ id, children }: DroppableColumnProps) {
  const { setNodeRef, isOver } = useDroppable({
    id: `droppable-${id}`,
  });

  return (
    <div
      ref={setNodeRef}
      className={`min-h-[200px] transition-colors ${
        isOver ? 'bg-[#d4af37]/5 ring-2 ring-[#d4af37] ring-inset' : ''
      }`}
    >
      {children}
    </div>
  );
}

function SortableTask({ task, subtasks, dependencies, allTasks, onToggleTask, onDeleteTask, onSelectTask, onToggleExpand, expandedTasks, onAddSubtask, onToggleSubtask, budgetItems, vendors, teamRoles, isDragging, activeId }: SortableTaskProps) {
  const [timelineEvent, setTimelineEvent] = useState<any>(null);

  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: task.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  useEffect(() => {
    if (task.timeline_event_id) {
      loadTimelineEvent();
    } else {
      setTimelineEvent(null);
    }
  }, [task.timeline_event_id]);

  const loadTimelineEvent = async () => {
    try {
      const { data } = await supabase
        .from('wedding_timeline')
        .select('title, time, color')
        .eq('id', task.timeline_event_id)
        .maybeSingle();
      if (data) setTimelineEvent(data);
    } catch (error) {
      console.error('Error loading timeline event:', error);
    }
  };

  const isExpanded = expandedTasks.has(task.id);
  const taskSubtasks = subtasks.filter(s => s.task_id === task.id);
  const hasSubtasks = taskSubtasks.length > 0;
  const completedSubtasks = taskSubtasks.filter(s => s.is_completed).length;
  const dependsOn = dependencies.filter(d => d.task_id === task.id);
  const blockedBy = dependsOn.filter(d => {
    const depTask = allTasks.find(t => t.id === d.depends_on_task_id);
    return depTask && depTask.status !== 'completed';
  });

  const isOverdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'completed';
  const budgetItem = task.budget_item_id ? budgetItems.find(b => b.id === task.budget_item_id) : null;
  const vendor = task.vendor_id ? vendors.find(v => v.id === task.vendor_id) : null;
  const assignedRole = task.assigned_to ? teamRoles.find(r => r.name === task.assigned_to) : null;

  return (
    <div ref={setNodeRef} style={style} {...attributes}>
      <div
        className={`p-4 rounded-xl bg-[#f7f2eb] hover:bg-[#d4af37]/10 transition-all group relative cursor-pointer shadow-sm hover:shadow-md ${isDragging && activeId === task.id ? 'opacity-50 scale-95' : ''} ${
          isOverdue ? 'border-2 border-red-400' : task.timeline_event_id ? 'border-2 border-[#d4af37]/30' : ''
        }`}
        onClick={(e) => {
          if (!(e.target as HTMLElement).closest('button') && !(e.target as HTMLElement).closest('[data-drag-handle]')) {
            onSelectTask(task);
          }
        }}
      >
        {blockedBy.length > 0 && (
          <div className="absolute -top-2 -right-2 bg-orange-500 text-white rounded-full p-1" title={`Blockiert durch andere ${TASK.PLURAL}`}>
            <AlertCircle className="w-4 h-4" />
          </div>
        )}
        <div className="flex items-start gap-3">
          <div
            {...listeners}
            data-drag-handle
            className="cursor-grab active:cursor-grabbing mt-1 hover:text-[#d4af37] transition-all group-hover:scale-125 duration-200 touch-none"
            title="⬍⬍ Ziehen zum Verschieben ⬍⬍"
          >
            <GripVertical className="w-6 h-6 text-[#666666] group-hover:text-[#d4af37] transition-colors" />
          </div>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onToggleTask(task);
            }}
            className="mt-1 flex-shrink-0"
          >
            {task.status === 'completed' ? (
              <CheckCircle className="w-5 h-5 text-green-500 fill-current hover:text-green-600 transition-colors" />
            ) : task.status === 'in_progress' ? (
              <Circle className="w-5 h-5 text-blue-500 fill-current hover:text-[#d4af37] transition-colors" />
            ) : (
              <Circle className="w-5 h-5 text-[#333333] hover:text-[#d4af37] transition-colors" />
            )}
          </button>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-1">
              {hasSubtasks && (
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onToggleExpand(task.id);
                  }}
                  className="hover:text-[#d4af37]"
                >
                  {isExpanded ? <ChevronDown className="w-4 h-4" /> : <ChevronRight className="w-4 h-4" />}
                </button>
              )}
              <p className={`font-semibold text-[#0a253c] ${task.status === 'completed' ? 'line-through' : ''}`}>{task.title}</p>
            </div>
            <div className="flex flex-wrap gap-2 items-center text-xs">
              <span className="px-2 py-1 bg-[#d4af37]/20 text-[#0a253c] rounded-full">
                {getCategoryLabel(task.category)}
              </span>
              {task.priority === 'high' && (
                <span className="px-2 py-1 bg-red-100 text-red-600 rounded-full font-semibold">
                  Wichtig
                </span>
              )}
              {task.due_date && (
                <span className={`flex items-center gap-1 ${isOverdue ? 'text-red-600 font-semibold' : 'text-[#333333]'}`}>
                  <Calendar className="w-3 h-3" />
                  {new Date(task.due_date).toLocaleDateString('de-DE')}
                </span>
              )}
              {hasSubtasks && (
                <span className="flex items-center gap-1 text-[#d4af37] font-semibold">
                  <CheckCircle className="w-3 h-3" />
                  {completedSubtasks}/{taskSubtasks.length}
                </span>
              )}
              {assignedRole && (
                <span
                  className="px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1 bg-blue-50 text-blue-700 border border-blue-200"
                  title={`Verantwortlich: ${assignedRole.name}`}
                >
                  {assignedRole.character_image ? (
                    <img
                      src={assignedRole.character_image}
                      alt={assignedRole.name}
                      className="w-4 h-4 rounded-full object-cover"
                    />
                  ) : (
                    <User className="w-3 h-3" />
                  )}
                  {assignedRole.name}
                </span>
              )}
              {budgetItem && (
                <span
                  className="px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1 bg-green-50 text-green-700 border border-green-200"
                  title={`Budget: ${budgetItem.item_name}`}
                >
                  <DollarSign className="w-3 h-3" />
                  {budgetItem.item_name}
                </span>
              )}
              {vendor && (
                <span
                  className="px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1 bg-purple-50 text-purple-700 border border-purple-200"
                  title={`Dienstleister: ${vendor.name} (${vendor.category})`}
                >
                  <Building2 className="w-3 h-3" />
                  {vendor.name}
                </span>
              )}
              {dependsOn.length > 0 && (
                <span className="flex items-center gap-1 text-orange-600" title="Hat Abhängigkeiten">
                  <LinkIcon className="w-3 h-3" />
                </span>
              )}
              {timelineEvent && (
                <span
                  className="px-2 py-1 rounded-full text-xs font-semibold flex items-center gap-1"
                  style={{
                    backgroundColor: `${timelineEvent.color}20`,
                    color: timelineEvent.color,
                    border: `1px solid ${timelineEvent.color}`
                  }}
                  title={`Block Planning: ${timelineEvent.title} um ${timelineEvent.time.substring(0, 5)}`}
                >
                  <CalendarClock className="w-3 h-3" />
                  {timelineEvent.title}
                </span>
              )}
            </div>
            {isExpanded && hasSubtasks && (
              <div className="mt-3 ml-6 space-y-2">
                {taskSubtasks.map(subtask => (
                  <div key={subtask.id} className="flex items-center gap-2 text-sm">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onToggleSubtask(subtask.id, !subtask.is_completed);
                      }}
                      className="flex-shrink-0"
                    >
                      {subtask.is_completed ? (
                        <CheckCircle className="w-4 h-4 text-green-500 fill-current" />
                      ) : (
                        <Circle className="w-4 h-4 text-[#333333]" />
                      )}
                    </button>
                    <span className={subtask.is_completed ? 'line-through text-[#666666]' : 'text-[#333333]'}>
                      {subtask.title}
                    </span>
                  </div>
                ))}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    onAddSubtask(task.id);
                  }}
                  className="text-xs text-[#d4af37] hover:text-[#c19a2e] font-semibold flex items-center gap-1"
                >
                  <Plus className="w-3 h-3" />
                  Unteraufgabe hinzufügen
                </button>
              </div>
            )}
          </div>
          <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
            <button
              onClick={(e) => {
                e.stopPropagation();
                onSelectTask(task);
              }}
              className="flex-shrink-0"
              title="Details anzeigen"
            >
              <MessageSquare className="w-4 h-4 text-[#d4af37] hover:text-[#c19a2e]" />
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                onDeleteTask(task.id);
              }}
              className="flex-shrink-0"
            >
              <Trash2 className="w-4 h-4 text-red-500 hover:text-red-700" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function TaskManager({ weddingId, tasks, onUpdate }: TaskManagerProps) {
  const { confirmDelete } = useConfirmDialog();
  const { showToast } = useToast();
  const [showAddModal, setShowAddModal] = useState(false);
  const [showTemplateSelector, setShowTemplateSelector] = useState(false);
  const [teamRoles, setTeamRoles] = useState<WeddingTeamRole[]>([]);
  const [selectedTask, setSelectedTask] = useState<Task | null>(null);
  const [viewMode, setViewMode] = useState<ViewMode>('kanban');
  const [subtasks, setSubtasks] = useState<TaskSubtask[]>([]);
  const [dependencies, setDependencies] = useState<TaskDependency[]>([]);
  const [expandedTasks, setExpandedTasks] = useState<Set<string>>(new Set());
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([]);
  const [showCategoryProgress, setShowCategoryProgress] = useState(false);
  const [quickSearchQuery, setQuickSearchQuery] = useState('');
  const [sortColumn, setSortColumn] = useState<'title' | 'category' | 'priority' | 'due_date' | 'assigned_to' | 'status' | null>(null);
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
  const [collapsedColumns, setCollapsedColumns] = useState<Set<string>>(new Set());
  const [calendarDate, setCalendarDate] = useState(new Date());
  const [activeId, setActiveId] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);

  const [filters, setFilters] = useState<FilterState>({
    categories: [],
    priorities: [],
    dueDateRange: 'all',
    assignedTo: '',
    searchQuery: '',
  });

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    loadTeamRoles();
    loadSubtasks();
    loadDependencies();
    loadBudgetItems();
    loadVendors();
    loadTimelineEvents();
  }, [weddingId]);

  const loadTeamRoles = async () => {
    try {
      const { data } = await supabase
        .from('wedding_team_roles')
        .select('*')
        .eq('wedding_id', weddingId);
      if (data) setTeamRoles(data);
    } catch (error) {
      console.error('Error loading team roles:', error);
    }
  };

  const loadSubtasks = async () => {
    try {
      const { data } = await supabase
        .from('task_subtasks')
        .select('*')
        .in('task_id', tasks.map(t => t.id));
      if (data) setSubtasks(data);
    } catch (error) {
      console.error('Error loading subtasks:', error);
    }
  };

  const loadDependencies = async () => {
    try {
      const { data } = await supabase
        .from('task_dependencies')
        .select('*')
        .in('task_id', tasks.map(t => t.id));
      if (data) setDependencies(data);
    } catch (error) {
      console.error('Error loading dependencies:', error);
    }
  };

  const loadBudgetItems = async () => {
    try {
      const { data } = await supabase
        .from('budget_items')
        .select('*')
        .eq('wedding_id', weddingId);
      if (data) setBudgetItems(data);
    } catch (error) {
      console.error('Error loading budget items:', error);
    }
  };

  const loadVendors = async () => {
    try {
      const { data } = await supabase
        .from('vendors')
        .select('*')
        .eq('wedding_id', weddingId);
      if (data) setVendors(data);
    } catch (error) {
      console.error('Error loading vendors:', error);
    }
  };

  const loadTimelineEvents = async () => {
    try {
      const { data } = await supabase
        .from('wedding_timeline')
        .select('*')
        .eq('wedding_id', weddingId)
        .order('order_index');
      if (data) setTimelineEvents(data);
    } catch (error) {
      console.error('Error loading timeline events:', error);
    }
  };

  const handleToggleTask = async (task: Task) => {
    try {
      let newStatus: 'pending' | 'in_progress' | 'completed';
      if (task.status === 'pending') {
        newStatus = 'in_progress';
      } else if (task.status === 'in_progress') {
        newStatus = 'completed';
      } else {
        newStatus = 'pending';
      }
      await supabase.from('tasks').update({ status: newStatus }).eq('id', task.id);
      onUpdate();
    } catch (error) {
      console.error('Error updating task:', error);
    }
  };

  const handleDeleteTask = async (taskId: string) => {
    const confirmed = await confirmDelete('Möchtest du diese Aufgabe wirklich löschen?');
    if (!confirmed) return;
    try {
      await supabase.from('tasks').delete().eq('id', taskId);
      onUpdate();
    } catch (error) {
      console.error('Error deleting task:', error);
    }
  };

  const handleAddSubtask = async (taskId: string) => {
    const title = prompt('Unteraufgabe hinzufügen:');
    if (!title) return;

    try {
      const { data: existingSubtasks } = await supabase
        .from('task_subtasks')
        .select('order_index')
        .eq('task_id', taskId)
        .order('order_index', { ascending: false })
        .limit(1);

      const nextOrderIndex = existingSubtasks && existingSubtasks.length > 0
        ? existingSubtasks[0].order_index + 1
        : 0;

      await supabase.from('task_subtasks').insert([
        {
          task_id: taskId,
          title,
          order_index: nextOrderIndex,
        },
      ]);

      loadSubtasks();
    } catch (error) {
      console.error('Error adding subtask:', error);
    }
  };

  const handleToggleSubtask = async (subtaskId: string, isCompleted: boolean) => {
    try {
      await supabase
        .from('task_subtasks')
        .update({ is_completed: isCompleted, updated_at: new Date().toISOString() })
        .eq('id', subtaskId);
      loadSubtasks();
    } catch (error) {
      console.error('Error toggling subtask:', error);
    }
  };

  const handleToggleExpand = (taskId: string) => {
    const newExpanded = new Set(expandedTasks);
    if (newExpanded.has(taskId)) {
      newExpanded.delete(taskId);
    } else {
      newExpanded.add(taskId);
    }
    setExpandedTasks(newExpanded);
  };

  const applyFilters = (tasksToFilter: Task[]) => {
    let filtered = [...tasksToFilter];

    const searchQuery = quickSearchQuery || filters.searchQuery;
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(task =>
        task.title.toLowerCase().includes(query) ||
        task.notes.toLowerCase().includes(query)
      );
    }

    if (filters.categories.length > 0) {
      filtered = filtered.filter(task => filters.categories.includes(task.category));
    }

    if (filters.priorities.length > 0) {
      filtered = filtered.filter(task => filters.priorities.includes(task.priority));
    }

    if (filters.assignedTo) {
      filtered = filtered.filter(task => task.assigned_to === filters.assignedTo);
    }

    if (filters.dueDateRange !== 'all') {
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      filtered = filtered.filter(task => {
        if (!task.due_date) return false;
        const dueDate = new Date(task.due_date);
        dueDate.setHours(0, 0, 0, 0);

        switch (filters.dueDateRange) {
          case 'overdue':
            return dueDate < today && task.status !== 'completed';
          case 'today':
            return dueDate.getTime() === today.getTime();
          case 'week': {
            const weekFromNow = new Date(today);
            weekFromNow.setDate(weekFromNow.getDate() + 7);
            return dueDate >= today && dueDate <= weekFromNow;
          }
          case 'month': {
            const monthFromNow = new Date(today);
            monthFromNow.setMonth(monthFromNow.getMonth() + 1);
            return dueDate >= today && dueDate <= monthFromNow;
          }
          default:
            return true;
        }
      });
    }

    return filtered;
  };

  let filteredTasks = applyFilters(tasks);

  if (sortColumn) {
    filteredTasks = [...filteredTasks].sort((a, b) => {
      let aValue: any;
      let bValue: any;

      switch (sortColumn) {
        case 'title':
          aValue = a.title.toLowerCase();
          bValue = b.title.toLowerCase();
          break;
        case 'category':
          aValue = a.category.toLowerCase();
          bValue = b.category.toLowerCase();
          break;
        case 'priority':
          const priorityOrder = { high: 3, medium: 2, low: 1 };
          aValue = priorityOrder[a.priority];
          bValue = priorityOrder[b.priority];
          break;
        case 'due_date':
          aValue = a.due_date ? new Date(a.due_date).getTime() : Infinity;
          bValue = b.due_date ? new Date(b.due_date).getTime() : Infinity;
          break;
        case 'assigned_to':
          aValue = (a.assigned_to || '').toLowerCase();
          bValue = (b.assigned_to || '').toLowerCase();
          break;
        case 'status':
          const statusOrder = { pending: 1, in_progress: 2, completed: 3 };
          aValue = statusOrder[a.status];
          bValue = statusOrder[b.status];
          break;
        default:
          return 0;
      }

      if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  }

  const handleSort = (column: typeof sortColumn) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection(column === 'due_date' ? 'asc' : 'asc');
    }
  };

  const getSortIcon = (column: typeof sortColumn) => {
    if (sortColumn !== column) {
      return <ArrowUpDown className="w-4 h-4 opacity-40" />;
    }
    return sortDirection === 'asc' ? (
      <ArrowUp className="w-4 h-4 text-[#d4af37]" />
    ) : (
      <ArrowDown className="w-4 h-4 text-[#d4af37]" />
    );
  };

  const groupedTasks = filteredTasks.reduce((acc, task) => {
    if (!acc[task.status]) acc[task.status] = [];
    acc[task.status].push(task);
    return acc;
  }, {} as Record<string, Task[]>);

  // Sort tasks within each column by order_index
  Object.keys(groupedTasks).forEach(status => {
    groupedTasks[status].sort((a, b) => (a.order_index || 0) - (b.order_index || 0));
  });

  const handleDragStart = (event: DragStartEvent) => {
    setActiveId(event.active.id.toString());
    setIsDragging(true);
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);
    setIsDragging(false);

    if (!over || active.id === over.id) return;

    const activeTask = tasks.find(t => t.id === active.id);
    if (!activeTask) return;

    const overId = over.id.toString();
    let newStatus: 'pending' | 'in_progress' | 'completed';
    let targetStatus: string;

    // Determine target status
    if (overId === 'droppable-pending' || overId === 'pending') {
      newStatus = 'pending';
      targetStatus = 'pending';
    } else if (overId === 'droppable-in_progress' || overId === 'in_progress') {
      newStatus = 'in_progress';
      targetStatus = 'in_progress';
    } else if (overId === 'droppable-completed' || overId === 'completed') {
      newStatus = 'completed';
      targetStatus = 'completed';
    } else {
      const overTask = tasks.find(t => t.id === overId);
      if (overTask) {
        newStatus = overTask.status;
        targetStatus = overTask.status;
      } else {
        return;
      }
    }

    const isSameColumn = activeTask.status === newStatus;

    try {
      if (isSameColumn) {
        // Reordering within same column
        const columnTasks = groupedTasks[activeTask.status] || [];
        const oldIndex = columnTasks.findIndex(t => t.id === active.id);
        const newIndex = columnTasks.findIndex(t => t.id === overId);

        if (oldIndex === -1 || newIndex === -1 || oldIndex === newIndex) return;

        // Reorder array
        const reorderedTasks = arrayMove(columnTasks, oldIndex, newIndex);

        // Update order_index for all affected tasks
        const updates = reorderedTasks.map((task, index) => ({
          id: task.id,
          order_index: index,
        }));

        // Perform batch update
        const updatePromises = updates.map(update =>
          supabase.from('tasks').update({ order_index: update.order_index }).eq('id', update.id)
        );

        await Promise.all(updatePromises);
        showToast('success', 'Position gespeichert', 'Aufgabe wurde erfolgreich verschoben.');
      } else {
        // Moving to different column
        const targetColumnTasks = groupedTasks[targetStatus] || [];
        const newOrderIndex = targetColumnTasks.length;

        await supabase
          .from('tasks')
          .update({ status: newStatus, order_index: newOrderIndex })
          .eq('id', active.id);

        showToast('success', 'Status aktualisiert', `Aufgabe wurde zu "${newStatus === 'pending' ? 'Offen' : newStatus === 'in_progress' ? 'In Bearbeitung' : 'Erledigt'}" verschoben.`);
      }

      onUpdate();
    } catch (error) {
      console.error('Error updating task:', error);
      showToast('error', 'Fehler', 'Aufgabe konnte nicht verschoben werden. Bitte versuche es erneut.');
      onUpdate(); // Reload to revert UI
    }
  };

  const getCategoryProgress = () => {
    const categoryStats: Record<string, { total: number; completed: number }> = {};

    tasks.forEach(task => {
      if (!categoryStats[task.category]) {
        categoryStats[task.category] = { total: 0, completed: 0 };
      }
      categoryStats[task.category].total++;
      if (task.status === 'completed') {
        categoryStats[task.category].completed++;
      }
    });

    return categoryStats;
  };

  const categoryProgress = getCategoryProgress();

  const hasActiveFilters = filters.categories.length > 0 ||
    filters.priorities.length > 0 ||
    filters.dueDateRange !== 'all' ||
    filters.assignedTo !== '' ||
    filters.searchQuery !== '';

  const clearFilters = () => {
    setFilters({
      categories: [],
      priorities: [],
      dueDateRange: 'all',
      assignedTo: '',
      searchQuery: '',
    });
  };

  const toggleColumnCollapse = (status: string) => {
    const newCollapsed = new Set(collapsedColumns);
    if (newCollapsed.has(status)) {
      newCollapsed.delete(status);
    } else {
      newCollapsed.add(status);
    }
    setCollapsedColumns(newCollapsed);
  };

  const renderKanbanView = () => (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragStart={handleDragStart}
      onDragEnd={handleDragEnd}
    >
      <div className="flex flex-col lg:flex-row gap-3 sm:gap-4 md:gap-6 overflow-x-auto lg:overflow-x-visible">
        {['pending', 'in_progress', 'completed'].map(status => {
          const isCollapsed = collapsedColumns.has(status);
          return (
          <div key={status} className={`bg-white rounded-xl sm:rounded-2xl shadow-lg transition-all ${isCollapsed ? 'flex-shrink-0 w-auto' : 'flex-1 min-w-[280px] lg:min-w-0'}`}>
            <button
              onClick={() => toggleColumnCollapse(status)}
              className="w-full p-3 sm:p-4 md:p-6 flex items-center justify-between active:bg-[#f7f2eb]/30 transition-all rounded-t-xl sm:rounded-t-2xl touch-manipulation"
            >
              <h3 className="text-base sm:text-lg md:text-xl font-bold text-[#0a253c] flex items-center gap-1.5 sm:gap-2">
                {status === 'pending' && <><Circle className="w-4 h-4 sm:w-5 sm:h-5 text-yellow-500" /><span className="hidden xs:inline">Offen</span><span className="xs:hidden">Offen</span></>}
                {status === 'in_progress' && <><Circle className="w-4 h-4 sm:w-5 sm:h-5 text-blue-500 fill-current" /><span className="hidden sm:inline">In Bearbeitung</span><span className="sm:hidden">Läuft</span></>}
                {status === 'completed' && <><CheckCircle className="w-4 h-4 sm:w-5 sm:h-5 text-green-500 fill-current" /><span className="hidden xs:inline">Erledigt</span><span className="xs:hidden">✓</span></>}
                <span className="ml-1 sm:ml-2 text-xs sm:text-sm">({groupedTasks[status]?.length || 0})</span>
              </h3>
              {isCollapsed ? (
                <ChevronRight className="w-4 h-4 sm:w-5 sm:h-5 text-[#0a253c]" />
              ) : (
                <ChevronDown className="w-4 h-4 sm:w-5 sm:h-5 text-[#0a253c]" />
              )}
            </button>
            {!isCollapsed && (
              <div className="px-2 sm:px-3 md:px-6 pb-2 sm:pb-3 md:pb-6">
                <DroppableColumn id={status}>
                  <SortableContext items={groupedTasks[status]?.map(t => t.id) || []} strategy={verticalListSortingStrategy}>
                    <div className="space-y-3">
                      {groupedTasks[status]?.map(task => (
                        <SortableTask
                          key={task.id}
                          task={task}
                          subtasks={subtasks}
                          dependencies={dependencies}
                          allTasks={tasks}
                          onToggleTask={handleToggleTask}
                          onDeleteTask={handleDeleteTask}
                          onSelectTask={setSelectedTask}
                          onToggleExpand={handleToggleExpand}
                          expandedTasks={expandedTasks}
                          onAddSubtask={handleAddSubtask}
                          onToggleSubtask={handleToggleSubtask}
                          budgetItems={budgetItems}
                          vendors={vendors}
                          teamRoles={teamRoles}
                          isDragging={isDragging}
                          activeId={activeId}
                        />
                      ))}
                      {!groupedTasks[status]?.length && (
                        <p className="text-[#333333] text-center py-8">
                          {status === 'pending' && 'Keine offenen Aufgaben'}
                          {status === 'in_progress' && 'Keine laufenden Aufgaben'}
                          {status === 'completed' && 'Keine erledigten Aufgaben'}
                        </p>
                      )}
                    </div>
                  </SortableContext>
                </DroppableColumn>
              </div>
            )}
          </div>
          );
        })}
      </div>
      <DragOverlay>
        {activeId ? (
          <div className="p-4 rounded-xl bg-[#f7f2eb] shadow-2xl border-2 border-[#d4af37] opacity-90 scale-105 rotate-3 cursor-grabbing">
            <div className="flex items-start gap-3">
              <GripVertical className="w-5 h-5 text-[#d4af37] mt-1" />
              <div className="flex-1">
                <p className="font-semibold text-[#0a253c]">
                  {tasks.find(t => t.id === activeId)?.title || 'Aufgabe'}
                </p>
              </div>
            </div>
          </div>
        ) : null}
      </DragOverlay>
    </DndContext>
  );

  const handleStatusChange = async (taskId: string, newStatus: 'pending' | 'in_progress' | 'completed') => {
    try {
      await supabase.from('tasks').update({ status: newStatus }).eq('id', taskId);
      onUpdate();
    } catch (error) {
      console.error('Error updating task status:', error);
    }
  };

  const renderListView = () => (
    <TaskListView
      tasks={filteredTasks}
      subtasks={subtasks}
      budgetItems={budgetItems}
      vendors={vendors}
      teamRoles={teamRoles}
      onTaskClick={setSelectedTask}
      onDeleteTask={handleDeleteTask}
      onStatusChange={handleStatusChange}
    />
  );

  const renderCalendarView = () => {
    const today = new Date();
    const currentMonth = calendarDate.getMonth();
    const currentYear = calendarDate.getFullYear();

    const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
    const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
    const adjustedFirstDay = firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1;

    const tasksByDate: Record<string, Task[]> = {};
    filteredTasks.forEach(task => {
      if (task.due_date) {
        const dateKey = task.due_date;
        if (!tasksByDate[dateKey]) tasksByDate[dateKey] = [];
        tasksByDate[dateKey].push(task);
      }
    });

    const days = [];
    for (let i = 0; i < adjustedFirstDay; i++) {
      days.push(<div key={`empty-${i}`} className="min-h-20 md:min-h-24 bg-gray-50"></div>);
    }

    for (let day = 1; day <= daysInMonth; day++) {
      const date = new Date(currentYear, currentMonth, day);
      const dateString = date.toISOString().split('T')[0];
      const dayTasks = tasksByDate[dateString] || [];
      const isToday = day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();

      days.push(
        <div key={day} className={`min-h-24 md:min-h-32 p-1 md:p-2 border border-[#d4af37]/20 ${isToday ? 'bg-[#d4af37]/10 border-[#d4af37]' : 'bg-white'}`}>
          <div className={`text-xs md:text-sm font-bold mb-1 md:mb-2 ${isToday ? 'text-[#d4af37]' : 'text-[#333333]'}`}>
            {day}
          </div>
          <div className="space-y-1 md:space-y-2">
            {dayTasks.slice(0, 2).map(task => {
              const isOverdue = task.due_date && new Date(task.due_date) < new Date() && task.status !== 'completed';
              const assignedRole = task.assigned_to ? teamRoles.find(r => r.name === task.assigned_to) : null;
              const budgetItem = task.budget_item_id ? budgetItems.find(b => b.id === task.budget_item_id) : null;
              const vendor = task.vendor_id ? vendors.find(v => v.id === task.vendor_id) : null;

              const getPriorityBorderColor = () => {
                if (isOverdue) return 'border-2 border-red-400';
                if (task.priority === 'high') return 'border-2 border-red-400';
                if (task.priority === 'medium') return 'border border-yellow-400';
                return 'border border-transparent';
              };

              const getPriorityBgColor = () => {
                if (task.status === 'completed') return 'bg-green-50';
                if (task.status === 'in_progress') return 'bg-blue-50';
                if (task.priority === 'high') return 'bg-red-50';
                if (task.priority === 'medium') return 'bg-yellow-50';
                return 'bg-[#f7f2eb]';
              };

              return (
                <button
                  key={task.id}
                  onClick={() => setSelectedTask(task)}
                  className={`w-full text-left px-1 md:px-2 py-1 md:py-2 rounded-lg transition-all hover:shadow-md ${getPriorityBgColor()} ${getPriorityBorderColor()} hover:scale-105`}
                >
                  <div className="flex items-start gap-0.5 md:gap-1 mb-0.5 md:mb-1">
                    {task.status === 'completed' ? (
                      <CheckCircle className="w-2.5 h-2.5 md:w-3 md:h-3 text-green-500 flex-shrink-0 mt-0.5" />
                    ) : task.status === 'in_progress' ? (
                      <Circle className="w-2.5 h-2.5 md:w-3 md:h-3 text-blue-500 fill-current flex-shrink-0 mt-0.5" />
                    ) : (
                      <Circle className="w-2.5 h-2.5 md:w-3 md:h-3 text-[#333333] flex-shrink-0 mt-0.5" />
                    )}
                    <span className={`text-[10px] md:text-xs font-semibold text-[#0a253c] line-clamp-2 ${task.status === 'completed' ? 'line-through' : ''}`}>
                      {task.title}
                    </span>
                  </div>
                  <div className="hidden md:flex flex-wrap gap-1 items-center ml-4">
                    <span className="px-1.5 py-0.5 bg-[#d4af37]/30 text-[#0a253c] rounded text-[10px] font-medium whitespace-nowrap">
                      {getCategoryLabel(task.category)}
                    </span>
                    {task.priority === 'high' && (
                      <span className="px-1.5 py-0.5 bg-red-500 text-white rounded text-[10px] font-bold" title="Hohe Priorität">
                        !
                      </span>
                    )}
                    {task.priority === 'medium' && (
                      <span className="px-1.5 py-0.5 bg-yellow-500 text-white rounded text-[10px] font-bold" title="Mittlere Priorität">
                        •
                      </span>
                    )}
                    {assignedRole && (
                      <span className="flex items-center gap-0.5" title={assignedRole.name}>
                        {assignedRole.character_image ? (
                          <img
                            src={assignedRole.character_image}
                            alt={assignedRole.name}
                            className="w-3 h-3 rounded-full object-cover"
                          />
                        ) : (
                          <User className="w-3 h-3 text-blue-600" />
                        )}
                      </span>
                    )}
                    {budgetItem && (
                      <span className="px-1 py-0.5 bg-green-500 text-white rounded text-[10px]" title={`Budget: ${budgetItem.item_name}`}>
                        <DollarSign className="w-2.5 h-2.5" />
                      </span>
                    )}
                    {vendor && (
                      <span className="px-1 py-0.5 bg-purple-500 text-white rounded text-[10px]" title={`Dienstleister: ${vendor.name}`}>
                        <Building2 className="w-2.5 h-2.5" />
                      </span>
                    )}
                  </div>
                </button>
              );
            })}
            {dayTasks.length > 2 && (
              <div className="text-[10px] md:text-xs text-[#d4af37] font-semibold text-center">+{dayTasks.length - 2} weitere</div>
            )}
          </div>
        </div>
      );
    }

    return (
      <div className="bg-white rounded-2xl p-3 md:p-6 shadow-lg">
        <div className="mb-4 md:mb-6 flex items-center justify-between">
          <button
            onClick={() => setCalendarDate(new Date(currentYear, currentMonth - 1, 1))}
            className="p-1 md:p-2 hover:bg-[#f7f2eb] rounded-lg transition-all"
            title="Vorheriger Monat"
          >
            <ChevronLeft className="w-5 h-5 md:w-6 md:h-6 text-[#0a253c]" />
          </button>
          <h3 className="text-lg md:text-2xl font-bold text-[#0a253c]">
            {new Date(currentYear, currentMonth).toLocaleDateString('de-DE', { month: 'long', year: 'numeric' })}
          </h3>
          <button
            onClick={() => setCalendarDate(new Date(currentYear, currentMonth + 1, 1))}
            className="p-1 md:p-2 hover:bg-[#f7f2eb] rounded-lg transition-all"
            title="Nächster Monat"
          >
            <ChevronRight className="w-5 h-5 md:w-6 md:h-6 text-[#0a253c]" />
          </button>
        </div>
        <div className="grid grid-cols-7 gap-0.5 md:gap-1">
          {['Mo', 'Di', 'Mi', 'Do', 'Fr', 'Sa', 'So'].map(day => (
            <div key={day} className="text-center font-bold text-[#0a253c] py-1 md:py-2 text-xs md:text-sm">
              {day}
            </div>
          ))}
          {days}
        </div>
      </div>
    );
  };

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
        <h2 className="text-2xl md:text-3xl font-bold text-[#0a253c]">{TASK.MODULE_NAME} & Checklisten</h2>
        <span className="px-3 py-1 bg-green-500 text-white text-xs font-bold rounded-full animate-pulse">
          DRAG & DROP AKTIV
        </span>
      </div>
        <div className="flex flex-wrap gap-2 md:gap-3 w-full sm:w-auto">
          <div className="flex gap-1 bg-[#f7f2eb] rounded-xl p-1 w-full sm:w-auto">
            <button
              onClick={() => setViewMode('kanban')}
              className={`flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-2 rounded-lg font-semibold transition-all text-xs sm:text-sm flex-1 sm:flex-initial justify-center ${
                viewMode === 'kanban' ? 'bg-[#d4af37] text-[#0a253c]' : 'text-[#333333] hover:bg-white'
              }`}
              title="Kanban-Ansicht"
            >
              <Grid className="w-4 h-4" />
              <span className="hidden sm:inline">Kanban</span>
            </button>
            <button
              onClick={() => setViewMode('list')}
              className={`flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-2 rounded-lg font-semibold transition-all text-xs sm:text-sm flex-1 sm:flex-initial justify-center ${
                viewMode === 'list' ? 'bg-[#d4af37] text-[#0a253c]' : 'text-[#333333] hover:bg-white'
              }`}
              title="Listen-Ansicht"
            >
              <List className="w-4 h-4" />
              <span className="hidden sm:inline">Liste</span>
            </button>
            <button
              onClick={() => setViewMode('calendar')}
              className={`flex items-center gap-1 sm:gap-2 px-2 sm:px-4 py-2 rounded-lg font-semibold transition-all text-xs sm:text-sm flex-1 sm:flex-initial justify-center ${
                viewMode === 'calendar' ? 'bg-[#d4af37] text-[#0a253c]' : 'text-[#333333] hover:bg-white'
              }`}
              title="Kalender-Ansicht"
            >
              <Calendar className="w-4 h-4" />
              <span className="hidden sm:inline">Kalender</span>
            </button>
          </div>
          <button
            onClick={() => setShowTemplateSelector(true)}
            className="flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-3 bg-white border-2 border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 rounded-xl font-bold transition-all text-sm sm:text-base flex-1 sm:flex-initial justify-center"
          >
            <FileText className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="hidden sm:inline">Vorlage</span>
          </button>
          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all text-sm sm:text-base flex-1 sm:flex-initial justify-center"
          >
            <Plus className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="hidden xs:inline">{TASK.ADD}</span>
            <span className="xs:hidden">Neu</span>
          </button>
        </div>
      </div>

      <TaskKPIPanel tasks={tasks} />

      <div className="bg-white rounded-2xl p-3 md:p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 mb-4">
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 flex-1">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center justify-center gap-2 px-4 py-2 bg-[#f7f2eb] rounded-xl font-semibold text-[#0a253c] hover:bg-[#d4af37]/10 transition-all text-sm"
            >
              <Filter className="w-4 h-4 sm:w-5 sm:h-5" />
              <span>Filter</span>
              {hasActiveFilters && <span className="ml-1">({filters.categories.length + filters.priorities.length + (filters.dueDateRange !== 'all' ? 1 : 0) + (filters.assignedTo ? 1 : 0)})</span>}
            </button>
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 sm:w-5 sm:h-5 text-[#333333]" />
              <input
                type="text"
                value={quickSearchQuery}
                onChange={(e) => setQuickSearchQuery(e.target.value)}
                placeholder="Schnellsuche..."
                className="w-full pl-9 sm:pl-10 pr-4 py-2 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none text-sm"
              />
            </div>
          </div>
          {hasActiveFilters && (
            <button
              onClick={clearFilters}
              className="flex items-center justify-center gap-2 px-4 py-2 text-[#d4af37] hover:text-[#c19a2e] transition-all text-sm whitespace-nowrap"
            >
              <X className="w-4 h-4" />
              <span className="hidden sm:inline">Filter zurücksetzen</span>
              <span className="sm:hidden">Zurücksetzen</span>
            </button>
          )}
        </div>

        {showFilters && (
          <div className="space-y-4 pt-4 border-t border-[#d4af37]/20">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#333333]" />
              <input
                type="text"
                value={filters.searchQuery}
                onChange={(e) => setFilters({ ...filters, searchQuery: e.target.value })}
                placeholder={`${TASK.PLURAL} durchsuchen...`}
                className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Kategorien</label>
              <div className="flex flex-wrap gap-2">
                {categories.map(cat => (
                  <button
                    key={cat.value}
                    onClick={() => {
                      const newCategories = filters.categories.includes(cat.value)
                        ? filters.categories.filter(c => c !== cat.value)
                        : [...filters.categories, cat.value];
                      setFilters({ ...filters, categories: newCategories });
                    }}
                    className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                      filters.categories.includes(cat.value)
                        ? 'bg-[#d4af37] text-[#0a253c]'
                        : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                    }`}
                  >
                    {cat.label}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Priorität</label>
              <div className="flex flex-wrap gap-2">
                {['low', 'medium', 'high'].map(priority => (
                  <button
                    key={priority}
                    onClick={() => {
                      const newPriorities = filters.priorities.includes(priority)
                        ? filters.priorities.filter(p => p !== priority)
                        : [...filters.priorities, priority];
                      setFilters({ ...filters, priorities: newPriorities });
                    }}
                    className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                      filters.priorities.includes(priority)
                        ? 'bg-[#d4af37] text-[#0a253c]'
                        : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                    }`}
                  >
                    {priority === 'high' ? 'Hoch' : priority === 'medium' ? 'Mittel' : 'Niedrig'}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Fälligkeitsdatum</label>
              <div className="flex flex-wrap gap-2">
                {[
                  { value: 'all', label: 'Alle' },
                  { value: 'overdue', label: 'Überfällig' },
                  { value: 'today', label: 'Heute' },
                  { value: 'week', label: 'Diese Woche' },
                  { value: 'month', label: 'Dieser Monat' },
                ].map(option => (
                  <button
                    key={option.value}
                    onClick={() => setFilters({ ...filters, dueDateRange: option.value as any })}
                    className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                      filters.dueDateRange === option.value
                        ? 'bg-[#d4af37] text-[#0a253c]'
                        : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            </div>

            {teamRoles.length > 0 && (
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Zugewiesen an</label>
                <div className="flex flex-wrap gap-2">
                  <button
                    onClick={() => setFilters({ ...filters, assignedTo: '' })}
                    className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                      filters.assignedTo === ''
                        ? 'bg-[#d4af37] text-[#0a253c]'
                        : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                    }`}
                  >
                    Alle
                  </button>
                  {teamRoles.map(role => (
                    <button
                      key={role.id}
                      onClick={() => setFilters({ ...filters, assignedTo: role.name })}
                      className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                        filters.assignedTo === role.name
                          ? 'bg-[#d4af37] text-[#0a253c]'
                          : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                      }`}
                    >
                      {role.name}
                    </button>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {Object.keys(categoryProgress).length > 0 && (
        <div className="bg-white rounded-2xl shadow-lg">
          <button
            onClick={() => setShowCategoryProgress(!showCategoryProgress)}
            className="w-full p-6 flex items-center justify-between hover:bg-[#f7f2eb]/30 transition-all rounded-2xl"
          >
            <h3 className="text-xl font-bold text-[#0a253c]">Fortschritt nach Kategorie</h3>
            {showCategoryProgress ? (
              <ChevronDown className="w-5 h-5 text-[#0a253c]" />
            ) : (
              <ChevronRight className="w-5 h-5 text-[#0a253c]" />
            )}
          </button>
          {showCategoryProgress && (
            <div className="px-6 pb-6">
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
                {Object.entries(categoryProgress).map(([category, stats]) => {
                  const percentage = Math.round((stats.completed / stats.total) * 100);
                  return (
                    <div key={category} className="p-4 bg-[#f7f2eb] rounded-xl">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-semibold text-[#0a253c]">{getCategoryLabel(category)}</span>
                        <span className="text-sm text-[#333333]">{stats.completed}/{stats.total}</span>
                      </div>
                      <div className="w-full bg-white rounded-full h-2 overflow-hidden">
                        <div
                          className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-full rounded-full transition-all duration-500"
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </div>
      )}

      {viewMode === 'kanban' && renderKanbanView()}
      {viewMode === 'list' && renderListView()}
      {viewMode === 'calendar' && renderCalendarView()}

      {selectedTask && (
        <TaskDetailModal
          taskId={selectedTask.id}
          taskTitle={selectedTask.title}
          weddingId={weddingId}
          onClose={() => {
            setSelectedTask(null);
            onUpdate();
            loadSubtasks();
            loadDependencies();
          }}
        />
      )}

      {showTemplateSelector && (
        <TaskTemplateSelector
          weddingId={weddingId}
          onClose={() => setShowTemplateSelector(false)}
          onApplyTemplate={() => {
            setShowTemplateSelector(false);
            onUpdate();
          }}
        />
      )}

      <TaskAddModal
        isOpen={showAddModal}
        weddingId={weddingId}
        onClose={() => setShowAddModal(false)}
        onTaskCreated={() => {
          setShowAddModal(false);
          onUpdate();
        }}
      />

      </div>
  );
}
