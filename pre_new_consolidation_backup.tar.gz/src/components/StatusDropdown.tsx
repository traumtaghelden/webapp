import { useState, useRef, useEffect } from 'react';
import { ChevronDown, Check } from 'lucide-react';

interface StatusOption {
  value: string;
  label: string;
  color: string;
  bgColor: string;
  borderColor: string;
}

interface StatusDropdownProps {
  value: string;
  onChange: (value: string) => void;
  options: StatusOption[];
  size?: 'sm' | 'md' | 'lg';
  onClick?: (e: React.MouseEvent) => void;
}

export default function StatusDropdown({ value, onChange, options, size = 'md', onClick }: StatusDropdownProps) {
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const selectedOption = options.find(opt => opt.value === value) || options[0];

  const sizeClasses = {
    sm: 'px-3 py-1.5 text-xs',
    md: 'px-4 py-2 text-sm',
    lg: 'px-5 py-2.5 text-base'
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    };

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isOpen]);

  const handleToggle = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onClick) onClick(e);
    setIsOpen(!isOpen);
  };

  const handleSelect = (optionValue: string) => {
    onChange(optionValue);
    setIsOpen(false);
  };

  return (
    <div ref={dropdownRef} className="relative">
      <button
        onClick={handleToggle}
        className={`${sizeClasses[size]} rounded-xl font-semibold border-2 transition-all duration-200 flex items-center gap-2 hover:shadow-md ${selectedOption.bgColor} ${selectedOption.color} ${selectedOption.borderColor} hover:brightness-95`}
      >
        <span className="flex-1">{selectedOption.label}</span>
        <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="absolute z-[9999] mt-2 w-full min-w-[200px] bg-white rounded-xl shadow-2xl border-2 border-[#d4af37]/20 overflow-hidden animate-in fade-in slide-in-from-top-2 duration-200">
          {options.map((option) => (
            <button
              key={option.value}
              onClick={() => handleSelect(option.value)}
              className={`w-full px-4 py-3 text-left text-sm font-semibold transition-all duration-150 flex items-center justify-between hover:bg-[#f7f2eb] ${
                option.value === value ? 'bg-[#f7f2eb]/50' : ''
              } ${option.color}`}
            >
              <span>{option.label}</span>
              {option.value === value && (
                <Check className="w-4 h-4 text-[#d4af37]" />
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
