import { useState, useEffect } from 'react';
import { Save, ChevronLeft, ChevronRight, Heart } from 'lucide-react';
import { supabase, type Wedding } from '../../lib/supabase';

interface SettingsHochzeitTabProps {
  weddingId: string;
  onUpdate: () => void;
}

export default function SettingsHochzeitTab({ weddingId, onUpdate }: SettingsHochzeitTabProps) {
  const [wedding, setWedding] = useState<Wedding | null>(null);
  const [saving, setSaving] = useState(false);
  const [successMessage, setSuccessMessage] = useState('');
  const [formData, setFormData] = useState({
    partner1Name: '',
    partner2Name: '',
    partner1Age: '',
    partner2Age: '',
    partner1HeroType: 'hero1',
    partner2HeroType: 'hero2',
    weddingDate: '',
    guestCount: '',
    ceremonyType: 'traditional',
    budget: '',
  });

  useEffect(() => {
    loadWedding();
  }, [weddingId]);

  const loadWedding = async () => {
    try {
      const { data } = await supabase
        .from('weddings')
        .select('*')
        .eq('id', weddingId)
        .maybeSingle();

      if (data) {
        setWedding(data);
        setFormData({
          partner1Name: data.partner_1_name,
          partner2Name: data.partner_2_name,
          partner1Age: data.partner_1_age?.toString() || '',
          partner2Age: data.partner_2_age?.toString() || '',
          partner1HeroType: data.partner_1_hero_type || 'hero1',
          partner2HeroType: data.partner_2_hero_type || 'hero2',
          weddingDate: data.wedding_date,
          guestCount: data.guest_count.toString(),
          ceremonyType: data.ceremony_type,
          budget: data.total_budget.toString(),
        });
      }
    } catch (error) {
      console.error('Error loading wedding:', error);
    }
  };

  const handleSave = async () => {
    try {
      setSaving(true);

      await supabase
        .from('weddings')
        .update({
          partner_1_name: formData.partner1Name,
          partner_2_name: formData.partner2Name,
          partner_1_age: formData.partner1Age ? parseInt(formData.partner1Age) : null,
          partner_2_age: formData.partner2Age ? parseInt(formData.partner2Age) : null,
          partner_1_hero_type: formData.partner1HeroType,
          partner_2_hero_type: formData.partner2HeroType,
          wedding_date: formData.weddingDate,
          guest_count: parseInt(formData.guestCount) || 0,
          ceremony_type: formData.ceremonyType,
          total_budget: parseFloat(formData.budget) || 0,
          updated_at: new Date().toISOString(),
        })
        .eq('id', weddingId);

      setSuccessMessage('Änderungen erfolgreich gespeichert!');
      setTimeout(() => setSuccessMessage(''), 3000);
      onUpdate();
    } catch (error) {
      console.error('Error saving:', error);
      alert('Fehler beim Speichern');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-2xl font-bold text-[#0a253c]">Hochzeitsdetails</h3>
        <button
          onClick={handleSave}
          disabled={saving}
          className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 transition-all"
        >
          <Save className="w-5 h-5" />
          {saving ? 'Speichert...' : 'Speichern'}
        </button>
      </div>

      {successMessage && (
        <div className="bg-green-100 border-2 border-green-500 rounded-xl p-4 text-green-700 font-semibold text-center">
          {successMessage}
        </div>
      )}

      <div className="bg-white rounded-2xl p-8 shadow-lg space-y-8">
        <div>
          <h4 className="text-xl font-bold text-[#0a253c] mb-6 flex items-center gap-2">
            <Heart className="w-5 h-5 text-[#d4af37]" />
            Partner-Informationen
          </h4>
          <div className="grid md:grid-cols-2 gap-8">
            <div className="space-y-4">
              <h5 className="text-lg font-semibold text-[#0a253c]">Partner 1</h5>
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                <input
                  type="text"
                  value={formData.partner1Name}
                  onChange={(e) => setFormData({ ...formData, partner1Name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Alter</label>
                <input
                  type="number"
                  value={formData.partner1Age}
                  onChange={(e) => setFormData({ ...formData, partner1Age: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  min="18"
                  max="120"
                />
              </div>
            </div>

            <div className="space-y-4">
              <h5 className="text-lg font-semibold text-[#0a253c]">Partner 2</h5>
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                <input
                  type="text"
                  value={formData.partner2Name}
                  onChange={(e) => setFormData({ ...formData, partner2Name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                />
              </div>
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Alter</label>
                <input
                  type="number"
                  value={formData.partner2Age}
                  onChange={(e) => setFormData({ ...formData, partner2Age: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  min="18"
                  max="120"
                />
              </div>
            </div>
          </div>
        </div>

        <div className="border-t-2 border-[#f7f2eb] pt-8">
          <h4 className="text-xl font-bold text-[#0a253c] mb-6">Hochzeitsdetails</h4>
          <div className="grid md:grid-cols-2 gap-6">
            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Hochzeitsdatum*</label>
              <input
                type="date"
                value={formData.weddingDate}
                onChange={(e) => setFormData({ ...formData, weddingDate: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Art der Trauung*</label>
              <select
                value={formData.ceremonyType}
                onChange={(e) => setFormData({ ...formData, ceremonyType: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
              >
                <option value="traditional">Traditionell</option>
                <option value="civil">Standesamtlich</option>
                <option value="religious">Kirchlich</option>
                <option value="outdoor">Im Freien</option>
                <option value="destination">Destination Wedding</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Gästezahl*</label>
              <input
                type="number"
                value={formData.guestCount}
                onChange={(e) => setFormData({ ...formData, guestCount: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                min="1"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Gesamtbudget (€)*</label>
              <input
                type="number"
                value={formData.budget}
                onChange={(e) => setFormData({ ...formData, budget: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                min="0"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
