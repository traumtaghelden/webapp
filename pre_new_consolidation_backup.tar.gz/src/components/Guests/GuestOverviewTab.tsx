import { useState } from 'react';
import { Plus, Search, Filter, User, Users, CheckCircle, XCircle, Clock, Mail, Phone } from 'lucide-react';
import { type Guest } from '../../lib/supabase';
import GuestDetailModal from '../GuestDetailModal';
import { GUEST, COMMON } from '../../constants/terminology';

interface GuestOverviewTabProps {
  guests: Guest[];
  onUpdate: () => void;
  onAddGuest: () => void;
}

export default function GuestOverviewTab({ guests, onUpdate, onAddGuest }: GuestOverviewTabProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState<'all' | 'accepted' | 'declined' | 'pending'>('all');
  const [selectedGuest, setSelectedGuest] = useState<Guest | null>(null);

  const filteredGuests = guests.filter(guest => {
    const matchesSearch = searchQuery === '' ||
      guest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      guest.email?.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesFilter = filterStatus === 'all' || guest.rsvp_status === filterStatus;

    return matchesSearch && matchesFilter;
  });

  const statusCounts = {
    total: guests.length,
    accepted: guests.filter(g => g.rsvp_status === 'accepted').length,
    declined: guests.filter(g => g.rsvp_status === 'declined').length,
    pending: guests.filter(g => g.rsvp_status === 'pending').length,
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-4 shadow-md border-2 border-[#d4af37]/30">
          <div className="flex items-center gap-3 mb-2">
            <Users className="w-5 h-5 text-[#d4af37]" />
            <h3 className="text-sm font-semibold text-[#666666]">Gesamt</h3>
          </div>
          <p className="text-3xl font-bold text-[#0a253c]">{statusCounts.total}</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-md border-2 border-green-200">
          <div className="flex items-center gap-3 mb-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Zugesagt</h3>
          </div>
          <p className="text-3xl font-bold text-green-600">{statusCounts.accepted}</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-md border-2 border-red-200">
          <div className="flex items-center gap-3 mb-2">
            <XCircle className="w-5 h-5 text-red-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Abgesagt</h3>
          </div>
          <p className="text-3xl font-bold text-red-600">{statusCounts.declined}</p>
        </div>

        <div className="bg-white rounded-xl p-4 shadow-md border-2 border-orange-200">
          <div className="flex items-center gap-3 mb-2">
            <Clock className="w-5 h-5 text-orange-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Ausstehend</h3>
          </div>
          <p className="text-3xl font-bold text-orange-600">{statusCounts.pending}</p>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-lg">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <h3 className="text-xl font-bold text-[#0a253c]">Alle {GUEST.PLURAL}</h3>
          <button
            onClick={onAddGuest}
            className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all"
          >
            <Plus className="w-5 h-5" />
            {GUEST.ADD}
          </button>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 mb-6">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#666666]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={`${GUEST.PLURAL} durchsuchen...`}
              className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
            />
          </div>

          <div className="flex gap-2">
            {[
              { id: 'all', label: 'Alle', icon: Users },
              { id: 'accepted', label: 'Zugesagt', icon: CheckCircle },
              { id: 'declined', label: 'Abgesagt', icon: XCircle },
              { id: 'pending', label: 'Ausstehend', icon: Clock },
            ].map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setFilterStatus(id as any)}
                className={`flex items-center gap-2 px-4 py-2 rounded-xl font-semibold transition-all ${
                  filterStatus === id
                    ? 'bg-[#d4af37] text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{label}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="grid gap-4">
          {filteredGuests.map((guest) => (
            <div
              key={guest.id}
              onClick={() => setSelectedGuest(guest)}
              className="group p-4 bg-[#f7f2eb] rounded-xl hover:bg-[#d4af37]/10 transition-all cursor-pointer border-2 border-transparent hover:border-[#d4af37]/30"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-[#d4af37] flex items-center justify-center text-white font-bold text-lg">
                    {guest.name.charAt(0).toUpperCase()}
                  </div>
                  <div>
                    <h4 className="font-bold text-[#0a253c] text-lg">{guest.name}</h4>
                    <div className="flex flex-wrap gap-3 mt-1 text-sm text-[#666666]">
                      {guest.email && (
                        <div className="flex items-center gap-1">
                          <Mail className="w-4 h-4" />
                          {guest.email}
                        </div>
                      )}
                      {guest.phone && (
                        <div className="flex items-center gap-1">
                          <Phone className="w-4 h-4" />
                          {guest.phone}
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  {guest.plus_one && (
                    <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold">
                      +1
                    </span>
                  )}
                  <span className={`px-4 py-2 rounded-full text-sm font-bold ${
                    guest.rsvp_status === 'accepted'
                      ? 'bg-green-100 text-green-700'
                      : guest.rsvp_status === 'declined'
                      ? 'bg-red-100 text-red-700'
                      : 'bg-orange-100 text-orange-700'
                  }`}>
                    {guest.rsvp_status === 'accepted' ? 'Zugesagt' : guest.rsvp_status === 'declined' ? 'Abgesagt' : 'Ausstehend'}
                  </span>
                </div>
              </div>
            </div>
          ))}

          {filteredGuests.length === 0 && (
            <div className="text-center py-12">
              <User className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
              <p className="text-[#666666] text-lg">Keine {GUEST.PLURAL} gefunden</p>
            </div>
          )}
        </div>
      </div>

      {selectedGuest && (
        <GuestDetailModal
          isOpen={true}
          onClose={() => setSelectedGuest(null)}
          guestId={selectedGuest.id}
          weddingId={selectedGuest.wedding_id}
          onUpdate={onUpdate}
        />
      )}
    </div>
  );
}
