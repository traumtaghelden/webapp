import { useState, useEffect } from 'react';
import { Plus, Users, Edit2, Trash2 } from 'lucide-react';
import { supabase } from '../../lib/supabase';

interface FamilyGroup {
  id: string;
  wedding_id: string;
  family_name: string;
  created_at: string;
}

interface GuestFamiliesTabProps {
  weddingId: string;
  onUpdate: () => void;
}

export default function GuestFamiliesTab({ weddingId, onUpdate }: GuestFamiliesTabProps) {
  const [families, setFamilies] = useState<FamilyGroup[]>([]);
  const [familyGuestCounts, setFamilyGuestCounts] = useState<Record<string, number>>({});

  useEffect(() => {
    loadFamilies();
  }, [weddingId]);

  const loadFamilies = async () => {
    try {
      const { data: familiesData } = await supabase
        .from('family_groups')
        .select('*')
        .eq('wedding_id', weddingId)
        .order('family_name');

      if (familiesData) {
        setFamilies(familiesData);

        const counts: Record<string, number> = {};
        for (const family of familiesData) {
          const { count } = await supabase
            .from('guests')
            .select('*', { count: 'exact', head: true })
            .eq('family_group_id', family.id);
          counts[family.id] = count || 0;
        }
        setFamilyGuestCounts(counts);
      }
    } catch (error) {
      console.error('Error loading families:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-2xl font-bold text-[#0a253c]">Familiengruppen</h3>
        <button className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all">
          <Plus className="w-5 h-5" />
          Familie hinzufügen
        </button>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
        {families.map((family) => (
          <div
            key={family.id}
            className="bg-white rounded-xl p-6 shadow-lg border-2 border-[#d4af37]/30 hover:border-[#d4af37] transition-all"
          >
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-[#d4af37]/20 flex items-center justify-center">
                  <Users className="w-6 h-6 text-[#d4af37]" />
                </div>
                <div>
                  <h4 className="font-bold text-[#0a253c] text-lg">{family.family_name}</h4>
                  <p className="text-sm text-[#666666]">
                    {familyGuestCounts[family.id] || 0} Mitglieder
                  </p>
                </div>
              </div>
              <div className="flex gap-2">
                <button className="p-2 hover:bg-[#f7f2eb] rounded-lg transition-all">
                  <Edit2 className="w-4 h-4 text-[#d4af37]" />
                </button>
                <button className="p-2 hover:bg-red-50 rounded-lg transition-all">
                  <Trash2 className="w-4 h-4 text-red-500" />
                </button>
              </div>
            </div>
          </div>
        ))}

        {families.length === 0 && (
          <div className="col-span-full text-center py-12 bg-[#f7f2eb] rounded-2xl">
            <Users className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
            <p className="text-[#666666] text-lg mb-2">Keine Familiengruppen vorhanden</p>
            <p className="text-sm text-[#999999]">Erstelle Gruppen um Gäste zu organisieren</p>
          </div>
        )}
      </div>
    </div>
  );
}
