import { useState, useEffect } from 'react';
import { Utensils, AlertCircle } from 'lucide-react';
import { type Guest } from '../../lib/supabase';

interface GuestDietaryTabProps {
  guests: Guest[];
}

export default function GuestDietaryTab({ guests }: GuestDietaryTabProps) {
  const guestsWithRestrictions = guests.filter(g => g.dietary_restrictions && g.dietary_restrictions.length > 0);
  const guestsWithAllergies = guests.filter(g => g.allergies && g.allergies.trim() !== '');

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-orange-200">
          <div className="flex items-center gap-3 mb-3">
            <Utensils className="w-6 h-6 text-orange-600" />
            <h3 className="text-lg font-bold text-[#0a253c]">Ernährungswünsche</h3>
          </div>
          <p className="text-4xl font-bold text-orange-600 mb-2">{guestsWithRestrictions.length}</p>
          <p className="text-sm text-[#666666]">Gäste mit speziellen Wünschen</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-red-200">
          <div className="flex items-center gap-3 mb-3">
            <AlertCircle className="w-6 h-6 text-red-600" />
            <h3 className="text-lg font-bold text-[#0a253c]">Allergien</h3>
          </div>
          <p className="text-4xl font-bold text-red-600 mb-2">{guestsWithAllergies.length}</p>
          <p className="text-sm text-[#666666]">Gäste mit Allergien</p>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-lg">
        <h4 className="font-bold text-[#0a253c] text-lg mb-4">Gäste mit Ernährungswünschen</h4>
        <div className="space-y-3">
          {guestsWithRestrictions.map(guest => (
            <div key={guest.id} className="p-4 bg-[#f7f2eb] rounded-xl">
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-bold text-[#0a253c] mb-2">{guest.name}</p>
                  <div className="flex flex-wrap gap-2">
                    {guest.dietary_restrictions?.map((restriction, idx) => (
                      <span
                        key={idx}
                        className="px-3 py-1 bg-orange-100 text-orange-700 rounded-full text-sm font-semibold"
                      >
                        {restriction}
                      </span>
                    ))}
                  </div>
                  {guest.allergies && (
                    <div className="mt-2 flex items-center gap-2 text-red-600">
                      <AlertCircle className="w-4 h-4" />
                      <span className="text-sm font-semibold">Allergien: {guest.allergies}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          ))}

          {guestsWithRestrictions.length === 0 && (
            <div className="text-center py-8 text-[#666666]">
              <Utensils className="w-12 h-12 mx-auto mb-3 opacity-30" />
              <p>Keine speziellen Ernährungswünsche erfasst</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
