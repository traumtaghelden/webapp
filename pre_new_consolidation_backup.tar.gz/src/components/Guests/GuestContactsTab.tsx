import { Mail, Phone, MapPin, MessageSquare } from 'lucide-react';
import { type Guest } from '../../lib/supabase';

interface GuestContactsTabProps {
  guests: Guest[];
}

export default function GuestContactsTab({ guests }: GuestContactsTabProps) {
  const guestsWithEmail = guests.filter(g => g.email);
  const guestsWithPhone = guests.filter(g => g.phone);
  const guestsWithAddress = guests.filter(g => g.address);

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-blue-200">
          <div className="flex items-center gap-3 mb-3">
            <Mail className="w-6 h-6 text-blue-600" />
            <h3 className="text-sm font-semibold text-[#666666]">E-Mail-Adressen</h3>
          </div>
          <p className="text-4xl font-bold text-blue-600">{guestsWithEmail.length}</p>
          <p className="text-sm text-[#666666] mt-2">von {guests.length} Gästen</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-green-200">
          <div className="flex items-center gap-3 mb-3">
            <Phone className="w-6 h-6 text-green-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Telefonnummern</h3>
          </div>
          <p className="text-4xl font-bold text-green-600">{guestsWithPhone.length}</p>
          <p className="text-sm text-[#666666] mt-2">von {guests.length} Gästen</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-orange-200">
          <div className="flex items-center gap-3 mb-3">
            <MapPin className="w-6 h-6 text-orange-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Adressen</h3>
          </div>
          <p className="text-4xl font-bold text-orange-600">{guestsWithAddress.length}</p>
          <p className="text-sm text-[#666666] mt-2">von {guests.length} Gästen</p>
        </div>
      </div>

      <div className="bg-white rounded-xl p-6 shadow-lg">
        <h4 className="font-bold text-[#0a253c] text-lg mb-4">Kontaktinformationen</h4>
        <div className="space-y-3">
          {guests.map(guest => (
            <div key={guest.id} className="p-4 bg-[#f7f2eb] rounded-xl">
              <h5 className="font-bold text-[#0a253c] mb-2">{guest.name}</h5>
              <div className="space-y-2 text-sm">
                {guest.email && (
                  <div className="flex items-center gap-2 text-[#666666]">
                    <Mail className="w-4 h-4 text-blue-600" />
                    <a href={`mailto:${guest.email}`} className="hover:text-[#d4af37]">
                      {guest.email}
                    </a>
                  </div>
                )}
                {guest.phone && (
                  <div className="flex items-center gap-2 text-[#666666]">
                    <Phone className="w-4 h-4 text-green-600" />
                    <a href={`tel:${guest.phone}`} className="hover:text-[#d4af37]">
                      {guest.phone}
                    </a>
                  </div>
                )}
                {guest.address && (
                  <div className="flex items-center gap-2 text-[#666666]">
                    <MapPin className="w-4 h-4 text-orange-600" />
                    <span>{guest.address}</span>
                  </div>
                )}
                {!guest.email && !guest.phone && !guest.address && (
                  <p className="text-[#999999] italic">Keine Kontaktinformationen</p>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
