import { Grid, Users, Plus } from 'lucide-react';

interface GuestSeatingTabProps {
  weddingId: string;
}

export default function GuestSeatingTab({ weddingId }: GuestSeatingTabProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h3 className="text-2xl font-bold text-[#0a253c]">Tischplan</h3>
        <button className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all">
          <Plus className="w-5 h-5" />
          Tisch hinzufügen
        </button>
      </div>

      <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-2xl p-8 text-center">
        <Grid className="w-20 h-20 text-[#d4af37] mx-auto mb-4" />
        <h4 className="text-2xl font-bold text-white mb-2">Tischplan-Designer</h4>
        <p className="text-white/70 mb-6">
          Visueller Tischplan-Designer kommt bald!
        </p>
        <div className="inline-block px-6 py-3 bg-[#d4af37]/20 text-[#d4af37] rounded-xl font-bold">
          Premium Feature
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h4 className="font-bold text-[#0a253c] text-lg mb-4 flex items-center gap-2">
            <Users className="w-5 h-5 text-[#d4af37]" />
            Tisch-Übersicht
          </h4>
          <p className="text-[#666666]">Noch keine Tische erstellt</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h4 className="font-bold text-[#0a253c] text-lg mb-4">Nicht zugewiesene Gäste</h4>
          <p className="text-[#666666]">Alle Gäste werden hier angezeigt</p>
        </div>
      </div>
    </div>
  );
}
