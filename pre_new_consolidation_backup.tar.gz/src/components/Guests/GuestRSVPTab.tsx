import { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Clock, TrendingUp } from 'lucide-react';
import { type Guest } from '../../lib/supabase';

interface GuestRSVPTabProps {
  guests: Guest[];
  onUpdate: () => void;
}

export default function GuestRSVPTab({ guests, onUpdate }: GuestRSVPTabProps) {
  const accepted = guests.filter(g => g.rsvp_status === 'accepted');
  const declined = guests.filter(g => g.rsvp_status === 'declined');
  const pending = guests.filter(g => g.rsvp_status === 'pending');

  const acceptanceRate = guests.length > 0
    ? Math.round((accepted.length / guests.length) * 100)
    : 0;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-[#d4af37]/30">
          <div className="flex items-center gap-3 mb-3">
            <TrendingUp className="w-6 h-6 text-[#d4af37]" />
            <h3 className="text-sm font-semibold text-[#666666]">Rücklaufquote</h3>
          </div>
          <p className="text-4xl font-bold text-[#d4af37]">{acceptanceRate}%</p>
          <div className="mt-4 w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-2 rounded-full transition-all"
              style={{ width: `${acceptanceRate}%` }}
            />
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-green-200">
          <div className="flex items-center gap-3 mb-3">
            <CheckCircle className="w-6 h-6 text-green-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Zugesagt</h3>
          </div>
          <p className="text-4xl font-bold text-green-600">{accepted.length}</p>
          <p className="text-sm text-[#666666] mt-2">
            {guests.length > 0 ? Math.round((accepted.length / guests.length) * 100) : 0}% der Einladungen
          </p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-red-200">
          <div className="flex items-center gap-3 mb-3">
            <XCircle className="w-6 h-6 text-red-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Abgesagt</h3>
          </div>
          <p className="text-4xl font-bold text-red-600">{declined.length}</p>
          <p className="text-sm text-[#666666] mt-2">
            {guests.length > 0 ? Math.round((declined.length / guests.length) * 100) : 0}% der Einladungen
          </p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-orange-200">
          <div className="flex items-center gap-3 mb-3">
            <Clock className="w-6 h-6 text-orange-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Ausstehend</h3>
          </div>
          <p className="text-4xl font-bold text-orange-600">{pending.length}</p>
          <p className="text-sm text-[#666666] mt-2">
            {guests.length > 0 ? Math.round((pending.length / guests.length) * 100) : 0}% der Einladungen
          </p>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h4 className="font-bold text-green-600 text-lg mb-4 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            Zugesagt ({accepted.length})
          </h4>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {accepted.map(guest => (
              <div key={guest.id} className="p-3 bg-green-50 rounded-lg">
                <p className="font-semibold text-[#0a253c]">{guest.name}</p>
                {guest.plus_one && (
                  <span className="text-xs text-green-600">Mit Begleitung</span>
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h4 className="font-bold text-red-600 text-lg mb-4 flex items-center gap-2">
            <XCircle className="w-5 h-5" />
            Abgesagt ({declined.length})
          </h4>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {declined.map(guest => (
              <div key={guest.id} className="p-3 bg-red-50 rounded-lg">
                <p className="font-semibold text-[#0a253c]">{guest.name}</p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg">
          <h4 className="font-bold text-orange-600 text-lg mb-4 flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Ausstehend ({pending.length})
          </h4>
          <div className="space-y-2 max-h-96 overflow-y-auto">
            {pending.map(guest => (
              <div key={guest.id} className="p-3 bg-orange-50 rounded-lg">
                <p className="font-semibold text-[#0a253c]">{guest.name}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
