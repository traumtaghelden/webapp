import { Gift, Euro, CheckCircle } from 'lucide-react';

interface GuestGiftsTabProps {
  weddingId: string;
}

export default function GuestGiftsTab({ weddingId }: GuestGiftsTabProps) {
  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 gap-4">
        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-[#d4af37]/30">
          <div className="flex items-center gap-3 mb-3">
            <Gift className="w-6 h-6 text-[#d4af37]" />
            <h3 className="text-sm font-semibold text-[#666666]">Geschenke gesamt</h3>
          </div>
          <p className="text-4xl font-bold text-[#d4af37]">0</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-green-200">
          <div className="flex items-center gap-3 mb-3">
            <CheckCircle className="w-6 h-6 text-green-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Dankeskarten versendet</h3>
          </div>
          <p className="text-4xl font-bold text-green-600">0</p>
        </div>

        <div className="bg-white rounded-xl p-6 shadow-lg border-2 border-blue-200">
          <div className="flex items-center gap-3 mb-3">
            <Euro className="w-6 h-6 text-blue-600" />
            <h3 className="text-sm font-semibold text-[#666666]">Geldgeschenke</h3>
          </div>
          <p className="text-4xl font-bold text-blue-600">0 €</p>
        </div>
      </div>

      <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-2xl p-8 text-center">
        <Gift className="w-20 h-20 text-[#d4af37] mx-auto mb-4" />
        <h4 className="text-2xl font-bold text-white mb-2">Geschenke-Tracking</h4>
        <p className="text-white/70 mb-6">
          Behalte den Überblick über alle Geschenke und Dankeskarten
        </p>
        <div className="inline-block px-6 py-3 bg-[#d4af37]/20 text-[#d4af37] rounded-xl font-bold">
          Premium Feature
        </div>
      </div>
    </div>
  );
}
