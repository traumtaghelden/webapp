import { useState, useEffect } from 'react';
import { X, Plus, Trash2, Save, Users, ChevronDown, ChevronRight } from 'lucide-react';
import { supabase, type FamilyGroup, type Guest } from '../lib/supabase';
import { useConfirmDialog } from '../hooks/useConfirmDialog';
import DietaryRestrictionsSelector from './DietaryRestrictionsSelector';

interface FamilyEditModalProps {
  familyGroupId: string;
  weddingId: string;
  groups: any[];
  onClose: () => void;
  onSuccess: () => void;
}

interface FamilyMember extends Guest {
  isNew?: boolean;
}

export default function FamilyEditModal({ familyGroupId, weddingId, groups, onClose, onSuccess }: FamilyEditModalProps) {
  const { confirmDelete } = useConfirmDialog();
  const [loading, setLoading] = useState(false);
  const [familyGroup, setFamilyGroup] = useState<FamilyGroup | null>(null);
  const [members, setMembers] = useState<FamilyMember[]>([]);
  const [expandedDietaryMembers, setExpandedDietaryMembers] = useState<Set<string>>(new Set());

  useEffect(() => {
    loadFamilyData();
  }, [familyGroupId]);

  const loadFamilyData = async () => {
    try {
      const { data: family, error: familyError } = await supabase
        .from('family_groups')
        .select('*')
        .eq('id', familyGroupId)
        .single();

      if (familyError) throw familyError;
      setFamilyGroup(family);

      const { data: guestData, error: guestsError } = await supabase
        .from('guests')
        .select('*')
        .eq('family_group_id', familyGroupId);

      if (guestsError) throw guestsError;
      setMembers(guestData || []);
    } catch (error) {
      console.error('Error loading family:', error);
    }
  };

  const handleSave = async () => {
    if (!familyGroup) return;

    setLoading(true);
    try {
      const { error: familyError } = await supabase
        .from('family_groups')
        .update({
          family_name: familyGroup.family_name,
          notes: familyGroup.notes,
        })
        .eq('id', familyGroupId);

      if (familyError) throw familyError;

      for (const member of members) {
        if (member.isNew) {
          const { error } = await supabase.from('guests').insert({
            wedding_id: weddingId,
            family_group_id: familyGroupId,
            name: member.name,
            age_group: member.age_group,
            dietary_restrictions: member.dietary_restrictions || null,
            family_role: member.family_role || member.relationship || null,
            email: member.email || null,
            phone: member.phone || null,
            rsvp_status: member.rsvp_status || 'planned',
            group_id: member.group_id || null,
            invitation_status: 'not_sent',
            gift_received: false,
            checked_in: false,
          });
          if (error) throw error;
        } else {
          const { error } = await supabase
            .from('guests')
            .update({
              name: member.name,
              age_group: member.age_group,
              dietary_restrictions: member.dietary_restrictions || null,
              family_role: member.family_role || null,
              email: member.email || null,
              phone: member.phone || null,
              rsvp_status: member.rsvp_status,
              group_id: member.group_id || null,
            })
            .eq('id', member.id);
          if (error) throw error;
        }
      }

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error saving family:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddMember = () => {
    setMembers([
      ...members,
      {
        id: crypto.randomUUID(),
        wedding_id: weddingId,
        family_group_id: familyGroupId,
        name: '',
        age_group: 'adult',
        dietary_restrictions: '',
        relationship: '',
        email: '',
        phone: '',
        rsvp_status: 'planned',
        group_id: familyGroup?.group_id || null,
        isNew: true,
      } as FamilyMember,
    ]);
  };

  const handleRemoveMember = async (memberId: string, isNew: boolean) => {
    if (!isNew) {
      const confirmed = await confirmDelete('Möchtest du dieses Familienmitglied wirklich entfernen?');
      if (!confirmed) return;

      try {
        await supabase.from('guests').delete().eq('id', memberId);
      } catch (error) {
        console.error('Error deleting member:', error);
        return;
      }
    }
    setMembers(members.filter((m) => m.id !== memberId));
  };

  const updateMember = (id: string, field: keyof FamilyMember, value: any) => {
    setMembers(members.map((m) => (m.id === id ? { ...m, [field]: value } : m)));
  };

  const toggleDietaryMember = (id: string) => {
    setExpandedDietaryMembers(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  if (!familyGroup) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
        <div className="bg-white rounded-2xl p-6">
          <p className="text-[#0a253c]">Lade Familie...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-2 sm:p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full my-4 sm:my-8">
        <div className="p-4 sm:p-6 border-b border-[#d4af37]/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Users className="w-6 h-6 text-[#d4af37]" />
              <h2 className="text-xl sm:text-2xl font-bold text-[#0a253c]">Familie bearbeiten</h2>
            </div>
            <button onClick={onClose} className="p-2 hover:bg-[#f7f2eb] rounded-full transition-colors">
              <X className="w-6 h-6 text-[#333333]" />
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-6 max-h-[70vh] overflow-y-auto">
          <div className="space-y-4 sm:space-y-6">
            <div className="bg-[#f7f2eb] p-6 rounded-xl">
              <h3 className="text-base sm:text-lg font-bold text-[#0a253c] mb-3 sm:mb-4">Familien-Informationen</h3>
              <div className="grid sm:grid-cols-2 gap-3 sm:gap-4">
                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-[#0a253c] mb-2">Familienname *</label>
                  <input
                    type="text"
                    value={familyGroup.name}
                    onChange={(e) => setFamilyGroup({ ...familyGroup, name: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                    placeholder="z.B. Familie Schmidt"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#0a253c] mb-2">Gruppe</label>
                  <select
                    value={familyGroup.group_id || ''}
                    onChange={(e) => setFamilyGroup({ ...familyGroup, group_id: e.target.value || null })}
                    className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                  >
                    <option value="">Keine Gruppe</option>
                    {groups.map((group) => (
                      <option key={group.id} value={group.id}>
                        {group.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#0a253c] mb-2">Tischnummer</label>
                  <input
                    type="number"
                    value={familyGroup.table_number || ''}
                    onChange={(e) => setFamilyGroup({ ...familyGroup, table_number: e.target.value ? parseInt(e.target.value) : null })}
                    className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                    placeholder="z.B. 5"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-[#0a253c] mb-2">Notizen</label>
                  <textarea
                    value={familyGroup.notes || ''}
                    onChange={(e) => setFamilyGroup({ ...familyGroup, notes: e.target.value })}
                    rows={2}
                    className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none resize-none"
                    placeholder="Optionale Notizen zur Familie"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-[#0a253c] mb-2">Straße & Hausnummer</label>
                  <input
                    type="text"
                    value={familyGroup.address || ''}
                    onChange={(e) => setFamilyGroup({ ...familyGroup, address: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                    placeholder="Musterstraße 123"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#0a253c] mb-2">PLZ</label>
                  <input
                    type="text"
                    value={familyGroup.postal_code || ''}
                    onChange={(e) => setFamilyGroup({ ...familyGroup, postal_code: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                    placeholder="12345"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-[#0a253c] mb-2">Stadt</label>
                  <input
                    type="text"
                    value={familyGroup.city || ''}
                    onChange={(e) => setFamilyGroup({ ...familyGroup, city: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                    placeholder="Musterstadt"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-[#0a253c] mb-2">Land</label>
                  <input
                    type="text"
                    value={familyGroup.country || ''}
                    onChange={(e) => setFamilyGroup({ ...familyGroup, country: e.target.value })}
                    className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                    placeholder="Deutschland"
                  />
                </div>
              </div>
            </div>

            <div>
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-base sm:text-lg font-bold text-[#0a253c]">Familienmitglieder ({members.length})</h3>
                <button
                  onClick={handleAddMember}
                  className="flex items-center justify-center gap-2 px-3 sm:px-4 py-2 bg-[#d4af37] text-white rounded-xl text-sm sm:text-base font-bold hover:bg-[#c49d2f] transition-colors"
                >
                  <Plus className="w-4 h-4" />
                  Mitglied hinzufügen
                </button>
              </div>

              <div className="space-y-4">
                {members.map((member, index) => (
                  <div key={member.id} className="bg-white border-2 border-[#d4af37]/20 rounded-xl p-4">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-bold text-[#0a253c]">
                        {member.isNew ? 'Neues Mitglied' : `Mitglied ${index + 1}`}
                      </h4>
                      <button
                        onClick={() => handleRemoveMember(member.id, member.isNew || false)}
                        className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-4 h-4 text-red-600" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
                      <div>
                        <label className="block text-sm font-medium text-[#0a253c] mb-2">Name *</label>
                        <input
                          type="text"
                          value={member.name}
                          onChange={(e) => updateMember(member.id, 'name', e.target.value)}
                          className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#0a253c] mb-2">Altersgruppe</label>
                        <select
                          value={member.age_group}
                          onChange={(e) => updateMember(member.id, 'age_group', e.target.value)}
                          className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                        >
                          <option value="adult">Erwachsene/r</option>
                          <option value="child">Kind</option>
                          <option value="infant">Kleinkind</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#0a253c] mb-2">Beziehung</label>
                        <input
                          type="text"
                          value={member.relationship || ''}
                          onChange={(e) => updateMember(member.id, 'relationship', e.target.value)}
                          placeholder="z.B. Mutter, Vater, Kind"
                          className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#0a253c] mb-2">E-Mail</label>
                        <input
                          type="email"
                          value={member.email || ''}
                          onChange={(e) => updateMember(member.id, 'email', e.target.value)}
                          className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#0a253c] mb-2">Telefon</label>
                        <input
                          type="tel"
                          value={member.phone || ''}
                          onChange={(e) => updateMember(member.id, 'phone', e.target.value)}
                          className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-medium text-[#0a253c] mb-2">Status</label>
                        <select
                          value={member.rsvp_status}
                          onChange={(e) => updateMember(member.id, 'rsvp_status', e.target.value)}
                          className="w-full px-4 py-2 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
                        >
                          <option value="planned">Geplant</option>
                          <option value="invited">Einladung versendet</option>
                          <option value="accepted">Zugesagt</option>
                          <option value="declined">Abgesagt</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2 lg:col-span-3">
                        <button
                          type="button"
                          onClick={() => toggleDietaryMember(member.id)}
                          className="w-full flex items-center justify-between p-3 bg-[#f7f2eb] hover:bg-[#f0e8d5] rounded-xl transition-colors border-2 border-[#d4af37]/20"
                        >
                          <span className="text-sm font-medium text-[#0a253c]">Diäteinschränkungen</span>
                          {expandedDietaryMembers.has(member.id) ? (
                            <ChevronDown className="w-4 h-4 text-[#d4af37]" />
                          ) : (
                            <ChevronRight className="w-4 h-4 text-[#d4af37]" />
                          )}
                        </button>
                        {expandedDietaryMembers.has(member.id) && (
                          <div className="mt-3 p-4 bg-white rounded-xl border-2 border-[#d4af37]/20">
                            <DietaryRestrictionsSelector
                              value={member.dietary_restrictions || ''}
                              onChange={(value) => updateMember(member.id, 'dietary_restrictions', value)}
                            />
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                ))}

                {members.length === 0 && (
                  <div className="text-center py-8 text-[#666666]">
                    <p>Keine Familienmitglieder vorhanden. Füge mindestens ein Mitglied hinzu.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        <div className="p-4 sm:p-6 border-t border-[#d4af37]/20 flex flex-col sm:flex-row gap-3">
          <button
            onClick={onClose}
            className="flex-1 px-4 sm:px-6 py-2.5 sm:py-3 border-2 border-[#333333] text-[#333333] rounded-xl text-sm sm:text-base font-bold hover:bg-[#f7f2eb] transition-colors"
          >
            Abbrechen
          </button>
          <button
            onClick={handleSave}
            disabled={loading || members.length === 0 || !familyGroup.family_name}
            className="flex-1 px-4 sm:px-6 py-2.5 sm:py-3 bg-[#d4af37] text-white rounded-xl text-sm sm:text-base font-bold hover:bg-[#c49d2f] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            <Save className="w-5 h-5" />
            {loading ? 'Speichere...' : 'Speichern'}
          </button>
        </div>
      </div>
    </div>
  );
}
