import { useState, useEffect } from 'react';
import { Users, TrendingUp, TrendingDown, DollarSign, Info } from 'lucide-react';
import { supabase, type BudgetItem, type Guest } from '../lib/supabase';
import { GUEST, COMMON } from '../constants/terminology';

interface PerGuestCostWidgetProps {
  weddingId: string;
  plannedGuestCount: number;
  onCalculatorClick?: () => void;
}

export default function PerGuestCostWidget({
  weddingId,
  plannedGuestCount,
  onCalculatorClick
}: PerGuestCostWidgetProps) {
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [confirmedGuests, setConfirmedGuests] = useState(0);
  const [loading, setLoading] = useState(true);
  const [showOnlyPerPerson, setShowOnlyPerPerson] = useState(true);

  useEffect(() => {
    loadData();
  }, [weddingId]);

  const loadData = async () => {
    try {
      const [budgetData, guestsData] = await Promise.all([
        supabase
          .from('budget_items')
          .select('*')
          .eq('wedding_id', weddingId),
        supabase
          .from('guests')
          .select('id')
          .eq('wedding_id', weddingId)
          .eq('rsvp_status', 'accepted')
      ]);

      if (budgetData.data) setBudgetItems(budgetData.data);
      if (guestsData.data) setConfirmedGuests(guestsData.data.length);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getPerPersonItems = () => {
    return budgetItems.filter(item => item.is_per_person);
  };

  const calculatePerPersonCosts = () => {
    const perPersonItems = getPerPersonItems();
    const perPersonTotal = perPersonItems.reduce(
      (sum, item) => sum + (Number(item.cost_per_person) || 0) * plannedGuestCount,
      0
    );
    return perPersonTotal;
  };

  const calculateTotalCosts = () => {
    return budgetItems.reduce(
      (sum, item) => sum + (Number(item.estimated_cost) || 0),
      0
    );
  };

  const getFixedCosts = () => {
    return budgetItems
      .filter(item => !item.is_per_person)
      .reduce((sum, item) => sum + (Number(item.estimated_cost) || 0), 0);
  };

  const calculateCostPerGuest = () => {
    if (showOnlyPerPerson) {
      const perPersonItems = getPerPersonItems();
      return perPersonItems.reduce(
        (sum, item) => sum + (Number(item.cost_per_person) || 0),
        0
      );
    } else {
      const totalCosts = calculateTotalCosts();
      return plannedGuestCount > 0 ? totalCosts / plannedGuestCount : 0;
    }
  };

  const calculateActualCostPerGuest = () => {
    const guestCount = confirmedGuests > 0 ? confirmedGuests : plannedGuestCount;
    if (showOnlyPerPerson) {
      const perPersonItems = getPerPersonItems();
      return perPersonItems.reduce(
        (sum, item) => sum + (Number(item.cost_per_person) || 0),
        0
      );
    } else {
      const totalCosts = calculateTotalCosts();
      return guestCount > 0 ? totalCosts / guestCount : 0;
    }
  };

  const plannedCostPerGuest = calculateCostPerGuest();
  const actualCostPerGuest = calculateActualCostPerGuest();
  const difference = actualCostPerGuest - plannedCostPerGuest;
  const percentChange = plannedCostPerGuest > 0 ? (difference / plannedCostPerGuest) * 100 : 0;

  const perPersonItems = getPerPersonItems();
  const perPersonTotal = calculatePerPersonCosts();
  const fixedCosts = getFixedCosts();
  const totalCosts = calculateTotalCosts();

  if (loading) {
    return (
      <div className="bg-white rounded-2xl shadow-lg border border-[#e5d4c1] p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-1/2"></div>
          <div className="h-32 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-2xl shadow-lg border border-[#e5d4c1] p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-purple-100 rounded-lg">
            <Users className="w-6 h-6 text-purple-600" />
          </div>
          <div>
            <h3 className="text-xl font-semibold text-[#0a253c]">Kosten pro {GUEST.SINGULAR}</h3>
            <p className="text-sm text-gray-600">{GUEST.MODULE_NAME}basierte Kalkulation</p>
          </div>
        </div>
        <button
          onClick={() => setShowOnlyPerPerson(!showOnlyPerPerson)}
          className="px-4 py-2 bg-gray-100 hover:bg-gray-200 rounded-lg text-sm font-medium transition-colors"
        >
          {showOnlyPerPerson ? 'Nur Pro-Kopf' : 'Gesamtkosten'}
        </button>
      </div>

      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl border border-blue-200">
          <p className="text-sm text-gray-600 mb-1">{showOnlyPerPerson ? 'Pro-Kopf-Kosten (geplant)' : 'Durchschnitt pro Gast (geplant)'}</p>
          <p className="text-3xl font-bold text-[#0a253c] mb-1">
            {plannedCostPerGuest.toFixed(2)}€
          </p>
          <p className="text-xs text-gray-500">{showOnlyPerPerson ? 'Pro Gast' : `${plannedGuestCount} Gäste geplant`}</p>
        </div>

        <div className="p-4 bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl border border-green-200">
          <p className="text-sm text-gray-600 mb-1">{showOnlyPerPerson ? 'Pro-Kopf-Kosten (aktuell)' : 'Durchschnitt pro Gast (aktuell)'}</p>
          <p className="text-3xl font-bold text-[#0a253c] mb-1">
            {actualCostPerGuest.toFixed(2)}€
          </p>
          <p className="text-xs text-gray-500">{showOnlyPerPerson ? 'Pro Gast' : `${confirmedGuests > 0 ? confirmedGuests : plannedGuestCount} Gäste`}</p>
        </div>
      </div>

      {Math.abs(difference) > 0.01 && (
        <div className={`p-4 rounded-xl mb-4 flex items-center gap-3 ${
          difference < 0 ? 'bg-green-50 border border-green-200' : 'bg-red-50 border border-red-200'
        }`}>
          {difference < 0 ? (
            <TrendingDown className="w-6 h-6 text-green-600" />
          ) : (
            <TrendingUp className="w-6 h-6 text-red-600" />
          )}
          <div>
            <p className={`font-semibold ${difference < 0 ? 'text-green-700' : 'text-red-700'}`}>
              {difference < 0 ? 'Einsparung' : 'Mehrkosten'}: {Math.abs(difference).toFixed(2)}€ {showOnlyPerPerson ? 'pro Gast' : 'durchschnittlich'}
            </p>
            <p className="text-sm text-gray-600">
              {Math.abs(percentChange).toFixed(1)}% {difference < 0 ? 'günstiger' : 'teurer'} als geplant
            </p>
          </div>
        </div>
      )}

      <div className="space-y-3 mb-4">
        <div className="flex items-center justify-between p-3 bg-purple-50 rounded-lg border border-purple-200">
          <div className="flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-purple-600" />
            <span className="text-sm font-medium text-gray-700">
              {showOnlyPerPerson ? 'Pro-Kopf-Kosten' : 'Gesamtkosten'}
            </span>
          </div>
          <span className="font-bold text-[#0a253c]">
            {showOnlyPerPerson ? perPersonTotal.toFixed(2) : totalCosts.toFixed(2)}€
          </span>
        </div>

        {showOnlyPerPerson ? (
          <>
            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
              <span className="text-sm text-gray-600">Anzahl Pro-Kopf-Positionen</span>
              <span className="font-semibold text-gray-700">{perPersonItems.length}</span>
            </div>
            <div className="flex items-center justify-between p-3 bg-blue-50 rounded-lg border border-blue-200">
              <span className="text-sm text-gray-600">Fixkosten (nicht beeinflussbar)</span>
              <span className="font-semibold text-gray-700">{fixedCosts.toFixed(2)}€</span>
            </div>
          </>
        ) : (
          <div className="space-y-2 p-3 bg-gray-50 rounded-lg">
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Fixkosten:</span>
              <span className="font-medium">{fixedCosts.toFixed(2)}€</span>
            </div>
            <div className="flex justify-between text-sm">
              <span className="text-gray-600">Variable Kosten:</span>
              <span className="font-medium">{perPersonTotal.toFixed(2)}€</span>
            </div>
          </div>
        )}
      </div>

      <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl flex items-start gap-3 mb-4">
        <Info className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-gray-700">
          {showOnlyPerPerson ? (
            <p>
              Diese Ansicht zeigt <strong>nur die variablen Pro-Kopf-Kosten</strong> (z.B. Catering, Getränke, Gastgeschenke).
              Dies ist der Betrag, der sich direkt mit der Gästezahl ändert. Fixkosten wie Location oder Dekoration ({fixedCosts.toFixed(2)}€) sind hier nicht enthalten.
            </p>
          ) : (
            <p>
              Diese Ansicht zeigt <strong>alle Budgetkosten gleichmäßig verteilt</strong> auf die Gästezahl
              (Fixkosten: {fixedCosts.toFixed(2)}€ + Variable Kosten: {perPersonTotal.toFixed(2)}€).
              Wechsle zu "Nur Pro-Kopf" um nur die variablen Kosten pro Gast zu sehen.
            </p>
          )}
        </div>
      </div>

      {onCalculatorClick && (
        <button
          onClick={onCalculatorClick}
          className="w-full py-3 bg-gradient-to-r from-purple-600 to-indigo-600 text-white rounded-xl hover:shadow-lg transition-all font-medium flex items-center justify-center gap-2"
        >
          <Users className="w-5 h-5" />
          Gästeanzahl-Rechner öffnen
        </button>
      )}
    </div>
  );
}
