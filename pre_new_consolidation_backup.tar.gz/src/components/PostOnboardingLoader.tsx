import { useState, useEffect } from 'react';
import { Heart, Sparkles, Star, Users } from 'lucide-react';
import { supabase, type WeddingTeamRole } from '../lib/supabase';

interface PostOnboardingLoaderProps {
  weddingId: string;
  partner1Name: string;
  partner2Name: string;
  partner1HeroType: string;
  partner2HeroType: string;
  weddingDate: string;
  ceremonyType: string;
  onComplete: () => void;
}

const loadingMessages = [
  "Eure Hochzeit wird gespeichert...",
  "Quest-Log wird erstellt...",
  "Die magische Checkliste wird erstellt...",
  "Euer Team wird zusammengestellt...",
  "Trauzeugen werden informiert...",
  "Meilensteine werden markiert...",
  "Budget-Planer wird aktiviert...",
  "Helfer werden aktiviert...",
  "Euer persönlicher Assistent wird vorbereitet...",
  "Dashboard wird vorbereitet...",
  "Save-Point erstellt - Euer Fortschritt ist gesichert",
  "Gemeinsam zum perfekten Tag...",
];

export default function PostOnboardingLoader({
  weddingId,
  partner1Name,
  partner2Name,
  partner1HeroType,
  partner2HeroType,
  weddingDate,
  ceremonyType,
  onComplete,
}: PostOnboardingLoaderProps) {
  const [progress, setProgress] = useState(0);
  const [currentMessageIndex, setCurrentMessageIndex] = useState(0);
  const [showRing, setShowRing] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [showCelebration, setShowCelebration] = useState(false);
  const [showTeamWitnesses, setShowTeamWitnesses] = useState(false);
  const [showTeamParents, setShowTeamParents] = useState(false);
  const [showTeamHelpers, setShowTeamHelpers] = useState(false);
  const [teamMembers, setTeamMembers] = useState<WeddingTeamRole[]>([]);
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number }>>([]);

  const ceremonyTypeText: Record<string, string> = {
    traditional: 'Traditionelle Hochzeit',
    civil: 'Standesamtliche Hochzeit',
    religious: 'Kirchliche Hochzeit',
    outdoor: 'Hochzeit im Freien',
    destination: 'Destination Wedding',
  };

  useEffect(() => {
    const loadTeamMembers = async () => {
      try {
        const { data } = await supabase
          .from('wedding_team_roles')
          .select('*')
          .eq('wedding_id', weddingId);
        if (data) {
          setTeamMembers(data);
        }
      } catch (error) {
        console.error('Error loading team members:', error);
      }
    };
    loadTeamMembers();
  }, [weddingId]);

  useEffect(() => {
    const progressInterval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(progressInterval);
          return 100;
        }
        return prev + 1;
      });
    }, 60);

    return () => clearInterval(progressInterval);
  }, []);

  useEffect(() => {
    if (progress >= 15 && !showRing) {
      setShowRing(true);
    }
    if (progress >= 30 && !showTeamWitnesses) {
      setShowTeamWitnesses(true);
      createParticles();
    }
    if (progress >= 45 && !showCalendar) {
      setShowCalendar(true);
      createParticles();
    }
    if (progress >= 60 && !showTeamParents) {
      setShowTeamParents(true);
      createParticles();
    }
    if (progress >= 75 && !showTeamHelpers) {
      setShowTeamHelpers(true);
      createParticles();
    }
    if (progress >= 100 && !showCelebration) {
      setShowCelebration(true);
      createMassiveParticles();
      setTimeout(() => {
        onComplete();
      }, 2000);
    }
  }, [progress, showRing, showTeamWitnesses, showCalendar, showTeamParents, showTeamHelpers, showCelebration, onComplete]);

  useEffect(() => {
    const messageInterval = setInterval(() => {
      setCurrentMessageIndex((prev) => (prev + 1) % loadingMessages.length);
    }, 3000);

    return () => clearInterval(messageInterval);
  }, []);

  const createParticles = () => {
    const newParticles = Array.from({ length: 15 }, (_, i) => ({
      id: Date.now() + i,
      x: Math.random() * 150 - 75,
      y: Math.random() * 150 - 75,
    }));
    setParticles(newParticles);
    setTimeout(() => setParticles([]), 1500);
  };

  const createMassiveParticles = () => {
    const newParticles = Array.from({ length: 40 }, (_, i) => ({
      id: Date.now() + i,
      x: Math.random() * 300 - 150,
      y: Math.random() * 300 - 150,
    }));
    setParticles(newParticles);
    setTimeout(() => setParticles([]), 2500);
  };

  const weddingDateObj = new Date(weddingDate);
  const formattedDate = weddingDateObj.toLocaleDateString('de-DE', {
    day: '2-digit',
    month: 'long',
    year: 'numeric',
  });

  const getDaysUntilWedding = () => {
    const today = new Date();
    const wedding = new Date(weddingDate);
    const diffTime = wedding.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays > 0 ? diffDays : 0;
  };

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center overflow-hidden">
      <div
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{
          backgroundImage:
            'url(https://res.cloudinary.com/dvaha0i6v/image/upload/v1761905970/Background_onboarding_1_jcn71r.png)',
        }}
      ></div>
      <div className="absolute inset-0 bg-gradient-to-b from-black/40 via-black/30 to-black/50"></div>

      {particles.map((particle) => (
        <div
          key={particle.id}
          className="particle"
          style={{
            left: '50%',
            top: '50%',
            // @ts-ignore
            '--tx': `${particle.x}px`,
            '--ty': `${particle.y}px`,
          }}
        />
      ))}

      {showCelebration && (
        <div className="fixed inset-0 pointer-events-none z-[9999] flex items-center justify-center">
          <div className="celebrate-screen-flash"></div>
        </div>
      )}

      <div className="relative z-10 text-center px-4 sm:px-6 max-w-4xl w-full flex flex-col justify-center min-h-screen py-safe">
        <div className="mb-5 sm:mb-6 cinematic-fade-up">
          <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold text-white mb-2 sm:mb-3 shine-effect px-2 leading-tight">
            {partner1Name} & {partner2Name}
          </h1>
          <p className="text-lg sm:text-xl text-[#f7f2eb] font-light">
            Die Reise beginnt
          </p>
          <p className="text-sm sm:text-base text-[#d4af37] mt-1.5 sm:mt-2 font-semibold">
            {ceremonyTypeText[ceremonyType] || ceremonyType}
          </p>
        </div>

        <div className="relative mb-6 sm:mb-8 flex items-center justify-center gap-3 sm:gap-6 md:gap-12 min-h-[160px] sm:min-h-[200px]">
          <div className="cinematic-zoom-in" style={{ animationDelay: '0.2s' }}>
            <div className="hero-card-large selected p-2 sm:p-3 md:p-4 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#f7f2eb]/20 to-transparent backdrop-blur-sm">
              <img
                src={
                  partner1HeroType === 'hero1'
                    ? '/Design ohne Titel (10).png'
                    : '/Design ohne Titel (11).png'
                }
                alt={partner1Name}
                className="w-20 h-20 sm:w-28 sm:h-28 md:w-36 md:h-36 object-contain animate-float"
              />
            </div>
            <p className="text-white font-bold text-xs sm:text-sm md:text-base mt-1.5 sm:mt-2">{partner1Name}</p>
          </div>

          {showRing && (
            <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 cinematic-zoom-in">
              <div className="relative">
                <Heart className="w-14 h-14 sm:w-18 sm:h-18 md:w-20 md:h-20 text-[#d4af37] animate-float fill-current ring-glow" />
                <Sparkles className="w-5 h-5 sm:w-6 sm:h-6 text-[#f4d03f] absolute -top-1 -right-1 animate-sparkle" />
              </div>
            </div>
          )}

          <div className="cinematic-zoom-in" style={{ animationDelay: '0.4s' }}>
            <div className="hero-card-large selected p-2 sm:p-3 md:p-4 rounded-xl sm:rounded-2xl bg-gradient-to-b from-[#f7f2eb]/20 to-transparent backdrop-blur-sm">
              <img
                src={
                  partner2HeroType === 'hero1'
                    ? '/Design ohne Titel (10).png'
                    : '/Design ohne Titel (11).png'
                }
                alt={partner2Name}
                className="w-20 h-20 sm:w-28 sm:h-28 md:w-36 md:h-36 object-contain animate-float-delayed"
              />
            </div>
            <p className="text-white font-bold text-xs sm:text-sm md:text-base mt-1.5 sm:mt-2">{partner2Name}</p>
          </div>
        </div>

        {showCalendar && (
          <div className="mb-5 sm:mb-6 cinematic-fade-up">
            <div className="inline-block bg-[#d4af37]/20 backdrop-blur-sm rounded-xl sm:rounded-2xl px-5 sm:px-6 py-3 sm:py-4 border-2 border-[#d4af37]/50">
              <p className="text-[#f7f2eb] text-xs sm:text-sm font-semibold mb-1">Der große Tag</p>
              <p className="text-white text-lg sm:text-xl md:text-2xl font-bold">{formattedDate}</p>
              <div className="mt-2 sm:mt-3 pt-2 sm:pt-3 border-t border-[#d4af37]/30">
                <p className="text-[#f7f2eb] text-xs font-semibold mb-0.5 sm:mb-1">Noch</p>
                <p className="text-[#d4af37] text-base sm:text-lg md:text-xl font-bold">{getDaysUntilWedding()} Tage</p>
              </div>
            </div>
          </div>
        )}

        {(showTeamWitnesses || showTeamParents || showTeamHelpers) && teamMembers.length > 0 && (
          <div className="mb-8 cinematic-fade-up">
            <div className="flex items-center justify-center gap-2 mb-4">
              <Users className="w-6 h-6 text-[#d4af37]" />
              <h3 className="text-xl md:text-2xl font-bold text-white">Euer Team</h3>
            </div>
            <div className="flex flex-wrap items-center justify-center gap-4 md:gap-6">
              {showTeamWitnesses && teamMembers.filter(m => m.role === 'trauzeuge').map((member, idx) => (
                <div key={member.id} className="cinematic-zoom-in" style={{ animationDelay: `${idx * 0.2}s` }}>
                  <div className="bg-gradient-to-b from-[#f7f2eb]/20 to-transparent backdrop-blur-sm p-4 rounded-2xl border-2 border-[#d4af37]/30">
                    {member.avatar_url && (
                      <img
                        src={member.avatar_url}
                        alt={member.name}
                        className="w-20 h-20 md:w-24 md:h-24 object-contain animate-float mx-auto"
                      />
                    )}
                    <p className="text-white font-semibold text-sm mt-2 text-center">{member.name}</p>
                    <p className="text-[#d4af37] text-xs text-center">Trauzeuge/in</p>
                  </div>
                </div>
              ))}
              {showTeamParents && teamMembers.filter(m => m.role === 'eltern').map((member, idx) => (
                <div key={member.id} className="cinematic-zoom-in" style={{ animationDelay: `${idx * 0.2}s` }}>
                  <div className="bg-gradient-to-b from-[#f7f2eb]/20 to-transparent backdrop-blur-sm p-4 rounded-2xl border-2 border-[#d4af37]/30">
                    {member.avatar_url && (
                      <img
                        src={member.avatar_url}
                        alt={member.name}
                        className="w-20 h-20 md:w-24 md:h-24 object-contain animate-float mx-auto"
                      />
                    )}
                    <p className="text-white font-semibold text-sm mt-2 text-center">{member.name}</p>
                    <p className="text-[#d4af37] text-xs text-center">Eltern</p>
                  </div>
                </div>
              ))}
              {showTeamHelpers && teamMembers.filter(m => m.role === 'helfer').map((member, idx) => (
                <div key={member.id} className="cinematic-zoom-in" style={{ animationDelay: `${idx * 0.2}s` }}>
                  <div className="bg-gradient-to-b from-[#f7f2eb]/20 to-transparent backdrop-blur-sm p-4 rounded-2xl border-2 border-[#d4af37]/30">
                    {member.avatar_url && (
                      <img
                        src={member.avatar_url}
                        alt={member.name}
                        className="w-20 h-20 md:w-24 md:h-24 object-contain animate-float mx-auto"
                      />
                    )}
                    <p className="text-white font-semibold text-sm mt-2 text-center">{member.name}</p>
                    <p className="text-[#d4af37] text-xs text-center">Helfer/in</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="max-w-2xl mx-auto mb-6">
          <div className="bg-white/10 backdrop-blur-sm rounded-full h-6 overflow-hidden border-2 border-[#d4af37]/30">
            <div
              className={`bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-full rounded-full transition-all duration-300 ease-out relative overflow-hidden ${
                progress >= 50 ? 'progress-milestone' : ''
              }`}
              style={{ width: `${progress}%` }}
            >
              <div className="absolute inset-0 shine-effect"></div>
            </div>
          </div>
          <div className="flex items-center justify-between mt-3">
            <span className="text-[#f7f2eb] text-sm font-semibold">
              {loadingMessages[currentMessageIndex]}
            </span>
            <span className="text-[#d4af37] text-lg font-bold">{progress}%</span>
          </div>
        </div>

        {showCelebration && (
          <div className="cinematic-zoom-in">
            <div className="flex items-center justify-center gap-3 mb-6">
              <Star className="w-8 h-8 text-[#d4af37] animate-spin-slow fill-current" />
              <h2 className="text-3xl md:text-4xl font-bold text-white shine-effect">
                BEREIT FÜR EURE REISE!
              </h2>
              <Star className="w-8 h-8 text-[#d4af37] animate-spin-slow fill-current" />
            </div>
            <p className="text-xl text-[#f7f2eb]">Euer Dashboard wird geladen...</p>
          </div>
        )}

        {progress >= 75 && !showCelebration && (
          <div className="flex justify-center gap-4 cinematic-fade-up">
            <div className="w-3 h-3 rounded-full bg-[#d4af37] animate-pulse"></div>
            <div className="w-3 h-3 rounded-full bg-[#d4af37] animate-pulse" style={{ animationDelay: '0.2s' }}></div>
            <div className="w-3 h-3 rounded-full bg-[#d4af37] animate-pulse" style={{ animationDelay: '0.4s' }}></div>
          </div>
        )}
      </div>
    </div>
  );
}
