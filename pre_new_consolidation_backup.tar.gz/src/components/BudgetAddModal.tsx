import { useState, useEffect, useMemo } from 'react';
import { Save, DollarSign, Users, Calendar, FileText, CreditCard, Package } from 'lucide-react';
import { supabase, type Vendor } from '../lib/supabase';
import StandardModal, { ModalFooter, ModalButton } from './StandardModal';
import BudgetItemProKopfForm from './BudgetItemProKopfForm';
import PaymentPlanModal from './PaymentPlanModal';

interface BudgetAddModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmit: (item: NewBudgetItem) => void;
  weddingId: string;
  categories: string[];
  vendors: Vendor[];
}

interface NewBudgetItem {
  category: string;
  item_name: string;
  estimated_cost: string;
  actual_cost: string;
  paid: boolean;
  payment_method: string;
  priority: 'low' | 'medium' | 'high';
  notes: string;
  currency: string;
  tax_rate: number;
  vendor_id: string;
  timeline_event_id: string;
  is_per_person: boolean;
  cost_per_person: string;
  use_confirmed_guests_only: boolean;
  guest_count_override: string;
  deposit_amount: string;
  deposit_paid: boolean;
  final_payment_due: string;
  directly_paid: boolean;
  payment_plan?: Array<{
    id: string;
    amount: string;
    dueDate: string;
    description: string;
  }>;
}

interface TimelineEvent {
  id: string;
  title: string;
  time: string;
  event_type: string;
}

type TabType = 'basics' | 'costs' | 'payment' | 'details';

export default function BudgetAddModal({ isOpen, onClose, onSubmit, weddingId, categories, vendors }: BudgetAddModalProps) {
  const [activeTab, setActiveTab] = useState<TabType>('basics');
  const [showPaymentPlan, setShowPaymentPlan] = useState(false);
  const [guestCount, setGuestCount] = useState(0);
  const [confirmedGuestCount, setConfirmedGuestCount] = useState(0);
  const [paymentType, setPaymentType] = useState<'single' | 'plan'>('single');
  const [singlePaymentDueDate, setSinglePaymentDueDate] = useState('');
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([]);
  const [loadingTimeline, setLoadingTimeline] = useState(false);
  const [loadingGuests, setLoadingGuests] = useState(false);

  const [newItem, setNewItem] = useState<NewBudgetItem>({
    category: categories[0] || 'venue',
    item_name: '',
    estimated_cost: '',
    actual_cost: '',
    paid: false,
    payment_method: 'bank_transfer',
    priority: 'medium',
    notes: '',
    currency: 'EUR',
    tax_rate: 0,
    vendor_id: '',
    timeline_event_id: '',
    is_per_person: false,
    cost_per_person: '',
    use_confirmed_guests_only: false,
    guest_count_override: '',
    deposit_amount: '0',
    deposit_paid: false,
    final_payment_due: '',
    directly_paid: false,
  });

  useEffect(() => {
    if (isOpen) {
      resetForm();
      setActiveTab('basics');
    }
  }, [isOpen]);

  const loadGuestCounts = async () => {
    if (loadingGuests) return;
    setLoadingGuests(true);
    try {
      const [weddingData, guestsData] = await Promise.all([
        supabase.from('weddings').select('guest_count').eq('id', weddingId).maybeSingle(),
        supabase.from('guests').select('id, rsvp_status').eq('wedding_id', weddingId)
      ]);

      if (weddingData.data) {
        setGuestCount(weddingData.data.guest_count || 0);
      }
      if (guestsData.data) {
        const confirmed = guestsData.data.filter(g => g.rsvp_status === 'accepted').length;
        setConfirmedGuestCount(confirmed);
      }
    } catch (error) {
      console.error('Error loading guest counts:', error);
    } finally {
      setLoadingGuests(false);
    }
  };

  const loadTimelineEvents = async () => {
    if (loadingTimeline || timelineEvents.length > 0) return;
    setLoadingTimeline(true);
    try {
      const { data, error } = await supabase
        .from('wedding_timeline')
        .select('id, title, time, event_type')
        .eq('wedding_id', weddingId)
        .order('time', { ascending: true });

      if (error) throw error;
      setTimelineEvents(data || []);
    } catch (error) {
      console.error('Error loading timeline events:', error);
    } finally {
      setLoadingTimeline(false);
    }
  };

  const resetForm = () => {
    setNewItem({
      category: categories[0] || 'venue',
      item_name: '',
      estimated_cost: '',
      actual_cost: '',
      paid: false,
      payment_method: 'bank_transfer',
      priority: 'medium',
      notes: '',
      currency: 'EUR',
      tax_rate: 0,
      vendor_id: '',
      timeline_event_id: '',
      is_per_person: false,
      cost_per_person: '',
      use_confirmed_guests_only: false,
      guest_count_override: '',
      deposit_amount: '0',
      deposit_paid: false,
      final_payment_due: '',
      directly_paid: false,
    });
    setTimelineEvents([]);
    setPaymentType('single');
    setSinglePaymentDueDate('');
  };

  const handleProKopfChange = (data: {
    is_per_person: boolean;
    cost_per_person: number | null;
    use_confirmed_guests_only: boolean;
    guest_count_override: number | null;
  }) => {
    setNewItem({
      ...newItem,
      is_per_person: data.is_per_person,
      cost_per_person: data.cost_per_person?.toString() || '',
      use_confirmed_guests_only: data.use_confirmed_guests_only,
      guest_count_override: data.guest_count_override?.toString() || '',
    });

    if (data.is_per_person && !loadingGuests && (guestCount === 0 && confirmedGuestCount === 0)) {
      loadGuestCounts();
    }
  };

  const handlePaymentPlanConfirm = (installments: Array<{id: string; amount: string; dueDate: string; description: string}>) => {
    setNewItem({ ...newItem, payment_plan: installments });
  };

  const calculateProKopfPreview = () => {
    if (!newItem.is_per_person || !newItem.cost_per_person) return 0;
    const costPerPerson = parseFloat(newItem.cost_per_person) || 0;
    let activeGuestCount = guestCount;
    if (newItem.use_confirmed_guests_only) {
      activeGuestCount = confirmedGuestCount;
    }
    if (newItem.guest_count_override) {
      activeGuestCount = parseFloat(newItem.guest_count_override) || 0;
    }
    return costPerPerson * activeGuestCount;
  };

  const getTotalAmount = useMemo(() => {
    if (newItem.is_per_person) {
      return calculateProKopfPreview();
    }
    return parseFloat(newItem.actual_cost || newItem.estimated_cost) || 0;
  }, [newItem.is_per_person, newItem.cost_per_person, newItem.actual_cost, newItem.estimated_cost, newItem.use_confirmed_guests_only, newItem.guest_count_override, guestCount, confirmedGuestCount]);

  const handleSubmit = () => {
    if (!newItem.item_name) return;
    const itemToSubmit = {
      ...newItem,
      final_payment_due: paymentType === 'single' && singlePaymentDueDate ? singlePaymentDueDate : newItem.final_payment_due
    };
    onSubmit(itemToSubmit);
    onClose();
  };

  const getCategoryTranslation = (category: string): string => {
    const translations: Record<string, string> = {
      venue: 'Location',
      catering: 'Catering',
      decoration: 'Dekoration',
      music: 'Musik',
      photography: 'Fotografie',
      flowers: 'Blumen',
      dress: 'Kleid',
      rings: 'Ringe',
      invitations: 'Einladungen',
      other: 'Sonstiges',
    };
    return translations[category.toLowerCase()] || category;
  };

  const isFormValid = newItem.item_name.trim().length > 0;

  const tabs = [
    { id: 'basics' as TabType, label: 'Grunddaten', icon: Package },
    { id: 'costs' as TabType, label: 'Kosten', icon: DollarSign },
    { id: 'payment' as TabType, label: 'Zahlung', icon: CreditCard },
    { id: 'details' as TabType, label: 'Details', icon: FileText },
  ];

  return (
    <>
      <StandardModal
        isOpen={isOpen}
        onClose={onClose}
        title="Neuen Budgetposten hinzufügen"
        subtitle="Erfasse einen neuen Ausgabenposten für deine Hochzeit"
        icon={DollarSign}
        maxWidth="4xl"
        footer={
          <ModalFooter>
            <ModalButton variant="secondary" onClick={onClose}>
              Abbrechen
            </ModalButton>
            <ModalButton
              variant="primary"
              onClick={handleSubmit}
              disabled={!isFormValid}
              icon={Save}
            >
              Posten speichern
            </ModalButton>
          </ModalFooter>
        }
      >
        <div className="space-y-6">
          {/* Kostenvorschau oben */}
          <div className="bg-gradient-to-r from-[#d4af37]/20 to-[#f4d03f]/20 rounded-xl p-5 border-2 border-[#d4af37]/40 backdrop-blur-sm">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-white/70 mb-1 font-semibold">Geschätzte Gesamtkosten</p>
                <p className="text-4xl font-bold text-white">
                  {getTotalAmount.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} €
                </p>
              </div>
              {newItem.is_per_person && newItem.cost_per_person && (
                <div className="text-right">
                  <p className="text-sm text-white/70 mb-1">Pro-Kopf-Berechnung</p>
                  <p className="text-lg font-semibold text-white">
                    {newItem.cost_per_person} € × {newItem.guest_count_override || (newItem.use_confirmed_guests_only ? confirmedGuestCount : guestCount)} Gäste
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Tab Navigation */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide -mx-1 px-1">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-4 py-3 rounded-xl font-semibold transition-all whitespace-nowrap flex-shrink-0 ${
                  activeTab === tab.id
                    ? 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#0a253c] shadow-gold'
                    : 'bg-white/10 text-white/70 hover:bg-white/20 hover:text-white border-2 border-[#d4af37]/30'
                }`}
              >
                <tab.icon className="w-5 h-5" />
                <span>{tab.label}</span>
              </button>
            ))}
          </div>

          {/* Tab Content */}
          <div className="min-h-[300px]">
            {activeTab === 'basics' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-right-3 duration-300">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2">Kategorie*</label>
                    <select
                      value={newItem.category}
                      onChange={(e) => setNewItem({ ...newItem, category: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                    >
                      {categories.map((cat) => (
                        <option key={cat} value={cat} className="bg-[#0a253c] text-white">
                          {getCategoryTranslation(cat)}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2">Bezeichnung*</label>
                    <input
                      type="text"
                      value={newItem.item_name}
                      onChange={(e) => setNewItem({ ...newItem, item_name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                      placeholder="z.B. Schloss Hochzeit"
                      autoFocus
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
                      <Package className="w-4 h-4 text-[#d4af37]" />
                      Dienstleister
                    </label>
                    <select
                      value={newItem.vendor_id}
                      onChange={(e) => setNewItem({ ...newItem, vendor_id: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                    >
                      <option value="" className="bg-[#0a253c] text-white">Kein Dienstleister</option>
                      {vendors.map(vendor => (
                        <option key={vendor.id} value={vendor.id} className="bg-[#0a253c] text-white">
                          {vendor.name} - {vendor.category}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[#d4af37]" />
                      Timeline-Event
                    </label>
                    <select
                      value={newItem.timeline_event_id}
                      onChange={(e) => setNewItem({ ...newItem, timeline_event_id: e.target.value })}
                      onFocus={loadTimelineEvents}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                      disabled={loadingTimeline}
                    >
                      <option value="" className="bg-[#0a253c] text-white">
                        {loadingTimeline ? 'Lädt...' : 'Kein Event'}
                      </option>
                      {timelineEvents.map(event => (
                        <option key={event.id} value={event.id} className="bg-[#0a253c] text-white">
                          {event.time} - {event.title}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-white/90 mb-2">Priorität</label>
                  <div className="flex gap-3">
                    {(['low', 'medium', 'high'] as const).map((priority) => (
                      <button
                        key={priority}
                        type="button"
                        onClick={() => setNewItem({ ...newItem, priority })}
                        className={`flex-1 px-4 py-3 rounded-xl font-semibold transition-all ${
                          newItem.priority === priority
                            ? 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#0a253c] shadow-lg'
                            : 'bg-white/10 border-2 border-[#d4af37]/30 text-white hover:bg-white/20'
                        }`}
                      >
                        {priority === 'low' ? 'Niedrig' : priority === 'medium' ? 'Mittel' : 'Hoch'}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'costs' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-right-3 duration-300">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2">Geplante Kosten (€)</label>
                    <input
                      type="number"
                      value={newItem.estimated_cost}
                      onChange={(e) => setNewItem({ ...newItem, estimated_cost: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                      placeholder="0.00"
                      step="0.01"
                      disabled={newItem.is_per_person}
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2">Tatsächliche Kosten (€)</label>
                    <input
                      type="number"
                      value={newItem.actual_cost}
                      onChange={(e) => setNewItem({ ...newItem, actual_cost: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                      placeholder="0.00"
                      step="0.01"
                      disabled={newItem.is_per_person}
                    />
                    {newItem.actual_cost && parseFloat(newItem.actual_cost) > 0 && (
                      <label className="flex items-center gap-2 mt-3">
                        <input
                          type="checkbox"
                          checked={newItem.directly_paid || false}
                          onChange={(e) => {
                            const checked = e.target.checked;
                            setNewItem({ ...newItem, directly_paid: checked, paid: checked });
                          }}
                          className="w-4 h-4 rounded border-2 border-[#d4af37] text-[#d4af37] focus:ring-[#d4af37]"
                        />
                        <span className="text-sm font-semibold text-green-400">Direkt bezahlt</span>
                      </label>
                    )}
                  </div>
                </div>

                {/* Pro-Kopf-Berechnung */}
                <div className="p-5 bg-white/10 rounded-xl border-2 border-[#d4af37]/30 backdrop-blur-sm">
                  <div className="flex items-center gap-2 mb-4">
                    <Users className="w-5 h-5 text-[#d4af37]" />
                    <h4 className="font-semibold text-white">Pro-Kopf-Kalkulation</h4>
                  </div>
                  <BudgetItemProKopfForm
                    weddingId={weddingId}
                    isPerPerson={newItem.is_per_person}
                    costPerPerson={newItem.cost_per_person ? parseFloat(newItem.cost_per_person) : null}
                    useConfirmedGuestsOnly={newItem.use_confirmed_guests_only}
                    guestCountOverride={newItem.guest_count_override ? parseFloat(newItem.guest_count_override) : null}
                    onChange={handleProKopfChange}
                  />
                  {loadingGuests && (
                    <div className="mt-3 text-sm text-white/70 flex items-center gap-2">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-[#d4af37]"></div>
                      Lädt Gästezahlen...
                    </div>
                  )}
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2">Währung</label>
                    <select
                      value={newItem.currency}
                      onChange={(e) => setNewItem({ ...newItem, currency: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                    >
                      <option value="EUR" className="bg-[#0a253c]">EUR (€)</option>
                      <option value="USD" className="bg-[#0a253c]">USD ($)</option>
                      <option value="GBP" className="bg-[#0a253c]">GBP (£)</option>
                      <option value="CHF" className="bg-[#0a253c]">CHF (Fr.)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2">Steuersatz (%)</label>
                    <input
                      type="number"
                      value={newItem.tax_rate}
                      onChange={(e) => setNewItem({ ...newItem, tax_rate: parseFloat(e.target.value) || 0 })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                      placeholder="19"
                      step="0.1"
                      min="0"
                      max="100"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'payment' && (
              <div className="space-y-5 animate-in fade-in slide-in-from-right-3 duration-300">
                <div className="p-5 bg-white/10 rounded-xl border-2 border-[#d4af37]/30 backdrop-blur-sm">
                  <h3 className="font-bold text-white flex items-center gap-2 mb-4">
                    <CreditCard className="w-5 h-5 text-[#d4af37]" />
                    Zahlungsart auswählen
                  </h3>

                  <div className="flex gap-3 mb-5">
                    <button
                      type="button"
                      onClick={() => setPaymentType('single')}
                      className={`flex-1 p-4 rounded-xl border-2 font-semibold transition-all ${
                        paymentType === 'single'
                          ? 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f] border-[#d4af37] text-[#0a253c] shadow-lg'
                          : 'bg-white/5 border-white/20 text-white hover:border-[#d4af37]/50'
                      }`}
                    >
                      <div className="text-center">
                        <p className="font-bold mb-1">Einmalzahlung</p>
                        <p className="text-xs opacity-80">Gesamtbetrag auf einmal</p>
                      </div>
                    </button>
                    <button
                      type="button"
                      onClick={() => setPaymentType('plan')}
                      className={`flex-1 p-4 rounded-xl border-2 font-semibold transition-all ${
                        paymentType === 'plan'
                          ? 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f] border-[#d4af37] text-[#0a253c] shadow-lg'
                          : 'bg-white/5 border-white/20 text-white hover:border-[#d4af37]/50'
                      }`}
                    >
                      <div className="text-center">
                        <p className="font-bold mb-1">Zahlungsplan</p>
                        <p className="text-xs opacity-80">In mehreren Raten zahlen</p>
                      </div>
                    </button>
                  </div>

                  {paymentType === 'single' && (
                    <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                      <label className="block text-sm font-semibold text-white/90 mb-2">
                        Fälligkeitsdatum (optional)
                      </label>
                      <input
                        type="date"
                        value={singlePaymentDueDate}
                        onChange={(e) => setSinglePaymentDueDate(e.target.value)}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                      />
                    </div>
                  )}

                  {paymentType === 'plan' && (
                    <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                      <div className="flex items-center justify-between mb-3">
                        <p className="text-sm text-white/70">Teile die Kosten in mehrere Raten auf</p>
                        <button
                          type="button"
                          onClick={() => setShowPaymentPlan(true)}
                          className="px-4 py-2 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#0a253c] rounded-lg font-semibold hover:shadow-lg transition-all"
                        >
                          {newItem.payment_plan ? 'Bearbeiten' : 'Erstellen'}
                        </button>
                      </div>

                      {newItem.payment_plan && newItem.payment_plan.length > 0 && (
                        <div className="space-y-2 mt-4">
                          <p className="text-sm font-semibold text-white mb-3">
                            {newItem.payment_plan.length} Raten geplant
                          </p>
                          {newItem.payment_plan.map((installment, index) => (
                            <div key={installment.id} className="flex items-center justify-between p-3 bg-white/5 rounded-lg border border-[#d4af37]/30">
                              <div className="flex items-center gap-3">
                                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#0a253c] flex items-center justify-center text-sm font-bold">
                                  {index + 1}
                                </div>
                                <span className="text-sm font-semibold text-white">
                                  {installment.description || `Rate ${index + 1}`}
                                </span>
                              </div>
                              <div className="text-right">
                                <p className="text-sm font-bold text-white">{parseFloat(installment.amount).toLocaleString('de-DE')} €</p>
                                <p className="text-xs text-white/60">
                                  {new Date(installment.dueDate).toLocaleDateString('de-DE')}
                                </p>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-sm font-semibold text-white/90 mb-2">Zahlungsmethode</label>
                  <select
                    value={newItem.payment_method}
                    onChange={(e) => setNewItem({ ...newItem, payment_method: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                  >
                    <option value="bank_transfer" className="bg-[#0a253c]">Banküberweisung</option>
                    <option value="cash" className="bg-[#0a253c]">Bar</option>
                    <option value="credit_card" className="bg-[#0a253c]">Kreditkarte</option>
                    <option value="paypal" className="bg-[#0a253c]">PayPal</option>
                    <option value="other" className="bg-[#0a253c]">Sonstiges</option>
                  </select>
                </div>
              </div>
            )}

            {activeTab === 'details' && (
              <div className="space-y-4 animate-in fade-in slide-in-from-right-3 duration-300">
                <div>
                  <label className="block text-sm font-semibold text-white/90 mb-2">Notizen</label>
                  <textarea
                    value={newItem.notes}
                    onChange={(e) => setNewItem({ ...newItem, notes: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                    rows={6}
                    placeholder="Zusätzliche Informationen, Besonderheiten, Kontaktdaten..."
                  />
                </div>

                <div className="bg-blue-500/20 border-2 border-blue-400/50 rounded-xl p-4 backdrop-blur-sm">
                  <p className="text-sm text-blue-200">
                    <span className="font-bold text-white">💡 Tipp:</span> Nutze die Notizen für wichtige Details wie Ansprechpartner, Vertragsdetails oder spezielle Vereinbarungen.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </StandardModal>

      {showPaymentPlan && (
        <PaymentPlanModal
          isOpen={showPaymentPlan}
          onClose={() => setShowPaymentPlan(false)}
          onConfirm={handlePaymentPlanConfirm}
          totalAmount={getTotalAmount}
          currency={newItem.currency}
        />
      )}
    </>
  );
}
