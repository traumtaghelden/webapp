import { Plus, X, UserPlus, DollarSign, CheckSquare, Calendar } from 'lucide-react';
import { useState, useEffect } from 'react';
import { disableBodyScroll, enableBodyScroll } from '../utils/scrollLockManager';

interface FABAction {
  id: string;
  icon: typeof UserPlus;
  label: string;
  onClick: () => void;
  color?: string;
}

interface FloatingActionButtonProps {
  actions: FABAction[];
}

export default function FloatingActionButton({ actions }: FloatingActionButtonProps) {
  const [isExpanded, setIsExpanded] = useState(false);
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      if (currentScrollY < 100) {
        setIsVisible(true);
      } else if (currentScrollY > lastScrollY && currentScrollY > 150) {
        setIsVisible(false);
        setIsExpanded(false);
      } else if (currentScrollY < lastScrollY - 10) {
        setIsVisible(true);
      }

      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  useEffect(() => {
    if (isExpanded) {
      disableBodyScroll();
    } else {
      enableBodyScroll();
    }

    return () => {
      if (isExpanded) {
        enableBodyScroll();
      }
    };
  }, [isExpanded]);

  const handleActionClick = (action: FABAction) => {
    action.onClick();
    setIsExpanded(false);
  };

  return (
    <>
      {isExpanded && (
        <div
          className="fixed inset-0 bg-black/50 z-40 animate-fade-in sm:hidden"
          onClick={() => setIsExpanded(false)}
        />
      )}

      <div
        className={`
          fixed bottom-20 right-4 z-50
          transition-all duration-300 ease-out
          sm:hidden
          ${isVisible ? 'translate-y-0 opacity-100' : 'translate-y-32 opacity-0 pointer-events-none'}
        `}
      >
        {isExpanded && (
          <div className="absolute bottom-16 right-0 flex flex-col gap-3 animate-slide-up-enter">
            {actions.map((action, index) => {
              const Icon = action.icon;
              return (
                <button
                  key={action.id}
                  onClick={() => handleActionClick(action)}
                  className={`
                    flex items-center gap-3 px-4 py-3 rounded-l-full rounded-r-full
                    ${action.color || 'bg-white'}
                    shadow-lg border-2 border-gray-100
                    hover:shadow-xl active:scale-95
                    transition-all duration-200
                    touch-target ripple
                    min-w-[180px]
                  `}
                  style={{ animationDelay: `${index * 50}ms` }}
                >
                  <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex items-center justify-center flex-shrink-0">
                    <Icon className="w-5 h-5 text-white" />
                  </div>
                  <span className="font-semibold text-[#0a253c] text-sm">
                    {action.label}
                  </span>
                </button>
              );
            })}
          </div>
        )}

        <button
          onClick={() => setIsExpanded(!isExpanded)}
          className={`
            w-14 h-14 rounded-full
            bg-gradient-to-r from-[#d4af37] to-[#f4d03f]
            shadow-lg hover:shadow-xl
            flex items-center justify-center
            transition-all duration-300
            touch-target ripple
            ${isExpanded ? 'rotate-45 scale-110' : 'rotate-0 scale-100'}
          `}
          aria-label={isExpanded ? 'Schließen' : 'Aktionen'}
          aria-expanded={isExpanded}
        >
          {isExpanded ? (
            <X className="w-6 h-6 text-white" strokeWidth={3} />
          ) : (
            <Plus className="w-6 h-6 text-white" strokeWidth={3} />
          )}
        </button>
      </div>
    </>
  );
}
