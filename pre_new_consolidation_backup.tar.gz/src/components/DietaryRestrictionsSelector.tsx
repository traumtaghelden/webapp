import { useState } from 'react';
import { X, Plus } from 'lucide-react';

interface DietaryRestrictionsSelectorProps {
  value: string;
  onChange: (value: string) => void;
}

const PREDEFINED_OPTIONS = [
  // Allergien
  { category: 'Allergien', label: 'Nussallergie', value: 'Nussallergie' },
  { category: 'Allergien', label: 'Laktoseintoleranz', value: 'Laktoseintoleranz' },
  { category: 'Allergien', label: 'Glutenunverträglichkeit', value: 'Glutenunverträglichkeit' },
  { category: 'Allergien', label: 'Fruktoseintoleranz', value: 'Fruktoseintoleranz' },
  { category: 'Allergien', label: 'Fischallergie', value: 'Fischallergie' },
  { category: 'Allergien', label: 'Schalentierallergie', value: 'Schalentierallergie' },
  { category: 'Allergien', label: 'Eierallergie', value: 'Eierallergie' },
  { category: 'Allergien', label: 'Sojaalllergie', value: 'Sojaalllergie' },

  // Diät
  { category: 'Diät', label: 'Vegetarisch', value: 'Vegetarisch' },
  { category: 'Diät', label: 'Vegan', value: 'Vegan' },
  { category: 'Diät', label: 'Pescetarisch', value: 'Pescetarisch' },
  { category: 'Diät', label: 'Halal', value: 'Halal' },
  { category: 'Diät', label: 'Kosher', value: 'Kosher' },
  { category: 'Diät', label: 'Kein Schweinefleisch', value: 'Kein Schweinefleisch' },
  { category: 'Diät', label: 'Kein Rindfleisch', value: 'Kein Rindfleisch' },
  { category: 'Diät', label: 'Low Carb', value: 'Low Carb' },

  // Besondere Bedürfnisse
  { category: 'Besondere Bedürfnisse', label: 'Diabetiker', value: 'Diabetiker' },
  { category: 'Besondere Bedürfnisse', label: 'Babynahrung erforderlich', value: 'Babynahrung erforderlich' },
  { category: 'Besondere Bedürfnisse', label: 'Kein Alkohol', value: 'Kein Alkohol' },
  { category: 'Besondere Bedürfnisse', label: 'Rollstuhlgerecht', value: 'Rollstuhlgerecht' },
  { category: 'Besondere Bedürfnisse', label: 'Sitzplatz-Anforderung', value: 'Sitzplatz-Anforderung' },
];

export default function DietaryRestrictionsSelector({ value, onChange }: DietaryRestrictionsSelectorProps) {
  const [customInputs, setCustomInputs] = useState<Record<string, { show: boolean; value: string }>>({});

  // Parse current value into array
  const selectedItems = value ? value.split(',').map(v => v.trim()).filter(v => v) : [];

  const toggleOption = (optionValue: string) => {
    if (selectedItems.includes(optionValue)) {
      // Remove
      const updated = selectedItems.filter(v => v !== optionValue);
      onChange(updated.join(', '));
    } else {
      // Add
      onChange([...selectedItems, optionValue].join(', '));
    }
  };

  const removeItem = (item: string) => {
    const updated = selectedItems.filter(v => v !== item);
    onChange(updated.join(', '));
  };

  const showCustomInput = (category: string) => {
    setCustomInputs({
      ...customInputs,
      [category]: { show: true, value: '' }
    });
  };

  const hideCustomInput = (category: string) => {
    const updated = { ...customInputs };
    delete updated[category];
    setCustomInputs(updated);
  };

  const updateCustomValue = (category: string, newValue: string) => {
    setCustomInputs({
      ...customInputs,
      [category]: { show: true, value: newValue }
    });
  };

  const addCustomItem = (category: string) => {
    const customValue = customInputs[category]?.value;
    if (customValue && customValue.trim()) {
      onChange([...selectedItems, customValue.trim()].join(', '));
      hideCustomInput(category);
    }
  };

  const groupedOptions = PREDEFINED_OPTIONS.reduce((acc, option) => {
    if (!acc[option.category]) {
      acc[option.category] = [];
    }
    acc[option.category].push(option);
    return acc;
  }, {} as Record<string, typeof PREDEFINED_OPTIONS>);

  return (
    <div className="space-y-4">
      {/* Selected items display */}
      {selectedItems.length > 0 && (
        <div className="flex flex-wrap gap-2 p-3 bg-[#f7f2eb] rounded-xl">
          {selectedItems.map((item, index) => (
            <span
              key={index}
              className="flex items-center gap-2 px-3 py-1 bg-white border-2 border-[#d4af37] text-[#0a253c] rounded-full text-sm font-semibold"
            >
              {item}
              <button
                type="button"
                onClick={() => removeItem(item)}
                className="hover:bg-red-50 rounded-full p-0.5 transition-colors"
              >
                <X className="w-3 h-3 text-red-500" />
              </button>
            </span>
          ))}
        </div>
      )}

      {/* Predefined options grouped by category */}
      <div className="space-y-4">
        {Object.entries(groupedOptions).map(([category, options]) => (
          <div key={category} className="bg-white border-2 border-[#d4af37]/20 rounded-xl p-4">
            <h4 className="text-sm font-bold text-[#0a253c] mb-3">{category}</h4>
            <div className="flex flex-wrap gap-2 mb-3">
              {options.map((option) => {
                const isSelected = selectedItems.includes(option.value);
                return (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() => toggleOption(option.value)}
                    className={`px-3 py-2 rounded-lg text-sm font-semibold transition-all ${
                      isSelected
                        ? 'bg-[#d4af37] text-white'
                        : 'bg-white border-2 border-[#d4af37]/20 text-[#666666] hover:border-[#d4af37] hover:bg-[#f7f2eb]'
                    }`}
                  >
                    {option.label}
                  </button>
                );
              })}
            </div>

            {/* Custom input per category */}
            <div className="pt-2 border-t border-[#d4af37]/10">
              {customInputs[category]?.show ? (
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customInputs[category]?.value || ''}
                    onChange={(e) => updateCustomValue(category, e.target.value)}
                    onKeyPress={(e) => {
                      if (e.key === 'Enter') {
                        e.preventDefault();
                        addCustomItem(category);
                      }
                    }}
                    placeholder={`Eigene ${category} eingeben...`}
                    className="flex-1 px-3 py-2 border-2 border-[#d4af37]/20 rounded-lg focus:border-[#d4af37] focus:outline-none text-sm"
                    autoFocus
                  />
                  <button
                    type="button"
                    onClick={() => addCustomItem(category)}
                    className="px-3 py-2 bg-[#d4af37] text-white rounded-lg font-semibold hover:bg-[#c49d2f] transition-colors text-sm"
                  >
                    Hinzufügen
                  </button>
                  <button
                    type="button"
                    onClick={() => hideCustomInput(category)}
                    className="px-3 py-2 border-2 border-[#666666] text-[#666666] rounded-lg font-semibold hover:bg-gray-50 transition-colors text-sm"
                  >
                    Abbrechen
                  </button>
                </div>
              ) : (
                <button
                  type="button"
                  onClick={() => showCustomInput(category)}
                  className="flex items-center gap-2 px-3 py-2 border-2 border-[#d4af37]/30 text-[#d4af37] rounded-lg font-semibold hover:bg-[#f7f2eb] transition-colors text-sm w-full justify-center"
                >
                  <Plus className="w-3 h-3" />
                  Eigene {category} hinzufügen
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
