import { ReactNode } from 'react';
import CompactKPICard from './CompactKPICard';

export interface StatCard {
  icon: ReactNode;
  label: string;
  value: string | number;
  subtitle?: string;
  color: 'yellow' | 'green' | 'blue' | 'red' | 'orange';
  onClick?: () => void;
}

interface PageHeaderWithStatsProps {
  title: string;
  subtitle?: string;
  stats: StatCard[];
}

export default function PageHeaderWithStats({ title, subtitle, stats }: PageHeaderWithStatsProps) {
  return (
    <div className="space-y-4 mb-6">
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
        <div className="flex-shrink-0">
          <h2 className="text-3xl font-bold text-[#0a253c]">{title}</h2>
          {subtitle && (
            <p className="text-[#666666] mt-1">{subtitle}</p>
          )}
        </div>

        <div className="grid grid-cols-2 lg:flex lg:flex-row gap-3 lg:gap-4">
          {stats.map((stat, index) => (
            <CompactKPICard
              key={index}
              icon={stat.icon}
              label={stat.label}
              value={stat.value}
              subtitle={stat.subtitle}
              color={stat.color}
              delay={index * 100}
              onClick={stat.onClick}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
