import { useState, useEffect, ReactNode } from 'react';

interface KPICardProps {
  icon: ReactNode;
  label: string;
  value: string | number;
  subtitle?: string;
  color: string;
  delay?: number;
  onClick?: () => void;
}

export default function KPICard({
  icon,
  label,
  value,
  subtitle,
  color,
  delay = 0,
  onClick
}: KPICardProps) {
  const [isVisible, setIsVisible] = useState(false);
  const [displayValue, setDisplayValue] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay);

    return () => clearTimeout(timer);
  }, [delay]);

  useEffect(() => {
    if (!isVisible) return;

    const numericValue = typeof value === 'string' ? parseFloat(value) : value;
    if (isNaN(numericValue)) {
      setDisplayValue(numericValue);
      return;
    }

    const duration = 800;
    const steps = 25;
    const increment = numericValue / steps;
    let current = 0;
    let step = 0;

    const counter = setInterval(() => {
      step++;
      current = Math.min(current + increment, numericValue);
      setDisplayValue(Math.round(current));

      if (step >= steps) {
        setDisplayValue(numericValue);
        clearInterval(counter);
      }
    }, duration / steps);

    return () => clearInterval(counter);
  }, [isVisible, value]);

  return (
    <div
      className={`transform transition-all duration-500 ease-out ${
        isVisible
          ? 'opacity-100 translate-y-0'
          : 'opacity-0 translate-y-4'
      }`}
      style={{ transitionDelay: `${delay}ms` }}
    >
      <div
        className={`
          bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl
          transition-all duration-300 border-l-4 ${color} h-full
          ${onClick ? 'cursor-pointer hover:-translate-y-1 active:scale-[0.98]' : ''}
        `}
        onClick={onClick}
      >
        <div className="flex items-start justify-between mb-3">
          <div className={`p-3 rounded-xl ${color.replace('border-', 'bg-')}/10`}>
            {icon}
          </div>
        </div>
        <div className="space-y-1">
          <p className="text-sm font-semibold text-[#666666] uppercase tracking-wide">
            {label}
          </p>
          <p className={`text-4xl font-bold ${color.replace('border-', 'text-')}`}>
            {typeof value === 'string' && value.includes('%')
              ? `${displayValue}%`
              : displayValue}
          </p>
          {subtitle && (
            <p className="text-xs text-[#999999] mt-1">{subtitle}</p>
          )}
        </div>
      </div>
    </div>
  );
}
