import { ReactNode, useEffect, useState } from 'react';

export interface Tab {
  id: string;
  label: string;
  icon?: ReactNode;
  badge?: number | string;
  disabled?: boolean;
  content: ReactNode;
}

interface TabContainerProps {
  tabs: Tab[];
  defaultTab?: string;
  storageKey?: string;
  urlParam?: string;
  onTabChange?: (tabId: string) => void;
  className?: string;
}

export default function TabContainer({
  tabs,
  defaultTab,
  storageKey,
  urlParam,
  onTabChange,
  className = ''
}: TabContainerProps) {
  const [activeTab, setActiveTab] = useState<string>(() => {
    if (urlParam) {
      const params = new URLSearchParams(window.location.search);
      const urlTab = params.get(urlParam);
      if (urlTab && tabs.some(t => t.id === urlTab)) {
        return urlTab;
      }
    }

    if (storageKey) {
      const stored = localStorage.getItem(storageKey);
      if (stored && tabs.some(t => t.id === stored)) {
        return stored;
      }
    }

    return defaultTab || tabs[0]?.id || '';
  });

  const [isTransitioning, setIsTransitioning] = useState(false);

  useEffect(() => {
    if (storageKey) {
      localStorage.setItem(storageKey, activeTab);
    }

    if (urlParam) {
      const url = new URL(window.location.href);
      url.searchParams.set(urlParam, activeTab);
      window.history.replaceState({}, '', url.toString());
    }
  }, [activeTab, storageKey, urlParam]);

  const handleTabChange = (tabId: string) => {
    if (tabs.find(t => t.id === tabId)?.disabled) return;

    setIsTransitioning(true);
    setTimeout(() => {
      setActiveTab(tabId);
      setIsTransitioning(false);
      onTabChange?.(tabId);
    }, 150);
  };

  const activeTabObj = tabs.find(t => t.id === activeTab);

  return (
    <div className={`space-y-6 ${className}`}>
      <div className="border-b border-gray-200">
        <nav className="flex flex-wrap gap-2 -mb-px overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            const isDisabled = tab.disabled;

            return (
              <button
                key={tab.id}
                onClick={() => handleTabChange(tab.id)}
                disabled={isDisabled}
                className={`
                  group relative flex items-center gap-2 px-4 py-3
                  font-semibold text-sm whitespace-nowrap
                  border-b-2 transition-all duration-200
                  ${
                    isActive
                      ? 'border-[#d4af37] text-[#d4af37]'
                      : isDisabled
                      ? 'border-transparent text-gray-400 cursor-not-allowed'
                      : 'border-transparent text-gray-600 hover:text-[#d4af37] hover:border-gray-300'
                  }
                `}
              >
                {tab.icon && (
                  <span className={`
                    ${isActive ? 'text-[#d4af37]' : isDisabled ? 'text-gray-400' : 'text-gray-500 group-hover:text-[#d4af37]'}
                  `}>
                    {tab.icon}
                  </span>
                )}
                <span>{tab.label}</span>
                {tab.badge !== undefined && (
                  <span className={`
                    px-2 py-0.5 rounded-full text-xs font-bold
                    ${
                      isActive
                        ? 'bg-[#d4af37] text-white'
                        : 'bg-gray-200 text-gray-700'
                    }
                  `}>
                    {tab.badge}
                  </span>
                )}
                {isActive && (
                  <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#d4af37] to-[#f4d03f]" />
                )}
              </button>
            );
          })}
        </nav>
      </div>

      <div
        className={`transition-opacity duration-150 ${isTransitioning ? 'opacity-0' : 'opacity-100'}`}
      >
        {activeTabObj?.content}
      </div>
    </div>
  );
}
