import { ReactNode } from 'react';

export interface Tab {
  id: string;
  label: string;
  icon?: ReactNode;
  badge?: number | string;
  disabled?: boolean;
}

interface TabNavigationProps {
  tabs: Tab[];
  activeTab: string;
  onTabChange: (tabId: string) => void;
  className?: string;
}

export default function TabNavigation({ tabs, activeTab, onTabChange, className = '' }: TabNavigationProps) {
  return (
    <div className={`border-b border-gray-200 ${className}`}>
      <nav className="flex flex-wrap gap-2 -mb-px overflow-x-auto scrollbar-hide">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const isDisabled = tab.disabled;

          return (
            <button
              key={tab.id}
              onClick={() => !isDisabled && onTabChange(tab.id)}
              disabled={isDisabled}
              className={`
                group relative flex items-center gap-2 px-4 py-3
                font-semibold text-sm whitespace-nowrap
                border-b-2 transition-all duration-200
                ${
                  isActive
                    ? 'border-[#d4af37] text-[#d4af37]'
                    : isDisabled
                    ? 'border-transparent text-gray-400 cursor-not-allowed'
                    : 'border-transparent text-gray-600 hover:text-[#d4af37] hover:border-gray-300'
                }
              `}
            >
              {tab.icon && (
                <span className={`
                  ${isActive ? 'text-[#d4af37]' : isDisabled ? 'text-gray-400' : 'text-gray-500 group-hover:text-[#d4af37]'}
                `}>
                  {tab.icon}
                </span>
              )}
              <span>{tab.label}</span>
              {tab.badge !== undefined && (
                <span className={`
                  px-2 py-0.5 rounded-full text-xs font-bold
                  ${
                    isActive
                      ? 'bg-[#d4af37] text-white'
                      : 'bg-gray-200 text-gray-700'
                  }
                `}>
                  {tab.badge}
                </span>
              )}
              {isActive && (
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-[#d4af37] to-[#f4d03f]" />
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
