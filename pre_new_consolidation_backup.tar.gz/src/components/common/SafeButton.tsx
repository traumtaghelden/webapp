import { useState, MouseEvent, ReactNode } from 'react';
import { logger } from '../../utils/logger';

interface SafeButtonProps {
  onClick: (e: MouseEvent<HTMLButtonElement>) => void | Promise<void>;
  children: ReactNode;
  className?: string;
  disabled?: boolean;
  type?: 'button' | 'submit' | 'reset';
  preventDoubleClick?: boolean;
  loadingText?: string;
  errorFallback?: (error: Error) => void;
}

export function SafeButton({
  onClick,
  children,
  className = '',
  disabled = false,
  type = 'button',
  preventDoubleClick = true,
  loadingText,
  errorFallback,
}: SafeButtonProps) {
  const [isLoading, setIsLoading] = useState(false);

  const handleClick = async (e: MouseEvent<HTMLButtonElement>) => {
    e.preventDefault();
    e.stopPropagation();

    if (isLoading && preventDoubleClick) {
      return;
    }

    try {
      setIsLoading(true);
      const result = onClick(e);

      if (result instanceof Promise) {
        await result;
      }
    } catch (error) {
      logger.error('SafeButton onClick error', 'SafeButton', error);

      if (errorFallback && error instanceof Error) {
        errorFallback(error);
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <button
      type={type}
      onClick={handleClick}
      className={className}
      disabled={disabled || isLoading}
    >
      {isLoading && loadingText ? loadingText : children}
    </button>
  );
}
