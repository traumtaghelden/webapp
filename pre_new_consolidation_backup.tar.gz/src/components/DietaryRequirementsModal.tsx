import { useState, useEffect } from 'react';
import { X, Printer, AlertCircle, Search } from 'lucide-react';
import { supabase, type Guest } from '../lib/supabase';

interface DietaryRequirementsModalProps {
  weddingId: string;
  onClose: () => void;
}

export default function DietaryRequirementsModal({ weddingId, onClose }: DietaryRequirementsModalProps) {
  const [guests, setGuests] = useState<Guest[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');

  useEffect(() => {
    loadGuests();
  }, [weddingId]);

  const loadGuests = async () => {
    try {
      const { data, error } = await supabase
        .from('guests')
        .select('*')
        .eq('wedding_id', weddingId)
        .not('dietary_restrictions', 'is', null)
        .order('name');

      if (error) throw error;

      // Filter out guests with empty dietary restrictions
      const filtered = (data || []).filter(
        (g) => g.dietary_restrictions && g.dietary_restrictions.trim() !== ''
      );
      setGuests(filtered);
    } catch (error) {
      console.error('Error loading guests:', error);
    } finally {
      setLoading(false);
    }
  };

  const handlePrint = () => {
    const printContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Allergien & Besondere Bedürfnisse</title>
        <style>
          @page { size: A4; margin: 20mm; }
          body {
            font-family: 'Georgia', serif;
            color: #0a253c;
            line-height: 1.6;
          }
          .header {
            text-align: center;
            border-bottom: 3px solid #d4af37;
            padding-bottom: 10mm;
            margin-bottom: 10mm;
          }
          .header h1 {
            color: #0a253c;
            font-size: 24pt;
            margin: 0;
          }
          .header p {
            color: #666;
            font-size: 12pt;
            margin: 5px 0 0 0;
          }
          table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 5mm;
          }
          th {
            background-color: #f7f2eb;
            color: #0a253c;
            font-weight: bold;
            padding: 10px;
            text-align: left;
            border-bottom: 2px solid #d4af37;
          }
          td {
            padding: 10px;
            border-bottom: 1px solid #e5e5e5;
          }
          tr:hover {
            background-color: #f7f2eb;
          }
          .count {
            text-align: center;
            margin-top: 10mm;
            padding: 10px;
            background-color: #f7f2eb;
            border-radius: 5px;
            font-weight: bold;
          }
          .dietary-text {
            color: #d4af37;
            font-weight: 600;
          }
          @media print {
            .no-print { display: none; }
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Allergien & Besondere Bedürfnisse</h1>
          <p>Gästeliste mit besonderen Anforderungen</p>
        </div>
        <table>
          <thead>
            <tr>
              <th style="width: 5%;">#</th>
              <th style="width: 30%;">Name</th>
              <th style="width: 20%;">Kontakt</th>
              <th style="width: 45%;">Allergien / Bedürfnisse</th>
            </tr>
          </thead>
          <tbody>
            ${filteredGuests
              .map(
                (guest, index) => `
              <tr>
                <td>${index + 1}</td>
                <td><strong>${guest.name}</strong></td>
                <td style="font-size: 10pt; color: #666;">
                  ${guest.email || ''}${guest.email && guest.phone ? '<br>' : ''}${guest.phone || ''}
                </td>
                <td class="dietary-text">${guest.dietary_restrictions}</td>
              </tr>
            `
              )
              .join('')}
          </tbody>
        </table>
        <div class="count">
          Gesamt: ${filteredGuests.length} ${filteredGuests.length === 1 ? 'Gast' : 'Gäste'} mit besonderen Anforderungen
        </div>
      </body>
      </html>
    `;

    const printWindow = window.open('', '_blank');
    if (printWindow) {
      printWindow.document.write(printContent);
      printWindow.document.close();
      printWindow.onload = () => {
        printWindow.print();
      };
    }
  };

  const filteredGuests = guests.filter((guest) => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      guest.name.toLowerCase().includes(query) ||
      (guest.dietary_restrictions && guest.dietary_restrictions.toLowerCase().includes(query)) ||
      (guest.email && guest.email.toLowerCase().includes(query))
    );
  });

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
        <div className="bg-white rounded-2xl p-6">
          <p className="text-[#0a253c]">Lade Daten...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl shadow-2xl max-w-5xl w-full my-8">
        <div className="p-6 border-b border-[#d4af37]/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-6 h-6 text-[#d4af37]" />
              <h2 className="text-2xl font-bold text-[#0a253c]">Allergien & Besondere Bedürfnisse</h2>
            </div>
            <div className="flex items-center gap-3">
              <button
                onClick={handlePrint}
                className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c49d2f] transition-colors"
              >
                <Printer className="w-5 h-5" />
                Drucken
              </button>
              <button onClick={onClose} className="p-2 hover:bg-[#f7f2eb] rounded-full transition-colors">
                <X className="w-6 h-6 text-[#333333]" />
              </button>
            </div>
          </div>
        </div>

        <div className="p-6">
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#666666]" />
              <input
                type="text"
                placeholder="Suche nach Name, Anforderungen..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 border-2 border-[#d4af37]/20 rounded-xl focus:border-[#d4af37] focus:outline-none"
              />
            </div>
          </div>

          {filteredGuests.length === 0 ? (
            <div className="text-center py-12">
              <AlertCircle className="w-16 h-16 text-[#999999] mx-auto mb-4" />
              <p className="text-[#666666] text-lg">
                {searchQuery
                  ? 'Keine Gäste gefunden'
                  : 'Keine Gäste mit Allergien oder besonderen Bedürfnissen'}
              </p>
            </div>
          ) : (
            <>
              <div className="bg-[#f7f2eb] rounded-xl p-4 mb-4 flex items-center justify-between">
                <span className="text-[#0a253c] font-semibold">
                  {filteredGuests.length} {filteredGuests.length === 1 ? 'Gast' : 'Gäste'} mit besonderen
                  Anforderungen
                </span>
              </div>

              <div className="overflow-x-auto max-h-[60vh] overflow-y-auto">
                <table className="w-full">
                  <thead className="bg-[#f7f2eb] sticky top-0">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-bold text-[#0a253c]">#</th>
                      <th className="px-6 py-3 text-left text-sm font-bold text-[#0a253c]">Name</th>
                      <th className="px-6 py-3 text-left text-sm font-bold text-[#0a253c]">Kontakt</th>
                      <th className="px-6 py-3 text-left text-sm font-bold text-[#0a253c]">
                        Allergien / Bedürfnisse
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredGuests.map((guest, index) => (
                      <tr
                        key={guest.id}
                        className="border-b border-[#d4af37]/10 hover:bg-[#f7f2eb]/50 transition-colors"
                      >
                        <td className="px-6 py-4 text-[#666666]">{index + 1}</td>
                        <td className="px-6 py-4">
                          <p className="font-bold text-[#0a253c]">{guest.name}</p>
                        </td>
                        <td className="px-6 py-4">
                          <div className="text-sm text-[#666666]">
                            {guest.email && <p>{guest.email}</p>}
                            {guest.phone && <p>{guest.phone}</p>}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex flex-wrap gap-2">
                            {guest.dietary_restrictions.split(',').map((item, idx) => (
                              <span
                                key={idx}
                                className="px-3 py-1 bg-[#d4af37]/10 text-[#d4af37] rounded-full text-sm font-semibold"
                              >
                                {item.trim()}
                              </span>
                            ))}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
