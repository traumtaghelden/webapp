import { useState, useEffect } from 'react';
import { X, Users, Edit, User, MapPin, Tag, Phone, Mail, Calendar } from 'lucide-react';
import { supabase, type FamilyGroup, type Guest } from '../lib/supabase';

interface FamilyDetailModalProps {
  familyGroupId: string;
  weddingId: string;
  groups: any[];
  onClose: () => void;
  onEdit: (familyId: string) => void;
  onUpdate: () => void;
}

export default function FamilyDetailModal({ familyGroupId, weddingId, groups, onClose, onEdit, onUpdate }: FamilyDetailModalProps) {
  const [loading, setLoading] = useState(true);
  const [familyGroup, setFamilyGroup] = useState<FamilyGroup | null>(null);
  const [members, setMembers] = useState<Guest[]>([]);

  useEffect(() => {
    loadFamilyData();
  }, [familyGroupId]);

  const loadFamilyData = async () => {
    try {
      const { data: family, error: familyError } = await supabase
        .from('family_groups')
        .select('*')
        .eq('id', familyGroupId)
        .single();

      if (familyError) throw familyError;
      setFamilyGroup(family);

      const { data: guestData, error: guestsError } = await supabase
        .from('guests')
        .select('*')
        .eq('family_group_id', familyGroupId)
        .order('created_at', { ascending: true });

      if (guestsError) throw guestsError;
      setMembers(guestData || []);
    } catch (error) {
      console.error('Error loading family:', error);
    } finally {
      setLoading(false);
    }
  };

  const getGroupName = (groupId: string | null) => {
    if (!groupId) return 'Keine Gruppe';
    const group = groups.find(g => g.id === groupId);
    return group?.name || 'Keine Gruppe';
  };

  const getStatusLabel = (status: string): string => {
    switch (status) {
      case 'planned': return 'Geplant';
      case 'invited': return 'Eingeladen';
      case 'accepted': return 'Zugesagt';
      case 'declined': return 'Abgesagt';
      default: return status;
    }
  };

  const getStatusColor = (status: string): string => {
    switch (status) {
      case 'planned': return 'bg-gray-100 text-gray-700';
      case 'invited': return 'bg-blue-100 text-blue-700';
      case 'accepted': return 'bg-green-100 text-green-700';
      case 'declined': return 'bg-red-100 text-red-700';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getAgeGroupLabel = (ageGroup: string): string => {
    switch (ageGroup) {
      case 'adult': return 'Erwachsener';
      case 'child': return 'Kind';
      case 'infant': return 'Kleinkind';
      default: return ageGroup;
    }
  };

  if (loading || !familyGroup) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
        <div className="bg-white rounded-2xl p-6">
          <p className="text-[#0a253c]">Lade Familie...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[9999] p-2 sm:p-4">
      <div className="bg-white rounded-2xl shadow-2xl max-w-4xl w-full max-h-[95vh] sm:max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b-2 border-[#d4af37]/20 px-4 sm:px-8 py-4 sm:py-6 flex flex-col sm:flex-row items-start sm:items-center justify-between z-10 gap-3 sm:gap-0">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-full bg-[#d4af37] flex items-center justify-center">
              <Users className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-[#0a253c] break-words">{familyGroup.name}</h2>
              <p className="text-xs sm:text-sm text-[#666666]">{members.length} Mitglied{members.length !== 1 ? 'er' : ''}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => onEdit(familyGroupId)}
              className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3 sm:px-4 py-2 bg-[#d4af37] text-[#0a253c] rounded-xl text-sm sm:text-base font-semibold hover:bg-[#c19a2e] transition-all"
            >
              <Edit className="w-4 h-4" />
              Bearbeiten
            </button>
            <button onClick={onClose} className="p-2 hover:bg-[#d4af37]/10 rounded-lg transition-all">
              <X className="w-6 h-6 text-[#0a253c]" />
            </button>
          </div>
        </div>

        <div className="p-4 sm:p-8 space-y-4 sm:space-y-6">
          {/* Familien-Informationen */}
          <div className="bg-[#f7f2eb] rounded-xl p-6 space-y-4">
            <h3 className="text-base sm:text-lg font-bold text-[#0a253c] mb-3 sm:mb-4">Familien-Informationen</h3>

            <div className="grid sm:grid-cols-2 gap-3 sm:gap-4">
              <div>
                <label className="block text-sm font-semibold text-[#666666] mb-1">Gruppe</label>
                <div className="flex items-center gap-2">
                  <Tag className="w-4 h-4 text-[#d4af37]" />
                  <p className="text-[#0a253c] font-medium">{getGroupName(familyGroup.group_id)}</p>
                </div>
              </div>

              {familyGroup.table_number && (
                <div>
                  <label className="block text-sm font-semibold text-[#666666] mb-1">Tischnummer</label>
                  <p className="text-[#0a253c] font-medium">Tisch {familyGroup.table_number}</p>
                </div>
              )}
            </div>

            {familyGroup.notes && (
              <div>
                <label className="block text-sm font-semibold text-[#666666] mb-1">Notizen</label>
                <p className="text-[#0a253c] bg-white rounded-lg p-3">{familyGroup.notes}</p>
              </div>
            )}

            {/* Adresse */}
            {(familyGroup.address || familyGroup.city || familyGroup.postal_code) && (
              <div className="pt-4 border-t border-[#d4af37]/20">
                <label className="block text-sm font-semibold text-[#666666] mb-2">Adresse</label>
                <div className="flex items-start gap-2 text-[#0a253c]">
                  <MapPin className="w-4 h-4 text-[#d4af37] mt-1 flex-shrink-0" />
                  <div>
                    {familyGroup.address && <p>{familyGroup.address}</p>}
                    {(familyGroup.postal_code || familyGroup.city) && (
                      <p>{familyGroup.postal_code} {familyGroup.city}</p>
                    )}
                    {familyGroup.country && <p>{familyGroup.country}</p>}
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Familienmitglieder */}
          <div>
            <h3 className="text-base sm:text-lg font-bold text-[#0a253c] mb-3 sm:mb-4">Familienmitglieder</h3>
            <div className="space-y-4">
              {members.map((member, index) => (
                <div key={member.id} className="bg-white rounded-xl p-6 border-2 border-[#d4af37]/20 hover:border-[#d4af37]/40 transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full bg-[#d4af37]/20 flex items-center justify-center">
                        <User className="w-5 h-5 text-[#d4af37]" />
                      </div>
                      <div>
                        <h4 className="text-base sm:text-lg font-bold text-[#0a253c] break-words">{member.name}</h4>
                        <p className="text-sm text-[#666666]">
                          {index === 0 ? 'Hauptperson' : `Person ${index + 1}`}
                        </p>
                      </div>
                    </div>
                    <span className={`px-3 py-1 rounded-full text-sm font-semibold ${getStatusColor(member.rsvp_status)}`}>
                      {getStatusLabel(member.rsvp_status)}
                    </span>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-3 sm:gap-4">
                    {member.email && (
                      <div className="flex items-center gap-2">
                        <Mail className="w-4 h-4 text-[#d4af37]" />
                        <span className="text-sm text-[#333333]">{member.email}</span>
                      </div>
                    )}
                    {member.phone && (
                      <div className="flex items-center gap-2">
                        <Phone className="w-4 h-4 text-[#d4af37]" />
                        <span className="text-sm text-[#333333]">{member.phone}</span>
                      </div>
                    )}
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-[#d4af37]" />
                      <span className="text-sm text-[#333333]">{getAgeGroupLabel(member.age_group)}</span>
                    </div>
                    {member.relationship && (
                      <div className="flex items-center gap-2">
                        <Tag className="w-4 h-4 text-[#d4af37]" />
                        <span className="text-sm text-[#333333]">{member.relationship}</span>
                      </div>
                    )}
                  </div>

                  {member.dietary_restrictions && (
                    <div className="mt-4 pt-4 border-t border-[#d4af37]/20">
                      <label className="block text-xs font-semibold text-[#666666] mb-2">Diätwünsche</label>
                      <div className="flex flex-wrap gap-2">
                        {member.dietary_restrictions.split(',').map((item, idx) => (
                          <span
                            key={idx}
                            className="px-2 py-1 bg-[#d4af37]/10 text-[#d4af37] rounded-full text-xs font-semibold"
                          >
                            {item.trim()}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
