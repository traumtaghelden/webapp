import { useState, useEffect } from 'react';
import { Plus, ArrowUp, ArrowDown, Search } from 'lucide-react';
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors, DragOverlay, useDraggable, useDroppable } from '@dnd-kit/core';
import { supabase, type Vendor } from '../lib/supabase';
import VendorKPIPanel from './Vendor/VendorKPIPanel';
import VendorCard from './VendorCard';
import VendorComparisonModal from './VendorComparisonModal';
import VendorBookingDialog from './VendorBookingDialog';
import VendorDetailModal from './VendorDetailModal';
import { useToast } from '../contexts/ToastContext';
import { VENDOR, COMMON } from '../constants/terminology';

function DraggableVendorCard({ vendor, onUpdate, onCompare, isComparing, onClick }: {
  vendor: Vendor;
  onUpdate: () => void;
  onCompare?: () => void;
  isComparing?: boolean;
  onClick: () => void;
}) {
  const { attributes, listeners, setNodeRef, transform, isDragging } = useDraggable({
    id: vendor.id,
  });

  const style = transform ? {
    transform: `translate3d(${transform.x}px, ${transform.y}px, 0)`,
  } : undefined;

  return (
    <div ref={setNodeRef} style={style} {...listeners} {...attributes}>
      <div onClick={(e) => {
        if (!isDragging) {
          onClick();
        }
      }}>
        <VendorCard
          vendor={vendor}
          onUpdate={onUpdate}
          onCompare={onCompare}
          isComparing={isComparing}
          isDragging={isDragging}
        />
      </div>
    </div>
  );
}

function DroppableZone({ id, children, isActive }: { id: string; children: React.ReactNode; isActive: boolean }) {
  const { setNodeRef, isOver } = useDroppable({
    id,
  });

  return (
    <div
      ref={setNodeRef}
      className={`transition-all duration-300 ${isOver ? 'ring-4 ring-blue-500 ring-offset-4 scale-[1.02]' : ''}`}
    >
      {children}
    </div>
  );
}

interface VendorManagerProps {
  weddingId: string;
}

export default function VendorManager({ weddingId }: VendorManagerProps) {
  const { showToast } = useToast();
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [filterMode, setFilterMode] = useState<'all' | 'booked' | 'favorite' | 'pending'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [draggedVendor, setDraggedVendor] = useState<Vendor | null>(null);
  const [comparisonVendors, setComparisonVendors] = useState<Vendor[]>([]);
  const [showComparison, setShowComparison] = useState(false);
  const [bookingVendor, setBookingVendor] = useState<Vendor | null>(null);
  const [selectedVendorId, setSelectedVendorId] = useState<string | null>(null);
  const [showAddForm, setShowAddForm] = useState(false);

  const canAddVendor = () => true;

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  useEffect(() => {
    loadVendors();
  }, [weddingId]);

  const loadVendors = async () => {
    try {
      const { data } = await supabase
        .from('vendors')
        .select('*')
        .eq('wedding_id', weddingId)
        .order('created_at', { ascending: false });

      if (data) setVendors(data);
    } catch (error) {
      console.error('Error loading vendors:', error);
    }
  };

  const handleDragStart = (event: any) => {
    const vendor = vendors.find(v => v.id === event.active.id);
    if (vendor) {
      setDraggedVendor(vendor);
    }
  };

  const handleDragEnd = async (event: any) => {
    const { active, over } = event;
    setDraggedVendor(null);

    if (!over) {
      console.log('No drop target');
      return;
    }

    console.log('Drag ended - Active:', active.id, 'Over:', over.id);

    const draggedVendor = vendors.find(v => v.id === active.id);
    if (!draggedVendor) {
      console.log('Vendor not found');
      return;
    }

    console.log('Vendor status:', draggedVendor.contract_status);

    let targetZone = over.id;

    if (over.id !== 'booked-zone' && over.id !== 'pool-zone') {
      const targetVendor = vendors.find(v => v.id === over.id);
      if (targetVendor) {
        targetZone = (targetVendor.contract_status === 'signed' || targetVendor.contract_status === 'completed')
          ? 'booked-zone'
          : 'pool-zone';
        console.log('Dropped on vendor, redirecting to zone:', targetZone);
      }
    }

    if (targetZone === 'booked-zone' && draggedVendor.contract_status !== 'signed' && draggedVendor.contract_status !== 'completed') {
      console.log('Opening booking dialog');
      setBookingVendor(draggedVendor);
    } else if (targetZone === 'pool-zone' && (draggedVendor.contract_status === 'signed' || draggedVendor.contract_status === 'completed')) {
      console.log('Moving to pool');
      try {
        const { error } = await supabase
          .from('vendors')
          .update({ contract_status: 'inquiry' })
          .eq('id', draggedVendor.id);

        if (error) throw error;

        showToast(`${VENDOR.SINGULAR} wurde zurück in den Pool verschoben`, 'success');
        loadVendors();
      } catch (error) {
        console.error('Error moving vendor to pool:', error);
        showToast('Fehler beim Verschieben', 'error');
      }
    } else {
      console.log('No action taken - Status check failed or wrong zone');
    }
  };

  const handleBookVendor = async (vendorId: string) => {
    const vendor = vendors.find(v => v.id === vendorId);
    if (!vendor) return;

    if (vendor.contract_status === 'signed' || vendor.contract_status === 'completed') {
      showToast(`Dieser ${VENDOR.SINGULAR} ist bereits gebucht`, 'info');
      return;
    }

    setBookingVendor(vendor);
  };

  const handleBookingConfirm = async (options: {
    linkToEvent: boolean;
    createBudgetItem: boolean;
    eventId?: string;
  }) => {
    if (!bookingVendor) return;

    try {
      await supabase
        .from('vendors')
        .update({ contract_status: 'signed' })
        .eq('id', bookingVendor.id);

      if (options.createBudgetItem && bookingVendor.total_cost && bookingVendor.total_cost > 0) {
        await supabase.from('budget_items').insert([{
          wedding_id: weddingId,
          category: bookingVendor.category,
          item_name: bookingVendor.name,
          estimated_cost: bookingVendor.total_cost,
          actual_cost: bookingVendor.total_cost,
          paid: false,
          vendor_id: bookingVendor.id,
          timeline_event_id: options.eventId || null,
          notes: `Automatisch angelegt für ${bookingVendor.name}`,
        }]);
      }

      if (options.linkToEvent && options.eventId) {
        await supabase
          .from('vendors')
          .update({ timeline_event_id: options.eventId })
          .eq('id', bookingVendor.id);
      }

      showToast(`${VENDOR.SINGULAR} erfolgreich gebucht!`, 'success');
      setBookingVendor(null);
      loadVendors();
    } catch (error) {
      console.error('Error booking vendor:', error);
      showToast('Fehler beim Buchen', 'error');
    }
  };

  const handleCompareToggle = (vendor: Vendor) => {
    if (comparisonVendors.find(v => v.id === vendor.id)) {
      setComparisonVendors(comparisonVendors.filter(v => v.id !== vendor.id));
    } else {
      if (comparisonVendors.length >= 2) {
        showToast(`Du kannst maximal 2 ${VENDOR.PLURAL} vergleichen`, 'info');
        return;
      }
      setComparisonVendors([...comparisonVendors, vendor]);
    }
  };

  useEffect(() => {
    if (comparisonVendors.length === 2) {
      setShowComparison(true);
    }
  }, [comparisonVendors]);

  const handleCloseComparison = () => {
    setShowComparison(false);
    setComparisonVendors([]);
  };

  const filteredVendors = vendors.filter(vendor => {
    if (filterMode === 'booked' && vendor.contract_status !== 'signed' && vendor.contract_status !== 'completed') return false;
    if (filterMode === 'favorite' && vendor.rating && vendor.rating >= 4) return false;
    if (filterMode === 'pending' && vendor.contract_status !== 'pending') return false;

    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      return (
        vendor.name.toLowerCase().includes(query) ||
        vendor.category.toLowerCase().includes(query) ||
        (vendor.description && vendor.description.toLowerCase().includes(query))
      );
    }

    return true;
  });

  const bookedVendors = filteredVendors.filter(v => v.contract_status === 'signed' || v.contract_status === 'completed');
  const poolVendors = filteredVendors.filter(v => v.contract_status !== 'signed' && v.contract_status !== 'completed');

  const moveVendorUp = async (vendor: Vendor) => {
    if (vendor.contract_status === 'signed' || vendor.contract_status === 'completed') return;
    setBookingVendor(vendor);
  };

  const moveVendorDown = async (vendor: Vendor) => {
    if (vendor.contract_status !== 'signed' && vendor.contract_status !== 'completed') return;
    try {
      await supabase
        .from('vendors')
        .update({ contract_status: 'inquiry' })
        .eq('id', vendor.id);

      showToast('Dienstleister wurde zurück in den Pool verschoben', 'success');
      loadVendors();
    } catch (error) {
      console.error('Error moving vendor:', error);
      showToast('Fehler beim Verschieben', 'error');
    }
  };

  return (
    <div className="space-y-4 md:space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
        <h2 className="text-2xl md:text-3xl font-bold text-[#0a253c]">{VENDOR.MODULE_NAME}</h2>
        <button
          onClick={() => setShowAddForm(true)}
          disabled={!canAddVendor()}
          className={`flex items-center gap-2 px-4 sm:px-6 py-2 sm:py-3 rounded-xl font-bold transition-all text-sm sm:text-base ${
            canAddVendor()
              ? 'bg-[#d4af37] text-[#0a253c] hover:bg-[#c19a2e]'
              : 'bg-gray-300 text-gray-600 cursor-not-allowed'
          }`}
        >
          <Plus className="w-4 h-4 sm:w-5 sm:h-5" />
          {VENDOR.ADD}
        </button>
      </div>

      <VendorKPIPanel vendors={vendors} />

      <div className="bg-white rounded-2xl p-4 sm:p-6 shadow-lg">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#666666]" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder={`${VENDOR.PLURAL} durchsuchen...`}
            className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
          />
        </div>
      </div>

      <DndContext
        sensors={sensors}
        collisionDetection={closestCenter}
        onDragStart={handleDragStart}
        onDragEnd={handleDragEnd}
      >
        <div className="space-y-6">
          <DroppableZone id="booked-zone" isActive={false}>
            <div className="bg-gradient-to-br from-green-50 to-white rounded-3xl p-6 shadow-xl border-2 border-green-200 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-green-200/20 to-transparent rounded-full blur-3xl"></div>

              <div className="relative">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-[#0a253c] mb-1">
                      Gebuchte {VENDOR.PLURAL}
                    </h3>
                    <p className="text-sm text-[#666666]">
                      {bookedVendors.length} {VENDOR.PLURAL} bestätigt
                    </p>
                  </div>
                </div>

                {bookedVendors.length === 0 ? (
                  <div className="text-center py-12 bg-white rounded-2xl border-2 border-dashed border-green-300">
                    <p className="text-[#666666] text-lg mb-2">Noch keine gebuchten {VENDOR.PLURAL}</p>
                    <p className="text-sm text-[#999999]">
                      Ziehe {VENDOR.PLURAL} aus dem Pool nach oben, um sie zu buchen
                    </p>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {bookedVendors.map(vendor => (
                      <div key={vendor.id} className="relative">
                        <DraggableVendorCard
                          vendor={vendor}
                          onUpdate={loadVendors}
                          onClick={() => setSelectedVendorId(vendor.id)}
                        />
                        <div className="absolute top-2 right-2 flex gap-1 opacity-0 hover:opacity-100 transition-opacity z-10">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              moveVendorDown(vendor);
                            }}
                            className="p-2 bg-white rounded-lg shadow-lg hover:bg-red-50 transition-all"
                            title="Zurück in den Pool"
                          >
                            <ArrowDown className="w-4 h-4 text-red-600" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </DroppableZone>

          <DroppableZone id="pool-zone" isActive={false}>
            <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-3xl p-6 shadow-xl border-2 border-[#d4af37]/30 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#d4af37]/10 to-transparent rounded-full blur-3xl"></div>

              <div className="relative">
                <div className="flex items-center justify-between mb-6">
                  <div>
                    <h3 className="text-2xl font-bold text-[#0a253c] mb-1">
                      {VENDOR.PLURAL}-Pool
                    </h3>
                    <p className="text-sm text-[#666666]">
                      {poolVendors.length} {VENDOR.PLURAL} verfügbar
                    </p>
                  </div>
                </div>

                {poolVendors.length === 0 ? (
                  <div className="text-center py-12 bg-white rounded-2xl border-2 border-dashed border-[#d4af37]">
                    <p className="text-[#666666] text-lg mb-2">Noch keine {VENDOR.PLURAL} im Pool</p>
                    <p className="text-sm text-[#999999] mb-4">
                      Füge {VENDOR.PLURAL} hinzu, um sie zu verwalten
                    </p>
                    <button
                      onClick={() => setShowAddForm(true)}
                      className="px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all"
                    >
                      Ersten {VENDOR.SINGULAR} hinzufügen
                    </button>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 max-h-[600px] overflow-y-auto pr-2">
                    {poolVendors.map(vendor => (
                      <div key={vendor.id} className="relative">
                        <DraggableVendorCard
                          vendor={vendor}
                          onUpdate={loadVendors}
                          onCompare={() => handleCompareToggle(vendor)}
                          isComparing={comparisonVendors.some(v => v.id === vendor.id)}
                          onClick={() => setSelectedVendorId(vendor.id)}
                        />
                        <div className="absolute top-2 right-2 flex gap-1 opacity-0 hover:opacity-100 transition-opacity z-10">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              moveVendorUp(vendor);
                            }}
                            className="p-2 bg-white rounded-lg shadow-lg hover:bg-green-50 transition-all"
                            title={VENDOR.BOOK}
                          >
                            <ArrowUp className="w-4 h-4 text-green-600" />
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </DroppableZone>
        </div>

        <DragOverlay>
          {draggedVendor && (
            <div className="scale-105 rotate-2">
              <VendorCard
                vendor={draggedVendor}
                onUpdate={() => {}}
                isDragging={true}
              />
            </div>
          )}
        </DragOverlay>
      </DndContext>

      {showComparison && comparisonVendors.length === 2 && (
        <VendorComparisonModal
          isOpen={showComparison}
          onClose={handleCloseComparison}
          vendor1={comparisonVendors[0]}
          vendor2={comparisonVendors[1]}
          onBook={handleBookVendor}
        />
      )}

      {bookingVendor && (
        <VendorBookingDialog
          isOpen={true}
          onClose={() => setBookingVendor(null)}
          vendor={bookingVendor}
          weddingId={weddingId}
          onConfirm={handleBookingConfirm}
        />
      )}

      {selectedVendorId && (
        <VendorDetailModal
          vendorId={selectedVendorId}
          weddingId={weddingId}
          onClose={() => setSelectedVendorId(null)}
          onUpdate={loadVendors}
        />
      )}
    </div>
  );
}
