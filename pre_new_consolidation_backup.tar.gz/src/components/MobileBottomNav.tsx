import { Home, CheckCircle, DollarSign, Users, Menu } from 'lucide-react';
import { useState, useEffect } from 'react';
import { TASK, BUDGET, GUEST, NAV } from '../constants/terminology';

type Tab = 'overview' | 'tasks' | 'budget' | 'guests' | 'more';

interface MobileBottomNavProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
  taskCount?: number;
  guestCount?: number;
}

export default function MobileBottomNav({
  activeTab,
  onTabChange,
  taskCount = 0,
  guestCount = 0
}: MobileBottomNavProps) {
  const [isVisible, setIsVisible] = useState(true);
  const [lastScrollY, setLastScrollY] = useState(0);

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollY = window.scrollY;

      if (currentScrollY < 50) {
        setIsVisible(true);
      } else if (currentScrollY > lastScrollY && currentScrollY > 100) {
        setIsVisible(false);
      } else if (currentScrollY < lastScrollY) {
        setIsVisible(true);
      }

      setLastScrollY(currentScrollY);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, [lastScrollY]);

  const navItems = [
    { id: 'overview' as Tab, icon: Home, label: NAV.OVERVIEW, badge: null },
    { id: 'tasks' as Tab, icon: CheckCircle, label: TASK.MODULE_NAME, badge: taskCount > 0 ? taskCount : null },
    { id: 'budget' as Tab, icon: DollarSign, label: BUDGET.MODULE_NAME, badge: null },
    { id: 'guests' as Tab, icon: Users, label: GUEST.MODULE_NAME, badge: guestCount > 0 ? guestCount : null },
    { id: 'more' as Tab, icon: Menu, label: 'Mehr', badge: null },
  ];

  return (
    <>
      <div className="h-[60px] sm:hidden" />

      <nav
        className={`
          fixed bottom-0 left-0 right-0
          bg-white border-t-2 border-gray-200
          shadow-[0_-4px_20px_rgba(0,0,0,0.1)]
          transition-transform duration-300 ease-in-out
          z-50 sm:hidden
          safe-area-bottom
          ${isVisible ? 'translate-y-0' : 'translate-y-full'}
        `}
      >
        <div className="flex items-center justify-around h-[60px] max-w-screen-xl mx-auto px-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;

            return (
              <button
                key={item.id}
                onClick={() => onTabChange(item.id)}
                className={`
                  relative flex flex-col items-center justify-center
                  min-w-[60px] flex-1 h-full
                  touch-target ripple
                  transition-all duration-200
                  ${isActive
                    ? 'text-[#d4af37]'
                    : 'text-gray-500 hover:text-gray-700 active:text-gray-900'
                  }
                `}
                aria-label={item.label}
                aria-current={isActive ? 'page' : undefined}
              >
                <div className="relative">
                  <Icon
                    className={`
                      w-6 h-6 transition-all duration-200
                      ${isActive ? 'scale-110' : 'scale-100'}
                    `}
                    strokeWidth={isActive ? 2.5 : 2}
                  />

                  {item.badge !== null && item.badge > 0 && (
                    <span className="
                      absolute -top-2 -right-2
                      min-w-[18px] h-[18px]
                      flex items-center justify-center
                      bg-red-500 text-white text-[10px] font-bold
                      rounded-full px-1
                      animate-pulse
                    ">
                      {item.badge > 99 ? '99+' : item.badge}
                    </span>
                  )}
                </div>

                <span className={`
                  text-[10px] font-medium mt-1
                  transition-all duration-200
                  ${isActive ? 'opacity-100 font-bold' : 'opacity-70'}
                `}>
                  {item.label}
                </span>

                {isActive && (
                  <div className="
                    absolute bottom-0 left-1/2 transform -translate-x-1/2
                    w-12 h-1 bg-[#d4af37] rounded-t-full
                    animate-slide-in-smooth
                  " />
                )}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
