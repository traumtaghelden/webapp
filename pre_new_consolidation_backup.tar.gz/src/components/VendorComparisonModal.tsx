import { X, Star, Mail, Phone, DollarSign, MapPin, ExternalLink, CheckCircle, ArrowRight } from 'lucide-react';
import { type Vendor } from '../lib/supabase';

interface VendorComparisonModalProps {
  isOpen: boolean;
  onClose: () => void;
  vendor1: Vendor;
  vendor2: Vendor;
  onBook: (vendorId: string) => void;
}

export default function VendorComparisonModal({
  isOpen,
  onClose,
  vendor1,
  vendor2,
  onBook
}: VendorComparisonModalProps) {
  if (!isOpen) return null;

  const ComparisonRow = ({ label, value1, value2, icon }: {
    label: string;
    value1: React.ReactNode;
    value2: React.ReactNode;
    icon?: React.ReactNode;
  }) => (
    <div className="grid grid-cols-3 gap-4 py-4 border-b border-[#d4af37]/20">
      <div className="flex items-center gap-2 text-sm font-semibold text-[#666666]">
        {icon}
        {label}
      </div>
      <div className="text-sm text-[#0a253c] font-medium">{value1}</div>
      <div className="text-sm text-[#0a253c] font-medium">{value2}</div>
    </div>
  );

  return (
    <div
      className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-[9999] p-4"
      style={{ animation: 'fadeIn 0.3s ease-out' }}
    >
      <div
        className="bg-white rounded-3xl shadow-2xl max-w-5xl w-full max-h-[90vh] flex flex-col transform transition-all duration-300"
        style={{ animation: 'zoomIn 0.3s ease-out' }}
      >
        <div className="p-6 border-b border-[#d4af37]/20 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 hover:bg-[#f7f2eb] rounded-full transition-colors"
          >
            <X className="w-6 h-6 text-[#333333]" />
          </button>

          <h2 className="text-2xl sm:text-3xl font-bold text-[#0a253c] mb-2 text-center">
            Dienstleister-Vergleich
          </h2>
          <p className="text-sm sm:text-base text-[#666666] text-center">
            Vergleiche beide {VENDOR.PLURAL} direkt nebeneinander
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div></div>
            <div className="bg-gradient-to-br from-blue-50 to-[#f7f2eb] rounded-2xl p-4 text-center border-2 border-blue-200">
              <div className="flex items-center justify-center gap-2 mb-2">
                <h3 className="text-lg font-bold text-[#0a253c]">{vendor1.name}</h3>
                {vendor1.rating && vendor1.rating >= 4 && (
                  <Star className="w-5 h-5 text-[#d4af37]" fill="currentColor" />
                )}
              </div>
              <span className="inline-block px-3 py-1 bg-[#d4af37]/10 text-[#d4af37] rounded-full text-xs font-semibold">
                {vendor1.category}
              </span>
            </div>
            <div className="bg-gradient-to-br from-green-50 to-[#f7f2eb] rounded-2xl p-4 text-center border-2 border-green-200">
              <div className="flex items-center justify-center gap-2 mb-2">
                <h3 className="text-lg font-bold text-[#0a253c]">{vendor2.name}</h3>
                {vendor2.rating && vendor2.rating >= 4 && (
                  <Star className="w-5 h-5 text-[#d4af37]" fill="currentColor" />
                )}
              </div>
              <span className="inline-block px-3 py-1 bg-[#d4af37]/10 text-[#d4af37] rounded-full text-xs font-semibold">
                {vendor2.category}
              </span>
            </div>
          </div>

          <div className="bg-[#f7f2eb] rounded-2xl p-6">
            <ComparisonRow
              label="Preis"
              icon={<DollarSign className="w-4 h-4 text-green-600" />}
              value1={
                vendor1.total_cost && vendor1.total_cost > 0
                  ? `${Number(vendor1.total_cost).toLocaleString('de-DE')} €`
                  : 'Auf Anfrage'
              }
              value2={
                vendor2.total_cost && vendor2.total_cost > 0
                  ? `${Number(vendor2.total_cost).toLocaleString('de-DE')} €`
                  : 'Auf Anfrage'
              }
            />

            <ComparisonRow
              label="E-Mail"
              icon={<Mail className="w-4 h-4 text-[#d4af37]" />}
              value1={
                vendor1.email ? (
                  <a href={`mailto:${vendor1.email}`} className="text-[#d4af37] hover:underline">
                    {vendor1.email}
                  </a>
                ) : (
                  <span className="text-[#999999]">Nicht angegeben</span>
                )
              }
              value2={
                vendor2.email ? (
                  <a href={`mailto:${vendor2.email}`} className="text-[#d4af37] hover:underline">
                    {vendor2.email}
                  </a>
                ) : (
                  <span className="text-[#999999]">Nicht angegeben</span>
                )
              }
            />

            <ComparisonRow
              label="Telefon"
              icon={<Phone className="w-4 h-4 text-[#d4af37]" />}
              value1={
                vendor1.phone ? (
                  <a href={`tel:${vendor1.phone}`} className="text-[#d4af37] hover:underline">
                    {vendor1.phone}
                  </a>
                ) : (
                  <span className="text-[#999999]">Nicht angegeben</span>
                )
              }
              value2={
                vendor2.phone ? (
                  <a href={`tel:${vendor2.phone}`} className="text-[#d4af37] hover:underline">
                    {vendor2.phone}
                  </a>
                ) : (
                  <span className="text-[#999999]">Nicht angegeben</span>
                )
              }
            />

            <ComparisonRow
              label="Standort"
              icon={<MapPin className="w-4 h-4 text-[#d4af37]" />}
              value1={vendor1.location || <span className="text-[#999999]">Nicht angegeben</span>}
              value2={vendor2.location || <span className="text-[#999999]">Nicht angegeben</span>}
            />

            <ComparisonRow
              label="Website"
              icon={<ExternalLink className="w-4 h-4 text-[#d4af37]" />}
              value1={
                vendor1.website ? (
                  <a
                    href={vendor1.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#d4af37] hover:underline"
                  >
                    Zur Website
                  </a>
                ) : (
                  <span className="text-[#999999]">Nicht vorhanden</span>
                )
              }
              value2={
                vendor2.website ? (
                  <a
                    href={vendor2.website}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-[#d4af37] hover:underline"
                  >
                    Zur Website
                  </a>
                ) : (
                  <span className="text-[#999999]">Nicht vorhanden</span>
                )
              }
            />

            <ComparisonRow
              label="Status"
              icon={<CheckCircle className="w-4 h-4 text-green-600" />}
              value1={
                <span className={`inline-block px-2 py-1 rounded-full text-xs font-semibold ${
                  vendor1.contract_status === 'signed' || vendor1.contract_status === 'completed' ? 'bg-green-100 text-green-700' :
                  vendor1.contract_status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                  vendor1.contract_status === 'cancelled' ? 'bg-red-100 text-red-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {vendor1.contract_status === 'signed' ? 'Gebucht' :
                   vendor1.contract_status === 'completed' ? 'Abgeschlossen' :
                   vendor1.contract_status === 'pending' ? 'In Verhandlung' :
                   vendor1.contract_status === 'cancelled' ? 'Storniert' : 'Anfrage'}
                </span>
              }
              value2={
                <span className={`inline-block px-2 py-1 rounded-full text-xs font-semibold ${
                  vendor2.contract_status === 'signed' || vendor2.contract_status === 'completed' ? 'bg-green-100 text-green-700' :
                  vendor2.contract_status === 'pending' ? 'bg-yellow-100 text-yellow-700' :
                  vendor2.contract_status === 'cancelled' ? 'bg-red-100 text-red-700' :
                  'bg-gray-100 text-gray-700'
                }`}>
                  {vendor2.contract_status === 'signed' ? 'Gebucht' :
                   vendor2.contract_status === 'completed' ? 'Abgeschlossen' :
                   vendor2.contract_status === 'pending' ? 'In Verhandlung' :
                   vendor2.contract_status === 'cancelled' ? 'Storniert' : 'Anfrage'}
                </span>
              }
            />

            {(vendor1.description || vendor2.description) && (
              <div className="grid grid-cols-3 gap-4 py-4 border-b border-[#d4af37]/20">
                <div className="text-sm font-semibold text-[#666666]">Beschreibung</div>
                <div className="text-sm text-[#0a253c]">
                  {vendor1.description || <span className="text-[#999999]">Keine Beschreibung</span>}
                </div>
                <div className="text-sm text-[#0a253c]">
                  {vendor2.description || <span className="text-[#999999]">Keine Beschreibung</span>}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="p-6 border-t border-[#d4af37]/20 bg-[#f7f2eb]">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <button
              onClick={() => {
                onBook(vendor1.id);
                onClose();
              }}
              disabled={vendor1.contract_status === 'signed' || vendor1.contract_status === 'completed'}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-blue-500 text-white rounded-xl font-bold hover:bg-blue-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <CheckCircle className="w-5 h-5" />
              {vendor1.name} buchen
            </button>
            <button
              onClick={onClose}
              className="flex items-center justify-center gap-2 px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-bold hover:bg-[#d4af37]/10 transition-all"
            >
              <ArrowRight className="w-5 h-5" />
              Zurück zum Pool
            </button>
            <button
              onClick={() => {
                onBook(vendor2.id);
                onClose();
              }}
              disabled={vendor2.contract_status === 'signed' || vendor2.contract_status === 'completed'}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <CheckCircle className="w-5 h-5" />
              {vendor2.name} buchen
            </button>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; }
          to { opacity: 1; }
        }
        @keyframes zoomIn {
          from {
            opacity: 0;
            transform: scale(0.9) translateY(20px);
          }
          to {
            opacity: 1;
            transform: scale(1) translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
