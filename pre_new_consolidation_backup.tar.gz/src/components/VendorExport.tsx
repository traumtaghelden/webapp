import { Download, FileText } from 'lucide-react';
import { Vendor } from '../lib/supabase';

interface VendorExportProps {
  vendors: Vendor[];
  onClose: () => void;
}

export default function VendorExport({ vendors, onClose }: VendorExportProps) {
  const exportToCSV = () => {
    const headers = [
      'Name',
      'Kategorie',
      'Ansprechpartner',
      'E-Mail',
      'Telefon',
      'Adresse',
      'Website',
      'Vertragsstatus',
      'Gesamtkosten',
      'Bereits bezahlt',
      'Offener Betrag',
      'Zahlungsfrist',
      'Bewertung',
      'Notizen',
    ];

    const categoryLabels: Record<string, string> = {
      location: 'Location',
      catering: 'Catering',
      photography: 'Fotografie',
      videography: 'Videografie',
      music: 'Musik/DJ',
      flowers: 'Floristik',
      decoration: 'Dekoration',
      dress: 'Brautmode',
      hair_makeup: 'Frisur & Make-up',
      transportation: 'Transport',
      cake: 'Hochzeitstorte',
      invitations: 'Einladungen',
      other: 'Sonstiges',
    };

    const statusLabels: Record<string, string> = {
      inquiry: 'Anfrage',
      pending: 'In Verhandlung',
      signed: 'Vertrag unterschrieben',
      completed: 'Abgeschlossen',
      cancelled: 'Storniert',
    };

    const rows = vendors.map((vendor) => [
      vendor.name,
      categoryLabels[vendor.category] || vendor.category,
      vendor.contact_name || '',
      vendor.email || '',
      vendor.phone || '',
      vendor.address || '',
      vendor.website || '',
      statusLabels[vendor.contract_status] || vendor.contract_status,
      vendor.total_cost?.toFixed(2) || '0.00',
      vendor.paid_amount?.toFixed(2) || '0.00',
      vendor.total_cost ? (vendor.total_cost - vendor.paid_amount).toFixed(2) : '0.00',
      vendor.payment_due_date || '',
      vendor.rating?.toString() || '',
      vendor.notes || '',
    ]);

    const csvContent = [
      headers.join(','),
      ...rows.map((row) =>
        row.map((cell) => `"${cell.toString().replace(/"/g, '""')}"`).join(',')
      ),
    ].join('\n');

    const blob = new Blob(['\ufeff' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `dienstleister_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    onClose();
  };

  const exportToPDF = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Bitte Pop-ups für diese Seite erlauben');
      return;
    }

    const categoryLabels: Record<string, string> = {
      location: 'Location',
      catering: 'Catering',
      photography: 'Fotografie',
      videography: 'Videografie',
      music: 'Musik/DJ',
      flowers: 'Floristik',
      decoration: 'Dekoration',
      dress: 'Brautmode',
      hair_makeup: 'Frisur & Make-up',
      transportation: 'Transport',
      cake: 'Hochzeitstorte',
      invitations: 'Einladungen',
      other: 'Sonstiges',
    };

    const statusLabels: Record<string, string> = {
      inquiry: 'Anfrage',
      pending: 'In Verhandlung',
      signed: 'Vertrag unterschrieben',
      completed: 'Abgeschlossen',
      cancelled: 'Storniert',
    };

    const totalCost = vendors.reduce((sum, v) => sum + (v.total_cost || 0), 0);
    const totalPaid = vendors.reduce((sum, v) => sum + (v.paid_amount || 0), 0);

    const html = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8">
          <title>Dienstleister Übersicht</title>
          <style>
            body {
              font-family: Arial, sans-serif;
              padding: 40px;
              color: #0a253c;
            }
            h1 {
              color: #d4af37;
              border-bottom: 3px solid #d4af37;
              padding-bottom: 10px;
              margin-bottom: 30px;
            }
            .summary {
              background: #f7f2eb;
              padding: 20px;
              border-radius: 10px;
              margin-bottom: 30px;
            }
            .summary-grid {
              display: grid;
              grid-template-columns: repeat(3, 1fr);
              gap: 20px;
            }
            .summary-item {
              text-align: center;
            }
            .summary-label {
              font-size: 14px;
              color: #666;
              margin-bottom: 5px;
            }
            .summary-value {
              font-size: 24px;
              font-weight: bold;
              color: #d4af37;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            th {
              background: #d4af37;
              color: #0a253c;
              padding: 12px;
              text-align: left;
              font-weight: bold;
            }
            td {
              padding: 10px;
              border-bottom: 1px solid #ddd;
            }
            tr:hover {
              background: #f7f2eb;
            }
            .vendor-name {
              font-weight: bold;
              color: #0a253c;
            }
            .status {
              display: inline-block;
              padding: 4px 12px;
              border-radius: 12px;
              font-size: 12px;
              font-weight: bold;
            }
            .status-inquiry { background: #e5e7eb; color: #374151; }
            .status-pending { background: #fef3c7; color: #92400e; }
            .status-signed { background: #dbeafe; color: #1e40af; }
            .status-completed { background: #d1fae5; color: #065f46; }
            .status-cancelled { background: #fee2e2; color: #991b1b; }
            .rating {
              color: #d4af37;
            }
            .footer {
              margin-top: 40px;
              text-align: center;
              color: #666;
              font-size: 12px;
            }
            @media print {
              body {
                padding: 20px;
              }
              .no-print {
                display: none;
              }
            }
          </style>
        </head>
        <body>
          <h1>Dienstleister Übersicht</h1>
          <p style="color: #666; margin-bottom: 20px;">
            Exportiert am ${new Date().toLocaleDateString('de-DE', {
              year: 'numeric',
              month: 'long',
              day: 'numeric'
            })}
          </p>

          <div class="summary">
            <div class="summary-grid">
              <div class="summary-item">
                <div class="summary-label">Anzahl Dienstleister</div>
                <div class="summary-value">${vendors.length}</div>
              </div>
              <div class="summary-item">
                <div class="summary-label">Gesamtkosten</div>
                <div class="summary-value">${totalCost.toLocaleString('de-DE')} €</div>
              </div>
              <div class="summary-item">
                <div class="summary-label">Bereits bezahlt</div>
                <div class="summary-value">${totalPaid.toLocaleString('de-DE')} €</div>
              </div>
            </div>
          </div>

          <table>
            <thead>
              <tr>
                <th>Name</th>
                <th>Kategorie</th>
                <th>Kontakt</th>
                <th>Status</th>
                <th style="text-align: right;">Kosten</th>
                <th>Bewertung</th>
              </tr>
            </thead>
            <tbody>
              ${vendors
                .map(
                  (vendor) => `
                <tr>
                  <td class="vendor-name">${vendor.name}</td>
                  <td>${categoryLabels[vendor.category] || vendor.category}</td>
                  <td>
                    ${vendor.contact_name || '-'}<br>
                    ${vendor.email ? `<small>${vendor.email}</small>` : ''}
                    ${vendor.phone ? `<br><small>${vendor.phone}</small>` : ''}
                  </td>
                  <td>
                    <span class="status status-${vendor.contract_status}">
                      ${statusLabels[vendor.contract_status] || vendor.contract_status}
                    </span>
                  </td>
                  <td style="text-align: right; font-weight: bold;">
                    ${vendor.total_cost ? `${vendor.total_cost.toLocaleString('de-DE')} €` : '-'}
                  </td>
                  <td class="rating">
                    ${vendor.rating ? '★'.repeat(vendor.rating) + '☆'.repeat(5 - vendor.rating) : '-'}
                  </td>
                </tr>
              `
                )
                .join('')}
            </tbody>
          </table>

          <div class="footer">
            <p>Hochzeitsplaner - Dienstleister Verwaltung</p>
          </div>

          <div class="no-print" style="margin-top: 30px; text-align: center;">
            <button onclick="window.print()" style="padding: 12px 24px; background: #d4af37; color: #0a253c; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 16px;">
              Drucken / Als PDF speichern
            </button>
            <button onclick="window.close()" style="padding: 12px 24px; background: #e5e7eb; color: #374151; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; font-size: 16px; margin-left: 10px;">
              Schließen
            </button>
          </div>
        </body>
      </html>
    `;

    printWindow.document.write(html);
    printWindow.document.close();
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-md w-full p-8">
        <h2 className="text-2xl font-bold text-[#0a253c] mb-6">Dienstleister exportieren</h2>
        <p className="text-gray-600 mb-6">
          Exportieren Sie {vendors.length} Dienstleister als CSV oder PDF
        </p>

        <div className="space-y-3">
          <button
            onClick={exportToCSV}
            className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-green-500 text-white rounded-xl font-bold hover:bg-green-600 transition-all"
          >
            <Download className="w-5 h-5" />
            Als CSV exportieren
          </button>

          <button
            onClick={exportToPDF}
            className="w-full flex items-center justify-center gap-3 px-6 py-4 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] transition-all"
          >
            <FileText className="w-5 h-5" />
            Als PDF exportieren
          </button>

          <button
            onClick={onClose}
            className="w-full px-6 py-4 bg-gray-200 text-gray-700 rounded-xl font-bold hover:bg-gray-300 transition-all"
          >
            Abbrechen
          </button>
        </div>

        <div className="mt-6 p-4 bg-blue-50 rounded-xl border-2 border-blue-200">
          <p className="text-sm text-blue-900">
            <strong>Hinweis:</strong> CSV-Dateien können in Excel oder Google Sheets geöffnet werden.
            PDF-Export öffnet eine Druckvorschau.
          </p>
        </div>
      </div>
    </div>
  );
}
