import { useState } from 'react';
import { Kanban, List, Calendar, FileText, Users, GitBranch, TrendingUp, ClipboardList, CheckCircle, Clock, AlertTriangle } from 'lucide-react';
import { type Task } from '../lib/supabase';
import TabContainer, { type Tab } from './common/TabContainer';
import PageHeaderWithStats, { type StatCard } from './common/PageHeaderWithStats';
import TaskKanbanTab from './Tasks/TaskKanbanTab';
import TaskListView from './Tasks/TaskListView';
import TaskCalendarTab from './Tasks/TaskCalendarTab';
import TaskTemplatesTab from './Tasks/TaskTemplatesTab';
import TaskTeamTab from './Tasks/TaskTeamTab';
import TaskDependenciesTab from './Tasks/TaskDependenciesTab';
import TaskProgressTab from './Tasks/TaskProgressTab';
import TaskAddModalDirect from './TaskAddModalDirect';
import { TASK } from '../constants/terminology';

interface TaskManagerProps {
  weddingId: string;
  tasks: Task[];
  onUpdate: () => void;
}

export default function TaskManager({ weddingId, tasks, onUpdate }: TaskManagerProps) {
  const [showAddTask, setShowAddTask] = useState(false);

  const totalTasks = tasks.length;
  const completedTasks = tasks.filter(t => t.status === 'completed').length;
  const pendingTasks = tasks.filter(t => t.status === 'pending' || t.status === 'in_progress').length;
  const overdueTasks = tasks.filter(t => {
    if (!t.due_date || t.status === 'completed') return false;
    return new Date(t.due_date) < new Date();
  }).length;

  const completionRate = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;

  const stats: StatCard[] = [
    {
      icon: <ClipboardList className="w-6 h-6 text-white" />,
      label: `Gesamt ${TASK.PLURAL}`,
      value: totalTasks,
      subtitle: `${completionRate}% abgeschlossen`,
      color: 'yellow'
    },
    {
      icon: <CheckCircle className="w-6 h-6 text-white" />,
      label: 'Erledigt',
      value: completedTasks,
      subtitle: totalTasks > 0 ? `${completionRate}% der ${TASK.PLURAL}` : '0%',
      color: 'green'
    },
    {
      icon: <Clock className="w-6 h-6 text-white" />,
      label: 'Offen',
      value: pendingTasks,
      subtitle: totalTasks > 0 ? `${Math.round((pendingTasks/totalTasks)*100)}% verbleibend` : '0%',
      color: 'blue'
    },
    {
      icon: <AlertTriangle className="w-6 h-6 text-white" />,
      label: 'Überfällig',
      value: overdueTasks,
      subtitle: overdueTasks > 0 ? 'Benötigt Aufmerksamkeit' : 'Keine überfälligen',
      color: 'red'
    }
  ];

  const tabs: Tab[] = [
    {
      id: 'kanban',
      label: 'Kanban',
      icon: <Kanban className="w-4 h-4" />,
      content: (
        <TaskKanbanTab
          weddingId={weddingId}
          tasks={tasks}
          onUpdate={onUpdate}
          onAddTask={() => setShowAddTask(true)}
        />
      ),
    },
    {
      id: 'list',
      label: 'Liste',
      icon: <List className="w-4 h-4" />,
      badge: tasks.length,
      content: (
        <TaskListView
          tasks={tasks}
          weddingId={weddingId}
          onUpdate={onUpdate}
        />
      ),
    },
    {
      id: 'calendar',
      label: 'Kalender',
      icon: <Calendar className="w-4 h-4" />,
      content: (
        <TaskCalendarTab
          weddingId={weddingId}
          tasks={tasks}
          onUpdate={onUpdate}
        />
      ),
    },
    {
      id: 'templates',
      label: 'Vorlagen',
      icon: <FileText className="w-4 h-4" />,
      content: (
        <TaskTemplatesTab
          weddingId={weddingId}
          onUpdate={onUpdate}
        />
      ),
    },
    {
      id: 'team',
      label: 'Team',
      icon: <Users className="w-4 h-4" />,
      content: (
        <TaskTeamTab
          weddingId={weddingId}
          tasks={tasks}
          onUpdate={onUpdate}
        />
      ),
    },
    {
      id: 'dependencies',
      label: 'Abhängigkeiten',
      icon: <GitBranch className="w-4 h-4" />,
      content: (
        <TaskDependenciesTab
          weddingId={weddingId}
          tasks={tasks}
          onUpdate={onUpdate}
        />
      ),
    },
    {
      id: 'progress',
      label: 'Fortschritt',
      icon: <TrendingUp className="w-4 h-4" />,
      badge: completedTasks > 0 ? `${Math.round((completedTasks / tasks.length) * 100)}%` : undefined,
      content: <TaskProgressTab tasks={tasks} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeaderWithStats
        title={TASK.MODULE_NAME}
        subtitle="Organisiere deine Hochzeitsplanung"
        stats={stats}
      />

      <TabContainer
        tabs={tabs}
        defaultTab="kanban"
        storageKey={`task-tab-${weddingId}`}
        urlParam="taskTab"
      />

      <TaskAddModalDirect
        isOpen={showAddTask}
        onClose={() => {
          setShowAddTask(false);
        }}
        weddingId={weddingId}
        onSuccess={() => {
          onUpdate();
        }}
      />
    </div>
  );
}
