import { useState, useEffect } from 'react';
import { Calendar, Plus, Trash2, Check, AlertCircle, Percent, DollarSign, Clock, Edit2 } from 'lucide-react';
import { supabase, type BudgetPayment } from '../lib/supabase';

interface PaymentPlanManagerProps {
  budgetItemId: string;
  weddingId: string;
  totalAmount: number;
  weddingDate: string;
  onUpdate: () => void;
}

interface PaymentPlanTemplate {
  id: string;
  name: string;
  description: string;
  payment_schedule: any[];
  is_default: boolean;
}

export default function PaymentPlanManager({
  budgetItemId,
  weddingId,
  totalAmount,
  weddingDate,
  onUpdate
}: PaymentPlanManagerProps) {
  const [payments, setPayments] = useState<BudgetPayment[]>([]);
  const [templates, setTemplates] = useState<PaymentPlanTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [showAddCustom, setShowAddCustom] = useState(false);
  const [animatingPayment, setAnimatingPayment] = useState<string | null>(null);
  const [customPayment, setCustomPayment] = useState({
    amount: '',
    due_date: '',
    payment_type: 'milestone' as 'deposit' | 'milestone' | 'final' | 'monthly',
    percentage_of_total: ''
  });

  useEffect(() => {
    loadData();
  }, [budgetItemId]);

  const loadData = async () => {
    try {
      const [paymentsData, templatesData] = await Promise.all([
        supabase
          .from('budget_payments')
          .select('*')
          .eq('budget_item_id', budgetItemId)
          .order('due_date', { ascending: true }),
        supabase
          .from('payment_plan_templates')
          .select('*')
          .order('is_default', { ascending: false })
      ]);

      if (paymentsData.data) setPayments(paymentsData.data);
      if (templatesData.data) setTemplates(templatesData.data);
    } catch (error) {
      console.error('Error loading payment data:', error);
    } finally {
      setLoading(false);
    }
  };

  const applyTemplate = async (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (!template) return;

    try {
      await supabase
        .from('budget_payments')
        .delete()
        .eq('budget_item_id', budgetItemId);

      const weddingDateTime = new Date(weddingDate);
      const paymentsToInsert = template.payment_schedule.map((schedule: any) => {
        let dueDate = new Date();

        if (schedule.trigger === 'contract') {
          dueDate = new Date();
        } else if (schedule.trigger === 'before_wedding') {
          dueDate = new Date(weddingDateTime);
          dueDate.setDate(dueDate.getDate() - (schedule.days_offset || 0));
        } else if (schedule.trigger === 'after_wedding') {
          dueDate = new Date(weddingDateTime);
          dueDate.setDate(dueDate.getDate() + (schedule.days_offset || 0));
        }

        const amount = totalAmount * (schedule.percentage / 100);

        return {
          budget_item_id: budgetItemId,
          amount: amount,
          due_date: dueDate.toISOString().split('T')[0],
          status: 'pending',
          payment_type: schedule.type,
          percentage_of_total: schedule.percentage,
          trigger_date_type: schedule.trigger,
          days_offset: schedule.days_offset || 0,
          payment_method: 'bank_transfer'
        };
      });

      await supabase.from('budget_payments').insert(paymentsToInsert);
      await loadData();
      onUpdate();
      setSelectedTemplate('');
    } catch (error) {
      console.error('Error applying template:', error);
    }
  };

  const handleAddCustomPayment = async () => {
    if (!customPayment.amount && !customPayment.percentage_of_total) return;
    if (!customPayment.due_date) return;

    try {
      const amount = customPayment.percentage_of_total
        ? totalAmount * (parseFloat(customPayment.percentage_of_total) / 100)
        : parseFloat(customPayment.amount);

      await supabase.from('budget_payments').insert([{
        budget_item_id: budgetItemId,
        amount: amount,
        due_date: customPayment.due_date,
        status: 'pending',
        payment_type: customPayment.payment_type,
        percentage_of_total: customPayment.percentage_of_total ? parseFloat(customPayment.percentage_of_total) : null,
        trigger_date_type: 'fixed',
        payment_method: 'bank_transfer'
      }]);

      setCustomPayment({
        amount: '',
        due_date: '',
        payment_type: 'milestone',
        percentage_of_total: ''
      });
      setShowAddCustom(false);
      await loadData();
      onUpdate();
    } catch (error) {
      console.error('Error adding custom payment:', error);
    }
  };

  const handleDeletePayment = async (paymentId: string) => {
    try {
      await supabase.from('budget_payments').delete().eq('id', paymentId);
      await loadData();
      onUpdate();
    } catch (error) {
      console.error('Error deleting payment:', error);
    }
  };

  const handleTogglePaymentStatus = async (payment: BudgetPayment) => {
    try {
      setAnimatingPayment(payment.id);
      const newStatus = payment.status === 'paid' ? 'pending' : 'paid';
      await supabase
        .from('budget_payments')
        .update({
          status: newStatus,
          payment_date: newStatus === 'paid' ? new Date().toISOString().split('T')[0] : null
        })
        .eq('id', payment.id);

      await updateBudgetItemPaymentStatus();
      await loadData();
      onUpdate();

      setTimeout(() => setAnimatingPayment(null), 600);
    } catch (error) {
      console.error('Error updating payment status:', error);
      setAnimatingPayment(null);
    }
  };

  const updateBudgetItemPaymentStatus = async () => {
    try {
      const { data: paymentsData } = await supabase
        .from('budget_payments')
        .select('*')
        .eq('budget_item_id', budgetItemId);

      const { data: budgetItemData } = await supabase
        .from('budget_items')
        .select('actual_cost')
        .eq('id', budgetItemId)
        .maybeSingle();

      if (paymentsData && budgetItemData) {
        const totalPaid = paymentsData
          .filter(p => p.status === 'paid')
          .reduce((sum, p) => sum + Number(p.amount), 0);

        let newPaymentStatus: 'pending' | 'partial' | 'paid' | 'overdue' = 'pending';

        if (totalPaid >= budgetItemData.actual_cost) {
          newPaymentStatus = 'paid';
        } else if (totalPaid > 0) {
          newPaymentStatus = 'partial';
        } else {
          const hasOverduePayments = paymentsData.some(p => p.status === 'overdue');
          newPaymentStatus = hasOverduePayments ? 'overdue' : 'pending';
        }

        await supabase
          .from('budget_items')
          .update({
            payment_status: newPaymentStatus,
            paid: newPaymentStatus === 'paid'
          })
          .eq('id', budgetItemId);
      }
    } catch (error) {
      console.error('Error updating budget item payment status:', error);
    }
  };

  const totalPaid = payments.filter(p => p.status === 'paid').reduce((sum, p) => sum + Number(p.amount), 0);
  const totalPending = payments.filter(p => p.status === 'pending').reduce((sum, p) => sum + Number(p.amount), 0);
  const totalPlanned = payments.reduce((sum, p) => sum + Number(p.amount), 0);
  const paymentProgress = totalAmount > 0 ? (totalPaid / totalAmount) * 100 : 0;

  const getPaymentTypeLabel = (type: string) => {
    switch (type) {
      case 'deposit': return 'Anzahlung';
      case 'milestone': return 'Teilzahlung';
      case 'final': return 'Restzahlung';
      case 'monthly': return 'Monatlich';
      default: return type;
    }
  };

  const getPaymentUrgency = (dueDate: string, status: string) => {
    if (status === 'paid') return 'paid';
    const today = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays < 0) return 'overdue';
    if (diffDays <= 7) return 'urgent';
    if (diffDays <= 30) return 'soon';
    return 'future';
  };

  if (loading) {
    return <div className="text-center py-8">Lade Zahlungspläne...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-4 gap-4">
        <div className="p-4 bg-green-50 border border-green-200 rounded-xl">
          <p className="text-sm text-gray-600 mb-1">Bezahlt</p>
          <p className="text-2xl font-bold text-green-600">{totalPaid.toFixed(2)}€</p>
        </div>
        <div className="p-4 bg-orange-50 border border-orange-200 rounded-xl">
          <p className="text-sm text-gray-600 mb-1">Ausstehend</p>
          <p className="text-2xl font-bold text-orange-600">{totalPending.toFixed(2)}€</p>
        </div>
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-xl">
          <p className="text-sm text-gray-600 mb-1">Gesamtbetrag</p>
          <p className="text-2xl font-bold text-[#0a253c]">{totalAmount.toFixed(2)}€</p>
        </div>
        <div className="p-4 bg-purple-50 border border-purple-200 rounded-xl">
          <p className="text-sm text-gray-600 mb-1">Fortschritt</p>
          <p className="text-2xl font-bold text-purple-600">{paymentProgress.toFixed(0)}%</p>
        </div>
      </div>

      {totalPlanned > totalAmount && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-xl flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
          <div className="text-sm text-red-700">
            <p className="font-semibold">Warnung: Zahlungen übersteigen Gesamtbetrag</p>
            <p>Geplante Zahlungen: {totalPlanned.toFixed(2)}€ / Budget: {totalAmount.toFixed(2)}€</p>
          </div>
        </div>
      )}

      <div className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-xl p-4">
        <h4 className="font-semibold text-[#0a253c] mb-3 flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Zahlungsplan-Vorlage anwenden
        </h4>
        <div className="grid grid-cols-2 gap-3">
          {templates.map((template) => (
            <button
              key={template.id}
              onClick={() => applyTemplate(template.id)}
              className={`p-3 rounded-lg border-2 text-left transition-all hover:shadow-md ${
                template.is_default
                  ? 'bg-white border-blue-400 hover:border-blue-500'
                  : 'bg-white border-gray-200 hover:border-blue-300'
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="font-semibold text-[#0a253c]">{template.name}</p>
                  <p className="text-xs text-gray-600 mt-1">{template.description}</p>
                </div>
                {template.is_default && (
                  <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-bold">
                    Standard
                  </span>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="flex items-center justify-between mb-4">
          <h4 className="font-semibold text-[#0a253c] flex items-center gap-2">
            <Calendar className="w-5 h-5" />
            Geplante Zahlungen ({payments.length})
          </h4>
          <button
            onClick={() => setShowAddCustom(!showAddCustom)}
            className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-[#0a253c] rounded-lg hover:bg-[#c19a2e] transition-all font-medium"
          >
            <Edit2 className="w-4 h-4" />
            {payments.length > 0 ? 'Zahlungsplan bearbeiten' : 'Zahlungsplan erstellen'}
          </button>
        </div>

        {showAddCustom && (
          <div className="mb-4 p-4 bg-gray-50 border border-gray-200 rounded-xl space-y-3">
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Betrag (€)</label>
                <input
                  type="number"
                  step="0.01"
                  value={customPayment.amount}
                  onChange={(e) => setCustomPayment({ ...customPayment, amount: e.target.value, percentage_of_total: '' })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  placeholder="z.B. 1000.00"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Oder Prozent (%)</label>
                <input
                  type="number"
                  step="0.01"
                  value={customPayment.percentage_of_total}
                  onChange={(e) => setCustomPayment({ ...customPayment, percentage_of_total: e.target.value, amount: '' })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                  placeholder="z.B. 30"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Fälligkeitsdatum</label>
                <input
                  type="date"
                  value={customPayment.due_date}
                  onChange={(e) => setCustomPayment({ ...customPayment, due_date: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg"
                />
              </div>
            </div>
            <div className="flex items-center gap-3">
              <select
                value={customPayment.payment_type}
                onChange={(e) => setCustomPayment({ ...customPayment, payment_type: e.target.value as any })}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg"
              >
                <option value="deposit">Anzahlung</option>
                <option value="milestone">Teilzahlung</option>
                <option value="final">Restzahlung</option>
                <option value="monthly">Monatlich</option>
              </select>
              <button
                onClick={handleAddCustomPayment}
                className="px-4 py-2 bg-green-500 text-white rounded-lg hover:bg-green-600 transition-all font-medium"
              >
                Hinzufügen
              </button>
              <button
                onClick={() => setShowAddCustom(false)}
                className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-all"
              >
                Abbrechen
              </button>
            </div>
          </div>
        )}

        <div className="space-y-3">
          {payments.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <Calendar className="w-12 h-12 mx-auto mb-3 opacity-50" />
              <p>Noch keine Zahlungen geplant</p>
              <p className="text-sm mt-1">Verwende eine Vorlage oder füge manuell Zahlungen hinzu</p>
            </div>
          ) : (
            payments.map((payment) => {
              const urgency = getPaymentUrgency(payment.due_date, payment.status);
              return (
                <div
                  key={payment.id}
                  className={`p-4 rounded-xl border-2 transition-all ${
                    urgency === 'paid' ? 'bg-green-50 border-green-300' :
                    urgency === 'overdue' ? 'bg-red-50 border-red-300' :
                    urgency === 'urgent' ? 'bg-orange-50 border-orange-300' :
                    urgency === 'soon' ? 'bg-yellow-50 border-yellow-300' :
                    'bg-white border-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div>
                          <p className="font-semibold text-[#0a253c]">
                            {getPaymentTypeLabel(payment.payment_type)}
                          </p>
                          {payment.percentage_of_total && (
                            <p className="text-xs text-gray-600">
                              {payment.percentage_of_total}% vom Gesamtbetrag
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-4 text-sm text-gray-600">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(payment.due_date).toLocaleDateString('de-DE')}
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <div className="text-right">
                        <p className="text-2xl font-bold text-[#0a253c]">
                          {Number(payment.amount).toFixed(2)}€
                        </p>
                        {payment.payment_date && (
                          <p className="text-xs text-gray-500">
                            Bezahlt am {new Date(payment.payment_date).toLocaleDateString('de-DE')}
                          </p>
                        )}
                      </div>
                      <button
                        onClick={() => handleTogglePaymentStatus(payment)}
                        disabled={animatingPayment === payment.id}
                        className={`px-6 py-2 rounded-lg font-semibold transition-all duration-200 flex items-center gap-2 ${
                          payment.status === 'paid'
                            ? 'bg-green-500 text-white hover:bg-green-600 shadow-md'
                            : urgency === 'overdue'
                            ? 'bg-red-100 text-red-700 hover:bg-red-200 border-2 border-red-300'
                            : 'bg-yellow-100 text-yellow-800 hover:bg-yellow-200 border-2 border-yellow-300'
                        } ${
                          animatingPayment === payment.id ? 'payment-button-click payment-success-pulse' : ''
                        }`}
                      >
                        {payment.status === 'paid' ? (
                          <>
                            <Check className="w-4 h-4" />
                            Bezahlt
                          </>
                        ) : (
                          'Als bezahlt markieren'
                        )}
                      </button>
                      <button
                        onClick={() => handleDeletePayment(payment.id)}
                        className="p-2 text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      >
                        <Trash2 className="w-5 h-5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
        <div
          className="bg-gradient-to-r from-green-500 to-emerald-500 h-full transition-all duration-500"
          style={{ width: `${Math.min(paymentProgress, 100)}%` }}
        />
      </div>
    </div>
  );
}
