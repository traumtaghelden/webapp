import { useState, useEffect } from 'react';
import { Activity, CheckSquare, DollarSign, Calendar, Link2, Clock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { TASK, BUDGET, VENDOR, TIMELINE } from '../constants/terminology';

interface ActivityItem {
  id: string;
  action_type: string;
  entity_type: string;
  related_entity_type?: string;
  actor_name?: string;
  details: Record<string, unknown>;
  created_at: string;
}

interface ActivityFeedProps {
  entityType: 'task' | 'budget' | 'vendor' | 'timeline';
  entityId: string;
  limit?: number;
  compact?: boolean;
}

export default function ActivityFeed({
  entityType,
  entityId,
  limit = 20,
  compact = false
}: ActivityFeedProps) {
  const [activities, setActivities] = useState<ActivityItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showFeed, setShowFeed] = useState(!compact);

  useEffect(() => {
    loadActivities();
  }, [entityType, entityId, limit]);

  const loadActivities = async () => {
    try {
      const { data, error } = await supabase
        .rpc('get_entity_activities', {
          p_entity_type: entityType,
          p_entity_id: entityId,
          p_limit: limit
        });

      if (error) throw error;
      setActivities(data || []);
    } catch (error) {
      console.error('Error loading activities:', error);
    } finally {
      setLoading(false);
    }
  };

  const getActionIcon = (actionType: string) => {
    switch (actionType) {
      case 'completed':
        return CheckSquare;
      case 'payment_made':
        return DollarSign;
      case 'date_changed':
        return Calendar;
      case 'linked':
      case 'unlinked':
        return Link2;
      default:
        return Activity;
    }
  };

  const getActionColor = (actionType: string) => {
    switch (actionType) {
      case 'completed':
        return 'text-green-600 bg-green-50';
      case 'payment_made':
        return 'text-blue-600 bg-blue-50';
      case 'date_changed':
        return 'text-orange-600 bg-orange-50';
      case 'deleted':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const getActionLabel = (actionType: string, details: any) => {
    switch (actionType) {
      case 'created':
        return 'Erstellt';
      case 'updated':
        return 'Aktualisiert';
      case 'completed':
        return 'Abgeschlossen';
      case 'payment_made':
        return 'Zahlung erfasst';
      case 'date_changed':
        return 'Datum geändert';
      case 'linked':
        return 'Verknüpft';
      case 'unlinked':
        return 'Verknüpfung gelöst';
      case 'status_changed':
        return 'Status geändert';
      default:
        return actionType;
    }
  };

  const getRelatedEntityLabel = (type?: string) => {
    switch (type) {
      case 'task':
        return TASK.SINGULAR;
      case 'budget':
        return BUDGET.MODULE_NAME;
      case 'vendor':
        return VENDOR.SINGULAR;
      case 'timeline':
        return TIMELINE.MODULE_NAME;
      case 'payment':
        return BUDGET.PAYMENT;
      default:
        return '';
    }
  };

  const formatRelativeTime = (date: string) => {
    const now = new Date();
    const then = new Date(date);
    const diffMs = now.getTime() - then.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 1) return 'Gerade eben';
    if (diffMins < 60) return `Vor ${diffMins} Min.`;
    if (diffHours < 24) return `Vor ${diffHours} Std.`;
    if (diffDays < 7) return `Vor ${diffDays} Tag${diffDays > 1 ? 'en' : ''}`;
    return then.toLocaleDateString('de-DE', { day: '2-digit', month: 'short' });
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center p-4">
        <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-[#d4af37]"></div>
      </div>
    );
  }

  if (activities.length === 0) {
    return (
      <div className="text-center p-4 text-sm text-[#666666]">
        Noch keine Aktivitäten vorhanden
      </div>
    );
  }

  if (compact) {
    return (
      <div className="space-y-2">
        <button
          onClick={() => setShowFeed(!showFeed)}
          className="flex items-center gap-2 text-sm font-semibold text-[#d4af37] hover:text-[#c19a2e] transition-colors"
        >
          <Activity className="w-4 h-4" />
          <span>{showFeed ? 'Aktivitäten ausblenden' : `${activities.length} Aktivitäten anzeigen`}</span>
        </button>

        {showFeed && (
          <div className="space-y-2 pl-6 border-l-2 border-[#d4af37]/20">
            {activities.slice(0, 5).map((activity) => {
              const Icon = getActionIcon(activity.action_type);
              return (
                <div
                  key={activity.id}
                  className="flex items-start gap-2 text-xs"
                >
                  <div className={`flex-shrink-0 w-6 h-6 rounded-lg flex items-center justify-center ${getActionColor(activity.action_type)}`}>
                    <Icon className="w-3.5 h-3.5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-[#0a253c] font-medium">
                      {getActionLabel(activity.action_type, activity.details)}
                    </p>
                    {activity.related_entity_type && (
                      <p className="text-[#666666] truncate">
                        {getRelatedEntityLabel(activity.related_entity_type)}
                        {activity.details?.task_title && `: ${activity.details.task_title}`}
                      </p>
                    )}
                    <p className="text-[#666666] mt-0.5">
                      {formatRelativeTime(activity.created_at)}
                    </p>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl border-2 border-[#d4af37]/20 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Activity className="w-5 h-5 text-[#d4af37]" />
          <h3 className="font-bold text-[#0a253c]">Aktivitäten</h3>
          <span className="px-2 py-0.5 bg-[#d4af37]/10 text-[#d4af37] rounded-full text-xs font-bold">
            {activities.length}
          </span>
        </div>
      </div>

      <div className="space-y-3">
        {activities.map((activity) => {
          const Icon = getActionIcon(activity.action_type);
          return (
            <div
              key={activity.id}
              className="flex items-start gap-3 p-3 bg-[#f7f2eb] rounded-lg hover:bg-[#f0e8d8] transition-colors"
            >
              <div className={`flex-shrink-0 w-8 h-8 rounded-lg flex items-center justify-center ${getActionColor(activity.action_type)}`}>
                <Icon className="w-4 h-4" />
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <p className="text-sm font-semibold text-[#0a253c]">
                    {getActionLabel(activity.action_type, activity.details)}
                  </p>
                  <span className="flex-shrink-0 text-xs text-[#666666] flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {formatRelativeTime(activity.created_at)}
                  </span>
                </div>

                {activity.related_entity_type && (
                  <p className="text-sm text-[#666666]">
                    {getRelatedEntityLabel(activity.related_entity_type)}
                    {activity.details?.task_title && `: ${activity.details.task_title}`}
                    {activity.details?.payment_amount && ` (${activity.details.payment_amount}€)`}
                  </p>
                )}

                {activity.details?.old_date && activity.details?.new_date && (
                  <p className="text-xs text-[#666666] mt-1">
                    {new Date(activity.details.old_date).toLocaleDateString('de-DE')}
                    {' → '}
                    {new Date(activity.details.new_date).toLocaleDateString('de-DE')}
                  </p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
