import { useState, useEffect, useRef } from 'react';
import {
  Save, CalendarClock, DollarSign, Building2, User, CheckSquare,
  ChevronDown, ChevronUp, Calendar, Clock, Plus, Search, AlertCircle,
  Sparkles, Copy, Zap, Tag, FileText, Info
} from 'lucide-react';
import { supabase, type WeddingTeamRole, type BudgetItem, type Vendor, type TimelineEvent } from '../lib/supabase';
import StandardModal, { ModalFooter, ModalButton } from './StandardModal';
import { useToast } from '../contexts/ToastContext';
import { logger } from '../utils/logger';

interface TaskAddModalProps {
  isOpen: boolean;
  weddingId: string;
  onClose: () => void;
  onSuccess?: () => void;
  onTaskCreated?: () => void;
  prefilledData?: Partial<TaskFormData>;
}

interface TaskFormData {
  title: string;
  category: string;
  priority: 'low' | 'medium' | 'high';
  due_date: string;
  start_date: string;
  assigned_to: string;
  notes: string;
  color: string;
  budget_item_id: string;
  vendor_id: string;
  timeline_event_id: string;
  estimated_hours: string;
}

const categories = [
  { value: 'general', label: 'Allgemein', icon: '📋', color: '#94a3b8' },
  { value: 'venue', label: 'Location', icon: '🏛️', color: '#8b5cf6' },
  { value: 'catering', label: 'Catering', icon: '🍽️', color: '#ef4444' },
  { value: 'decoration', label: 'Dekoration', icon: '🎨', color: '#ec4899' },
  { value: 'music', label: 'Musik', icon: '🎵', color: '#06b6d4' },
  { value: 'photography', label: 'Fotografie', icon: '📸', color: '#f59e0b' },
  { value: 'invitations', label: 'Einladungen', icon: '✉️', color: '#10b981' },
  { value: 'flowers', label: 'Blumen', icon: '💐', color: '#f472b6' },
  { value: 'dress', label: 'Kleidung', icon: '👗', color: '#a855f7' },
  { value: 'other', label: 'Sonstiges', icon: '📦', color: '#64748b' },
];

const STORAGE_KEY_PREFIX = 'task_draft_';

export default function TaskAddModal({
  isOpen,
  weddingId,
  onClose,
  onSuccess,
  onTaskCreated,
  prefilledData
}: TaskAddModalProps) {
  const { showToast } = useToast();
  const [teamRoles, setTeamRoles] = useState<WeddingTeamRole[]>([]);
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [timelineEvents, setTimelineEvents] = useState<TimelineEvent[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [budgetSearch, setBudgetSearch] = useState('');
  const [vendorSearch, setVendorSearch] = useState('');
  const [hasDraft, setHasDraft] = useState(false);
  const [weddingDate, setWeddingDate] = useState<string>('');

  const isMountedRef = useRef(true);
  const isSubmittingRef = useRef(false);
  const formRef = useRef<HTMLDivElement>(null);

  const [newTask, setNewTask] = useState<TaskFormData>({
    title: '',
    category: 'general',
    priority: 'medium',
    due_date: '',
    start_date: '',
    assigned_to: '',
    notes: '',
    color: '#d4af37',
    budget_item_id: '',
    vendor_id: '',
    timeline_event_id: '',
    estimated_hours: '',
  });

  useEffect(() => {
    if (isOpen) {
      logger.info('TaskAddModal opened', 'TaskAddModal.useEffect');
      setIsSubmitting(false);
      isSubmittingRef.current = false;

      const draftKey = `${STORAGE_KEY_PREFIX}${weddingId}`;
      const savedDraft = localStorage.getItem(draftKey);

      if (savedDraft && !prefilledData) {
        setHasDraft(true);
      } else {
        resetForm();
      }

      loadData();
      loadWeddingDate();
    }
  }, [weddingId, isOpen]);

  useEffect(() => {
    isMountedRef.current = true;
    return () => {
      isMountedRef.current = false;
    };
  }, []);

  useEffect(() => {
    if (isOpen && newTask.title) {
      const timer = setTimeout(() => {
        saveDraft();
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [newTask, isOpen]);

  useEffect(() => {
    if (prefilledData) {
      setNewTask(prev => ({ ...prev, ...prefilledData }));
    }
  }, [prefilledData]);

  useEffect(() => {
    if (newTask.title && !prefilledData) {
      autoSuggestCategory();
    }
  }, [newTask.title]);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && isOpen && newTask.title.trim()) {
        e.preventDefault();
        handleSubmit(false);
      }
      if (e.key === 'Escape' && isOpen && !isSubmitting) {
        e.preventDefault();
        handleClose();
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleKeyDown);
      return () => window.removeEventListener('keydown', handleKeyDown);
    }
  }, [isOpen, newTask.title, isSubmitting]);

  const loadWeddingDate = async () => {
    try {
      const { data } = await supabase
        .from('weddings')
        .select('wedding_date')
        .eq('id', weddingId)
        .maybeSingle();

      if (data?.wedding_date) {
        setWeddingDate(data.wedding_date);
      }
    } catch (error) {
      console.error('Error loading wedding date:', error);
    }
  };

  const resetForm = () => {
    setNewTask({
      title: '',
      category: 'general',
      priority: 'medium',
      due_date: '',
      start_date: '',
      assigned_to: '',
      notes: '',
      color: '#d4af37',
      budget_item_id: '',
      vendor_id: '',
      timeline_event_id: '',
      estimated_hours: '',
    });
    setShowAdvanced(false);
    setBudgetSearch('');
    setVendorSearch('');
    setHasDraft(false);
  };

  const saveDraft = () => {
    if (newTask.title) {
      const draftKey = `${STORAGE_KEY_PREFIX}${weddingId}`;
      localStorage.setItem(draftKey, JSON.stringify(newTask));
    }
  };

  const loadDraft = () => {
    const draftKey = `${STORAGE_KEY_PREFIX}${weddingId}`;
    const savedDraft = localStorage.getItem(draftKey);
    if (savedDraft) {
      try {
        const draft = JSON.parse(savedDraft);
        setNewTask(draft);
        setHasDraft(false);
        showToast('Entwurf wiederhergestellt', 'success');
      } catch (error) {
        console.error('Error loading draft:', error);
      }
    }
  };

  const clearDraft = () => {
    const draftKey = `${STORAGE_KEY_PREFIX}${weddingId}`;
    localStorage.removeItem(draftKey);
    setHasDraft(false);
  };

  const autoSuggestCategory = () => {
    const title = newTask.title.toLowerCase();
    const suggestions: { [key: string]: string[] } = {
      'venue': ['location', 'raum', 'saal', 'halle', 'besichtigung'],
      'catering': ['essen', 'catering', 'menü', 'buffet', 'getränk'],
      'decoration': ['deko', 'dekoration', 'schmuck', 'tisch'],
      'music': ['musik', 'dj', 'band', 'playlist'],
      'photography': ['foto', 'fotograf', 'kamera', 'video'],
      'invitations': ['einladung', 'karte', 'save the date'],
      'flowers': ['blumen', 'blume', 'strauß', 'florist'],
      'dress': ['kleid', 'anzug', 'outfit', 'schneider'],
    };

    for (const [category, keywords] of Object.entries(suggestions)) {
      if (keywords.some(keyword => title.includes(keyword))) {
        if (newTask.category === 'general') {
          setNewTask(prev => ({ ...prev, category }));
        }
        break;
      }
    }
  };

  const loadData = async () => {
    try {
      const [teamData, budgetData, vendorsData, timelineData] = await Promise.all([
        supabase.from('wedding_team_roles').select('*').eq('wedding_id', weddingId),
        supabase.from('budget_items').select('*').eq('wedding_id', weddingId),
        supabase.from('vendors').select('*').eq('wedding_id', weddingId),
        supabase.from('wedding_timeline').select('*').eq('wedding_id', weddingId).order('order_index'),
      ]);

      if (teamData.data) setTeamRoles(teamData.data);
      if (budgetData.data) setBudgetItems(budgetData.data);
      if (vendorsData.data) setVendors(vendorsData.data);
      if (timelineData.data) setTimelineEvents(timelineData.data);
    } catch (error) {
      console.error('Error loading data:', error);
    }
  };

  const getQuickDate = (days: number) => {
    const date = new Date();
    date.setDate(date.getDate() + days);
    return date.toISOString().split('T')[0];
  };

  const getDaysUntilWedding = () => {
    if (!weddingDate || !newTask.due_date) return null;
    const wedding = new Date(weddingDate);
    const due = new Date(newTask.due_date);
    const diff = Math.ceil((wedding.getTime() - due.getTime()) / (1000 * 60 * 60 * 24));
    return diff;
  };

  const validateForm = (): string | null => {
    if (!newTask.title.trim()) {
      return 'Bitte gib einen Titel ein';
    }

    if (newTask.due_date && weddingDate) {
      const dueDate = new Date(newTask.due_date);
      const wedding = new Date(weddingDate);
      if (dueDate > wedding) {
        return 'Das Fälligkeitsdatum sollte vor dem Hochzeitstermin liegen';
      }
    }

    if (newTask.start_date && newTask.due_date) {
      const start = new Date(newTask.start_date);
      const due = new Date(newTask.due_date);
      if (start > due) {
        return 'Das Startdatum muss vor dem Fälligkeitsdatum liegen';
      }
    }

    return null;
  };

  const handleSubmit = async (createAnother: boolean = false) => {
    const validationError = validateForm();
    if (validationError) {
      showToast(validationError, 'error');
      return;
    }

    if (isSubmittingRef.current) {
      logger.warn('Submit already in progress', 'TaskAddModal.handleSubmit');
      return;
    }

    isSubmittingRef.current = true;
    setIsSubmitting(true);

    try {
      logger.info('Creating task', 'TaskAddModal.handleSubmit', { title: newTask.title });

      const taskData: any = {
        wedding_id: weddingId,
        title: newTask.title,
        category: newTask.category,
        priority: newTask.priority,
        status: 'pending',
        due_date: newTask.due_date || null,
        assigned_to: newTask.assigned_to || null,
        notes: newTask.notes || null,
        color: newTask.color,
        budget_item_id: newTask.budget_item_id || null,
        vendor_id: newTask.vendor_id || null,
        timeline_event_id: newTask.timeline_event_id || null,
      };

      const { error } = await supabase.from('tasks').insert([taskData]);

      if (error) throw error;

      if (!isMountedRef.current) {
        logger.warn('Component unmounted during submission', 'TaskAddModal.handleSubmit');
        return;
      }

      logger.info('Task created successfully', 'TaskAddModal.handleSubmit');

      clearDraft();
      showToast('Aufgabe erfolgreich erstellt', 'success');

      if (onSuccess) {
        try {
          onSuccess();
        } catch (callbackError) {
          logger.error('Error in onSuccess callback', 'TaskAddModal.handleSubmit', callbackError);
        }
      }

      if (createAnother) {
        const preservedData = {
          category: newTask.category,
          priority: newTask.priority,
          assigned_to: newTask.assigned_to,
          timeline_event_id: newTask.timeline_event_id,
        };
        resetForm();
        setNewTask(prev => ({ ...prev, ...preservedData }));
      } else {
        if (onTaskCreated) {
          try {
            onTaskCreated();
          } catch (callbackError) {
            logger.error('Error in onTaskCreated callback', 'TaskAddModal.handleSubmit', callbackError);
          }
        } else {
          onClose();
        }
      }
    } catch (error) {
      logger.error('Error creating task', 'TaskAddModal.handleSubmit', error);
      if (isMountedRef.current) {
        showToast('Fehler beim Erstellen der Aufgabe', 'error');
      }
    } finally {
      if (isMountedRef.current) {
        setIsSubmitting(false);
        isSubmittingRef.current = false;
      }
    }
  };

  const handleClose = () => {
    if (newTask.title && !isSubmitting) {
      if (window.confirm('Du hast ungespeicherte Änderungen. Möchtest du wirklich schließen?')) {
        saveDraft();
        onClose();
      }
    } else {
      onClose();
    }
  };

  const filteredBudgetItems = budgetItems.filter(item =>
    item.item_name.toLowerCase().includes(budgetSearch.toLowerCase()) ||
    item.category.toLowerCase().includes(budgetSearch.toLowerCase())
  );

  const filteredVendors = vendors.filter(vendor =>
    vendor.name.toLowerCase().includes(vendorSearch.toLowerCase()) ||
    vendor.category.toLowerCase().includes(vendorSearch.toLowerCase())
  );

  const selectedCategory = categories.find(cat => cat.value === newTask.category);
  const selectedBudgetItem = budgetItems.find(item => item.id === newTask.budget_item_id);
  const selectedVendor = vendors.find(vendor => vendor.id === newTask.vendor_id);
  const daysUntilWedding = getDaysUntilWedding();

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'text-red-400';
      case 'medium': return 'text-yellow-400';
      case 'low': return 'text-green-400';
      default: return 'text-white/70';
    }
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return '🔴';
      case 'medium': return '🟡';
      case 'low': return '🟢';
      default: return '⚪';
    }
  };

  return (
    <StandardModal
      isOpen={isOpen}
      onClose={handleClose}
      title="Neue Aufgabe erstellen"
      subtitle="Erstelle eine neue Aufgabe für deine Hochzeitsplanung"
      icon={CheckSquare}
      maxWidth="4xl"
      footer={
        <ModalFooter>
          <div className="flex items-center justify-between w-full">
            <div className="flex items-center gap-2">
              {hasDraft && (
                <button
                  onClick={loadDraft}
                  className="px-3 py-2 rounded-lg bg-blue-600/20 text-blue-400 hover:bg-blue-600/30 transition-colors text-sm flex items-center gap-2"
                >
                  <Copy className="w-4 h-4" />
                  Entwurf laden
                </button>
              )}
            </div>
            <div className="flex gap-3">
              <ModalButton variant="secondary" onClick={handleClose} disabled={isSubmitting}>
                Abbrechen
              </ModalButton>
              <ModalButton
                variant="secondary"
                onClick={() => handleSubmit(true)}
                disabled={!newTask.title.trim() || isSubmitting}
                icon={Plus}
              >
                Erstellen & Weitere
              </ModalButton>
              <ModalButton
                variant="primary"
                onClick={() => handleSubmit(false)}
                disabled={!newTask.title.trim() || isSubmitting}
                icon={Save}
              >
                {isSubmitting ? 'Wird erstellt...' : 'Aufgabe erstellen'}
              </ModalButton>
            </div>
          </div>
        </ModalFooter>
      }
    >
      <div ref={formRef} className="space-y-6">
        {hasDraft && (
          <div className="bg-blue-600/10 border border-blue-500/30 rounded-xl p-4 flex items-start gap-3">
            <Info className="w-5 h-5 text-blue-400 flex-shrink-0 mt-0.5" />
            <div className="flex-1">
              <h4 className="text-sm font-semibold text-blue-400 mb-1">Entwurf gefunden</h4>
              <p className="text-xs text-white/70">
                Du hast einen gespeicherten Entwurf. Möchtest du diesen wiederherstellen?
              </p>
            </div>
            <button
              onClick={loadDraft}
              className="px-3 py-1.5 rounded-lg bg-blue-600 text-white text-sm hover:bg-blue-700 transition-colors"
            >
              Laden
            </button>
          </div>
        )}

        <div>
          <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#d4af37]" />
            Titel*
          </label>
          <input
            type="text"
            value={newTask.title}
            onChange={(e) => setNewTask({ ...newTask, title: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm transition-all"
            placeholder="z.B. Location besichtigen"
            autoFocus
          />
          <div className="mt-1 flex items-center justify-between text-xs">
            <span className="text-white/50">Tipp: Der Titel wird automatisch analysiert</span>
            {newTask.title && (
              <span className="text-white/70">{newTask.title.length} Zeichen</span>
            )}
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
              <Tag className="w-4 h-4 text-[#d4af37]" />
              Kategorie
            </label>
            <select
              value={newTask.category}
              onChange={(e) => setNewTask({ ...newTask, category: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm transition-all"
            >
              {categories.map((cat) => (
                <option key={cat.value} value={cat.value} className="bg-[#0a253c] text-white">
                  {cat.icon} {cat.label}
                </option>
              ))}
            </select>
            {selectedCategory && (
              <div className="mt-2 flex items-center gap-2">
                <div
                  className="w-3 h-3 rounded-full"
                  style={{ backgroundColor: selectedCategory.color }}
                />
                <span className="text-xs text-white/60">
                  {selectedCategory.label}
                </span>
              </div>
            )}
          </div>

          <div>
            <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
              <AlertCircle className="w-4 h-4 text-[#d4af37]" />
              Priorität
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { value: 'low', label: 'Niedrig', icon: '🟢' },
                { value: 'medium', label: 'Mittel', icon: '🟡' },
                { value: 'high', label: 'Hoch', icon: '🔴' }
              ].map((priority) => (
                <button
                  key={priority.value}
                  type="button"
                  onClick={() => setNewTask({ ...newTask, priority: priority.value as any })}
                  className={`px-4 py-3 rounded-xl border-2 transition-all ${
                    newTask.priority === priority.value
                      ? 'border-[#d4af37] bg-[#d4af37]/20'
                      : 'border-[#d4af37]/30 bg-white/5 hover:bg-white/10'
                  }`}
                >
                  <div className="flex flex-col items-center gap-1">
                    <span className="text-lg">{priority.icon}</span>
                    <span className="text-xs text-white/80">{priority.label}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
              <Calendar className="w-4 h-4 text-[#d4af37]" />
              Fällig am
            </label>
            <input
              type="date"
              value={newTask.due_date}
              onChange={(e) => setNewTask({ ...newTask, due_date: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
            />
            <div className="mt-2 flex flex-wrap gap-2">
              <button
                type="button"
                onClick={() => setNewTask({ ...newTask, due_date: getQuickDate(1) })}
                className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-white/70 transition-colors"
              >
                Morgen
              </button>
              <button
                type="button"
                onClick={() => setNewTask({ ...newTask, due_date: getQuickDate(7) })}
                className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-white/70 transition-colors"
              >
                In 1 Woche
              </button>
              <button
                type="button"
                onClick={() => setNewTask({ ...newTask, due_date: getQuickDate(30) })}
                className="px-2 py-1 rounded-lg bg-white/5 hover:bg-white/10 text-xs text-white/70 transition-colors"
              >
                In 1 Monat
              </button>
            </div>
            {daysUntilWedding !== null && (
              <p className="mt-2 text-xs text-white/60">
                {daysUntilWedding > 0
                  ? `${daysUntilWedding} Tage vor der Hochzeit`
                  : `${Math.abs(daysUntilWedding)} Tage nach der Hochzeit`}
              </p>
            )}
          </div>

          <div>
            <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
              <User className="w-4 h-4 text-[#d4af37]" />
              Verantwortlich
            </label>
            <select
              value={newTask.assigned_to}
              onChange={(e) => setNewTask({ ...newTask, assigned_to: e.target.value })}
              className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
            >
              <option value="" className="bg-[#0a253c] text-white">Nicht zugewiesen</option>
              {teamRoles.map((role) => (
                <option key={role.id} value={role.name} className="bg-[#0a253c] text-white">
                  {role.character_type && `${role.character_type} - `}{role.name}
                </option>
              ))}
            </select>
            {teamRoles.length === 0 && (
              <p className="mt-2 text-xs text-white/60">
                Noch keine Team-Mitglieder erstellt
              </p>
            )}
          </div>
        </div>

        <button
          type="button"
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="w-full flex items-center justify-between px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/5 hover:bg-white/10 transition-colors"
        >
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-[#d4af37]" />
            <span className="text-sm font-semibold text-white/90">Erweiterte Optionen</span>
          </div>
          {showAdvanced ? (
            <ChevronUp className="w-5 h-5 text-white/70" />
          ) : (
            <ChevronDown className="w-5 h-5 text-white/70" />
          )}
        </button>

        {showAdvanced && (
          <div className="space-y-6 animate-in fade-in duration-300">
            <div>
              <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
                <Clock className="w-4 h-4 text-[#d4af37]" />
                Startdatum (optional)
              </label>
              <input
                type="date"
                value={newTask.start_date}
                onChange={(e) => setNewTask({ ...newTask, start_date: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
              />
              <p className="mt-1 text-xs text-white/50">
                Für Aufgaben, die über mehrere Tage gehen
              </p>
            </div>

            <div>
              <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
                <DollarSign className="w-4 h-4 text-[#d4af37]" />
                Budget-Posten
              </label>
              <div className="relative">
                <div className="absolute left-3 top-3.5 z-10">
                  <Search className="w-4 h-4 text-white/50" />
                </div>
                <input
                  type="text"
                  value={budgetSearch}
                  onChange={(e) => setBudgetSearch(e.target.value)}
                  placeholder="Budget-Posten suchen..."
                  className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm mb-2"
                />
              </div>
              <select
                value={newTask.budget_item_id}
                onChange={(e) => setNewTask({ ...newTask, budget_item_id: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
              >
                <option value="" className="bg-[#0a253c] text-white">Keine Verknüpfung</option>
                {filteredBudgetItems.map((item) => (
                  <option key={item.id} value={item.id} className="bg-[#0a253c] text-white">
                    {item.item_name} - {item.category} ({item.estimated_cost}€)
                  </option>
                ))}
              </select>
              {selectedBudgetItem && (
                <div className="mt-2 p-3 rounded-lg bg-white/5 border border-[#d4af37]/20">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-white/70">Geschätzte Kosten:</span>
                    <span className="text-[#d4af37] font-semibold">{selectedBudgetItem.estimated_cost}€</span>
                  </div>
                  <div className="flex items-center justify-between text-xs mt-1">
                    <span className="text-white/70">Status:</span>
                    <span className={selectedBudgetItem.paid ? 'text-green-400' : 'text-yellow-400'}>
                      {selectedBudgetItem.paid ? 'Bezahlt' : 'Ausstehend'}
                    </span>
                  </div>
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
                <Building2 className="w-4 h-4 text-[#d4af37]" />
                Dienstleister
              </label>
              <div className="relative">
                <div className="absolute left-3 top-3.5 z-10">
                  <Search className="w-4 h-4 text-white/50" />
                </div>
                <input
                  type="text"
                  value={vendorSearch}
                  onChange={(e) => setVendorSearch(e.target.value)}
                  placeholder="Dienstleister suchen..."
                  className="w-full pl-10 pr-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm mb-2"
                />
              </div>
              <select
                value={newTask.vendor_id}
                onChange={(e) => setNewTask({ ...newTask, vendor_id: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
              >
                <option value="" className="bg-[#0a253c] text-white">Keine Verknüpfung</option>
                {filteredVendors.map((vendor) => (
                  <option key={vendor.id} value={vendor.id} className="bg-[#0a253c] text-white">
                    {vendor.name} - {vendor.category}
                  </option>
                ))}
              </select>
              {selectedVendor && (
                <div className="mt-2 p-3 rounded-lg bg-white/5 border border-[#d4af37]/20">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-white/70">Kategorie:</span>
                    <span className="text-white/90">{selectedVendor.category}</span>
                  </div>
                  {selectedVendor.email && (
                    <div className="flex items-center justify-between text-xs mt-1">
                      <span className="text-white/70">Kontakt:</span>
                      <span className="text-white/90">{selectedVendor.email}</span>
                    </div>
                  )}
                </div>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
                <CalendarClock className="w-4 h-4 text-[#d4af37]" />
                Block Planning (Timeline-Event)
              </label>
              <select
                value={newTask.timeline_event_id}
                onChange={(e) => setNewTask({ ...newTask, timeline_event_id: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
              >
                <option value="" className="bg-[#0a253c] text-white">Keine Verknüpfung</option>
                {timelineEvents.map((event) => (
                  <option key={event.id} value={event.id} className="bg-[#0a253c] text-white">
                    {event.title} - {event.time?.substring(0, 5)} ({event.duration_minutes} Min.)
                  </option>
                ))}
              </select>
              {timelineEvents.length === 0 && (
                <p className="mt-2 text-xs text-white/60">
                  Keine Timeline-Events verfügbar. Erstelle zuerst Events im Timeline-Bereich.
                </p>
              )}
            </div>

            <div>
              <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
                <Zap className="w-4 h-4 text-[#d4af37]" />
                Geschätzter Aufwand (Stunden)
              </label>
              <input
                type="number"
                min="0"
                step="0.5"
                value={newTask.estimated_hours}
                onChange={(e) => setNewTask({ ...newTask, estimated_hours: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                placeholder="z.B. 2.5"
              />
            </div>
          </div>
        )}

        <div>
          <label className="block text-sm font-semibold text-white/90 mb-2 flex items-center gap-2">
            <FileText className="w-4 h-4 text-[#d4af37]" />
            Notizen
          </label>
          <textarea
            value={newTask.notes}
            onChange={(e) => setNewTask({ ...newTask, notes: e.target.value })}
            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm resize-none"
            rows={4}
            placeholder="Zusätzliche Details, Checklisten, oder wichtige Informationen..."
          />
          {newTask.notes && (
            <div className="mt-1 flex justify-end">
              <span className="text-xs text-white/50">{newTask.notes.length} Zeichen</span>
            </div>
          )}
        </div>

        <div className="border-t border-[#d4af37]/20 pt-4">
          <div className="flex items-center gap-2 text-xs text-white/60">
            <Info className="w-4 h-4" />
            <span>
              Tipp: Drücke Strg+Enter (Cmd+Enter auf Mac) zum schnellen Speichern
            </span>
          </div>
        </div>
      </div>
    </StandardModal>
  );
}
