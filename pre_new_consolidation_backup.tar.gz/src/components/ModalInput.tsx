import { useState, useEffect } from 'react';
import { Save, Type } from 'lucide-react';
import StandardModal, { ModalFooter, ModalButton } from './StandardModal';

interface ModalInputProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (value: string) => void;
  title: string;
  placeholder?: string;
  defaultValue?: string;
  type?: 'text' | 'number' | 'date';
  required?: boolean;
}

export default function ModalInput({
  isOpen,
  onClose,
  onConfirm,
  title,
  placeholder = '',
  defaultValue = '',
  type = 'text',
  required = false,
}: ModalInputProps) {
  const [value, setValue] = useState(defaultValue);

  useEffect(() => {
    if (isOpen) {
      setValue(defaultValue);
    }
  }, [isOpen, defaultValue]);

  const handleConfirm = () => {
    if (required && !value.trim()) return;
    onConfirm(value);
    setValue('');
    onClose();
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleConfirm();
    }
  };

  return (
    <StandardModal
      isOpen={isOpen}
      onClose={onClose}
      title={title}
      icon={Type}
      maxWidth="md"
      footer={
        <ModalFooter>
          <ModalButton variant="secondary" onClick={onClose}>
            Abbrechen
          </ModalButton>
          <ModalButton
            variant="primary"
            onClick={handleConfirm}
            disabled={required && !value.trim()}
            icon={Save}
          >
            OK
          </ModalButton>
        </ModalFooter>
      }
    >
      <div>
        <input
          type={type}
          value={value}
          onChange={(e) => setValue(e.target.value)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          autoFocus
          className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
          step={type === 'number' ? '0.01' : undefined}
        />
        {required && !value.trim() && (
          <p className="text-xs text-red-400 mt-2">
            Dieses Feld ist erforderlich
          </p>
        )}
      </div>
    </StandardModal>
  );
}
