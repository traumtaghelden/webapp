import { useState, useEffect } from 'react';
import { Plus, GripVertical, Edit2, Trash2, Clock, AlertTriangle, Save, X } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import { TimelineEvent, TimelineBlockSubtask } from '../../lib/supabase';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface SubTimelineTabProps {
  event: TimelineEvent;
  onUpdate: () => void;
  onUnsavedChanges: (hasChanges: boolean) => void;
}

function SortableSubtask({
  subtask,
  eventStartTime,
  onEdit,
  onDelete,
}: {
  subtask: TimelineBlockSubtask;
  eventStartTime: string;
  onEdit: (subtask: TimelineBlockSubtask) => void;
  onDelete: (id: string) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: subtask.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const calculateAbsoluteTime = (offsetMinutes: number) => {
    const [hours, minutes] = eventStartTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + offsetMinutes;
    const newHours = Math.floor(totalMinutes / 60) % 24;
    const newMinutes = totalMinutes % 60;
    return `${String(newHours).padStart(2, '0')}:${String(newMinutes).padStart(2, '0')}`;
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="bg-white border-2 border-gray-200 rounded-xl p-4 hover:border-blue-300 transition-colors"
    >
      <div className="flex items-start gap-3">
        <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing mt-1">
          <GripVertical className="w-5 h-5 text-gray-400" />
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-start justify-between gap-3 mb-2">
            <h4 className="font-semibold text-gray-900 text-lg">{subtask.title}</h4>
            <div className="flex items-center gap-2">
              <button
                onClick={() => onEdit(subtask)}
                className="p-1.5 text-blue-600 hover:bg-blue-50 rounded"
              >
                <Edit2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => onDelete(subtask.id)}
                className="p-1.5 text-red-600 hover:bg-red-50 rounded"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3 text-sm text-gray-600 mb-2">
            <div className="flex items-center gap-1.5">
              <Clock className="w-4 h-4" />
              <span className="font-medium">
                {calculateAbsoluteTime(subtask.start_offset_minutes)}
              </span>
              <span className="text-gray-400">({subtask.start_offset_minutes} Min)</span>
            </div>
            <span className="text-gray-400">•</span>
            <span>{subtask.duration_minutes} Min Dauer</span>
            {subtask.assigned_to && (
              <>
                <span className="text-gray-400">•</span>
                <span>Verantwortlich: {subtask.assigned_to}</span>
              </>
            )}
          </div>

          {subtask.description && (
            <p className="text-sm text-gray-600 mt-2">{subtask.description}</p>
          )}
        </div>
      </div>
    </div>
  );
}

export default function SubTimelineTab({
  event,
  onUpdate,
  onUnsavedChanges,
}: SubTimelineTabProps) {
  const [subtasks, setSubtasks] = useState<TimelineBlockSubtask[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingSubtask, setEditingSubtask] = useState<TimelineBlockSubtask | null>(null);
  const [formData, setFormData] = useState({
    title: '',
    start_offset_minutes: 0,
    duration_minutes: 15,
    description: '',
    assigned_to: '',
  });

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    loadSubtasks();
  }, [event.id]);

  useEffect(() => {
    if (!showAddModal && !editingSubtask) {
      resetForm();
    }
  }, [subtasks, showAddModal, editingSubtask]);

  const loadSubtasks = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('timeline_block_subtasks')
      .select('*')
      .eq('timeline_event_id', event.id)
      .order('order_index', { ascending: true });

    if (!error && data) {
      setSubtasks(data);
    }
    setLoading(false);
  };

  const handleDragEnd = async (dragEvent: DragEndEvent) => {
    const { active, over } = dragEvent;

    if (over && active.id !== over.id) {
      const oldIndex = subtasks.findIndex((s) => s.id === active.id);
      const newIndex = subtasks.findIndex((s) => s.id === over.id);

      const newOrder = arrayMove(subtasks, oldIndex, newIndex);
      setSubtasks(newOrder);

      for (let i = 0; i < newOrder.length; i++) {
        await supabase
          .from('timeline_block_subtasks')
          .update({ order_index: i })
          .eq('id', newOrder[i].id);
      }

      onUpdate();
    }
  };

  const handleAdd = async () => {
    if (!formData.title.trim()) return;

    const newSubtask = {
      timeline_event_id: event.id,
      ...formData,
      order_index: subtasks.length,
    };

    const { error } = await supabase.from('timeline_block_subtasks').insert(newSubtask);

    if (!error) {
      setShowAddModal(false);
      resetForm();
      loadSubtasks();
      onUpdate();
    }
  };

  const handleUpdate = async () => {
    if (!editingSubtask || !formData.title.trim()) return;

    const { error } = await supabase
      .from('timeline_block_subtasks')
      .update(formData)
      .eq('id', editingSubtask.id);

    if (!error) {
      setShowAddModal(false);
      setEditingSubtask(null);
      resetForm();
      loadSubtasks();
      onUpdate();
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('Diesen Sub-Event wirklich löschen?')) return;

    const { error } = await supabase.from('timeline_block_subtasks').delete().eq('id', id);

    if (!error) {
      loadSubtasks();
      onUpdate();
    }
  };

  const handleEdit = (subtask: TimelineBlockSubtask) => {
    setEditingSubtask(subtask);
    setFormData({
      title: subtask.title,
      start_offset_minutes: subtask.start_offset_minutes,
      duration_minutes: subtask.duration_minutes,
      description: subtask.description,
      assigned_to: subtask.assigned_to,
    });
    setShowAddModal(true);
  };

  const resetForm = () => {
    const lastSubtaskEndTime = subtasks.length > 0
      ? subtasks[subtasks.length - 1].start_offset_minutes + subtasks[subtasks.length - 1].duration_minutes
      : 0;

    setFormData({
      title: '',
      start_offset_minutes: lastSubtaskEndTime,
      duration_minutes: 15,
      description: '',
      assigned_to: '',
    });
  };

  const checkTimeConflict = () => {
    const endOffset = formData.start_offset_minutes + formData.duration_minutes;
    return endOffset > event.duration_minutes;
  };

  const generateTimeOptions = () => {
    const options = [];
    for (let i = 0; i <= event.duration_minutes; i += 5) {
      options.push(i);
    }
    return options;
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-xl font-semibold text-gray-900">Minutengenaue Zeitplanung</h3>
          <p className="text-sm text-gray-600 mt-1">
            Erstellen Sie einen detaillierten Ablauf für dieses Event
          </p>
        </div>
        <button
          onClick={() => {
            setEditingSubtask(null);
            resetForm();
            setShowAddModal(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" />
          Sub-Event hinzufügen
        </button>
      </div>

      {subtasks.length === 0 ? (
        <div className="text-center py-12 bg-gray-50 rounded-xl">
          <Clock className="w-12 h-12 text-gray-400 mx-auto mb-3" />
          <p className="text-gray-600 mb-4">Noch keine Sub-Events erstellt</p>
          <button
            onClick={() => setShowAddModal(true)}
            className="text-blue-600 hover:text-blue-700 font-medium"
          >
            Erstes Sub-Event hinzufügen
          </button>
        </div>
      ) : (
        <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
          <SortableContext items={subtasks.map((s) => s.id)} strategy={verticalListSortingStrategy}>
            <div className="space-y-3">
              {subtasks.map((subtask) => (
                <SortableSubtask
                  key={subtask.id}
                  subtask={subtask}
                  eventStartTime={event.time}
                  onEdit={handleEdit}
                  onDelete={handleDelete}
                />
              ))}
            </div>
          </SortableContext>
        </DndContext>
      )}

      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-xl font-semibold text-gray-900">
                {editingSubtask ? 'Sub-Event bearbeiten' : 'Neues Sub-Event'}
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingSubtask(null);
                  resetForm();
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Titel *
                </label>
                <input
                  type="text"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  placeholder="z.B. Gäste Empfang, Anstoßen mit Sekt..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  autoFocus
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Startzeit (Minuten nach Blockstart)
                  </label>
                  <select
                    value={formData.start_offset_minutes}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        start_offset_minutes: parseInt(e.target.value),
                      })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    {generateTimeOptions().map((minutes) => (
                      <option key={minutes} value={minutes}>
                        {minutes} Min
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Dauer (Minuten)
                  </label>
                  <select
                    value={formData.duration_minutes}
                    onChange={(e) =>
                      setFormData({ ...formData, duration_minutes: parseInt(e.target.value) })
                    }
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  >
                    {[5, 10, 15, 20, 30, 45, 60, 90, 120].map((minutes) => (
                      <option key={minutes} value={minutes}>
                        {minutes} Min
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              {checkTimeConflict() && (
                <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2">
                  <AlertTriangle className="w-5 h-5 text-red-600 mt-0.5" />
                  <p className="text-sm text-red-800">
                    Warnung: Dieses Sub-Event würde über die Event-Endzeit hinausgehen!
                  </p>
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Verantwortliche Person
                </label>
                <input
                  type="text"
                  value={formData.assigned_to}
                  onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                  placeholder="z.B. Trauzeuge, Brautmutter..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Beschreibung
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  placeholder="Zusätzliche Details zu diesem Sub-Event..."
                  rows={3}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingSubtask(null);
                    resetForm();
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Abbrechen
                </button>
                <button
                  onClick={editingSubtask ? handleUpdate : handleAdd}
                  disabled={!formData.title.trim() || checkTimeConflict()}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {editingSubtask ? 'Speichern' : 'Hinzufügen'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
