import { useState } from 'react';
import { X, Plus, Tag as TagIcon, Edit2, Trash2, Save } from 'lucide-react';
import { supabase, type BudgetTag } from '../lib/supabase';

interface BudgetTagManagerProps {
  weddingId: string;
  availableTags: BudgetTag[];
  onClose: () => void;
  onUpdate: () => void;
}

const colorOptions = [
  '#d4af37', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6',
  '#ec4899', '#14b8a6', '#f97316', '#ef4444', '#06b6d4',
];

export default function BudgetTagManager({ weddingId, availableTags, onClose, onUpdate }: BudgetTagManagerProps) {
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingTag, setEditingTag] = useState<BudgetTag | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    color: '#d4af37',
  });

  const handleSaveTag = async () => {
    if (!formData.name.trim()) return;

    try {
      if (editingTag) {
        await supabase
          .from('budget_tags')
          .update(formData)
          .eq('id', editingTag.id);
      } else {
        await supabase.from('budget_tags').insert([{
          wedding_id: weddingId,
          ...formData,
        }]);
      }

      setFormData({ name: '', color: '#d4af37' });
      setShowAddForm(false);
      setEditingTag(null);
      onUpdate();
    } catch (error) {
      console.error('Error saving tag:', error);
    }
  };

  const handleEditTag = (tag: BudgetTag) => {
    setEditingTag(tag);
    setFormData({
      name: tag.name,
      color: tag.color,
    });
    setShowAddForm(true);
  };

  const handleDeleteTag = async (tagId: string) => {
    if (!confirm('Tag wirklich löschen? Alle Zuordnungen zu Budget-Posten werden ebenfalls entfernt.')) return;

    try {
      await supabase.from('budget_tags').delete().eq('id', tagId);
      onUpdate();
    } catch (error) {
      console.error('Error deleting tag:', error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col">
        <div className="p-6 border-b border-[#d4af37]/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-12 h-12 rounded-xl flex items-center justify-center shadow-lg">
                <TagIcon className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-[#0a253c]">Budget-Tags verwalten</h2>
                <p className="text-sm text-[#666666]">Organisiere deine Budget-Posten mit Tags</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-[#f7f2eb] rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-[#333333]" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {showAddForm && (
            <div className="mb-6 p-6 rounded-2xl bg-[#f7f2eb] border-2 border-[#d4af37]">
              <h3 className="text-xl font-bold text-[#0a253c] mb-4">
                {editingTag ? 'Tag bearbeiten' : 'Neues Tag erstellen'}
              </h3>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    placeholder="z.B. Wichtig, Noch klären, Bezahlt"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Farbe</label>
                  <div className="flex gap-2 flex-wrap">
                    {colorOptions.map(color => (
                      <button
                        key={color}
                        onClick={() => setFormData({ ...formData, color })}
                        className={`w-10 h-10 rounded-full transition-all ${
                          formData.color === color ? 'ring-4 ring-offset-2 ring-[#d4af37]' : 'hover:scale-110'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={handleSaveTag}
                  disabled={!formData.name.trim()}
                  className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  <Save className="w-4 h-4" />
                  {editingTag ? 'Speichern' : 'Erstellen'}
                </button>
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    setEditingTag(null);
                    setFormData({ name: '', color: '#d4af37' });
                  }}
                  className="px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-bold hover:bg-[#d4af37]/10 transition-all"
                >
                  Abbrechen
                </button>
              </div>
            </div>
          )}

          {!showAddForm && (
            <button
              onClick={() => setShowAddForm(true)}
              className="w-full mb-6 flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#0a253c] rounded-xl font-bold hover:shadow-lg transition-all"
            >
              <Plus className="w-5 h-5" />
              Neues Tag erstellen
            </button>
          )}

          <div className="grid md:grid-cols-2 gap-4">
            {availableTags.map(tag => (
              <div
                key={tag.id}
                className="p-4 rounded-xl border-2 border-[#d4af37]/30 hover:border-[#d4af37] transition-all group"
                style={{ backgroundColor: `${tag.color}10` }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div
                      className="w-10 h-10 rounded-full flex items-center justify-center shadow-md"
                      style={{ backgroundColor: tag.color }}
                    >
                      <TagIcon className="w-5 h-5 text-white" />
                    </div>
                    <span className="font-semibold text-[#0a253c]">{tag.name}</span>
                  </div>
                  <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={() => handleEditTag(tag)}
                      className="p-2 hover:bg-[#d4af37]/20 rounded-lg transition-colors"
                    >
                      <Edit2 className="w-4 h-4 text-[#d4af37]" />
                    </button>
                    <button
                      onClick={() => handleDeleteTag(tag.id)}
                      className="p-2 hover:bg-red-50 rounded-lg transition-colors"
                    >
                      <Trash2 className="w-4 h-4 text-red-500" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {availableTags.length === 0 && (
            <div className="text-center py-16">
              <TagIcon className="w-20 h-20 text-[#d4af37] mx-auto mb-4 opacity-50" />
              <p className="text-[#333333] text-lg mb-2">Noch keine Tags erstellt</p>
              <p className="text-sm text-[#666666]">Erstelle Tags, um deine Budget-Posten besser zu organisieren</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
