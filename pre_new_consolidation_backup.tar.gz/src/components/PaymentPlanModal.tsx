import { useState, useEffect } from 'react';
import { X, Plus, Trash2, Calendar, DollarSign, Percent, Check, Crown, Lock } from 'lucide-react';

interface PaymentInstallment {
  id: string;
  amount: string;
  dueDate: string;
  description: string;
}

interface PaymentPlanModalProps {
  isOpen: boolean;
  onClose: () => void;
  onConfirm: (installments: PaymentInstallment[]) => void;
  totalAmount: number;
  currency?: string;
  existingPayments?: Array<{ amount: number; due_date: string; notes?: string }>;
}

export default function PaymentPlanModal({ isOpen, onClose, onConfirm, totalAmount, currency = 'EUR', existingPayments }: PaymentPlanModalProps) {

  const [installments, setInstallments] = useState<PaymentInstallment[]>([
    { id: '1', amount: '', dueDate: '', description: '' }
  ]);
  const [selectedTemplate, setSelectedTemplate] = useState<string>('');

  const templates = [
    {
      id: '50-50',
      name: '50/50 Teilung',
      description: '50% sofort, 50% später',
      splits: [50, 50],
      premium: false
    },
    {
      id: '30-70',
      name: '30/70 Anzahlung',
      description: '30% sofort, 70% später',
      splits: [30, 70],
      premium: true
    },
    {
      id: '20-40-40',
      name: '3 Raten (20/40/40)',
      description: '20% Anzahlung, 2x 40%',
      splits: [20, 40, 40],
      premium: true
    },
    {
      id: '25-25-25-25',
      name: '4 gleiche Raten',
      description: '4x 25%',
      splits: [25, 25, 25, 25],
      premium: true
    },
    {
      id: '33-33-33',
      name: '3 gleiche Raten',
      description: '3x 33,33%',
      splits: [33.33, 33.33, 33.34],
      premium: true
    }
  ];

  useEffect(() => {
    if (isOpen) {
      if (existingPayments && existingPayments.length > 0) {
        const loadedInstallments: PaymentInstallment[] = existingPayments.map((payment, index) => ({
          id: String(index + 1),
          amount: payment.amount.toString(),
          dueDate: payment.due_date.split('T')[0],
          description: payment.notes || ''
        }));
        setInstallments(loadedInstallments);
      } else {
        setInstallments([{ id: '1', amount: '', dueDate: '', description: '' }]);
      }
      setSelectedTemplate('');
    }
  }, [isOpen, existingPayments]);

  const handleAddInstallment = () => {
    const newId = String(installments.length + 1);
    setInstallments([...installments, { id: newId, amount: '', dueDate: '', description: '' }]);
  };

  const handleRemoveInstallment = (id: string) => {
    if (installments.length > 1) {
      setInstallments(installments.filter(inst => inst.id !== id));
    }
  };

  const handleUpdateInstallment = (id: string, field: keyof PaymentInstallment, value: string) => {
    setInstallments(installments.map(inst =>
      inst.id === id ? { ...inst, [field]: value } : inst
    ));
  };

  const handleApplyTemplate = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (!template) return;

    setSelectedTemplate(templateId);

    const today = new Date();
    const newInstallments: PaymentInstallment[] = template.splits.map((percentage, index) => {
      const amount = (totalAmount * percentage / 100).toFixed(2);
      const dueDate = new Date(today);
      dueDate.setDate(today.getDate() + (index * 30));

      let description = '';
      if (index === 0) {
        description = 'Anzahlung';
      } else if (index === template.splits.length - 1) {
        description = 'Restzahlung';
      } else {
        description = `${index}. Rate`;
      }

      return {
        id: String(index + 1),
        amount: amount,
        dueDate: dueDate.toISOString().split('T')[0],
        description
      };
    });

    setInstallments(newInstallments);
  };

  const calculateTotal = () => {
    return installments.reduce((sum, inst) => sum + (parseFloat(inst.amount) || 0), 0);
  };

  const calculateRemaining = () => {
    return totalAmount - calculateTotal();
  };

  const isValid = () => {
    if (installments.length === 0) return false;

    const allFilled = installments.every(inst =>
      inst.amount && parseFloat(inst.amount) > 0 && inst.dueDate
    );

    const total = calculateTotal();
    const difference = Math.abs(total - totalAmount);

    return allFilled && difference < 0.01;
  };

  const handleSubmit = () => {
    if (isValid()) {
      onConfirm(installments);
      onClose();
    }
  };

  if (!isOpen) return null;

  const calculatedTotal = calculateTotal();
  const remaining = calculateRemaining();
  const percentageSum = (calculatedTotal / totalAmount * 100);

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-2 sm:p-4">
      <div className="bg-white rounded-2xl sm:rounded-3xl shadow-2xl max-w-4xl w-full max-h-[95vh] sm:max-h-[90vh] flex flex-col">
        <div className="p-4 sm:p-6 border-b border-[#d4af37]/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3 pr-8 sm:pr-0 flex-1 min-w-0">
              <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-10 h-10 sm:w-12 sm:h-12 rounded-xl flex items-center justify-center shadow-lg flex-shrink-0">
                <Calendar className="w-5 h-5 sm:w-6 sm:h-6 text-white" />
              </div>
              <div className="min-w-0">
                <h2 className="text-lg sm:text-2xl font-bold text-[#0a253c]">Zahlungsplan erstellen</h2>
                <p className="text-xs sm:text-sm text-[#666666] hidden sm:block">Teile den Gesamtbetrag in mehrere Raten auf</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1.5 sm:p-2 hover:bg-[#f7f2eb] rounded-full transition-colors absolute top-3 right-3 sm:static"
            >
              <X className="w-5 h-5 sm:w-6 sm:h-6 text-[#333333]" />
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          <div className="space-y-4 sm:space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4">
              <div className="bg-gradient-to-br from-[#d4af37]/10 to-[#f4d03f]/10 rounded-xl p-4 border-2 border-[#d4af37]/30">
                <p className="text-sm text-[#666666] mb-1">Gesamtbetrag</p>
                <p className="text-2xl font-bold text-[#0a253c]">
                  {totalAmount.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currency}
                </p>
              </div>

              <div className={`bg-gradient-to-br rounded-xl p-4 border-2 ${
                Math.abs(remaining) < 0.01 ? 'from-green-50 to-green-100 border-green-300' : 'from-yellow-50 to-yellow-100 border-yellow-300'
              }`}>
                <p className="text-sm text-[#666666] mb-1">Geplante Raten</p>
                <p className={`text-2xl font-bold ${Math.abs(remaining) < 0.01 ? 'text-green-600' : 'text-yellow-600'}`}>
                  {calculatedTotal.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currency}
                </p>
              </div>

              <div className={`bg-gradient-to-br rounded-xl p-4 border-2 ${
                Math.abs(remaining) < 0.01 ? 'from-green-50 to-green-100 border-green-300' : 'from-red-50 to-red-100 border-red-300'
              }`}>
                <p className="text-sm text-[#666666] mb-1">Verbleibend</p>
                <p className={`text-2xl font-bold ${Math.abs(remaining) < 0.01 ? 'text-green-600' : 'text-red-600'}`}>
                  {remaining.toLocaleString('de-DE', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {currency}
                </p>
              </div>
            </div>

            <div>
              <h3 className="text-base sm:text-lg font-bold text-[#0a253c] mb-3">Vorlagen</h3>
              <div className="grid sm:grid-cols-2 gap-2 sm:gap-3">
                {templates.map(template => (
                  <button
                    key={template.id}
                    onClick={() => handleApplyTemplate(template.id)}
                    className={`p-3 sm:p-4 rounded-xl border-2 text-left transition-all text-sm sm:text-base relative ${
                      selectedTemplate === template.id
                        ? 'bg-[#d4af37] border-[#d4af37] text-[#0a253c]'
                        : 'bg-white border-[#d4af37]/30 hover:border-[#d4af37] text-[#0a253c]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <p className="font-bold">{template.name}</p>
                      </div>
                      {selectedTemplate === template.id && (
                        <Check className="w-5 h-5" />
                      )}
                    </div>
                    <p className="text-sm opacity-80">{template.description}</p>
                  </button>
                ))}
              </div>
              
            </div>

            <div>
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-3 gap-2">
                <h3 className="text-base sm:text-lg font-bold text-[#0a253c]">Zahlungsraten</h3>
                <button
                  onClick={handleAddInstallment}
                  className="flex items-center gap-2 px-3 py-2 bg-[#d4af37] text-[#0a253c] rounded-lg font-semibold hover:bg-[#c19a2e] transition-all text-xs sm:text-sm w-full sm:w-auto justify-center"
                >
                  <Plus className="w-3 h-3 sm:w-4 sm:h-4" />
                  Rate hinzufügen
                </button>
              </div>

              <div className="space-y-2 sm:space-y-3">
                {installments.map((installment, index) => (
                  <div
                    key={installment.id}
                    className="p-3 sm:p-4 rounded-xl bg-[#f7f2eb] border-2 border-[#d4af37]/30"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-8 h-8 rounded-full bg-[#d4af37] flex items-center justify-center">
                        <span className="text-sm font-bold text-white">{index + 1}</span>
                      </div>
                      <h4 className="font-bold text-[#0a253c]">Rate {index + 1}</h4>
                      {installments.length > 1 && (
                        <button
                          onClick={() => handleRemoveInstallment(installment.id)}
                          className="ml-auto p-2 hover:bg-red-100 rounded-lg transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-red-500" />
                        </button>
                      )}
                    </div>

                    <div className="grid sm:grid-cols-3 gap-2 sm:gap-3">
                      <div>
                        <label className="block text-sm font-semibold text-[#333333] mb-2">
                          Betrag ({currency})
                        </label>
                        <div className="relative">
                          <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[#666666]" />
                          <input
                            type="number"
                            value={installment.amount}
                            onChange={(e) => handleUpdateInstallment(installment.id, 'amount', e.target.value)}
                            className="w-full pl-10 pr-4 py-2 rounded-lg border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                            placeholder="0.00"
                            step="0.01"
                            min="0"
                          />
                        </div>
                        {installment.amount && (
                          <p className="text-xs text-[#666666] mt-1 flex items-center gap-1">
                            <Percent className="w-3 h-3" />
                            {((parseFloat(installment.amount) / totalAmount) * 100).toFixed(1)}% des Gesamtbetrags
                          </p>
                        )}
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-[#333333] mb-2">
                          Fälligkeitsdatum
                        </label>
                        <div className="relative">
                          <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[#666666]" />
                          <input
                            type="date"
                            value={installment.dueDate}
                            onChange={(e) => handleUpdateInstallment(installment.id, 'dueDate', e.target.value)}
                            className="w-full pl-10 pr-4 py-2 rounded-lg border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-[#333333] mb-2">
                          Beschreibung
                        </label>
                        <input
                          type="text"
                          value={installment.description}
                          onChange={(e) => handleUpdateInstallment(installment.id, 'description', e.target.value)}
                          className="w-full px-4 py-2 rounded-lg border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                          placeholder="z.B. Anzahlung, 1. Rate..."
                        />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {!isValid() && installments.some(i => i.amount || i.dueDate) && (
              <div className="bg-yellow-50 border-2 border-yellow-300 rounded-xl p-4">
                <div className="flex items-start gap-3">
                  <div className="flex-shrink-0 w-5 h-5 rounded-full bg-yellow-400 flex items-center justify-center mt-0.5">
                    <span className="text-white text-xs font-bold">!</span>
                  </div>
                  <div>
                    <p className="font-semibold text-yellow-900 mb-1">Zahlungsplan unvollständig</p>
                    <ul className="text-sm text-yellow-800 space-y-1">
                      {Math.abs(remaining) >= 0.01 && (
                        <li>• Die Summe der Raten ({calculatedTotal.toFixed(2)} {currency}) entspricht nicht dem Gesamtbetrag ({totalAmount.toFixed(2)} {currency})</li>
                      )}
                      {installments.some(i => !i.amount || parseFloat(i.amount) <= 0) && (
                        <li>• Alle Raten benötigen einen gültigen Betrag</li>
                      )}
                      {installments.some(i => !i.dueDate) && (
                        <li>• Alle Raten benötigen ein Fälligkeitsdatum</li>
                      )}
                    </ul>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="p-4 sm:p-6 border-t border-[#d4af37]/20">
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={handleSubmit}
              disabled={!isValid()}
              className="flex-1 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all text-sm sm:text-base"
            >
              Zahlungsplan speichern
            </button>
            <button
              onClick={onClose}
              className="px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-bold hover:bg-[#d4af37]/10 transition-all text-sm sm:text-base"
            >
              Abbrechen
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
