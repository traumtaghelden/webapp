import { Edit3, Folder } from 'lucide-react';
import { type BudgetCategory } from '../../lib/supabase';
import { BUDGET, COMMON } from '../../constants/terminology';

interface CategoryPanelsProps {
  categories: BudgetCategory[];
  categorySpending: Record<string, { planned: number; actual: number }>;
  selectedCategory: string | null;
  onSelectCategory: (categoryId: string | null) => void;
  onEditCategory: (category: BudgetCategory) => void;
}

export default function CategoryPanels({
  categories,
  categorySpending,
  selectedCategory,
  onSelectCategory,
  onEditCategory,
}: CategoryPanelsProps) {
  if (categories.length === 0) {
    return null;
  }

  return (
    <div className="space-y-3">
      <h3 className="text-lg font-bold text-[#0a253c]">{BUDGET.CATEGORY_PLURAL}</h3>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-3">
        {categories.map((category) => {
          const spending = categorySpending[category.id] || { planned: 0, actual: 0 };
          const isSelected = selectedCategory === category.id;
          const percentageUsed = spending.planned > 0
            ? (spending.actual / spending.planned) * 100
            : 0;

          return (
            <div
              key={category.id}
              onClick={() => onSelectCategory(isSelected ? null : category.id)}
              className={`group relative p-4 rounded-xl border-2 transition-all cursor-pointer hover:shadow-lg ${
                isSelected
                  ? 'border-[#d4af37] bg-[#f7f2eb] shadow-md'
                  : 'border-gray-200 bg-white hover:border-[#d4af37]/50'
              }`}
            >
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onEditCategory(category);
                }}
                className="absolute top-2 right-2 p-1.5 bg-white/80 hover:bg-white rounded-lg transition-all opacity-0 group-hover:opacity-100 z-10"
                title={`${BUDGET.CATEGORY} ${COMMON.EDIT.toLowerCase()}`}
              >
                <Edit3 className="w-3.5 h-3.5 text-[#666666] hover:text-[#d4af37]" />
              </button>

              <div className="flex items-center gap-2 mb-3">
                <div
                  className="p-2 rounded-lg"
                  style={{ backgroundColor: `${category.color}20` }}
                >
                  <Folder className="w-4 h-4" style={{ color: category.color }} />
                </div>
                <h4 className="font-bold text-sm text-[#0a253c] truncate flex-1 pr-6">
                  {category.name}
                </h4>
              </div>

              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#666666]">{BUDGET.ESTIMATED_COST}:</span>
                  <span className="font-semibold text-[#0a253c]">
                    {spending.planned.toLocaleString('de-DE')} €
                  </span>
                </div>
                <div className="flex items-center justify-between text-xs">
                  <span className="text-[#666666]">{BUDGET.ACTUAL_COST}:</span>
                  <span className={`font-semibold ${
                    spending.actual > spending.planned ? 'text-red-600' : 'text-green-600'
                  }`}>
                    {spending.actual.toLocaleString('de-DE')} €
                  </span>
                </div>
              </div>

              {spending.planned > 0 && (
                <div className="mt-3">
                  <div className="w-full bg-gray-200 rounded-full h-1.5 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        percentageUsed > 100 ? 'bg-red-500' :
                        percentageUsed > 90 ? 'bg-yellow-500' :
                        'bg-green-500'
                      }`}
                      style={{ width: `${Math.min(percentageUsed, 100)}%` }}
                    />
                  </div>
                </div>
              )}

              {isSelected && (
                <div className="absolute inset-0 rounded-xl border-2 border-[#d4af37] pointer-events-none" />
              )}
            </div>
          );
        })}
      </div>

      <style>{`
        @media (max-width: 640px) {
          .grid {
            grid-template-columns: repeat(2, 1fr);
          }
        }
      `}</style>
    </div>
  );
}
