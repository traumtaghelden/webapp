import { ArrowRight, TrendingUp, TrendingDown, DollarSign } from 'lucide-react';
import { type BudgetItem } from '../../lib/supabase';

interface BudgetComparisonTabProps {
  budgetItems: BudgetItem[];
  totalBudget: number;
}

export default function BudgetComparisonTab({ budgetItems, totalBudget }: BudgetComparisonTabProps) {
  const totalPlanned = budgetItems.reduce((sum, item) => sum + (item.estimated_cost || 0), 0);
  const totalActual = budgetItems.reduce((sum, item) => sum + (item.actual_cost || 0), 0);
  const difference = totalActual - totalPlanned;
  const percentDiff = totalPlanned > 0 ? (difference / totalPlanned) * 100 : 0;

  const getVarianceColor = (planned: number, actual: number) => {
    if (actual > planned) return 'text-red-500';
    if (actual < planned * 0.9) return 'text-green-600';
    return 'text-gray-600';
  };

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-[#0a253c]">Geplant vs. Tatsächlich</h3>
        <p className="text-gray-600 mt-1">Vergleiche deine geplanten mit den tatsächlichen Kosten</p>
      </div>

      <div className="bg-gradient-to-br from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-2xl p-8 text-white shadow-xl">
        <h4 className="text-lg font-semibold mb-6 opacity-90">Gesamtübersicht</h4>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div>
            <p className="text-sm opacity-75 mb-2">Geplante Kosten</p>
            <p className="text-3xl font-bold">{totalPlanned.toLocaleString('de-DE')} €</p>
          </div>
          <div className="flex items-center justify-center">
            <ArrowRight className="w-8 h-8 text-[#d4af37]" />
          </div>
          <div>
            <p className="text-sm opacity-75 mb-2">Tatsächliche Kosten</p>
            <p className="text-3xl font-bold">{totalActual.toLocaleString('de-DE')} €</p>
          </div>
        </div>
        <div className="mt-6 pt-6 border-t border-white/10">
          <div className="flex items-center justify-between">
            <span className="text-sm opacity-90">Differenz</span>
            <div className="flex items-center gap-3">
              {difference >= 0 ? (
                <TrendingUp className="w-5 h-5 text-red-400" />
              ) : (
                <TrendingDown className="w-5 h-5 text-green-400" />
              )}
              <span className={`text-xl font-bold ${difference >= 0 ? 'text-red-400' : 'text-green-400'}`}>
                {difference >= 0 ? '+' : ''}{difference.toLocaleString('de-DE')} €
              </span>
              <span className={`text-sm ${difference >= 0 ? 'text-red-400' : 'text-green-400'}`}>
                ({percentDiff >= 0 ? '+' : ''}{percentDiff.toFixed(1)}%)
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-md border-2 border-gray-100">
        <h4 className="text-xl font-bold text-[#0a253c] mb-6">Detaillierter Vergleich</h4>
        <div className="space-y-3">
          {budgetItems.map(item => {
            const planned = item.estimated_cost || 0;
            const actual = item.actual_cost || 0;
            const diff = actual - planned;
            const diffPercent = planned > 0 ? (diff / planned) * 100 : 0;

            return (
              <div key={item.id} className="p-4 bg-gray-50 hover:bg-gray-100 rounded-xl transition-all">
                <div className="flex items-start justify-between mb-3">
                  <div className="flex-1">
                    <p className="font-bold text-[#0a253c] mb-1">{item.name}</p>
                    <p className="text-sm text-gray-600">{item.category || 'Ohne Kategorie'}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4 mb-3">
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Geplant</p>
                    <p className="text-lg font-bold text-gray-700">{planned.toLocaleString('de-DE')} €</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500 mb-1">Tatsächlich</p>
                    <p className={`text-lg font-bold ${getVarianceColor(planned, actual)}`}>
                      {actual.toLocaleString('de-DE')} €
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                        <div
                          className="bg-blue-500 h-full rounded-full"
                          style={{ width: '100%' }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 min-w-[50px] text-right">Geplant</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                        <div
                          className={`h-full rounded-full ${
                            actual > planned ? 'bg-red-500' : 'bg-green-500'
                          }`}
                          style={{ width: `${Math.min((actual / planned) * 100, 100)}%` }}
                        />
                      </div>
                      <span className="text-xs text-gray-500 min-w-[50px] text-right">Aktuell</span>
                    </div>
                  </div>
                  <div className="text-right min-w-[100px]">
                    <p className={`text-sm font-bold ${diff >= 0 ? 'text-red-500' : 'text-green-600'}`}>
                      {diff >= 0 ? '+' : ''}{diff.toLocaleString('de-DE')} €
                    </p>
                    <p className={`text-xs ${diff >= 0 ? 'text-red-500' : 'text-green-600'}`}>
                      {diffPercent >= 0 ? '+' : ''}{diffPercent.toFixed(1)}%
                    </p>
                  </div>
                </div>
              </div>
            );
          })}

          {budgetItems.length === 0 && (
            <div className="text-center py-16 text-gray-500">
              <DollarSign className="w-16 h-16 mx-auto mb-4 opacity-30" />
              <p className="text-lg font-semibold mb-2">Keine Daten für Vergleich</p>
              <p className="text-sm">Füge Budget-Einträge hinzu, um einen Vergleich zu sehen</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
