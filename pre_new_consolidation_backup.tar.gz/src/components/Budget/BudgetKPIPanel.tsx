import { Wallet, PiggyBank, TrendingDown, AlertTriangle } from 'lucide-react';
import { type BudgetItem, type BudgetPayment } from '../../lib/supabase';
import KPICard from '../common/KPICard';
import { BUDGET } from '../../constants/terminology';

interface BudgetKPIPanelProps {
  totalBudget: number;
  items: BudgetItem[];
  onFilterChange?: (filter: string | null) => void;
}

export default function BudgetKPIPanel({ totalBudget, items, onFilterChange }: BudgetKPIPanelProps) {
  const totalSpent = items.reduce((sum, item) => sum + (item.actual_cost || 0), 0);
  const remaining = totalBudget - totalSpent;

  const now = new Date();
  const currentMonth = now.toLocaleDateString('de-DE', { month: 'long', year: 'numeric' });

  const monthlyDue = items.reduce((sum, item) => {
    const payments = (item.budget_payments || []) as BudgetPayment[];
    const monthlyPayments = payments.filter(p => {
      if (p.status === 'paid') return false;
      const dueDate = new Date(p.due_date);
      return dueDate.getMonth() === now.getMonth() && dueDate.getFullYear() === now.getFullYear();
    });
    return sum + monthlyPayments.reduce((pSum, p) => pSum + Number(p.amount), 0);
  }, 0);

  const overduePayments = items.reduce((count, item) => {
    const payments = (item.budget_payments || []) as BudgetPayment[];
    const overdue = payments.filter(p => {
      if (p.status === 'paid') return false;
      return new Date(p.due_date) < now;
    });
    return count + overdue.length;
  }, 0);

  const percentageRemaining = totalBudget > 0 ? Math.round((remaining / totalBudget) * 100) : 0;

  const metrics = [
    {
      icon: <Wallet className="w-6 h-6 text-[#d4af37]" />,
      label: 'Gesamtbudget',
      value: totalBudget,
      subtitle: `${items.length} ${BUDGET.ITEM_PLURAL}`,
      color: 'border-[#d4af37]',
      delay: 0,
      filter: null
    },
    {
      icon: <PiggyBank className="w-6 h-6 text-green-600" />,
      label: 'Übriges Budget',
      value: Math.max(0, remaining),
      subtitle: `${percentageRemaining}% verfügbar`,
      color: remaining < 0 ? 'border-red-500' : 'border-green-500',
      delay: 100,
      filter: 'remaining'
    },
    {
      icon: <TrendingDown className="w-6 h-6 text-blue-600" />,
      label: 'Monatliche Ausgaben',
      value: monthlyDue,
      subtitle: `Fällig in ${currentMonth}`,
      color: 'border-blue-500',
      delay: 200,
      filter: 'monthly'
    },
    {
      icon: <AlertTriangle className="w-6 h-6 text-red-600" />,
      label: 'Offene Zahlungen',
      value: overduePayments,
      subtitle: overduePayments > 0 ? 'Benötigt Aufmerksamkeit' : 'Keine überfälligen',
      color: 'border-red-500',
      delay: 300,
      filter: 'overdue'
    }
  ];

  return (
    <div className="relative overflow-hidden bg-gradient-to-br from-[#f7f2eb] via-white to-[#f7f2eb] rounded-3xl shadow-xl mb-8">
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxnIGZpbGw9IiNkNGFmMzciIGZpbGwtb3BhY2l0eT0iMC4wMyI+PHBhdGggZD0iTTM2IDM0djItaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTAtNHYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6bTItMnYyaDJ2LTJoLTJ6Ii8+PC9nPjwvZz48L3N2Zz4=')] opacity-40"></div>

      <div className="relative p-8">
        <div className="mb-6">
          <h2 className="text-3xl font-bold text-[#0a253c] mb-2">
            Übersicht
          </h2>
          <p className="text-[#666666]">
            Alle wichtigen Kennzahlen auf einen Blick
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {metrics.map((metric, index) => (
            <KPICard
              key={index}
              icon={metric.icon}
              label={metric.label}
              value={typeof metric.value === 'number' ? `${metric.value.toLocaleString('de-DE')} €` : metric.value}
              subtitle={metric.subtitle}
              color={metric.color}
              delay={metric.delay}
              onClick={onFilterChange ? () => onFilterChange(metric.filter) : undefined}
            />
          ))}
        </div>
      </div>

      <div className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-[#d4af37] via-blue-500 to-green-500"></div>
    </div>
  );
}
