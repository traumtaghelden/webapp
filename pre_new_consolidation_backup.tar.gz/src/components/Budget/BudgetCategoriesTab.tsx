import { useState } from 'react';
import { Plus, Edit2, Trash2, DollarSign, TrendingUp, TrendingDown } from 'lucide-react';
import { type BudgetCategory } from '../../lib/supabase';
import { BUDGET, COMMON } from '../../constants/terminology';

interface BudgetCategoriesTabProps {
  categories: BudgetCategory[];
  categorySpending: Record<string, { planned: number; actual: number }>;
  onEditCategory: (category: BudgetCategory) => void;
  onAddCategory: () => void;
  onDeleteCategory: (categoryId: string) => void;
}

export default function BudgetCategoriesTab({
  categories,
  categorySpending,
  onEditCategory,
  onAddCategory,
  onDeleteCategory,
}: BudgetCategoriesTabProps) {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold text-[#0a253c]">Kategorie-Verwaltung</h3>
          <p className="text-gray-600 mt-1">Verwalte deine Budget-Kategorien und deren Ausgaben</p>
        </div>
        <button
          onClick={onAddCategory}
          className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c19a2e] hover:shadow-lg transition-all hover:scale-105"
        >
          <Plus className="w-5 h-5" />
          Kategorie erstellen
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {categories.map((category) => {
          const spending = categorySpending[category.id] || { planned: 0, actual: 0 };
          const percentage = spending.planned > 0 ? (spending.actual / spending.planned) * 100 : 0;
          const isOverBudget = spending.actual > spending.planned;

          return (
            <div
              key={category.id}
              className="bg-white rounded-2xl p-6 shadow-md hover:shadow-xl transition-all border-2 border-gray-100 hover:border-[#d4af37]/30"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: category.color || '#d4af37' }}
                    />
                    <h4 className="text-lg font-bold text-[#0a253c]">{category.name}</h4>
                  </div>
                  {category.description && (
                    <p className="text-sm text-gray-600 line-clamp-2">{category.description}</p>
                  )}
                </div>
                <div className="flex items-center gap-1">
                  <button
                    onClick={() => onEditCategory(category)}
                    className="p-2 text-gray-400 hover:text-[#d4af37] hover:bg-[#f7f2eb] rounded-lg transition-all"
                  >
                    <Edit2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => onDeleteCategory(category.id)}
                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-all"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              <div className="space-y-3">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Geplant:</span>
                  <span className="font-bold text-[#0a253c]">{spending.planned.toLocaleString('de-DE')} €</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Ausgegeben:</span>
                  <span className={`font-bold ${isOverBudget ? 'text-red-500' : 'text-green-600'}`}>
                    {spending.actual.toLocaleString('de-DE')} €
                  </span>
                </div>

                <div className="pt-3 border-t border-gray-100">
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-semibold text-gray-500">Budgetauslastung</span>
                    <div className="flex items-center gap-1">
                      {isOverBudget ? (
                        <TrendingUp className="w-4 h-4 text-red-500" />
                      ) : (
                        <TrendingDown className="w-4 h-4 text-green-600" />
                      )}
                      <span className={`text-xs font-bold ${isOverBudget ? 'text-red-500' : 'text-green-600'}`}>
                        {percentage.toFixed(0)}%
                      </span>
                    </div>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2 overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-300 ${
                        isOverBudget ? 'bg-red-500' : 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f]'
                      }`}
                      style={{ width: `${Math.min(percentage, 100)}%` }}
                    />
                  </div>
                </div>

                {category.budget_limit && (
                  <div className="flex items-center gap-2 p-2 bg-[#f7f2eb] rounded-lg mt-3">
                    <DollarSign className="w-4 h-4 text-[#d4af37]" />
                    <span className="text-xs font-semibold text-[#0a253c]">
                      Limit: {category.budget_limit.toLocaleString('de-DE')} €
                    </span>
                  </div>
                )}
              </div>
            </div>
          );
        })}

        {categories.length === 0 && (
          <div className="col-span-full text-center py-16 bg-[#f7f2eb] rounded-2xl">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Plus className="w-10 h-10 text-[#d4af37]" />
            </div>
            <p className="text-gray-600 text-lg mb-2 font-semibold">Noch keine Kategorien</p>
            <p className="text-gray-500 text-sm mb-6">Erstelle deine erste Budget-Kategorie</p>
            <button
              onClick={onAddCategory}
              className="px-6 py-3 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c19a2e] hover:shadow-lg transition-all"
            >
              Kategorie erstellen
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
