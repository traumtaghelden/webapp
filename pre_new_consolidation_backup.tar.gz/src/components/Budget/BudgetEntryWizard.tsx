import { useState, useEffect } from 'react';
import { X, ArrowRight, ArrowLeft, DollarSign, Calendar, Users, Lock, CheckCircle, CreditCard } from 'lucide-react';
import { supabase, type BudgetCategory } from '../../lib/supabase';
import { BUDGET, COMMON } from '../../constants/terminology';

interface BudgetEntryWizardProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
  weddingId: string;
  categories: BudgetCategory[];
  onCreateCategory: () => void;
}

type Step = 1 | 2 | 3;
type CalculationType = 'total' | 'perHead';
type PaymentType = 'single' | 'installments' | 'paid';
type InstallmentType = 'deposit' | 'equal' | 'custom';

interface PaymentPlan {
  amount: number;
  dueDate: string;
  description: string;
}

export default function BudgetEntryWizard({
  isOpen,
  onClose,
  onSuccess,
  weddingId,
  categories,
  onCreateCategory,
}: BudgetEntryWizardProps) {

  const [step, setStep] = useState<Step>(1);
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState('');
  const [calculationType, setCalculationType] = useState<CalculationType>('total');
  const [totalAmount, setTotalAmount] = useState('');
  const [perHeadAmount, setPerHeadAmount] = useState('');
  const [guestCount, setGuestCount] = useState(0);
  const [paymentType, setPaymentType] = useState<PaymentType>('single');
  const [installmentType, setInstallmentType] = useState<InstallmentType>('deposit');
  const [singlePaymentDate, setSinglePaymentDate] = useState('');
  const [depositAmount, setDepositAmount] = useState('');
  const [depositDate, setDepositDate] = useState('');
  const [finalAmount, setFinalAmount] = useState('');
  const [finalDate, setFinalDate] = useState('');
  const [equalInstallments, setEqualInstallments] = useState('3');
  const [customPayments, setCustomPayments] = useState<PaymentPlan[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  useEffect(() => {
    if (isOpen) {
      loadGuestCount();
    }
  }, [isOpen, weddingId]);

  const loadGuestCount = async () => {
    try {
      const { data } = await supabase
        .from('guests')
        .select('invitation_status')
        .eq('wedding_id', weddingId);

      if (data) {
        const confirmed = data.filter(g => g.invitation_status === 'confirmed').length;
        setGuestCount(confirmed);
      }
    } catch (error) {
      console.error('Error loading guest count:', error);
    }
  };

  const resetForm = () => {
    setStep(1);
    setTitle('');
    setCategory('');
    setCalculationType('total');
    setTotalAmount('');
    setPerHeadAmount('');
    setPaymentType('single');
    setInstallmentType('deposit');
    setSinglePaymentDate('');
    setDepositAmount('');
    setDepositDate('');
    setFinalAmount('');
    setFinalDate('');
    setEqualInstallments('3');
    setCustomPayments([]);
  };

  const handleClose = () => {
    resetForm();
    onClose();
  };

  const canProceedStep1 = title.trim() !== '' && category !== '';
  const canProceedStep2 = calculationType === 'total' ? totalAmount !== '' : perHeadAmount !== '';

  const calculatedTotal = calculationType === 'perHead' && perHeadAmount
    ? parseFloat(perHeadAmount) * guestCount
    : parseFloat(totalAmount) || 0;

  const handleStep2Next = () => {
    setStep(3);
  };

  const handleSubmit = async () => {
    if (isSubmitting) return;

    setIsSubmitting(true);

    try {
      const actualCost = calculatedTotal;
      const isPaid = paymentType === 'paid';

      const { data: budgetItem, error: itemError } = await supabase
        .from('budget_items')
        .insert({
          wedding_id: weddingId,
          category,
          item_name: title,
          estimated_cost: actualCost,
          actual_cost: actualCost,
          paid: isPaid,
          payment_status: isPaid ? 'paid' : 'pending',
          is_per_person: calculationType === 'perHead',
          cost_per_person: calculationType === 'perHead' ? parseFloat(perHeadAmount) : null,
        })
        .select()
        .single();

      if (itemError) throw itemError;

      if (paymentType === 'single' && singlePaymentDate && !isPaid) {
        await supabase.from('budget_payments').insert({
          budget_item_id: budgetItem.id,
          amount: actualCost,
          due_date: singlePaymentDate,
          status: 'pending',
          notes: 'Einmalzahlung',
          payment_method: 'bank_transfer',
        });
      } else if (paymentType === 'installments') {
        if (installmentType === 'deposit') {
          const deposit = parseFloat(depositAmount);
          const final = parseFloat(finalAmount);

          await supabase.from('budget_payments').insert([
            {
              budget_item_id: budgetItem.id,
              amount: deposit,
              due_date: depositDate,
              status: 'pending',
              notes: 'Anzahlung',
              payment_method: 'bank_transfer',
            },
            {
              budget_item_id: budgetItem.id,
              amount: final,
              due_date: finalDate,
              status: 'pending',
              notes: 'Schlussrate',
              payment_method: 'bank_transfer',
            },
          ]);
        } else if (installmentType === 'equal') {
          const count = parseInt(equalInstallments);
          const amountPerInstallment = actualCost / count;
          const today = new Date();

          const payments = Array.from({ length: count }, (_, i) => ({
            budget_item_id: budgetItem.id,
            amount: amountPerInstallment,
            due_date: new Date(today.setMonth(today.getMonth() + i)).toISOString().split('T')[0],
            status: 'pending' as const,
            notes: `Rate ${i + 1} von ${count}`,
            payment_method: 'bank_transfer',
          }));

          await supabase.from('budget_payments').insert(payments);
        } else if (installmentType === 'custom' && customPayments.length > 0) {
          const payments = customPayments.map(p => ({
            budget_item_id: budgetItem.id,
            amount: p.amount,
            due_date: p.dueDate,
            status: 'pending' as const,
            notes: p.description,
            payment_method: 'bank_transfer',
          }));

          await supabase.from('budget_payments').insert(payments);
        }
      }

      onSuccess();
      handleClose();
    } catch (error) {
      console.error('Error creating budget item:', error);
      alert('Fehler beim Erstellen des Eintrags');
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/60 backdrop-blur-md flex items-center justify-center z-[9999] p-4">
      <div className="bg-gradient-to-b from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-3xl shadow-gold-lg border-2 border-[#d4af37]/30 max-w-2xl w-full max-h-[90vh] flex flex-col relative overflow-hidden">
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyMTIsIDE3NSwgNTUsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20"></div>
        <div className="relative z-10 p-6 border-b border-[#d4af37]/30">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-2xl font-bold text-white">{BUDGET.ADD_ITEM}</h2>
            <button onClick={handleClose} className="p-2 hover:bg-white/10 rounded-full transition-all">
              <X className="w-6 h-6 text-white/80 hover:text-white" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            {[1, 2, 3].map(s => (
              <div key={s} className="flex items-center flex-1">
                <div
                  className={`flex items-center justify-center w-8 h-8 rounded-full font-bold text-sm transition-all ${
                    step >= s
                      ? 'bg-[#d4af37] text-white'
                      : 'bg-white/20 text-white/60'
                  }`}
                >
                  {step > s ? <CheckCircle className="w-5 h-5" /> : s}
                </div>
                {s < 3 && (
                  <div className={`flex-1 h-1 mx-2 rounded ${step > s ? 'bg-[#d4af37]' : 'bg-white/20'}`} />
                )}
              </div>
            ))}
          </div>
        </div>

        <div className="relative z-10 flex-1 overflow-y-auto p-6">
          {step === 1 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-white/90 mb-2">
                  Titel <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  placeholder="z.B. Hochzeitstorte"
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-white/90 mb-2">
                  {BUDGET.CATEGORY} <span className="text-red-500">*</span>
                </label>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm transition-all"
                >
                  <option value="">{BUDGET.CATEGORY} auswählen</option>
                  {categories.map(cat => (
                    <option key={cat.id} value={cat.name}>
                      {cat.name}
                    </option>
                  ))}
                </select>
                <button
                  onClick={onCreateCategory}
                  className="mt-2 text-sm text-[#d4af37] hover:underline font-semibold"
                >
                  + Neue {BUDGET.CATEGORY} erstellen
                </button>
              </div>
            </div>
          )}

          {step === 2 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-white mb-3">Berechnungsart</label>
                <div className="grid grid-cols-2 gap-3">
                  <button
                    onClick={() => setCalculationType('total')}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      calculationType === 'total'
                        ? 'border-[#d4af37] bg-[#d4af37]/20'
                        : 'border-white/20 hover:border-[#d4af37]/50'
                    }`}
                  >
                    <DollarSign className="w-6 h-6 mx-auto mb-2 text-[#d4af37]" />
                    <div className="font-semibold text-white">Gesamtbetrag</div>
                  </button>

                  <button
                    onClick={() => {
                      setCalculationType('perHead');
                    }}
                    className={`p-4 rounded-xl border-2 transition-all relative ${
                      calculationType === 'perHead'
                        ? 'border-[#d4af37] bg-[#d4af37]/20'
                        : 'border-white/20 hover:border-[#d4af37]/50'
                    }`}
                  >
                    <Users className="w-6 h-6 mx-auto mb-2 text-[#d4af37]" />
                    <div className="font-semibold text-white">Pro Kopf</div>
                    {false && (
                      <div className="absolute -top-2 -right-2 bg-[#d4af37] text-white rounded-full p-1">
                        <Lock className="w-4 h-4" />
                      </div>
                    )}
                  </button>
                </div>
              </div>

              {calculationType === 'total' ? (
                <div>
                  <label className="block text-sm font-semibold text-white/90 mb-2">
                    Gesamtbetrag <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      value={totalAmount}
                      onChange={e => setTotalAmount(e.target.value)}
                      placeholder="0"
                      className="w-full px-4 py-3 pr-12 rounded-xl border-2 border-white/20 focus:border-[#d4af37] focus:outline-none transition-all"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white/70 font-semibold">€</span>
                  </div>
                </div>
              ) : (
                <div>
                  <label className="block text-sm font-semibold text-white/90 mb-2">
                    Betrag pro Person <span className="text-red-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      value={perHeadAmount}
                      onChange={e => setPerHeadAmount(e.target.value)}
                      placeholder="0"
                      className="w-full px-4 py-3 pr-12 rounded-xl border-2 border-white/20 focus:border-[#d4af37] focus:outline-none transition-all"
                    />
                    <span className="absolute right-4 top-1/2 -translate-y-1/2 text-white/70 font-semibold">€</span>
                  </div>

                  {perHeadAmount && (
                    <div className="mt-4 p-4 bg-blue-500/20 rounded-xl border-2 border-blue-500/50">
                      <div className="text-sm text-blue-300 mb-1">Live-Berechnung:</div>
                      <div className="text-2xl font-bold text-white">
                        {guestCount} Gäste × {perHeadAmount} € = {calculatedTotal.toLocaleString('de-DE')} €
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {step === 3 && (
            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-white mb-3">Zahlungsart</label>
                <div className="grid grid-cols-3 gap-3 mb-6">
                  <button
                    onClick={() => setPaymentType('single')}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      paymentType === 'single'
                        ? 'border-[#d4af37] bg-[#d4af37]/20'
                        : 'border-white/20 hover:border-[#d4af37]/50'
                    }`}
                  >
                    <Calendar className="w-6 h-6 mx-auto mb-2 text-[#d4af37]" />
                    <div className="text-sm font-semibold text-white">Einmalzahlung</div>
                  </button>

                  <button
                    onClick={() => setPaymentType('installments')}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      paymentType === 'installments'
                        ? 'border-[#d4af37] bg-[#d4af37]/20'
                        : 'border-white/20 hover:border-[#d4af37]/50'
                    }`}
                  >
                    <CreditCard className="w-6 h-6 mx-auto mb-2 text-[#d4af37]" />
                    <div className="text-sm font-semibold text-white">Ratenzahlung</div>
                  </button>

                  <button
                    onClick={() => setPaymentType('paid')}
                    className={`p-4 rounded-xl border-2 transition-all ${
                      paymentType === 'paid'
                        ? 'border-[#d4af37] bg-[#d4af37]/20'
                        : 'border-white/20 hover:border-[#d4af37]/50'
                    }`}
                  >
                    <CheckCircle className="w-6 h-6 mx-auto mb-2 text-green-600" />
                    <div className="text-sm font-semibold text-white">Bereits bezahlt</div>
                  </button>
                </div>

                {paymentType === 'single' && (
                  <div>
                    <label className="block text-sm font-semibold text-white/90 mb-2">Fälligkeitsdatum</label>
                    <input
                      type="date"
                      value={singlePaymentDate}
                      onChange={e => setSinglePaymentDate(e.target.value)}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm transition-all"
                    />
                  </div>
                )}

                {paymentType === 'installments' && (
                  <div className="space-y-4">
                    <div className="flex gap-2">
                      <button
                        onClick={() => setInstallmentType('deposit')}
                        className={`flex-1 px-4 py-2 rounded-lg font-semibold transition-all ${
                          installmentType === 'deposit'
                            ? 'bg-[#d4af37] text-white'
                            : 'bg-white/10 text-white/70 hover:bg-white/20'
                        }`}
                      >
                        Anzahlung + Schlussrate
                      </button>
                      <button
                        onClick={() => setInstallmentType('equal')}
                        className={`flex-1 px-4 py-2 rounded-lg font-semibold transition-all ${
                          installmentType === 'equal'
                            ? 'bg-[#d4af37] text-white'
                            : 'bg-white/10 text-white/70 hover:bg-white/20'
                        }`}
                      >
                        Gleiche Raten
                      </button>
                    </div>

                    {installmentType === 'deposit' && (
                      <div className="space-y-4 p-4 bg-white/10 rounded-xl">
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-white/70 mb-1">Anzahlung</label>
                            <input
                              type="number"
                              value={depositAmount}
                              onChange={e => {
                                setDepositAmount(e.target.value);
                                const remaining = calculatedTotal - parseFloat(e.target.value || '0');
                                setFinalAmount(remaining.toString());
                              }}
                              placeholder="0 €"
                              className="w-full px-3 py-2 rounded-lg border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-white/70 mb-1">Datum</label>
                            <input
                              type="date"
                              value={depositDate}
                              onChange={e => setDepositDate(e.target.value)}
                              className="w-full px-3 py-2 rounded-lg border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                            />
                          </div>
                        </div>
                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-xs font-semibold text-white/70 mb-1">Schlussrate</label>
                            <input
                              type="number"
                              value={finalAmount}
                              onChange={e => setFinalAmount(e.target.value)}
                              placeholder="0 €"
                              className="w-full px-3 py-2 rounded-lg border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                            />
                          </div>
                          <div>
                            <label className="block text-xs font-semibold text-white/70 mb-1">Datum</label>
                            <input
                              type="date"
                              value={finalDate}
                              onChange={e => setFinalDate(e.target.value)}
                              className="w-full px-3 py-2 rounded-lg border-2 border-[#d4af37]/30 bg-white/10 text-white placeholder-white/50 focus:border-[#d4af37] focus:outline-none backdrop-blur-sm"
                            />
                          </div>
                        </div>
                      </div>
                    )}

                    {installmentType === 'equal' && (
                      <div className="p-4 bg-white/10 rounded-xl">
                        <label className="block text-sm font-semibold text-white/90 mb-2">Anzahl Raten</label>
                        <select
                          value={equalInstallments}
                          onChange={e => setEqualInstallments(e.target.value)}
                          className="w-full px-4 py-3 rounded-xl border-2 border-white/20 focus:border-[#d4af37] focus:outline-none"
                        >
                          {[2, 3, 4, 5, 6, 12].map(n => (
                            <option key={n} value={n}>
                              {n} Raten à {(calculatedTotal / n).toLocaleString('de-DE')} €
                            </option>
                          ))}
                        </select>
                      </div>
                    )}
                  </div>
                )}

                {paymentType === 'paid' && (
                  <div className="p-4 bg-green-50 rounded-xl border-2 border-green-200">
                    <div className="flex items-center gap-2 text-green-700">
                      <CheckCircle className="w-5 h-5" />
                      <span className="font-semibold">Dieser Betrag wird als bereits bezahlt markiert.</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        <div className="relative z-10 p-6 border-t border-[#d4af37]/30 flex justify-between gap-3 bg-gradient-to-b from-transparent to-[#0a253c]/50 backdrop-blur-sm">
          {step > 1 ? (
            <button
              onClick={() => setStep((step - 1) as Step)}
              className="flex items-center gap-2 px-6 py-3 border-2 border-[#d4af37]/40 text-white/70 rounded-xl font-bold hover:bg-white/10 transition-all"
            >
              <ArrowLeft className="w-5 h-5" />
              {COMMON.BACK}
            </button>
          ) : (
            <button
              onClick={handleClose}
              className="px-6 py-3 border-2 border-[#d4af37]/40 text-white/70 rounded-xl font-bold hover:bg-white/10 transition-all"
            >
              {COMMON.CANCEL}
            </button>
          )}

          {step < 3 ? (
            <button
              onClick={() => (step === 1 ? setStep(2) : handleStep2Next())}
              disabled={step === 1 ? !canProceedStep1 : !canProceedStep2}
              className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c19a2e] transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Weiter
              <ArrowRight className="w-5 h-5" />
            </button>
          ) : (
            <button
              onClick={handleSubmit}
              disabled={isSubmitting}
              className="flex items-center gap-2 px-6 py-3 bg-green-600 text-white rounded-xl font-bold hover:bg-green-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <CheckCircle className="w-5 h-5" />
              {isSubmitting ? 'Wird erstellt...' : `${BUDGET.ITEM} erstellen`}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
