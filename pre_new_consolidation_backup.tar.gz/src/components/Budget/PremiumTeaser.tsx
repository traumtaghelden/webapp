import { Users, CreditCard, Building2, FileText, ArrowRight, Sparkles } from 'lucide-react';

interface Feature {
  icon: React.ReactNode;
  title: string;
  description: string;
}

export default function PremiumTeaser() {
  const { showUpgrade } = useUpgrade();

  const features: Feature[] = [
    {
      icon: <Users className="w-6 h-6 text-[#d4af37]" />,
      title: 'Pro-Kopf-Berechnung',
      description: 'Automatische Berechnung basierend auf bestätigten Gästen',
    },
    {
      icon: <CreditCard className="w-6 h-6 text-[#d4af37]" />,
      title: 'Eigene Ratenpläne',
      description: 'Flexible Zahlungspläne nach euren Bedürfnissen',
    },
    {
      icon: <Building2 className="w-6 h-6 text-[#d4af37]" />,
      title: 'Dienstleister-Verknüpfung',
      description: 'Automatische Synchronisation mit gebuchten Anbietern',
    },
    {
      icon: <FileText className="w-6 h-6 text-[#d4af37]" />,
      title: 'PDF-Export',
      description: 'Professionelle Budget-Übersichten zum Download',
    },
  ];

  return (
    <div className="mt-8 bg-gradient-to-br from-[#f7f2eb] via-white to-[#fefdfb] rounded-3xl p-8 border-2 border-[#d4af37]/20 relative overflow-hidden">
      <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-[#d4af37]/10 to-transparent rounded-full blur-3xl" />

      <div className="relative">
        <div className="flex items-center gap-3 mb-6">
          <div className="p-3 bg-[#d4af37]/10 rounded-2xl">
            <Sparkles className="w-8 h-8 text-[#d4af37]" />
          </div>
          <div>
            <h3 className="text-2xl font-bold text-[#0a253c]">
              Mit Premium plant ihr euer Budget wie Profis
            </h3>
            <p className="text-[#666666] mt-1">
              Professionelle Tools für eine stressfreie Budget-Verwaltung
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
          {features.map((feature, index) => (
            <div
              key={index}
              className="bg-white rounded-2xl p-5 border-2 border-[#d4af37]/20 hover:border-[#d4af37] hover:shadow-lg transition-all duration-300 group"
              style={{
                animation: `slideInUp 0.5s ease-out ${index * 0.1}s backwards`,
              }}
            >
              <div className="flex items-center justify-center w-12 h-12 bg-[#f7f2eb] rounded-xl mb-3 group-hover:scale-110 transition-transform">
                {feature.icon}
              </div>
              <h4 className="font-bold text-[#0a253c] mb-2">{feature.title}</h4>
              <p className="text-sm text-[#666666] leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>

        <div className="flex justify-center">
          <div className="text-center">
            <p className="text-[#666666] text-sm">Alle Features sind jetzt verfügbar!</p>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slideInUp {
          from {
            opacity: 0;
            transform: translateY(20px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </div>
  );
}
