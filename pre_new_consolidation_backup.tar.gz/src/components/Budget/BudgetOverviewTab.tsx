import { Plus, Folder, X } from 'lucide-react';
import { type BudgetItem, type BudgetCategory } from '../../lib/supabase';
import { BUDGET, COMMON } from '../../constants/terminology';
import BudgetKPIPanel from './BudgetKPIPanel';
import CategoryPanels from './CategoryPanels';
import BudgetTable from './BudgetTable';

interface BudgetOverviewTabProps {
  weddingId: string;
  budgetItems: BudgetItem[];
  enrichedItems: BudgetItem[];
  totalBudget: number;
  categories: BudgetCategory[];
  categorySpending: Record<string, { planned: number; actual: number }>;
  selectedCategory: string | null;
  onSelectCategory: (categoryId: string | null) => void;
  onEditCategory: (category: BudgetCategory) => void;
  onAddEntry: () => void;
  onAddCategory: () => void;
  onViewItem: (itemId: string) => void;
  onDeleteItem: (itemId: string) => void;
}

export default function BudgetOverviewTab({
  budgetItems,
  enrichedItems,
  totalBudget,
  categories,
  categorySpending,
  selectedCategory,
  onSelectCategory,
  onEditCategory,
  onAddEntry,
  onAddCategory,
  onViewItem,
  onDeleteItem,
}: BudgetOverviewTabProps) {
  return (
    <div className="space-y-6">
      <BudgetKPIPanel
        totalBudget={totalBudget}
        items={budgetItems}
      />

      <CategoryPanels
        categories={categories}
        categorySpending={categorySpending}
        selectedCategory={selectedCategory}
        onSelectCategory={onSelectCategory}
        onEditCategory={onEditCategory}
      />

      <div className="space-y-4">
        <div className="flex flex-wrap items-center gap-3">
          <button
            onClick={onAddEntry}
            className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-white rounded-xl font-bold hover:bg-[#c19a2e] hover:shadow-lg transition-all hover:scale-105"
          >
            <Plus className="w-5 h-5" />
            {BUDGET.ADD_ITEM}
          </button>

          <button
            onClick={onAddCategory}
            className="flex items-center gap-2 px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-bold hover:bg-[#f7f2eb] transition-all hover:scale-105"
          >
            <Folder className="w-5 h-5" />
            {BUDGET.CATEGORY} hinzufügen
          </button>
        </div>

        {selectedCategory && (
          <div className="flex items-center gap-2 p-3 bg-[#f7f2eb] border-2 border-[#d4af37]/30 rounded-xl">
            <span className="flex-1 text-sm font-semibold text-[#0a253c]">
              Filter aktiv: {categories.find(c => c.id === selectedCategory)?.name}
            </span>
            <button
              onClick={() => onSelectCategory(null)}
              className="flex items-center gap-1 px-3 py-1.5 bg-white hover:bg-gray-50 rounded-lg font-semibold text-sm text-[#666666] transition-all"
            >
              <X className="w-4 h-4" />
              {COMMON.FILTER} entfernen
            </button>
          </div>
        )}
      </div>

      <BudgetTable
        items={enrichedItems}
        onEdit={onViewItem}
        onDelete={onDeleteItem}
        onView={onViewItem}
        selectedCategory={selectedCategory}
      />
    </div>
  );
}
