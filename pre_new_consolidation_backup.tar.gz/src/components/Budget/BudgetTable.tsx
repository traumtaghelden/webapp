import { Edit2, Trash2, Eye, Calendar, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { type BudgetItem } from '../../lib/supabase';
import { BUDGET, COMMON } from '../../constants/terminology';
import UnifiedTable from '../common/UnifiedTable';

interface BudgetTableProps {
  items: BudgetItem[];
  onEdit: (itemId: string) => void;
  onDelete: (itemId: string) => void;
  onView: (itemId: string) => void;
  selectedCategory: string | null;
}

export default function BudgetTable({ items, onEdit, onDelete, onView, selectedCategory }: BudgetTableProps) {
  const filteredItems = selectedCategory
    ? items.filter(item => item.budget_category_id === selectedCategory)
    : items;

  const getNextPayment = (item: BudgetItem) => {
    if (item.paid || item.is_manually_paid) return { label: 'Bezahlt', color: 'green', date: null };

    const payments = item.budget_payments || [];
    const unpaid = payments.filter(p => p.status !== 'paid').sort((a, b) =>
      new Date(a.due_date).getTime() - new Date(b.due_date).getTime()
    );

    if (unpaid.length === 0) {
      return item.is_manually_paid ? { label: 'Bezahlt', color: 'green', date: null } : { label: 'Offen', color: 'gray', date: null };
    }

    const next = unpaid[0];
    const dueDate = new Date(next.due_date);
    const today = new Date();
    const daysUntil = Math.ceil((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));

    if (daysUntil < 0) {
      return { label: 'Überfällig', color: 'red', date: dueDate };
    } else if (daysUntil <= 7) {
      return { label: 'Bald fällig', color: 'yellow', date: dueDate };
    } else {
      return { label: dueDate.toLocaleDateString('de-DE'), color: 'blue', date: dueDate };
    }
  };

  const getRemainingColor = (remaining: number) => {
    if (remaining === 0) return 'text-green-600';
    if (remaining < 0) return 'text-blue-600';
    return 'text-red-600';
  };

  const emptyState = (
    <div className="text-center py-16 bg-white rounded-2xl border-2 border-dashed border-gray-300">
      <div className="inline-flex items-center justify-center w-16 h-16 bg-gray-100 rounded-full mb-4">
        <AlertCircle className="w-8 h-8 text-gray-400" />
      </div>
      <h3 className="text-xl font-bold text-[#0a253c] mb-2">Noch keine {BUDGET.ITEM_PLURAL}</h3>
      <p className="text-[#666666]">
        {selectedCategory
          ? `Keine ${BUDGET.ITEM_PLURAL} in dieser ${BUDGET.CATEGORY} gefunden.`
          : `Starte mit deinem ersten ${BUDGET.ITEM}.`}
      </p>
    </div>
  );

  const columns = [
    {
      key: 'item_name',
      label: BUDGET.ITEM,
      sortable: true,
      align: 'left' as const,
      render: (item: BudgetItem) => (
        <>
          <div className="font-bold text-[#0a253c]">{item.item_name}</div>
          {(item.vendor_id || item.timeline_event_id) && (
            <div className="text-xs text-[#999999] mt-1">
              {item.vendor_id && 'Verknüpft mit Dienstleister'}
              {item.vendor_id && item.timeline_event_id && ' • '}
              {item.timeline_event_id && 'Event'}
            </div>
          )}
        </>
      ),
    },
    {
      key: 'category',
      label: BUDGET.CATEGORY,
      sortable: true,
      align: 'left' as const,
      render: (item: BudgetItem) => (
        <span
          className="inline-block px-3 py-1 rounded-full text-xs font-semibold text-white"
          style={{ backgroundColor: item.budget_category?.color || '#d4af37' }}
        >
          {item.category}
        </span>
      ),
    },
    {
      key: 'cost',
      label: 'Kosten',
      sortable: true,
      align: 'right' as const,
      render: (item: BudgetItem) => (
        <div className="font-bold text-[#0a253c]">
          {(item.actual_cost || 0).toLocaleString('de-DE')} €
        </div>
      ),
    },
    {
      key: 'remaining',
      label: 'Restbetrag',
      sortable: true,
      align: 'right' as const,
      render: (item: BudgetItem) => {
        const payments = item.budget_payments || [];
        const totalPaid = payments.filter(p => p.status === 'paid').reduce((sum, p) => sum + Number(p.amount), 0);
        const remaining = (item.actual_cost || 0) - totalPaid;
        return (
          <div className={`font-bold ${getRemainingColor(remaining)}`}>
            {remaining < 0 ? '-' : ''}{Math.abs(remaining || 0).toLocaleString('de-DE')} €
          </div>
        );
      },
    },
    {
      key: 'next_payment',
      label: `Nächste ${BUDGET.PAYMENT}`,
      align: 'left' as const,
      render: (item: BudgetItem) => {
        const nextPayment = getNextPayment(item);
        return (
          <div className="flex items-center gap-2">
            {nextPayment.color === 'green' && <CheckCircle className="w-4 h-4 text-green-600" />}
            {nextPayment.color === 'yellow' && <Clock className="w-4 h-4 text-yellow-600" />}
            {nextPayment.color === 'red' && <AlertCircle className="w-4 h-4 text-red-600" />}
            {nextPayment.color === 'blue' && <Calendar className="w-4 h-4 text-blue-600" />}
            <span
              className={`text-sm font-semibold ${
                nextPayment.color === 'green'
                  ? 'text-green-700'
                  : nextPayment.color === 'yellow'
                  ? 'text-yellow-700'
                  : nextPayment.color === 'red'
                  ? 'text-red-700'
                  : 'text-blue-700'
              }`}
            >
              {nextPayment.label}
            </span>
          </div>
        );
      },
    },
    {
      key: 'actions',
      label: 'Aktionen',
      align: 'center' as const,
      render: (item: BudgetItem) => (
        <div className="flex items-center justify-center gap-1">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onView(item.id);
            }}
            className="p-2 hover:bg-blue-100 rounded-lg transition-all group"
            title={COMMON.VIEW_DETAILS}
          >
            <Eye className="w-4 h-4 text-blue-600 group-hover:scale-110 transition-transform" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onEdit(item.id);
            }}
            className="p-2 hover:bg-[#f7f2eb] rounded-lg transition-all group"
            title={COMMON.EDIT}
          >
            <Edit2 className="w-4 h-4 text-[#d4af37] group-hover:scale-110 transition-transform" />
          </button>
          <button
            onClick={(e) => {
              e.stopPropagation();
              onDelete(item.id);
            }}
            className="p-2 hover:bg-red-100 rounded-lg transition-all group"
            title={COMMON.DELETE}
          >
            <Trash2 className="w-4 h-4 text-red-600 group-hover:scale-110 transition-transform" />
          </button>
        </div>
      ),
    },
  ];

  return (
    <UnifiedTable
      data={filteredItems}
      columns={columns}
      getRowKey={(item) => item.id}
      emptyState={emptyState}
      striped={true}
      hoverable={true}
    />
  );
}
