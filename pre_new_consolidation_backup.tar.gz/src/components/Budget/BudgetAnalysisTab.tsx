import { useState } from 'react';
import { BarChart3, PieChart, TrendingUp, TrendingDown } from 'lucide-react';
import { type BudgetItem } from '../../lib/supabase';
import BudgetCharts from '../BudgetCharts';

interface BudgetAnalysisTabProps {
  weddingId: string;
  budgetItems: BudgetItem[];
  totalBudget: number;
}

export default function BudgetAnalysisTab({ weddingId, budgetItems, totalBudget }: BudgetAnalysisTabProps) {
  const [showCharts, setShowCharts] = useState(false);
  const calculateStats = () => {
    const totalSpent = budgetItems.reduce((sum, item) => sum + (item.actual_cost || 0), 0);
    const totalPlanned = budgetItems.reduce((sum, item) => sum + (item.estimated_cost || 0), 0);
    const remaining = totalBudget - totalSpent;
    const percentUsed = (totalSpent / totalBudget) * 100;

    const categoryBreakdown: Record<string, { planned: number; actual: number; count: number }> = {};

    budgetItems.forEach(item => {
      const category = item.category || 'Sonstiges';
      if (!categoryBreakdown[category]) {
        categoryBreakdown[category] = { planned: 0, actual: 0, count: 0 };
      }
      categoryBreakdown[category].planned += item.estimated_cost || 0;
      categoryBreakdown[category].actual += item.actual_cost || 0;
      categoryBreakdown[category].count += 1;
    });

    return {
      totalSpent,
      totalPlanned,
      remaining,
      percentUsed,
      categoryBreakdown,
    };
  };

  const stats = calculateStats();

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold text-[#0a253c]">Budget-Analyse</h3>
        <p className="text-gray-600 mt-1">Detaillierte Übersicht und Visualisierungen deiner Ausgaben</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-2xl p-6 text-white shadow-lg">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
              <TrendingUp className="w-6 h-6 text-[#d4af37]" />
            </div>
            <span className="text-sm font-semibold opacity-90">Ausgegeben</span>
          </div>
          <p className="text-3xl font-bold mb-2">{stats.totalSpent.toLocaleString('de-DE')} €</p>
          <div className="flex items-center gap-2 text-sm">
            <div className="flex-1 bg-white/10 rounded-full h-2">
              <div
                className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] h-full rounded-full"
                style={{ width: `${Math.min(stats.percentUsed, 100)}%` }}
              />
            </div>
            <span className="font-semibold">{stats.percentUsed.toFixed(1)}%</span>
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-2xl p-6 text-white shadow-lg">
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
              <BarChart3 className="w-6 h-6" />
            </div>
            <span className="text-sm font-semibold opacity-90">Geplant</span>
          </div>
          <p className="text-3xl font-bold mb-2">{stats.totalPlanned.toLocaleString('de-DE')} €</p>
          <p className="text-sm opacity-90">von {totalBudget.toLocaleString('de-DE')} € Budget</p>
        </div>

        <div className={`bg-gradient-to-br ${stats.remaining >= 0 ? 'from-green-500 to-green-600' : 'from-red-500 to-red-600'} rounded-2xl p-6 text-white shadow-lg`}>
          <div className="flex items-center gap-3 mb-3">
            <div className="w-12 h-12 bg-white/10 rounded-xl flex items-center justify-center">
              {stats.remaining >= 0 ? (
                <TrendingUp className="w-6 h-6" />
              ) : (
                <TrendingDown className="w-6 h-6" />
              )}
            </div>
            <span className="text-sm font-semibold opacity-90">
              {stats.remaining >= 0 ? 'Verfügbar' : 'Überzogen'}
            </span>
          </div>
          <p className="text-3xl font-bold mb-2">{Math.abs(stats.remaining).toLocaleString('de-DE')} €</p>
          <p className="text-sm opacity-90">
            {stats.remaining >= 0 ? 'noch im Budget' : 'über Budget'}
          </p>
        </div>
      </div>

      <div className="bg-white rounded-2xl p-6 shadow-md border-2 border-gray-100">
        <h4 className="text-xl font-bold text-[#0a253c] mb-6 flex items-center gap-3">
          <PieChart className="w-6 h-6 text-[#d4af37]" />
          Ausgaben nach Kategorie
        </h4>
        <button
          onClick={() => setShowCharts(true)}
          className="w-full px-6 py-4 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-white font-semibold rounded-xl hover:shadow-lg transition-all flex items-center justify-center gap-2"
        >
          <PieChart className="w-5 h-5" />
          Detaillierte Visualisierung öffnen
        </button>
      </div>

      {showCharts && (
        <BudgetCharts
          budgetItems={budgetItems}
          totalBudget={totalBudget}
          onClose={() => setShowCharts(false)}
        />
      )}

      <div className="bg-white rounded-2xl p-6 shadow-md border-2 border-gray-100">
        <h4 className="text-xl font-bold text-[#0a253c] mb-6">Kategorie-Details</h4>
        <div className="space-y-4">
          {Object.entries(stats.categoryBreakdown)
            .sort((a, b) => b[1].actual - a[1].actual)
            .map(([category, data]) => {
              const percentage = stats.totalSpent > 0 ? (data.actual / stats.totalSpent) * 100 : 0;
              const isOverBudget = data.actual > data.planned;

              return (
                <div key={category} className="p-4 bg-gray-50 rounded-xl">
                  <div className="flex items-center justify-between mb-3">
                    <div>
                      <p className="font-bold text-[#0a253c]">{category}</p>
                      <p className="text-sm text-gray-600">{data.count} Einträge</p>
                    </div>
                    <div className="text-right">
                      <p className={`text-lg font-bold ${isOverBudget ? 'text-red-500' : 'text-[#0a253c]'}`}>
                        {data.actual.toLocaleString('de-DE')} €
                      </p>
                      <p className="text-sm text-gray-600">
                        von {data.planned.toLocaleString('de-DE')} € geplant
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="flex-1 bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-full rounded-full ${
                          isOverBudget ? 'bg-red-500' : 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f]'
                        }`}
                        style={{ width: `${Math.min((data.actual / data.planned) * 100, 100)}%` }}
                      />
                    </div>
                    <span className="text-sm font-semibold text-gray-600 min-w-[60px] text-right">
                      {percentage.toFixed(1)}% gesamt
                    </span>
                  </div>
                </div>
              );
            })}

          {Object.keys(stats.categoryBreakdown).length === 0 && (
            <div className="text-center py-12 text-gray-500">
              Noch keine Daten für Analyse verfügbar
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
