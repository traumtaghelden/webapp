import { useState, useEffect } from 'react';
import { Clock, Edit2, DollarSign, TrendingUp, TrendingDown, Calendar } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import BudgetHistoryTimeline from '../BudgetHistoryTimeline';

interface HistoryEntry {
  id: string;
  budget_item_id: string | null;
  change_type: string;
  old_value: number | null;
  new_value: number | null;
  changed_by: string;
  created_at: string;
  budget_item?: {
    name: string;
    category: string;
  };
}

interface BudgetHistoryTabProps {
  weddingId: string;
}

export default function BudgetHistoryTab({ weddingId }: BudgetHistoryTabProps) {
  const [history, setHistory] = useState<HistoryEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterType, setFilterType] = useState<string>('all');

  useEffect(() => {
    loadHistory();
  }, [weddingId]);

  const loadHistory = async () => {
    try {
      const { data: budgetItems } = await supabase
        .from('budget_items')
        .select('id, item_name, category')
        .eq('wedding_id', weddingId);

      const { data: historyData } = await supabase
        .from('budget_history')
        .select('*')
        .in('budget_item_id', budgetItems?.map(item => item.id) || [])
        .order('created_at', { ascending: false });

      const enrichedHistory = historyData?.map(entry => ({
        ...entry,
        budget_item: budgetItems?.find(item => item.id === entry.budget_item_id),
      })) || [];

      setHistory(enrichedHistory);
    } catch (error) {
      console.error('Error loading history:', error);
    } finally {
      setLoading(false);
    }
  };

  const getChangeTypeLabel = (type: string) => {
    const labels: Record<string, string> = {
      'created': 'Erstellt',
      'estimated_cost_changed': 'Geplante Kosten geändert',
      'actual_cost_changed': 'Tatsächliche Kosten geändert',
      'status_changed': 'Status geändert',
      'deleted': 'Gelöscht',
    };
    return labels[type] || type;
  };

  const getChangeIcon = (type: string) => {
    switch (type) {
      case 'created':
        return <Calendar className="w-5 h-5 text-green-600" />;
      case 'estimated_cost_changed':
      case 'actual_cost_changed':
        return <DollarSign className="w-5 h-5 text-blue-600" />;
      case 'deleted':
        return <TrendingDown className="w-5 h-5 text-red-600" />;
      default:
        return <Edit2 className="w-5 h-5 text-gray-600" />;
    }
  };

  const filteredHistory = filterType === 'all'
    ? history
    : history.filter(entry => entry.change_type === filterType);

  const groupedHistory: Record<string, HistoryEntry[]> = {};
  filteredHistory.forEach(entry => {
    const date = new Date(entry.created_at).toLocaleDateString('de-DE', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
    if (!groupedHistory[date]) {
      groupedHistory[date] = [];
    }
    groupedHistory[date].push(entry);
  });

  if (loading) {
    return (
      <div className="flex items-center justify-center py-16">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-[#d4af37] border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Lade Änderungsverlauf...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-2xl font-bold text-[#0a253c]">Änderungsverlauf</h3>
          <p className="text-gray-600 mt-1">Alle Änderungen an deinem Budget im Überblick</p>
        </div>
        <select
          value={filterType}
          onChange={(e) => setFilterType(e.target.value)}
          className="px-4 py-2 border-2 border-gray-200 rounded-xl font-semibold text-sm focus:border-[#d4af37] focus:outline-none"
        >
          <option value="all">Alle Änderungen</option>
          <option value="created">Neu erstellt</option>
          <option value="estimated_cost_changed">Geplante Kosten</option>
          <option value="actual_cost_changed">Tatsächliche Kosten</option>
          <option value="deleted">Gelöscht</option>
        </select>
      </div>

      <BudgetHistoryTimeline weddingId={weddingId} />

      <div className="space-y-6">
        {Object.entries(groupedHistory).map(([date, entries]) => (
          <div key={date} className="bg-white rounded-2xl p-6 shadow-md border-2 border-gray-100">
            <div className="flex items-center gap-3 mb-4 pb-4 border-b border-gray-200">
              <Clock className="w-5 h-5 text-[#d4af37]" />
              <h4 className="text-lg font-bold text-[#0a253c]">{date}</h4>
              <span className="ml-auto px-3 py-1 bg-[#f7f2eb] text-[#d4af37] rounded-full text-sm font-bold">
                {entries.length} {entries.length === 1 ? 'Änderung' : 'Änderungen'}
              </span>
            </div>

            <div className="space-y-3">
              {entries.map(entry => (
                <div key={entry.id} className="flex items-start gap-4 p-4 bg-gray-50 rounded-xl">
                  <div className="flex-shrink-0 mt-1">
                    {getChangeIcon(entry.change_type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-[#0a253c] mb-1">
                      {entry.budget_item?.item_name || 'Unbekannter Eintrag'}
                    </p>
                    <p className="text-sm text-gray-600 mb-2">
                      {getChangeTypeLabel(entry.change_type)}
                    </p>
                    {entry.old_value !== null && entry.new_value !== null && (
                      <div className="flex items-center gap-3 text-sm">
                        <span className="text-gray-500">{entry.old_value.toLocaleString('de-DE')} €</span>
                        <TrendingUp className={`w-4 h-4 ${entry.new_value > entry.old_value ? 'text-red-500' : 'text-green-600'}`} />
                        <span className={`font-bold ${entry.new_value > entry.old_value ? 'text-red-500' : 'text-green-600'}`}>
                          {entry.new_value.toLocaleString('de-DE')} €
                        </span>
                      </div>
                    )}
                  </div>
                  <div className="text-right text-xs text-gray-500">
                    {new Date(entry.created_at).toLocaleTimeString('de-DE', {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}

        {filteredHistory.length === 0 && (
          <div className="text-center py-16 bg-[#f7f2eb] rounded-2xl">
            <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto mb-4 shadow-lg">
              <Clock className="w-10 h-10 text-[#d4af37]" />
            </div>
            <p className="text-gray-600 text-lg mb-2 font-semibold">Kein Änderungsverlauf</p>
            <p className="text-gray-500 text-sm">
              {filterType === 'all'
                ? 'Noch keine Änderungen vorgenommen'
                : 'Keine Änderungen dieses Typs gefunden'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
