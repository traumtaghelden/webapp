import { Heart, CheckCircle, Calendar, Users, Sparkles, Zap, Sliders, RefreshCw, Star, ArrowRight, TrendingUp, Award, Trophy, Target, X, DollarSign, MinusCircle, PlusCircle, Check, Mail, FileText, Shield, Instagram, Facebook, Twitter, LogIn, Crown, AlertTriangle, Clock, Timer, LayoutGrid } from 'lucide-react';
import { useState, useEffect } from 'react';
import { ModalRoot } from './Modals';
import { attachModalTriggers, openModal } from '../lib/modalManager';

interface LandingPageProps {
  onGetStarted: () => void;
}

interface FAQItem {
  question: string;
  answer: string;
}

export default function LandingPage({ onGetStarted }: LandingPageProps) {
  const [budget, setBudget] = useState(15000);
  const [demoTasks, setDemoTasks] = useState([
    { id: 1, text: 'Location suchen', completed: false },
    { id: 2, text: 'Save-the-Date versenden', completed: false },
    { id: 3, text: 'Catering anfragen', completed: false },
  ]);
  const [selectedTimelineEvent, setSelectedTimelineEvent] = useState(0);
  const [openFAQ, setOpenFAQ] = useState<number | null>(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [videoLoaded, setVideoLoaded] = useState(false);

  useEffect(() => {
    // Optimize video playback
    const video = document.querySelector('video');
    if (video) {
      // Reduce buffering and prioritize smooth playback
      video.setAttribute('x-webkit-airplay', 'deny');
      video.setAttribute('disablePictureInPicture', 'true');

      // Force lower playback rate for smoother performance if needed
      const handleCanPlay = () => {
        video.playbackRate = 1.0;
        // Remove will-change after initial load
        setTimeout(() => {
          video.style.willChange = 'auto';
        }, 3000);
      };

      video.addEventListener('canplay', handleCanPlay);

      return () => {
        video.removeEventListener('canplay', handleCanPlay);
      };
    }
  }, []);

  const demoTimelineEvents = [
    { id: 1, time: '14:00', title: 'Trauung', duration: '45 Min', guests: 80, color: '#d4af37' },
    { id: 2, time: '15:00', title: 'Sektempfang', duration: '60 Min', guests: 80, color: '#c19a2e' },
    { id: 3, time: '17:00', title: 'Fotoshooting', duration: '90 Min', guests: 2, color: '#a88529' },
    { id: 4, time: '18:30', title: 'Abendessen', duration: '120 Min', guests: 80, color: '#d4af37' },
  ];

  const faqs: FAQItem[] = [
    {
      question: "Kostet die Plattform etwas?",
      answer: "Wir bieten eine kostenlose Version mit allen Basis-Features. Für erweiterte Funktionen wie unbegrenzte Timeline-Events, Block-Planung und erweiterte Budget-Analysen gibt es einen Premium-Plan."
    },
    {
      question: "Wie sicher sind meine Daten?",
      answer: "Eure Daten werden verschlüsselt und sicher in Deutschland gespeichert. Wir halten uns streng an die DSGVO und geben keine Daten an Dritte weiter. Ihr habt jederzeit volle Kontrolle über eure Informationen."
    },
    {
      question: "Was ist die Timeline-Funktion?",
      answer: "Mit der Timeline-Funktion plant ihr euren Hochzeitstag minutengenau. Jedes Event (Trauung, Empfang, Dinner etc.) wird zu einem planbaren Block mit eigenen Checklisten, Gästen, Dienstleistern und Budget."
    },
    {
      question: "Was sind Pufferzeiten?",
      answer: "Pufferzeiten sind flexible Zeitblöcke zwischen euren Events. Sie geben euch Raum zum Durchatmen und fangen Verzögerungen ab, damit euer Tag entspannt bleibt."
    },
    {
      question: "Funktioniert es auch auf dem Smartphone?",
      answer: "Absolut! Die Plattform ist vollständig responsive und funktioniert perfekt auf Smartphones und Tablets. Plant unterwegs, von überall aus."
    },
    {
      question: "Was ist der Unterschied zu Excel oder anderen Tools?",
      answer: "Im Gegensatz zu Excel bieten wir Echtzeit-Synchronisation, intelligente Automatisierung und eine intuitive Benutzeroberfläche. Keine komplizierten Formeln, sondern smarte Features die mitdenken."
    },
    {
      question: "Kann ich meine Daten exportieren?",
      answer: "Ja, ihr könnt alle eure Daten jederzeit als PDF oder CSV exportieren. Eure Daten gehören euch und ihr habt volle Kontrolle darüber."
    },
    {
      question: "Wie detailliert kann ich meinen Tagesablauf planen?",
      answer: "Extrem detailliert! Ihr könnt für jedes Event Sub-Timelines erstellen, Aufgaben verknüpfen, Dienstleister zuordnen und sogar Kosten pro Block tracken."
    },
    {
      question: "Wie lange kann ich die Plattform nutzen?",
      answer: "Unbegrenzt! Auch nach eurer Hochzeit habt ihr Zugriff auf alle Daten und könnt sie als digitale Erinnerung behalten oder für andere Events nutzen."
    }
  ];

  const toggleDemoTask = (id: number) => {
    setDemoTasks(tasks =>
      tasks.map(task =>
        task.id === id ? { ...task, completed: !task.completed } : task
      )
    );
  };

  const getBudgetRecommendation = (amount: number) => {
    if (amount < 5000) return { text: 'Intime Feier (20-30 Gäste)', icon: '🌸' };
    if (amount < 15000) return { text: 'Klassische Hochzeit (50-80 Gäste)', icon: '💒' };
    if (amount < 30000) return { text: 'Große Feier (100-150 Gäste)', icon: '✨' };
    return { text: 'Luxus-Hochzeit (150+ Gäste)', icon: '👑' };
  };

  useEffect(() => {
    attachModalTriggers();
  }, []);

  return (
    <div className="min-h-screen bg-[#f7f2eb]">
      <ModalRoot />
      {/* Header Navigation */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-[#0a253c]/95 backdrop-blur-sm border-b border-white/10">
        <div className="container mx-auto px-4 sm:px-6 py-3 sm:py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 sm:gap-3">
              <Heart className="w-6 h-6 sm:w-8 sm:h-8 text-[#d4af37] fill-current" />
              <span className="text-lg sm:text-xl font-bold text-white">Heldenreise</span>
              <span className="bg-orange-500 text-white text-xs font-bold px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-full animate-pulse">BETA</span>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden md:flex items-center gap-8">
              <a href="#features" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors text-sm font-medium">
                Features
              </a>
              <a href="#pricing" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors text-sm font-medium">
                Preise
              </a>
              <a href="#faq" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors text-sm font-medium">
                FAQ
              </a>
              <button
                onClick={() => openModal('login')}
                className="flex items-center gap-2 text-[#d4af37] hover:text-[#f4d03f] transition-colors text-sm font-semibold"
              >
                <LogIn className="w-4 h-4" />
                Login
              </button>
              <button
                onClick={() => openModal('login')}
                className="bg-[#d4af37] hover:bg-[#f4d03f] text-[#0a253c] px-6 py-2 rounded-full text-sm font-bold transition-all"
              >
                Kostenlos starten
              </button>
            </nav>

            {/* Mobile Menu Button */}
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="md:hidden p-2 text-white hover:text-[#d4af37] transition-colors touch-manipulation"
              aria-label="Menü"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <LayoutGrid className="w-6 h-6" />}
            </button>
          </div>

          {/* Mobile Navigation */}
          {mobileMenuOpen && (
            <nav className="md:hidden mt-4 pb-4 border-t border-white/10 pt-4 space-y-3">
              <a
                href="#features"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-3 px-4 text-[#f7f2eb] hover:bg-white/10 rounded-lg transition-colors text-base font-medium touch-manipulation"
              >
                Features
              </a>
              <a
                href="#pricing"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-3 px-4 text-[#f7f2eb] hover:bg-white/10 rounded-lg transition-colors text-base font-medium touch-manipulation"
              >
                Preise
              </a>
              <a
                href="#faq"
                onClick={() => setMobileMenuOpen(false)}
                className="block py-3 px-4 text-[#f7f2eb] hover:bg-white/10 rounded-lg transition-colors text-base font-medium touch-manipulation"
              >
                FAQ
              </a>
              <button
                onClick={() => {
                  openModal('login');
                  setMobileMenuOpen(false);
                }}
                className="w-full flex items-center justify-center gap-2 py-3 px-4 text-[#d4af37] hover:bg-white/10 rounded-lg transition-colors text-base font-semibold touch-manipulation"
              >
                <LogIn className="w-5 h-5" />
                Login
              </button>
              <button
                onClick={() => {
                  openModal('login');
                  setMobileMenuOpen(false);
                }}
                className="w-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#0a253c] py-3 px-4 rounded-lg text-base font-bold transition-all shadow-lg touch-manipulation"
              >
                Kostenlos starten
              </button>
            </nav>
          )}
        </div>
      </header>

      <div className="relative pt-14 sm:pt-16">
        <div className="relative overflow-hidden text-white">
          <div className="absolute inset-0 z-0">
            {/* Fallback gradient background */}
            <div className="absolute inset-0 bg-gradient-to-br from-[#0a253c] via-[#1a3a5c] to-[#0a253c] z-0"></div>

            {/* Video overlay gradient */}
            <div className="absolute inset-0 bg-gradient-to-b from-[#0a253c]/80 via-[#0a253c]/60 to-[#0a253c]/95 z-10"></div>

            {/* Hero video with optimizations */}
            <video
              autoPlay
              loop
              muted
              playsInline
              preload="auto"
              poster="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 1920 1080'%3E%3Crect fill='%230a253c' width='1920' height='1080'/%3E%3C/svg%3E"
              onLoadedData={() => setVideoLoaded(true)}
              className={`absolute inset-0 w-full h-full object-cover transition-opacity duration-1000 ${videoLoaded ? 'opacity-100' : 'opacity-0'}`}
              style={{
                transform: 'translate3d(0, 0, 0)',
                willChange: 'auto',
                backfaceVisibility: 'hidden',
                WebkitBackfaceVisibility: 'hidden',
                perspective: 1000,
                WebkitPerspective: 1000
              }}
            >
              <source
                src="https://res.cloudinary.com/dvaha0i6v/video/upload/q_auto:low,w_768,c_limit/v1761865110/Background_hero_5_1_iwxwaf.mp4"
                type="video/mp4"
                media="(max-width: 768px)"
              />
              <source
                src="https://res.cloudinary.com/dvaha0i6v/video/upload/q_auto:good,w_1920,c_limit/v1761865110/Background_hero_5_1_iwxwaf.mp4"
                type="video/mp4"
              />
            </video>
          </div>
          <div className="container mx-auto px-4 sm:px-6 py-12 sm:py-16 md:py-20 relative z-20">
          <div className="text-center mb-10 sm:mb-14">
            <div className="flex justify-center mb-6 sm:mb-8">
              <div className="relative">
                <Heart className="w-12 h-12 sm:w-16 sm:h-16 md:w-20 md:h-20 text-[#d4af37] animate-float fill-current" />
                <Sparkles className="w-6 h-6 sm:w-7 sm:h-7 md:w-8 md:h-8 text-[#f4d03f] absolute -top-1 -right-1 md:-top-2 md:-right-2 animate-pulse" />
              </div>
            </div>
            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-5 sm:mb-7 leading-tight animate-hero-title px-4">
              <span className="animate-hero-word" style={{ animationDelay: '0.1s' }}>Eure</span>{' '}
              <span className="text-gradient-gold animate-hero-word" style={{ animationDelay: '0.3s' }}>Heldenreise</span>
              <br />
              <span className="animate-hero-word" style={{ animationDelay: '0.5s' }}>beginnt</span>{' '}
              <span className="animate-hero-word" style={{ animationDelay: '0.7s' }}>hier</span>
            </h1>
            <p className="text-lg sm:text-xl md:text-2xl text-[#f7f2eb] mb-4 sm:mb-5 max-w-2xl mx-auto leading-relaxed px-4" style={{ lineHeight: '1.6' }}>
              Plant eure Traumhochzeit mit Leichtigkeit und Freude. Jeden magischen Moment perfekt gestalten.
            </p>
            <p className="text-sm sm:text-base text-[#f4d03f] mb-8 sm:mb-10 px-4">
              In der Beta-Phase - Sei Teil unserer Hochzeits-Revolution
            </p>
            <div className="relative px-4">
              <button
                onClick={() => openModal('login')}
                className="button-modern bg-gradient-to-r from-[#d4af37] to-[#f4d03f] hover:from-[#f4d03f] hover:to-[#d4af37] text-[#0a253c] w-full sm:w-auto px-10 sm:px-12 md:px-14 py-5 sm:py-5.5 rounded-full text-lg sm:text-xl font-bold shadow-gold-lg hover:shadow-gold animate-pulse-glow relative touch-manipulation"
                style={{ maxWidth: '400px', margin: '0 auto', display: 'block' }}
              >
                Jetzt starten
              </button>
            </div>
          </div>

          {/* Mobile: Horizontal Swiper, Desktop: Grid */}
          <div className="mt-12 sm:mt-16 md:mt-20 max-w-6xl mx-auto">
            <div className="mobile-swiper md:grid md:grid-cols-3 md:gap-8 md:px-6">
              <div className="mobile-swiper-item glassmorphism-dark rounded-2xl p-6 sm:p-8 card-hover hover-lift" style={{ minHeight: '280px' }}>
                <div className="bg-gradient-to-br from-[#d4af37] to-[#f4d03f] w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mb-4 sm:mb-6 shadow-gold">
                  <CheckCircle className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold mb-3 gradient-text-gold">Aufgaben meistern</h3>
                <p className="text-sm sm:text-base text-[#f7f2eb] leading-relaxed">
                  Behaltet den Überblick mit intelligenten Checklisten und Erinnerungen für jeden Planungsschritt.
                </p>
              </div>

              <div className="mobile-swiper-item glassmorphism-dark rounded-2xl p-6 sm:p-8 card-hover hover-lift" style={{ minHeight: '280px' }}>
                <div className="bg-gradient-to-br from-[#d4af37] to-[#f4d03f] w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mb-4 sm:mb-6 shadow-gold">
                  <Calendar className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold mb-3 gradient-text-gold">Budget im Blick</h3>
                <p className="text-sm sm:text-base text-[#f7f2eb] leading-relaxed">
                  Verwaltet euer Budget clever und transparent. Keine versteckten Kosten, nur pure Vorfreude.
                </p>
              </div>

              <div className="mobile-swiper-item glassmorphism-dark rounded-2xl p-6 sm:p-8 card-hover hover-lift" style={{ minHeight: '280px' }}>
                <div className="bg-gradient-to-br from-[#d4af37] to-[#f4d03f] w-14 h-14 sm:w-16 sm:h-16 rounded-full flex items-center justify-center mb-4 sm:mb-6 shadow-gold">
                  <Clock className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
                </div>
                <h3 className="text-xl sm:text-2xl font-bold mb-3 gradient-text-gold">Tagesablauf perfekt</h3>
                <p className="text-sm sm:text-base text-[#f7f2eb] leading-relaxed">
                  Plant euren Hochzeitstag minutengenau mit der Timeline-Funktion. Jedes Detail zur richtigen Zeit.
                </p>
              </div>
            </div>

            {/* Swiper Indicator Dots - Only on mobile */}
            <div className="swiper-pagination md:hidden">
              <div className="swiper-dot active"></div>
              <div className="swiper-dot"></div>
              <div className="swiper-dot"></div>
            </div>
          </div>
        </div>
        </div>
      </div>

      <div className="relative min-h-screen overflow-hidden">
        <div className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-gradient-to-b from-[#0a253c]/60 via-[#0a253c]/20 to-[#f7f2eb] z-10"></div>
          <img
            src="/u8897456249_httpss.mj.runYRcXMjrT75I_httpss.mj.runlU60IeIG40k_7a5311e0-f1b2-48ea-8d12-af642ba22d00_2.png"
            alt="Hero couple"
            loading="lazy"
            decoding="async"
            className="w-full h-full object-cover object-top"
            style={{ contentVisibility: 'auto' }}
          />
        </div>

        <div className="container mx-auto px-4 sm:px-6 py-16 sm:py-24 md:py-32 relative z-20">
          <div className="max-w-4xl mx-auto text-center">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-white mb-4 sm:mb-6 drop-shadow-lg px-4" style={{ textShadow: '0 4px 20px rgba(0,0,0,0.4)' }}>
              Warum unsere Plattform?
            </h2>
            <p className="text-base sm:text-lg md:text-xl text-white leading-relaxed mb-8 sm:mb-12 drop-shadow-lg px-4" style={{ textShadow: '0 2px 10px rgba(0,0,0,0.5)' }}>
              Wir verstehen, dass eure Hochzeit einzigartig ist. Deshalb haben wir eine Plattform geschaffen, die sich euren Träumen anpasst – verspielt, intuitiv und voller Magie.
            </p>

            {/* Mobile: Horizontal Swiper, Desktop: Grid */}
            <div className="mobile-swiper sm:grid sm:grid-cols-2 sm:gap-6 md:gap-8 sm:px-4">
              <div className="mobile-swiper-item glassmorphism rounded-2xl p-6 sm:p-8 shadow-gold-lg card-hover hover-lift border-gradient" style={{ minHeight: '220px' }}>
                <div className="text-4xl sm:text-5xl mb-3 sm:mb-4">✨</div>
                <h3 className="text-xl sm:text-2xl font-bold gradient-text-gold mb-2 sm:mb-3">Pixar-Magie</h3>
                <p className="text-sm sm:text-base text-[#333333] leading-relaxed">
                  Eine fröhliche, cinematic Erfahrung, die die Planung zum Vergnügen macht.
                </p>
              </div>

              <div className="mobile-swiper-item glassmorphism rounded-2xl p-6 sm:p-8 shadow-gold-lg card-hover hover-lift border-gradient" style={{ minHeight: '220px' }}>
                <div className="text-4xl sm:text-5xl mb-3 sm:mb-4">📱</div>
                <h3 className="text-xl sm:text-2xl font-bold gradient-text-gold mb-2 sm:mb-3">Überall dabei</h3>
                <p className="text-sm sm:text-base text-[#333333] leading-relaxed">
                  Plant von überall – ob am Desktop, Tablet oder Smartphone.
                </p>
              </div>

              <div className="mobile-swiper-item glassmorphism rounded-2xl p-6 sm:p-8 shadow-gold-lg card-hover hover-lift border-gradient" style={{ minHeight: '220px' }}>
                <div className="text-4xl sm:text-5xl mb-3 sm:mb-4">🎯</div>
                <h3 className="text-xl sm:text-2xl font-bold gradient-text-gold mb-2 sm:mb-3">Klar strukturiert</h3>
                <p className="text-sm sm:text-base text-[#333333] leading-relaxed">
                  Keine Verwirrung mehr – jeder Schritt ist klar und einfach zu verstehen.
                </p>
              </div>

              <div className="mobile-swiper-item glassmorphism rounded-2xl p-6 sm:p-8 shadow-gold-lg card-hover hover-lift border-gradient" style={{ minHeight: '220px' }}>
                <div className="text-4xl sm:text-5xl mb-3 sm:mb-4">⏰</div>
                <h3 className="text-xl sm:text-2xl font-bold gradient-text-gold mb-2 sm:mb-3">Timeline-Planung</h3>
                <p className="text-sm sm:text-base text-[#333333] leading-relaxed">
                  Plant euren Tagesablauf minutengenau mit der Timeline- und Block-Planungs-Funktion.
                </p>
              </div>
            </div>

            {/* Swiper Indicator Dots - Only on mobile */}
            <div className="swiper-pagination sm:hidden">
              <div className="swiper-dot active"></div>
              <div className="swiper-dot"></div>
              <div className="swiper-dot"></div>
              <div className="swiper-dot"></div>
            </div>

            <div className="mt-12 sm:mt-16 px-4">
              <button
                onClick={() => openModal('login')}
                className="button-modern bg-[#0a253c] hover:bg-[#1a3a5c] text-[#d4af37] px-8 sm:px-10 md:px-12 py-4 sm:py-5 rounded-full text-base sm:text-lg md:text-xl font-bold shadow-gold-lg hover:shadow-gold touch-manipulation"
              >
                Eure Reise beginnt jetzt
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Section 2: Interactive Demo Elements */}
      <div className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#0a253c] mb-4">
              Probiert es <span className="text-gradient-gold">selbst aus</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Spielt mit unseren interaktiven Tools und erlebt, wie einfach Hochzeitsplanung sein kann
            </p>
          </div>

          <div className="grid lg:grid-cols-3 gap-8 max-w-7xl mx-auto">
            {/* Budget Slider Demo */}
            <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-3xl p-8 shadow-xl border-2 border-[#d4af37]/20">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-[#d4af37] p-3 rounded-xl">
                  <DollarSign className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0a253c]">Budget-Rechner</h3>
              </div>
              <p className="text-gray-600 mb-6">
                Seht sofort, was mit eurem Budget möglich ist
              </p>

              <div className="space-y-6">
                <div>
                  <div className="flex justify-between items-center mb-3">
                    <span className="text-gray-700 font-semibold">Euer Budget:</span>
                    <span className="text-3xl font-bold text-[#d4af37]">
                      {budget.toLocaleString('de-DE')} €
                    </span>
                  </div>
                  <input
                    type="range"
                    min="2000"
                    max="50000"
                    step="1000"
                    value={budget}
                    onChange={(e) => setBudget(Number(e.target.value))}
                    className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer slider-gold"
                  />
                  <div className="flex justify-between text-xs text-gray-500 mt-2">
                    <span>2.000 €</span>
                    <span>50.000 €</span>
                  </div>
                </div>

                <div className="bg-white rounded-2xl p-6 border-2 border-[#d4af37]/30">
                  <div className="text-5xl mb-3 text-center">
                    {getBudgetRecommendation(budget).icon}
                  </div>
                  <p className="text-center text-lg font-semibold text-[#0a253c]">
                    {getBudgetRecommendation(budget).text}
                  </p>
                  <div className="mt-4 space-y-2 text-sm text-gray-600">
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                      <span>Location & Catering</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                      <span>Fotografie & Video</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <CheckCircle className="w-4 h-4 text-[#d4af37]" />
                      <span>Dekoration & Blumen</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Interactive Checklist Demo */}
            <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-3xl p-8 shadow-xl border-2 border-[#d4af37]/20">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-[#d4af37] p-3 rounded-xl">
                  <CheckCircle className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0a253c]">Task-Manager</h3>
              </div>
              <p className="text-gray-600 mb-6">
                Hakt Aufgaben ab und fühlt den Fortschritt
              </p>

              <div className="space-y-3">
                {demoTasks.map((task) => (
                  <div
                    key={task.id}
                    onClick={() => toggleDemoTask(task.id)}
                    className={`flex items-center gap-4 p-4 rounded-xl border-2 transition-all cursor-pointer ${
                      task.completed
                        ? 'bg-[#d4af37]/10 border-[#d4af37] shadow-md'
                        : 'bg-white border-gray-200 hover:border-[#d4af37]/50'
                    }`}
                  >
                    <div
                      className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${
                        task.completed
                          ? 'bg-[#d4af37] border-[#d4af37]'
                          : 'border-gray-300'
                      }`}
                    >
                      {task.completed && (
                        <CheckCircle className="w-4 h-4 text-white fill-current" />
                      )}
                    </div>
                    <span
                      className={`flex-1 font-medium transition-all ${
                        task.completed
                          ? 'line-through text-gray-400'
                          : 'text-[#0a253c]'
                      }`}
                    >
                      {task.text}
                    </span>
                  </div>
                ))}
              </div>

              <div className="mt-6 bg-white rounded-2xl p-4 border-2 border-[#d4af37]/30">
                <div className="flex items-center justify-between">
                  <span className="text-gray-700 font-semibold">Fortschritt:</span>
                  <span className="text-2xl font-bold text-[#d4af37]">
                    {Math.round((demoTasks.filter(t => t.completed).length / demoTasks.length) * 100)}%
                  </span>
                </div>
                <div className="mt-3 h-3 bg-gray-200 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] transition-all duration-500"
                    style={{
                      width: `${(demoTasks.filter(t => t.completed).length / demoTasks.length) * 100}%`
                    }}
                  ></div>
                </div>
              </div>
            </div>

            {/* Interactive Timeline Demo */}
            <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-3xl p-8 shadow-xl border-2 border-[#d4af37]/20">
              <div className="flex items-center gap-3 mb-6">
                <div className="bg-[#d4af37] p-3 rounded-xl">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <h3 className="text-2xl font-bold text-[#0a253c]">Timeline-Planer</h3>
              </div>
              <p className="text-gray-600 mb-6">
                Plant euren Tagesablauf minutengenau
              </p>

              <div className="space-y-2">
                {demoTimelineEvents.map((event, index) => (
                  <div
                    key={event.id}
                    onClick={() => setSelectedTimelineEvent(index)}
                    className={`p-4 rounded-xl border-2 transition-all cursor-pointer ${
                      selectedTimelineEvent === index
                        ? 'border-[#d4af37] shadow-md'
                        : 'bg-white border-gray-200 hover:border-[#d4af37]/50'
                    }`}
                    style={{
                      backgroundColor: selectedTimelineEvent === index ? `${event.color}15` : 'white'
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="px-3 py-1 rounded-lg text-white text-sm font-bold min-w-[60px] text-center"
                        style={{ backgroundColor: event.color }}
                      >
                        {event.time}
                      </div>
                      <div className="flex-1">
                        <div className="font-bold text-[#0a253c]">{event.title}</div>
                        <div className="text-xs text-gray-500 flex items-center gap-3 mt-1">
                          <span className="flex items-center gap-1">
                            <Timer className="w-3 h-3" />
                            {event.duration}
                          </span>
                          <span className="flex items-center gap-1">
                            <Users className="w-3 h-3" />
                            {event.guests}
                          </span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 bg-white rounded-2xl p-4 border-2 border-[#d4af37]/30">
                <div className="text-center">
                  <div className="text-3xl mb-2">🎯</div>
                  <p className="text-sm text-gray-600">
                    <span className="font-bold text-[#d4af37]">{demoTimelineEvents.length} Events</span> geplant
                  </p>
                  <p className="text-xs text-gray-500 mt-1">
                    Von 14:00 bis 20:30 Uhr
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <button
              onClick={onGetStarted}
              className="bg-[#0a253c] hover:bg-[#1a3a5c] text-[#d4af37] px-10 py-4 rounded-full text-lg font-bold transition-all transform hover:scale-105 shadow-lg inline-flex items-center gap-2"
            >
              Mehr Funktionen entdecken
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Section 3: Funktioniert für jede Hochzeit */}
      <div className="py-24 bg-gradient-to-b from-[#f7f2eb] to-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#0a253c] mb-4">
              Funktioniert für <span className="text-gradient-gold">jede Hochzeit</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Egal ob spontan oder geplant, klein oder groß – unser System passt sich euren Träumen an
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 card-hover border-2 border-transparent hover:border-[#d4af37]/30">
              <div className="text-6xl mb-4 text-center">💍</div>
              <h3 className="text-xl font-bold text-[#0a253c] mb-3 text-center">Standesamt nächsten Monat</h3>
              <p className="text-gray-600 text-center leading-relaxed mb-4">
                Spontane Entscheidung? Kein Problem! Fokus auf das Wesentliche.
              </p>
              <div className="flex items-center justify-center text-sm text-[#d4af37] font-semibold">
                <TrendingUp className="w-4 h-4 mr-1" />
                Express-Planung
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 card-hover border-2 border-transparent hover:border-[#d4af37]/30">
              <div className="text-6xl mb-4 text-center">🌸</div>
              <h3 className="text-xl font-bold text-[#0a253c] mb-3 text-center">Intimes Fest im Garten</h3>
              <p className="text-gray-600 text-center leading-relaxed mb-4">
                Kleine, persönliche Feier mit euren Liebsten. DIY-Charme inklusive.
              </p>
              <div className="flex items-center justify-center text-sm text-[#d4af37] font-semibold">
                <Heart className="w-4 h-4 mr-1" />
                20-50 Gäste
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 card-hover border-2 border-transparent hover:border-[#d4af37]/30">
              <div className="text-6xl mb-4 text-center">✨</div>
              <h3 className="text-xl font-bold text-[#0a253c] mb-3 text-center">Große Feier in 18 Monaten</h3>
              <p className="text-gray-600 text-center leading-relaxed mb-4">
                Zeit für jedes Detail. Entspannt planen und genießen.
              </p>
              <div className="flex items-center justify-center text-sm text-[#d4af37] font-semibold">
                <Calendar className="w-4 h-4 mr-1" />
                Volle Flexibilität
              </div>
            </div>

            <div className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-2xl transition-all duration-300 card-hover border-2 border-transparent hover:border-[#d4af37]/30">
              <div className="text-6xl mb-4 text-center">🌴</div>
              <h3 className="text-xl font-bold text-[#0a253c] mb-3 text-center">Destination Wedding</h3>
              <p className="text-gray-600 text-center leading-relaxed mb-4">
                Traumhochzeit am Strand oder in den Bergen. Abenteuer pur!
              </p>
              <div className="flex items-center justify-center text-sm text-[#d4af37] font-semibold">
                <Star className="w-4 h-4 mr-1" />
                Weltweit
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <button
              onClick={onGetStarted}
              className="bg-[#d4af37] hover:bg-[#c19a2e] text-[#0a253c] px-10 py-4 rounded-full text-lg font-bold transition-all transform hover:scale-105 shadow-lg inline-flex items-center gap-2"
            >
              Starte deine individuelle Planung
              <ArrowRight className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>

      {/* Section 4: Timeline & Block-Planung Feature */}
      <div className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 bg-[#d4af37]/10 border-2 border-[#d4af37]/30 px-4 py-2 rounded-full text-sm font-bold mb-4 text-[#0a253c]">
              <Clock className="w-4 h-4 text-[#d4af37]" />
              Kernfunktion
            </div>
            <h2 className="text-4xl md:text-5xl font-bold text-[#0a253c] mb-4">
              Euer Tagesablauf – <span className="text-gradient-gold">Perfekt durchdacht</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Mit unserer Timeline-Funktion plant ihr euren Hochzeitstag minutengenau. Jedes Event wird zu einem planbaren Block mit allen Details.
            </p>
          </div>

          {/* Feature Benefits - Moved above the panel */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 sm:gap-8 max-w-6xl mx-auto mb-12 px-4">
            <div className="text-center">
              <div className="bg-[#d4af37] w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 shadow-lg hover-scale">
                <Timer className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-[#0a253c] mb-2 sm:mb-3">Pufferzeiten</h3>
              <p className="text-sm sm:text-base text-gray-600 leading-relaxed px-2">
                Plant Puffer zwischen Events ein, damit ihr entspannt von einem Moment zum nächsten gleiten könnt.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-[#d4af37] w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 shadow-lg hover-scale">
                <LayoutGrid className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-[#0a253c] mb-2 sm:mb-3">Sub-Timelines</h3>
              <p className="text-sm sm:text-base text-gray-600 leading-relaxed px-2">
                Erstellt innerhalb jedes Blocks eigene Mini-Timelines für noch detailliertere Planung.
              </p>
            </div>

            <div className="text-center">
              <div className="bg-[#d4af37] w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center mx-auto mb-3 sm:mb-4 shadow-lg hover-scale">
                <CheckCircle className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
              </div>
              <h3 className="text-lg sm:text-xl font-bold text-[#0a253c] mb-2 sm:mb-3">Alles verknüpft</h3>
              <p className="text-sm sm:text-base text-gray-600 leading-relaxed px-2">
                Verbindet Aufgaben, Dienstleister und Budget-Positionen direkt mit eurem Tagesablauf.
              </p>
            </div>
          </div>

          {/* Visual Timeline Flow Panel */}
          <div className="max-w-5xl mx-auto mb-16">
            <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-3xl p-6 sm:p-8 md:p-12 shadow-2xl border-2 border-[#d4af37]/20">
              <div className="grid md:grid-cols-2 gap-6 sm:gap-8 items-center">
                <div>
                  <h3 className="text-2xl sm:text-3xl font-bold text-[#0a253c] mb-3 sm:mb-4">
                    Von Chaos zu Klarheit
                  </h3>
                  <p className="text-sm sm:text-base text-gray-600 leading-relaxed mb-4 sm:mb-6">
                    Organisiert euren Hochzeitstag in übersichtliche Blöcke. Jedes Event – ob Trauung, Empfang oder Dinner – bekommt seine eigene Detailplanung.
                  </p>
                  <div className="space-y-2.5 sm:space-y-3">
                    <div className="flex items-start gap-2.5 sm:gap-3">
                      <div className="bg-[#d4af37] p-1.5 sm:p-2 rounded-lg flex-shrink-0">
                        <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-sm sm:text-base text-[#0a253c]">Minutengenaue Planung</div>
                        <div className="text-xs sm:text-sm text-gray-600">Start, Ende und Pufferzeiten für jedes Event</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2.5 sm:gap-3">
                      <div className="bg-[#d4af37] p-1.5 sm:p-2 rounded-lg flex-shrink-0">
                        <LayoutGrid className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-sm sm:text-base text-[#0a253c]">Block-Planung</div>
                        <div className="text-xs sm:text-sm text-gray-600">Checklisten, Aufgaben und Notizen pro Event</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2.5 sm:gap-3">
                      <div className="bg-[#d4af37] p-1.5 sm:p-2 rounded-lg flex-shrink-0">
                        <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-sm sm:text-base text-[#0a253c]">Gäste & Dienstleister</div>
                        <div className="text-xs sm:text-sm text-gray-600">Zuordnung von Teilnehmern und Vendors pro Block</div>
                      </div>
                    </div>
                    <div className="flex items-start gap-2.5 sm:gap-3">
                      <div className="bg-[#d4af37] p-1.5 sm:p-2 rounded-lg flex-shrink-0">
                        <DollarSign className="w-3.5 h-3.5 sm:w-4 sm:h-4 text-white" />
                      </div>
                      <div>
                        <div className="font-bold text-sm sm:text-base text-[#0a253c]">Budget-Tracking</div>
                        <div className="text-xs sm:text-sm text-gray-600">Kosten pro Event im Blick behalten</div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-white rounded-xl sm:rounded-2xl p-4 sm:p-6 shadow-xl border-2 border-[#d4af37]/30">
                  <div className="text-xs sm:text-sm font-bold text-[#d4af37] mb-3 sm:mb-4 flex items-center gap-2">
                    <Calendar className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    Beispiel-Tagesablauf
                  </div>
                  <div className="space-y-2 sm:space-y-3">
                    <div className="flex items-center gap-2 sm:gap-3 p-2 sm:p-3 bg-[#d4af37]/5 rounded-lg border-l-4 border-[#d4af37]">
                      <div className="text-base sm:text-lg font-bold text-[#d4af37] min-w-[45px] sm:min-w-[50px]">13:00</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm sm:text-base text-[#0a253c]">Getting Ready</div>
                        <div className="text-[10px] sm:text-xs text-gray-500">120 Min • 8 Personen</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 sm:gap-3 p-2 sm:p-3 bg-[#d4af37]/5 rounded-lg border-l-4 border-[#d4af37]">
                      <div className="text-base sm:text-lg font-bold text-[#d4af37] min-w-[45px] sm:min-w-[50px]">15:00</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm sm:text-base text-[#0a253c]">Trauung</div>
                        <div className="text-[10px] sm:text-xs text-gray-500">45 Min • 80 Personen</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 sm:gap-3 p-2 sm:p-3 bg-gray-100 rounded-lg border-l-4 border-gray-400">
                      <div className="text-base sm:text-lg font-bold text-gray-500 min-w-[45px] sm:min-w-[50px]">16:00</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm sm:text-base text-gray-600">Puffer</div>
                        <div className="text-[10px] sm:text-xs text-gray-500">30 Min</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 sm:gap-3 p-2 sm:p-3 bg-[#d4af37]/5 rounded-lg border-l-4 border-[#d4af37]">
                      <div className="text-base sm:text-lg font-bold text-[#d4af37] min-w-[45px] sm:min-w-[50px]">16:30</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm sm:text-base text-[#0a253c]">Sektempfang</div>
                        <div className="text-[10px] sm:text-xs text-gray-500">90 Min • 80 Personen</div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 sm:gap-3 p-2 sm:p-3 bg-[#d4af37]/5 rounded-lg border-l-4 border-[#d4af37]">
                      <div className="text-base sm:text-lg font-bold text-[#d4af37] min-w-[45px] sm:min-w-[50px]">18:30</div>
                      <div className="flex-1 min-w-0">
                        <div className="font-bold text-sm sm:text-base text-[#0a253c]">Abendessen</div>
                        <div className="text-[10px] sm:text-xs text-gray-500">120 Min • 80 Personen</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center">
            <button
              onClick={onGetStarted}
              className="bg-[#d4af37] hover:bg-[#f4d03f] text-[#0a253c] px-8 sm:px-12 py-4 sm:py-5 rounded-full text-lg sm:text-xl font-bold transition-all transform hover:scale-105 shadow-lg inline-flex items-center gap-2 touch-manipulation"
            >
              Timeline jetzt erstellen
              <ArrowRight className="w-5 h-5 sm:w-6 sm:h-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Section 5: Passt sich euch an */}
      <div className="py-24 bg-gradient-to-b from-white to-[#f7f2eb]">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#0a253c] mb-4">
              Passt sich <span className="text-gradient-gold">euch an</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Keine starren Vorgaben. Euer System wächst mit euren Bedürfnissen.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8 max-w-6xl mx-auto">
            <div className="text-center group">
              <div className="bg-gradient-to-br from-[#d4af37] to-[#f4d03f] w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 transform transition-all duration-300 group-hover:scale-110 group-hover:rotate-3 shadow-lg">
                <Sliders className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#0a253c] mb-3">Flexible Prioritäten</h3>
              <p className="text-gray-600 leading-relaxed">
                Ihr entscheidet, was wichtig ist. Keine erzwungenen Schritte.
              </p>
            </div>

            <div className="text-center group">
              <div className="bg-gradient-to-br from-[#d4af37] to-[#f4d03f] w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 transform transition-all duration-300 group-hover:scale-110 group-hover:rotate-3 shadow-lg">
                <RefreshCw className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#0a253c] mb-3">Wächst mit euch</h3>
              <p className="text-gray-600 leading-relaxed">
                Pläne ändern sich? Perfekt. Das System passt sich an.
              </p>
            </div>

            <div className="text-center group">
              <div className="bg-gradient-to-br from-[#d4af37] to-[#f4d03f] w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 transform transition-all duration-300 group-hover:scale-110 group-hover:rotate-3 shadow-lg">
                <Zap className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#0a253c] mb-3">Kein Druck</h3>
              <p className="text-gray-600 leading-relaxed">
                Keine festen Deadlines. Plant in eurem Tempo.
              </p>
            </div>

            <div className="text-center group">
              <div className="bg-gradient-to-br from-[#d4af37] to-[#f4d03f] w-20 h-20 rounded-2xl flex items-center justify-center mx-auto mb-6 transform transition-all duration-300 group-hover:scale-110 group-hover:rotate-3 shadow-lg">
                <Star className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-xl font-bold text-[#0a253c] mb-3">Eure Kategorien</h3>
              <p className="text-gray-600 leading-relaxed">
                Erstellt eigene Aufgabenbereiche. Ganz nach eurem Stil.
              </p>
            </div>
          </div>

          <div className="mt-16 max-w-4xl mx-auto bg-white rounded-3xl p-10 shadow-2xl border-2 border-[#d4af37]/20">
            <div className="flex flex-col md:flex-row items-center gap-8">
              <div className="flex-shrink-0">
                <div className="w-24 h-24 bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-full flex items-center justify-center">
                  <Heart className="w-12 h-12 text-[#d4af37] fill-current" />
                </div>
              </div>
              <div className="flex-1 text-center md:text-left">
                <h3 className="text-2xl font-bold text-[#0a253c] mb-3">
                  Eure Hochzeit, eure Regeln
                </h3>
                <p className="text-gray-600 leading-relaxed text-lg">
                  Wir glauben daran, dass jede Liebe einzigartig ist. Deshalb gibt es bei uns keine Schablonen – nur pure Freiheit, eure Traumhochzeit genau so zu planen, wie ihr es wollt.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Section 6: Comparison - Excel vs App / With vs Without */}
      <div className="py-24 bg-gradient-to-b from-[#f7f2eb] to-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#0a253c] mb-4">
              Der <span className="text-gradient-gold">Unterschied</span> ist spürbar
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Warum unsere Plattform eure Planung revolutioniert
            </p>
          </div>

          {/* Excel vs App Comparison */}
          <div className="max-w-5xl mx-auto mb-16">
            <div className="grid md:grid-cols-2 gap-6">
              {/* Excel/Traditional */}
              <div className="bg-gray-100 rounded-3xl p-8 border-2 border-gray-300 relative overflow-hidden">
                <div className="absolute top-4 right-4 bg-gray-400 text-white px-4 py-1 rounded-full text-sm font-semibold">
                  Alt
                </div>
                <div className="text-6xl mb-4 text-center opacity-60">📊</div>
                <h3 className="text-2xl font-bold text-gray-700 mb-6 text-center">Excel & Notizzettel</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 text-gray-600">
                    <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <span>Unübersichtliche Tabellen</span>
                  </div>
                  <div className="flex items-start gap-3 text-gray-600">
                    <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <span>Keine Echtzeit-Updates</span>
                  </div>
                  <div className="flex items-start gap-3 text-gray-600">
                    <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <span>Chaos bei Änderungen</span>
                  </div>
                  <div className="flex items-start gap-3 text-gray-600">
                    <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <span>Stundenlange Formatierung</span>
                  </div>
                  <div className="flex items-start gap-3 text-gray-600">
                    <X className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5" />
                    <span>Keine Timeline-Visualisierung</span>
                  </div>
                </div>
              </div>

              {/* Our App */}
              <div className="bg-gradient-to-br from-[#d4af37]/10 to-[#f4d03f]/10 rounded-3xl p-8 border-2 border-[#d4af37] relative overflow-hidden shadow-xl">
                <div className="absolute top-4 right-4 bg-[#d4af37] text-[#0a253c] px-4 py-1 rounded-full text-sm font-semibold">
                  Neu ✨
                </div>
                <div className="text-6xl mb-4 text-center">🚀</div>
                <h3 className="text-2xl font-bold text-[#0a253c] mb-6 text-center">Unsere Plattform</h3>
                <div className="space-y-3">
                  <div className="flex items-start gap-3 text-[#0a253c]">
                    <CheckCircle className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
                    <span className="font-medium">Visuell & intuitiv</span>
                  </div>
                  <div className="flex items-start gap-3 text-[#0a253c]">
                    <CheckCircle className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
                    <span className="font-medium">Live-Synchronisation</span>
                  </div>
                  <div className="flex items-start gap-3 text-[#0a253c]">
                    <CheckCircle className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
                    <span className="font-medium">Flexibel anpassbar</span>
                  </div>
                  <div className="flex items-start gap-3 text-[#0a253c]">
                    <CheckCircle className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
                    <span className="font-medium">Sofort einsatzbereit</span>
                  </div>
                  <div className="flex items-start gap-3 text-[#0a253c]">
                    <CheckCircle className="w-5 h-5 text-[#d4af37] flex-shrink-0 mt-0.5" />
                    <span className="font-medium">Timeline-Planung inklusive</span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* With vs Without Stress Level */}
          <div className="max-w-4xl mx-auto">
            <h3 className="text-3xl font-bold text-[#0a253c] mb-8 text-center">
              Stress-Level im Vergleich
            </h3>
            <div className="grid md:grid-cols-2 gap-8">
              {/* Without */}
              <div className="bg-white rounded-2xl p-8 shadow-lg border-2 border-gray-200">
                <h4 className="text-xl font-bold text-gray-700 mb-4 text-center">
                  Ohne Heldenreise 😰
                </h4>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2 text-sm">
                      <span className="text-gray-600">Stress</span>
                      <span className="font-bold text-red-500">85%</span>
                    </div>
                    <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-red-500 rounded-full" style={{ width: '85%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-2 text-sm">
                      <span className="text-gray-600">Vorfreude</span>
                      <span className="font-bold text-gray-400">30%</span>
                    </div>
                    <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gray-400 rounded-full" style={{ width: '30%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-2 text-sm">
                      <span className="text-gray-600">Zeitersparnis</span>
                      <span className="font-bold text-gray-400">0h</span>
                    </div>
                    <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gray-400 rounded-full" style={{ width: '0%' }}></div>
                    </div>
                  </div>
                </div>
              </div>

              {/* With */}
              <div className="bg-gradient-to-br from-[#d4af37]/10 to-[#f4d03f]/10 rounded-2xl p-8 shadow-xl border-2 border-[#d4af37]">
                <h4 className="text-xl font-bold text-[#0a253c] mb-4 text-center">
                  Mit Heldenreise 🎉
                </h4>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2 text-sm">
                      <span className="text-gray-700">Stress</span>
                      <span className="font-bold text-[#d4af37]">15%</span>
                    </div>
                    <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] rounded-full" style={{ width: '15%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-2 text-sm">
                      <span className="text-gray-700">Vorfreude</span>
                      <span className="font-bold text-[#d4af37]">95%</span>
                    </div>
                    <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] rounded-full" style={{ width: '95%' }}></div>
                    </div>
                  </div>
                  <div>
                    <div className="flex justify-between mb-2 text-sm">
                      <span className="text-gray-700">Zeitersparnis</span>
                      <span className="font-bold text-[#d4af37]">47h</span>
                    </div>
                    <div className="h-4 bg-gray-200 rounded-full overflow-hidden">
                      <div className="h-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] rounded-full" style={{ width: '90%' }}></div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Section 12: Your Way Visual Story */}
      <div className="py-24 bg-[#0a253c] relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-64 h-64 bg-[#d4af37] rounded-full blur-3xl"></div>
          <div className="absolute bottom-20 right-10 w-96 h-96 bg-[#f4d03f] rounded-full blur-3xl"></div>
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-white mb-4">
              Startet <span className="text-[#d4af37]">genau dort</span>, wo es sich richtig anfühlt
            </h2>
            <p className="text-xl text-[#f7f2eb] max-w-2xl mx-auto">
              Es gibt keinen "richtigen" ersten Schritt. Jede Reise ist anders.
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-3 gap-6">
              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 hover:bg-white/20 transition-all duration-300 card-hover border-2 border-[#d4af37]/30 cursor-pointer">
                <div className="text-5xl mb-4 text-center">💰</div>
                <h3 className="text-2xl font-bold text-[#d4af37] mb-3 text-center">Budget zuerst</h3>
                <p className="text-[#f7f2eb] leading-relaxed text-center mb-4">
                  Klärt euer Budget und lasst alles andere drum herum wachsen.
                </p>
                <div className="flex justify-center">
                  <ArrowRight className="w-6 h-6 text-[#d4af37] animate-pulse" />
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 hover:bg-white/20 transition-all duration-300 card-hover border-2 border-[#d4af37]/30 cursor-pointer">
                <div className="text-5xl mb-4 text-center">👥</div>
                <h3 className="text-2xl font-bold text-[#d4af37] mb-3 text-center">Gästeliste zuerst</h3>
                <p className="text-[#f7f2eb] leading-relaxed text-center mb-4">
                  Wer soll dabei sein? Beginnt mit den Menschen, die zählen.
                </p>
                <div className="flex justify-center">
                  <ArrowRight className="w-6 h-6 text-[#d4af37] animate-pulse" />
                </div>
              </div>

              <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-8 hover:bg-white/20 transition-all duration-300 card-hover border-2 border-[#d4af37]/30 cursor-pointer">
                <div className="text-5xl mb-4 text-center">📍</div>
                <h3 className="text-2xl font-bold text-[#d4af37] mb-3 text-center">Location zuerst</h3>
                <p className="text-[#f7f2eb] leading-relaxed text-center mb-4">
                  Der perfekte Ort ist gefunden? Super! Plant von dort aus weiter.
                </p>
                <div className="flex justify-center">
                  <ArrowRight className="w-6 h-6 text-[#d4af37] animate-pulse" />
                </div>
              </div>
            </div>

            <div className="mt-8 bg-white/10 backdrop-blur-lg rounded-2xl p-8 border-2 border-[#f4d03f]/40">
              <div className="text-center">
                <div className="text-4xl sm:text-5xl mb-3 sm:mb-4">🤔</div>
                <h3 className="text-2xl font-bold text-white mb-3">Keine Ahnung wo anfangen?</h3>
                <p className="text-[#f7f2eb] leading-relaxed mb-6 max-w-xl mx-auto">
                  Perfekt! Wir führen euch durch einen kurzen Onboarding-Prozess und helfen euch, den besten Startpunkt für eure persönliche Planung zu finden.
                </p>
                <button
                  onClick={() => openModal('login')}
                  className="bg-[#d4af37] hover:bg-[#f4d03f] text-[#0a253c] px-10 py-4 rounded-full text-lg font-bold transition-all transform hover:scale-105 shadow-lg inline-flex items-center gap-2"
                >
                  Jetzt starten
                  <Sparkles className="w-5 h-5" />
                </button>
              </div>
            </div>
          </div>

          <div className="mt-16 text-center">
            <p className="text-[#f7f2eb]/80 text-sm max-w-2xl mx-auto italic">
              "Die beste Hochzeitsplanung ist die, die zu euch passt – nicht zu einem Lehrbuch."
            </p>
          </div>
        </div>
      </div>

      {/* Section: How It Works */}
      <div className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#0a253c] mb-4">
              So <span className="text-gradient-gold">einfach</span> geht's
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              In nur 3 Schritten zu eurer perfekt organisierten Hochzeitsplanung
            </p>
          </div>

          <div className="max-w-5xl mx-auto">
            <div className="grid md:grid-cols-3 gap-12">
              {/* Step 1 */}
              <div className="text-center relative">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[#d4af37] text-[#0a253c] w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl shadow-lg">
                  1
                </div>
                <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-2xl p-8 pt-12 shadow-xl border-2 border-[#d4af37]/20 h-full card-hover">
                  <div className="bg-[#d4af37] w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <Sparkles className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-[#0a253c] mb-4">Kostenlos registrieren</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Erstellt euren Account in unter einer Minute. Keine Kreditkarte erforderlich, keine versteckten Kosten.
                  </p>
                </div>
              </div>

              {/* Step 2 */}
              <div className="text-center relative">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[#d4af37] text-[#0a253c] w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl shadow-lg">
                  2
                </div>
                <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-2xl p-8 pt-12 shadow-xl border-2 border-[#d4af37]/20 h-full card-hover">
                  <div className="bg-[#d4af37] w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <Heart className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-[#0a253c] mb-4">Hochzeit anlegen</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Beantwortet ein paar einfache Fragen und wir erstellen eure personalisierte Planungsumgebung.
                  </p>
                </div>
              </div>

              {/* Step 3 */}
              <div className="text-center relative">
                <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-[#d4af37] text-[#0a253c] w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl shadow-lg">
                  3
                </div>
                <div className="bg-gradient-to-br from-[#f7f2eb] to-white rounded-2xl p-8 pt-12 shadow-xl border-2 border-[#d4af37]/20 h-full card-hover">
                  <div className="bg-[#d4af37] w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <CheckCircle className="w-10 h-10 text-white" />
                  </div>
                  <h3 className="text-2xl font-bold text-[#0a253c] mb-4">Loslegen & Feiern</h3>
                  <p className="text-gray-600 leading-relaxed">
                    Plant entspannt, nutzt alle Features und genießt den Weg zu eurem großen Tag.
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-12 text-center">
              <button
                onClick={() => openModal('login')}
                className="bg-[#d4af37] hover:bg-[#f4d03f] text-[#0a253c] px-12 py-5 rounded-full text-xl font-bold transition-all transform hover:scale-105 shadow-lg inline-flex items-center gap-2"
              >
                Jetzt kostenlos starten
                <ArrowRight className="w-6 h-6" />
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Section: Pricing */}
      <div id="pricing" className="py-24 bg-gradient-to-b from-[#f7f2eb] to-white">
        <div className="container mx-auto px-6">
          <div className="bg-orange-50 border border-orange-200 rounded-xl p-6 mb-12 max-w-4xl mx-auto">
            <div className="flex items-center justify-center gap-3 mb-3">
              <AlertTriangle className="w-6 h-6 text-orange-600" />
              <h3 className="text-xl font-bold text-orange-900">Beta-Phase Information</h3>
            </div>
            <p className="text-center text-orange-800">
              Diese App befindet sich in aktiver Entwicklung. Wir arbeiten kontinuierlich an neuen Features und Verbesserungen. Vielen Dank für eure Unterstützung!
            </p>
          </div>

          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#0a253c] mb-4">
              Transparent & <span className="text-gradient-gold">Fair</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Startet kostenlos und upgradet nur, wenn ihr mehr wollt
            </p>
          </div>

          <div className="max-w-5xl mx-auto grid md:grid-cols-2 gap-8">
            {/* Free Plan */}
            <div className="bg-white rounded-3xl p-10 shadow-xl border-2 border-gray-200">
              <div className="text-center mb-8">
                <h3 className="text-3xl font-bold text-[#0a253c] mb-2">Free Plan</h3>
                <div className="text-5xl font-bold text-[#0a253c] mb-2">0€</div>
                <p className="text-gray-600">Perfekt für den Start</p>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Bis zu 40 Gäste</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Bis zu 15 Budget-Einträge</span>
                </li>
                <li className="flex items-start gap-3 bg-[#d4af37]/5 -mx-2 px-2 py-2 rounded-lg">
                  <Clock className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="text-gray-700 font-semibold block">Bis zu 3 Timeline-Events + 2 Puffer</span>
                    <span className="text-xs text-gray-500">Basis-Timeline für euren Hochzeitstag</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Bis zu 5 Dienstleister</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Basis Budget-Übersicht</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">CSV Export</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">Unbegrenzte Notifications</span>
                </li>
              </ul>

              <p className="text-xs text-gray-500 text-center mb-4 italic">
                Traumtaghelden Beta Wasserzeichen
              </p>

              <button
                onClick={() => openModal('login')}
                className="w-full bg-gray-100 hover:bg-gray-200 text-[#0a253c] py-4 rounded-full text-lg font-bold transition-all"
              >
                Kostenlos starten
              </button>
            </div>

            {/* Premium Plan */}
            <div className="bg-gradient-to-br from-[#0a253c] to-[#1a3a5c] rounded-3xl p-10 shadow-2xl border-2 border-[#d4af37] relative overflow-hidden transform scale-105">
              <div className="absolute top-4 right-4 bg-[#d4af37] text-[#0a253c] px-4 py-1 rounded-full text-sm font-bold">
                Beliebteste Wahl
              </div>

              <div className="text-center mb-8">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Crown className="w-6 h-6 text-[#d4af37]" />
                  <h3 className="text-3xl font-bold text-white">Heldenreise Premium</h3>
                </div>
                <div className="text-5xl font-bold text-[#d4af37] mb-2">29,99€</div>
                <p className="text-[#f7f2eb]">pro Monat - Monatlich kündbar</p>
              </div>

              <ul className="space-y-4 mb-8">
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-white font-semibold">Unbegrenzte Gäste</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-[#f7f2eb]">Unbegrenzte Budget-Einträge</span>
                </li>
                <li className="flex items-start gap-3 bg-[#d4af37]/10 -mx-2 px-2 py-2 rounded-lg">
                  <Clock className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-bold block">Unbegrenzte Timeline-Events & Puffer</span>
                    <span className="text-xs text-[#f7f2eb]/80">Detaillierte Tagesablauf-Planung ohne Limits</span>
                  </div>
                </li>
                <li className="flex items-start gap-3 bg-[#d4af37]/10 -mx-2 px-2 py-2 rounded-lg">
                  <LayoutGrid className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="text-white font-bold block">Block-Planung für Timeline</span>
                    <span className="text-xs text-[#f7f2eb]/80">Checklisten, Aufgaben & Notizen pro Event</span>
                  </div>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-[#f7f2eb]">Unbegrenzte Dienstleister</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-[#f7f2eb]">Erweiterte Budget-Analysen & Charts</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-[#f7f2eb]">Erweiterte Zahlungspläne (Raten, Meilensteine)</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-[#f7f2eb]">PDF & CSV Export</span>
                </li>
                <li className="flex items-start gap-3">
                  <Check className="w-6 h-6 text-[#d4af37] flex-shrink-0 mt-0.5" />
                  <span className="text-[#f7f2eb]">Kein Wasserzeichen</span>
                </li>
              </ul>

              <button
                onClick={() => openModal('login')}
                className="w-full bg-[#d4af37] hover:bg-[#f4d03f] text-[#0a253c] py-4 rounded-full text-lg font-bold transition-all transform hover:scale-105 shadow-lg"
              >
                Jetzt Premium werden
              </button>

              <p className="text-xs text-center text-[#f7f2eb] mt-4">
                Beta-Phase: Monatlich kündbar, keine versteckten Kosten
              </p>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-600 text-sm max-w-2xl mx-auto">
              Sichere Zahlung über Stripe • DSGVO-konform • Made in Germany • Monatlich kündbar
            </p>
          </div>
        </div>
      </div>

      {/* Section: FAQ */}
      <div className="py-24 bg-white">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-bold text-[#0a253c] mb-4">
              Häufig gestellte <span className="text-gradient-gold">Fragen</span>
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Hier findet ihr Antworten auf die wichtigsten Fragen
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-4">
            {faqs.map((faq, index) => (
              <div
                key={index}
                className="bg-[#f7f2eb] rounded-2xl overflow-hidden border-2 border-transparent hover:border-[#d4af37]/30 transition-all"
              >
                <button
                  onClick={() => setOpenFAQ(openFAQ === index ? null : index)}
                  className="w-full text-left p-6 flex items-center justify-between gap-4"
                >
                  <span className="text-lg font-bold text-[#0a253c]">{faq.question}</span>
                  <div className={`transform transition-transform ${openFAQ === index ? 'rotate-180' : ''}`}>
                    <ArrowRight className="w-6 h-6 text-[#d4af37] rotate-90" />
                  </div>
                </button>
                {openFAQ === index && (
                  <div className="px-6 pb-6">
                    <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>

          <div className="mt-12 text-center">
            <p className="text-gray-600 mb-4">Noch Fragen?</p>
            <button
              onClick={() => window.location.href = 'mailto:support@hochzeitsheldenreise.de'}
              className="inline-flex items-center gap-2 text-[#d4af37] hover:text-[#f4d03f] font-semibold transition-colors"
            >
              <Mail className="w-5 h-5" />
              Schreibt uns eine E-Mail
            </button>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="bg-[#0a253c] text-white py-16">
        <div className="container mx-auto px-6">
          <div className="grid md:grid-cols-4 gap-12 mb-12">
            {/* Brand */}
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 mb-4">
                <Heart className="w-8 h-8 text-[#d4af37] fill-current" />
                <span className="text-xl font-bold">Heldenreise</span>
              </div>
              <p className="text-[#f7f2eb]/80 text-sm leading-relaxed">
                Eure Hochzeit verdient mehr als Excel-Tabellen. Plant mit Herz, Verstand und der besten Plattform.
              </p>
            </div>

            {/* Product */}
            <div>
              <h4 className="font-bold text-lg mb-4 text-[#d4af37]">Produkt</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#features" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors">Features</a></li>
                <li><a href="#pricing" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors">Preise</a></li>
                <li><a href="#how-it-works" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors">So funktioniert's</a></li>
                <li><a href="#faq" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors">FAQ</a></li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="font-bold text-lg mb-4 text-[#d4af37]">Rechtliches</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <a href="#impressum" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors flex items-center gap-2">
                    <FileText className="w-4 h-4" />
                    Impressum
                  </a>
                </li>
                <li>
                  <a href="#datenschutz" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Datenschutz
                  </a>
                </li>
                <li>
                  <a href="#agb" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors">
                    AGB
                  </a>
                </li>
              </ul>
            </div>

            {/* Contact & Social */}
            <div>
              <h4 className="font-bold text-lg mb-4 text-[#d4af37]">Kontakt</h4>
              <ul className="space-y-2 text-sm mb-6">
                <li>
                  <a href="mailto:support@hochzeitsheldenreise.de" className="text-[#f7f2eb]/80 hover:text-[#d4af37] transition-colors flex items-center gap-2">
                    <Mail className="w-4 h-4" />
                    support@hochzeitsheldenreise.de
                  </a>
                </li>
              </ul>
              <div className="flex gap-4">
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" className="bg-white/10 hover:bg-[#d4af37] w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                  <Instagram className="w-5 h-5" />
                </a>
                <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" className="bg-white/10 hover:bg-[#d4af37] w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                  <Facebook className="w-5 h-5" />
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="bg-white/10 hover:bg-[#d4af37] w-10 h-10 rounded-full flex items-center justify-center transition-colors">
                  <Twitter className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-[#f7f2eb]/60 text-sm">
                © 2024 Hochzeit Heldenreise. Made with ❤️ für euren großen Tag.
              </p>
              <button
                onClick={() => openModal('login')}
                className="text-[#d4af37] hover:text-[#f4d03f] font-semibold text-sm flex items-center gap-2 transition-colors"
              >
                <LogIn className="w-4 h-4" />
                Login
              </button>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
