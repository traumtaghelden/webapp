
export default function BetaWatermark() {

  

  return (
    <div className="fixed bottom-4 right-4 pointer-events-none z-10">
      <div className="bg-white/80 backdrop-blur-sm border border-gray-200 rounded-lg px-3 py-2 shadow-lg">
        <p className="text-xs font-semibold text-gray-500">
          Traumtaghelden <span className="text-[#d4af37]">Beta</span>
        </p>
      </div>
    </div>
  );
}
