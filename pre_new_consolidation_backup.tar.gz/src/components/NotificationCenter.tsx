import { useState, useEffect } from 'react';
import { Bell, X, Check } from 'lucide-react';
import { supabase, type Notification } from '../lib/supabase';

interface NotificationCenterProps {
  weddingId: string;
  userId: string;
}

export default function NotificationCenter({ weddingId, userId }: NotificationCenterProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [showPanel, setShowPanel] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadNotifications();
    const channel = supabase
      .channel('notifications')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'notifications',
          filter: `user_id=eq.${userId}`,
        },
        () => {
          loadNotifications();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [weddingId, userId]);

  const loadNotifications = async () => {
    try {
      const { data } = await supabase
        .from('notifications')
        .select('*')
        .eq('wedding_id', weddingId)
        .eq('user_id', userId)
        .order('created_at', { ascending: false })
        .limit(20);

      if (data) setNotifications(data);
    } catch (error) {
      console.error('Error loading notifications:', error);
    }
  };

  const markAsRead = async (notificationId: string) => {
    try {
      await supabase.from('notifications').update({ read: true }).eq('id', notificationId);
      loadNotifications();
    } catch (error) {
      console.error('Error marking notification as read:', error);
    }
  };

  const markAllAsRead = async () => {
    setLoading(true);
    try {
      await supabase
        .from('notifications')
        .update({ read: true })
        .eq('wedding_id', weddingId)
        .eq('user_id', userId)
        .eq('read', false);
      loadNotifications();
    } catch (error) {
      console.error('Error marking all as read:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteNotification = async (notificationId: string) => {
    try {
      await supabase.from('notifications').delete().eq('id', notificationId);
      loadNotifications();
    } catch (error) {
      console.error('Error deleting notification:', error);
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'task_reminder':
        return '📋';
      case 'budget_alert':
        return '💰';
      case 'rsvp_reminder':
        return '✉️';
      default:
        return '🔔';
    }
  };

  return (
    <div className="relative">
      <button
        onClick={() => setShowPanel(!showPanel)}
        className="relative p-2 rounded-full hover:bg-[#d4af37]/10 transition-all"
        title="Benachrichtigungen"
      >
        <Bell className="w-6 h-6 text-[#333333]" />
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs font-bold rounded-full w-5 h-5 flex items-center justify-center animate-pulse">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {showPanel && (
        <>
          <div className="fixed inset-0 z-[60]" onClick={() => setShowPanel(false)}></div>
          <div className="fixed right-4 w-96 max-w-[calc(100vw-2rem)] bg-white rounded-2xl shadow-2xl border-2 border-[#d4af37]/20 max-h-[80vh] flex flex-col z-[70]" style={{ top: 'calc(var(--header-height) + 0.5rem)' }}>
            <div className="flex items-center justify-between p-4 border-b-2 border-[#f7f2eb]">
              <h3 className="text-lg font-bold text-[#0a253c]">Benachrichtigungen</h3>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <button
                    onClick={markAllAsRead}
                    disabled={loading}
                    className="text-xs px-3 py-1 bg-[#d4af37] text-white rounded-full hover:bg-[#c19a2e] transition-all disabled:opacity-50"
                  >
                    <Check className="w-3 h-3 inline mr-1" />
                    Alle gelesen
                  </button>
                )}
                <button
                  onClick={() => setShowPanel(false)}
                  className="p-1 hover:bg-[#f7f2eb] rounded-full transition-all"
                >
                  <X className="w-5 h-5 text-[#333333]" />
                </button>
              </div>
            </div>

            <div className="overflow-y-auto flex-1">
              {notifications.length === 0 ? (
                <div className="p-8 text-center">
                  <div className="text-4xl mb-2">🔔</div>
                  <p className="text-[#333333]">Keine Benachrichtigungen</p>
                </div>
              ) : (
                <div className="divide-y divide-[#f7f2eb]">
                  {notifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`p-4 hover:bg-[#f7f2eb]/50 transition-all ${
                        !notification.read ? 'bg-[#d4af37]/5' : ''
                      }`}
                    >
                      <div className="flex items-start gap-3">
                        <span className="text-2xl flex-shrink-0">{getNotificationIcon(notification.type)}</span>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between gap-2 mb-1">
                            <h4 className={`font-semibold text-sm ${!notification.read ? 'text-[#0a253c]' : 'text-[#333333]'}`}>
                              {notification.title}
                            </h4>
                            {!notification.read && (
                              <span className="w-2 h-2 bg-[#d4af37] rounded-full flex-shrink-0 mt-1"></span>
                            )}
                          </div>
                          <p className="text-xs text-[#333333] mb-2">{notification.message}</p>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-[#666666]">
                              {new Date(notification.created_at).toLocaleDateString('de-DE', {
                                day: '2-digit',
                                month: 'short',
                                hour: '2-digit',
                                minute: '2-digit',
                              })}
                            </span>
                            <div className="flex items-center gap-2">
                              {!notification.read && (
                                <button
                                  onClick={() => markAsRead(notification.id)}
                                  className="text-xs text-[#d4af37] hover:text-[#c19a2e] font-semibold"
                                >
                                  Als gelesen markieren
                                </button>
                              )}
                              <button
                                onClick={() => deleteNotification(notification.id)}
                                className="text-xs text-red-500 hover:text-red-700"
                              >
                                <X className="w-4 h-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
