import { Bell, Calendar, DollarSign, Users, Building2, CheckCircle, AlertCircle, Heart, Sparkles, ArrowRight, TrendingUp, Clock, AlertTriangle } from 'lucide-react';
import { Task, BudgetItem, Guest } from '../lib/supabase';

interface DashboardNotificationsProps {
  tasks: Task[];
  budgetItems: BudgetItem[];
  guests: Guest[];
  totalBudget: number;
  weddingDate: string;
  onNavigate: (tab: string) => void;
}

interface Notification {
  id: string;
  type: 'success' | 'warning' | 'info' | 'urgent';
  icon: any;
  iconColor: string;
  bgColor: string;
  title: string;
  description: string;
  action?: {
    label: string;
    tab: string;
  };
}

export default function DashboardNotifications({
  tasks,
  budgetItems,
  guests,
  totalBudget,
  weddingDate,
  onNavigate
}: DashboardNotificationsProps) {

  const generateNotifications = (): Notification[] => {
    const notifications: Notification[] = [];
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    // Überfällige Aufgaben
    const overdueTasks = tasks.filter(t => {
      if (t.status === 'completed' || !t.due_date) return false;
      const dueDate = new Date(t.due_date);
      return dueDate < today;
    });

    if (overdueTasks.length > 0) {
      notifications.push({
        id: 'overdue-tasks',
        type: 'urgent',
        icon: AlertTriangle,
        iconColor: 'text-red-500',
        bgColor: 'from-red-50 to-orange-50',
        title: `${overdueTasks.length} ${overdueTasks.length === 1 ? 'Aufgabe benötigt' : 'Aufgaben benötigen'} eure Aufmerksamkeit`,
        description: 'Diese To-Dos sind bereits überfällig – aber keine Sorge, ihr schafft das!',
        action: { label: 'Aufgaben ansehen', tab: 'tasks' }
      });
    }

    // Hochprioritäts-Aufgaben
    const highPriorityTasks = tasks.filter(t =>
      t.status !== 'completed' && t.priority === 'high'
    ).slice(0, 5);

    if (highPriorityTasks.length > 0 && overdueTasks.length === 0) {
      notifications.push({
        id: 'high-priority',
        type: 'warning',
        icon: Clock,
        iconColor: 'text-orange-500',
        bgColor: 'from-orange-50 to-amber-50',
        title: `${highPriorityTasks.length} wichtige ${highPriorityTasks.length === 1 ? 'Aufgabe wartet' : 'Aufgaben warten'} auf euch`,
        description: 'Diese haben hohe Priorität – am besten bald erledigen!',
        action: { label: 'Zur Aufgabenliste', tab: 'tasks' }
      });
    }

    // Erledigte Aufgaben (Erfolg)
    const recentlyCompleted = tasks.filter(t => {
      if (t.status !== 'completed' || !t.updated_at) return false;
      const updatedDate = new Date(t.updated_at);
      const daysDiff = Math.floor((now.getTime() - updatedDate.getTime()) / (1000 * 60 * 60 * 24));
      return daysDiff <= 7;
    });

    if (recentlyCompleted.length >= 3 && notifications.length < 2) {
      notifications.push({
        id: 'recent-success',
        type: 'success',
        icon: CheckCircle,
        iconColor: 'text-green-500',
        bgColor: 'from-green-50 to-emerald-50',
        title: `Großartig! ${recentlyCompleted.length} ${recentlyCompleted.length === 1 ? 'Aufgabe' : 'Aufgaben'} diese Woche erledigt`,
        description: 'Ihr macht tolle Fortschritte – weiter so!',
        action: undefined
      });
    }

    // Überfällige oder bevorstehende Zahlungen
    const unpaidItems = budgetItems.filter(item =>
      !item.paid && item.actual_cost > 0
    );

    const overduePayments = unpaidItems.filter(item => {
      if (!item.payment_due_date) return false;
      const dueDate = new Date(item.payment_due_date);
      return dueDate < today;
    });

    if (overduePayments.length > 0) {
      const totalOverdue = overduePayments.reduce((sum, item) => sum + item.actual_cost, 0);
      notifications.push({
        id: 'overdue-payments',
        type: 'urgent',
        icon: DollarSign,
        iconColor: 'text-red-500',
        bgColor: 'from-red-50 to-pink-50',
        title: `Zahlungserinnerung: ${totalOverdue.toLocaleString('de-DE')} €`,
        description: `${overduePayments.length} ${overduePayments.length === 1 ? 'Zahlung ist' : 'Zahlungen sind'} fällig – vergesst nicht, sie zu begleichen!`,
        action: { label: 'Zum Budget', tab: 'budget' }
      });
    } else if (unpaidItems.length > 0 && notifications.length < 3) {
      const upcomingPayments = unpaidItems.filter(item => {
        if (!item.payment_due_date) return false;
        const dueDate = new Date(item.payment_due_date);
        const daysUntil = Math.floor((dueDate.getTime() - today.getTime()) / (1000 * 60 * 60 * 24));
        return daysUntil >= 0 && daysUntil <= 30;
      });

      if (upcomingPayments.length > 0) {
        const totalUpcoming = upcomingPayments.reduce((sum, item) => sum + item.actual_cost, 0);
        notifications.push({
          id: 'upcoming-payments',
          type: 'info',
          icon: Calendar,
          iconColor: 'text-blue-500',
          bgColor: 'from-blue-50 to-cyan-50',
          title: `Bald fällig: ${totalUpcoming.toLocaleString('de-DE')} €`,
          description: `${upcomingPayments.length} ${upcomingPayments.length === 1 ? 'Zahlung steht' : 'Zahlungen stehen'} in den nächsten 30 Tagen an`,
          action: { label: 'Budget prüfen', tab: 'budget' }
        });
      }
    }

    // Budget fast ausgeschöpft
    const spentBudget = budgetItems.reduce((sum, item) => sum + item.actual_cost, 0);
    const budgetPercentage = (spentBudget / totalBudget) * 100;

    if (budgetPercentage > 90 && notifications.length < 4) {
      notifications.push({
        id: 'budget-warning',
        type: 'warning',
        icon: TrendingUp,
        iconColor: 'text-orange-500',
        bgColor: 'from-orange-50 to-yellow-50',
        title: `Budget zu ${Math.round(budgetPercentage)}% ausgeschöpft`,
        description: 'Ihr nähert euch eurem Budget-Limit – behaltet die Ausgaben im Blick!',
        action: { label: 'Budget ansehen', tab: 'budget' }
      });
    }

    // Offene Einladungen / Gästeantworten
    const pendingGuests = guests.filter(g =>
      g.invitation_status === 'invited' || g.invitation_status === 'pending'
    );

    if (pendingGuests.length > 10 && notifications.length < 4) {
      notifications.push({
        id: 'pending-rsvp',
        type: 'info',
        icon: Users,
        iconColor: 'text-purple-500',
        bgColor: 'from-purple-50 to-pink-50',
        title: `${pendingGuests.length} Gäste haben noch nicht geantwortet`,
        description: 'Vielleicht möchtet ihr freundlich nachfragen?',
        action: { label: 'Gästeliste öffnen', tab: 'guests' }
      });
    }

    // Neue Zusagen (Erfolg)
    const confirmedRecently = guests.filter(g => {
      if (g.invitation_status !== 'confirmed' || !g.updated_at) return false;
      const updatedDate = new Date(g.updated_at);
      const daysDiff = Math.floor((now.getTime() - updatedDate.getTime()) / (1000 * 60 * 60 * 24));
      return daysDiff <= 7;
    });

    if (confirmedRecently.length >= 5 && notifications.length < 3) {
      notifications.push({
        id: 'new-confirmations',
        type: 'success',
        icon: Heart,
        iconColor: 'text-pink-500',
        bgColor: 'from-pink-50 to-rose-50',
        title: `${confirmedRecently.length} neue ${confirmedRecently.length === 1 ? 'Zusage' : 'Zusagen'} diese Woche!`,
        description: 'Eure Gäste freuen sich mit euch – wie schön!',
        action: undefined
      });
    }

    // Tage bis zur Hochzeit Milestone
    const weddingDateObj = new Date(weddingDate);
    const daysUntil = Math.ceil((weddingDateObj.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    if ([365, 180, 100, 50, 30, 14, 7].includes(daysUntil) && notifications.length < 4) {
      notifications.push({
        id: 'milestone',
        type: 'info',
        icon: Sparkles,
        iconColor: 'text-[#d4af37]',
        bgColor: 'from-[#f7f2eb] to-[#d4af37]/10',
        title: `Noch ${daysUntil} Tage bis zum großen Tag!`,
        description: daysUntil <= 30
          ? 'Die Vorfreude steigt – bald ist es soweit!'
          : 'Die Zeit läuft – aber ihr seid auf einem guten Weg!',
        action: undefined
      });
    }

    // Limitiere auf maximal 5 Benachrichtigungen
    return notifications.slice(0, 5);
  };

  const notifications = generateNotifications();

  const getTypeStyles = (type: Notification['type']) => {
    switch (type) {
      case 'urgent':
        return 'border-red-300/50';
      case 'warning':
        return 'border-orange-300/50';
      case 'success':
        return 'border-green-300/50';
      default:
        return 'border-[#d4af37]/30';
    }
  };

  return (
    <div className="relative bg-gradient-to-br from-[#0a253c] via-[#1a3a5c] to-[#0a253c] rounded-2xl md:rounded-3xl p-5 md:p-10 shadow-2xl border-2 border-[#d4af37]/50 overflow-hidden animate-slide-in-smooth" style={{ animationDelay: '400ms' }}>
      <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#d4af37]/20 to-transparent rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute bottom-0 left-0 w-80 h-80 bg-gradient-to-tr from-[#f4d03f]/10 to-transparent rounded-full blur-3xl animate-pulse"></div>
      <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAiIGhlaWdodD0iNDAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+PGRlZnM+PHBhdHRlcm4gaWQ9ImdyaWQiIHdpZHRoPSI0MCIgaGVpZ2h0PSI0MCIgcGF0dGVyblVuaXRzPSJ1c2VyU3BhY2VPblVzZSI+PHBhdGggZD0iTSAwIDEwIEwgNDAgMTAgTSAxMCAwIEwgMTAgNDAgTSAwIDIwIEwgNDAgMjAgTSAyMCAwIEwgMjAgNDAgTSAwIDMwIEwgNDAgMzAgTSAzMCAwIEwgMzAgNDAiIGZpbGw9Im5vbmUiIHN0cm9rZT0icmdiYSgyMTIsIDE3NSwgNTUsIDAuMSkiIHN0cm9rZS13aWR0aD0iMSIvPjwvcGF0dGVybj48L2RlZnM+PHJlY3Qgd2lkdGg9IjEwMCUiIGhlaWdodD0iMTAwJSIgZmlsbD0idXJsKCNncmlkKSIvPjwvc3ZnPg==')] opacity-20"></div>

      <div className="relative z-10">
        <div className="flex items-center gap-2 md:gap-3 mb-2 md:mb-3">
          <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-10 h-10 md:w-14 md:h-14 rounded-xl md:rounded-2xl flex items-center justify-center shadow-lg shadow-[#d4af37]/50 animate-pulse">
            <Bell className="w-5 h-5 md:w-7 md:h-7 text-white" />
          </div>
          <div>
            <h2 className="text-xl md:text-3xl font-bold text-white">Benachrichtigungen & Ereignisse</h2>
            <p className="text-white/70 text-xs md:text-sm mt-0.5">Was gerade in eurer Planung passiert</p>
          </div>
        </div>

        {notifications.length === 0 ? (
          <div className="mt-6 md:mt-8 bg-white/5 backdrop-blur-sm rounded-xl p-6 md:p-8 border border-white/10 text-center">
            <CheckCircle className="w-12 h-12 md:w-16 md:h-16 text-green-400 mx-auto mb-3" />
            <p className="text-white font-semibold text-base md:text-lg mb-1">Alles im grünen Bereich!</p>
            <p className="text-white/70 text-sm">Keine dringenden Aufgaben oder Benachrichtigungen</p>
          </div>
        ) : (
          <div className="mt-5 md:mt-8 space-y-3 md:space-y-4">
            {notifications.map((notification) => {
              const Icon = notification.icon;
              return (
                <div
                  key={notification.id}
                  className={`bg-gradient-to-r ${notification.bgColor} backdrop-blur-sm rounded-xl md:rounded-2xl p-4 md:p-5 border-2 ${getTypeStyles(notification.type)} hover:scale-[1.02] transition-all duration-300 group`}
                >
                  <div className="flex items-start gap-3 md:gap-4">
                    <div className={`flex-shrink-0 w-10 h-10 md:w-12 md:h-12 rounded-xl bg-white shadow-md flex items-center justify-center group-hover:scale-110 transition-transform`}>
                      <Icon className={`w-5 h-5 md:w-6 md:h-6 ${notification.iconColor}`} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-[#0a253c] text-sm md:text-base mb-1 leading-tight">
                        {notification.title}
                      </h3>
                      <p className="text-[#333333] text-xs md:text-sm leading-relaxed mb-3">
                        {notification.description}
                      </p>
                      {notification.action && (
                        <button
                          onClick={() => onNavigate(notification.action!.tab)}
                          className="inline-flex items-center gap-1.5 px-3 md:px-4 py-1.5 md:py-2 bg-[#0a253c] text-white rounded-lg text-xs md:text-sm font-semibold hover:bg-[#1a3a5c] transition-all group-hover:shadow-lg"
                        >
                          {notification.action.label}
                          <ArrowRight className="w-3 h-3 md:w-4 md:h-4 group-hover:translate-x-1 transition-transform" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}

        {notifications.length > 0 && (
          <div className="mt-5 md:mt-6 text-center">
            <p className="text-white/50 text-xs md:text-sm">
              Die Benachrichtigungen aktualisieren sich automatisch
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
