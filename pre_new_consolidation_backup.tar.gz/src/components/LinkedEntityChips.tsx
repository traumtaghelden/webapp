import { DollarSign, CheckSquare, Calendar, Building2, Link2, ExternalLink } from 'lucide-react';
import { useState } from 'react';
import { TASK, BUDGET, VENDOR, TIMELINE } from '../constants/terminology';

interface LinkedEntity {
  id: string;
  type: 'task' | 'budget' | 'vendor' | 'timeline';
  name: string;
  status?: string;
  onClick?: () => void;
}

interface LinkedEntityChipsProps {
  entities: LinkedEntity[];
  compact?: boolean;
  showCount?: boolean;
  onShowAll?: () => void;
}

export default function LinkedEntityChips({
  entities,
  compact = false,
  showCount = false,
  onShowAll
}: LinkedEntityChipsProps) {
  const [showAll, setShowAll] = useState(false);

  const getIcon = (type: string) => {
    switch (type) {
      case 'task':
        return CheckSquare;
      case 'budget':
        return DollarSign;
      case 'vendor':
        return Building2;
      case 'timeline':
        return Calendar;
      default:
        return Link2;
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'task':
        return 'bg-blue-50 text-blue-700 border-blue-200 hover:bg-blue-100';
      case 'budget':
        return 'bg-green-50 text-green-700 border-green-200 hover:bg-green-100';
      case 'vendor':
        return 'bg-purple-50 text-purple-700 border-purple-200 hover:bg-purple-100';
      case 'timeline':
        return 'bg-orange-50 text-orange-700 border-orange-200 hover:bg-orange-100';
      default:
        return 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-gray-100';
    }
  };

  const getTypeLabel = (type: string) => {
    switch (type) {
      case 'task':
        return TASK.SINGULAR;
      case 'budget':
        return BUDGET.MODULE_NAME;
      case 'vendor':
        return VENDOR.SINGULAR;
      case 'timeline':
        return TIMELINE.MODULE_NAME;
      default:
        return 'Verknüpft';
    }
  };

  if (entities.length === 0) {
    return null;
  }

  const displayEntities = showAll || compact ? entities : entities.slice(0, 3);
  const hasMore = entities.length > 3 && !showAll && !compact;

  if (showCount) {
    const grouped = entities.reduce((acc, entity) => {
      acc[entity.type] = (acc[entity.type] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return (
      <div className="flex flex-wrap gap-2">
        {Object.entries(grouped).map(([type, count]) => {
          const Icon = getIcon(type);
          return (
            <button
              key={type}
              onClick={onShowAll}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border-2 transition-all ${getTypeColor(type)}`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{getTypeLabel(type)}</span>
              <span className="ml-1 px-1.5 py-0.5 bg-white rounded-full text-xs font-bold">
                {count}
              </span>
            </button>
          );
        })}
      </div>
    );
  }

  return (
    <div className="flex flex-wrap gap-2">
      {displayEntities.map((entity) => {
        const Icon = getIcon(entity.type);
        return (
          <button
            key={entity.id}
            onClick={(e) => {
              e.stopPropagation();
              entity.onClick?.();
            }}
            className={`group flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold border-2 transition-all ${getTypeColor(entity.type)}`}
            title={`${getTypeLabel(entity.type)}: ${entity.name}`}
          >
            <Icon className="w-3.5 h-3.5" />
            {!compact && (
              <span className="max-w-[150px] truncate">
                {entity.name}
              </span>
            )}
            {compact && (
              <span>{getTypeLabel(entity.type)}</span>
            )}
            <ExternalLink className="w-3 h-3 opacity-0 group-hover:opacity-100 transition-opacity" />
          </button>
        );
      })}

      {hasMore && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            setShowAll(true);
          }}
          className="flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-gray-100 text-gray-700 hover:bg-gray-200 transition-all"
        >
          <Link2 className="w-3.5 h-3.5" />
          <span>+{entities.length - 3} weitere</span>
        </button>
      )}
    </div>
  );
}
