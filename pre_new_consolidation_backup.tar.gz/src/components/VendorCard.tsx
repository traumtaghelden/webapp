import { useState } from 'react';
import { Star, Mail, Phone, DollarSign, MapPin, Calendar, Receipt, ExternalLink, CheckCircle, Clock, AlertCircle } from 'lucide-react';
import { type Vendor } from '../lib/supabase';
import { supabase } from '../lib/supabase';

interface VendorCardProps {
  vendor: Vendor;
  onUpdate: () => void;
  onCompare?: () => void;
  isBooked?: boolean;
  isDragging?: boolean;
  isComparing?: boolean;
}

export default function VendorCard({ vendor, onUpdate, onCompare, isBooked, isDragging, isComparing }: VendorCardProps) {
  const [isTogglingFavorite, setIsTogglingFavorite] = useState(false);

  const toggleFavorite = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isTogglingFavorite) return;

    setIsTogglingFavorite(true);
    try {
      const newRating = (vendor.rating && vendor.rating >= 4) ? 3 : 5;
      const { error } = await supabase
        .from('vendors')
        .update({ rating: newRating })
        .eq('id', vendor.id);

      if (error) throw error;
      onUpdate();
    } catch (error) {
      console.error('Error toggling favorite:', error);
    } finally {
      setIsTogglingFavorite(false);
    }
  };

  const getStatusColor = () => {
    switch (vendor.contract_status) {
      case 'signed':
      case 'completed':
        return 'bg-green-100 text-green-700 border-green-300';
      case 'pending':
        return 'bg-yellow-100 text-yellow-700 border-yellow-300';
      case 'cancelled':
        return 'bg-red-100 text-red-700 border-red-300';
      default:
        return 'bg-gray-100 text-gray-700 border-gray-300';
    }
  };

  const getStatusIcon = () => {
    switch (vendor.contract_status) {
      case 'signed':
      case 'completed':
        return <CheckCircle className="w-3 h-3" />;
      case 'pending':
        return <Clock className="w-3 h-3" />;
      case 'cancelled':
        return <AlertCircle className="w-3 h-3" />;
      default:
        return null;
    }
  };

  const getStatusLabel = () => {
    switch (vendor.contract_status) {
      case 'signed':
        return 'Gebucht';
      case 'completed':
        return 'Abgeschlossen';
      case 'pending':
        return 'In Verhandlung';
      case 'cancelled':
        return 'Storniert';
      default:
        return 'Anfrage';
    }
  };

  return (
    <div
      className={`bg-white rounded-2xl p-4 sm:p-5 shadow-md hover:shadow-xl transition-all duration-300 border-2 ${
        isBooked ? 'border-green-300 bg-green-50/30' : 'border-[#d4af37]/20'
      } ${isDragging ? 'scale-105 rotate-2 shadow-2xl' : ''} ${
        isComparing ? 'ring-4 ring-blue-500 ring-offset-2' : ''
      } relative overflow-hidden group`}
    >
      <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-[#d4af37]/5 to-transparent rounded-full blur-2xl"></div>

      <div className="relative">
        <div className="flex items-start justify-between mb-3">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="text-lg sm:text-xl font-bold text-[#0a253c] truncate">
                {vendor.name}
              </h3>
              <button
                onClick={toggleFavorite}
                disabled={isTogglingFavorite}
                className={`flex-shrink-0 transition-all duration-300 ${
                  vendor.rating && vendor.rating >= 4
                    ? 'text-[#d4af37] scale-110'
                    : 'text-gray-300 hover:text-[#d4af37] hover:scale-110'
                }`}
              >
                <Star
                  className="w-5 h-5"
                  fill={vendor.rating && vendor.rating >= 4 ? 'currentColor' : 'none'}
                />
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2 mb-3">
              <span className="px-3 py-1 bg-[#d4af37]/10 text-[#d4af37] rounded-full text-xs font-semibold">
                {vendor.category}
              </span>
              <span className={`px-3 py-1 rounded-full text-xs font-semibold border-2 flex items-center gap-1 ${getStatusColor()}`}>
                {getStatusIcon()}
                {getStatusLabel()}
              </span>
            </div>
          </div>
        </div>

        {vendor.description && (
          <p className="text-sm text-[#666666] mb-3 line-clamp-2">
            {vendor.description}
          </p>
        )}

        <div className="space-y-2 mb-4">
          {vendor.email && (
            <div className="flex items-center gap-2 text-sm text-[#666666]">
              <Mail className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
              <a
                href={`mailto:${vendor.email}`}
                className="truncate hover:text-[#d4af37] transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                {vendor.email}
              </a>
            </div>
          )}

          {vendor.phone && (
            <div className="flex items-center gap-2 text-sm text-[#666666]">
              <Phone className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
              <a
                href={`tel:${vendor.phone}`}
                className="hover:text-[#d4af37] transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                {vendor.phone}
              </a>
            </div>
          )}

          {vendor.location && (
            <div className="flex items-center gap-2 text-sm text-[#666666]">
              <MapPin className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
              <span className="truncate">{vendor.location}</span>
            </div>
          )}

          {vendor.website && (
            <div className="flex items-center gap-2 text-sm text-[#666666]">
              <ExternalLink className="w-4 h-4 text-[#d4af37] flex-shrink-0" />
              <a
                href={vendor.website}
                target="_blank"
                rel="noopener noreferrer"
                className="truncate hover:text-[#d4af37] transition-colors"
                onClick={(e) => e.stopPropagation()}
              >
                Website
              </a>
            </div>
          )}
        </div>

        <div className="flex items-center justify-between pt-3 border-t border-[#d4af37]/20">
          <div className="flex items-center gap-2">
            {vendor.total_cost && vendor.total_cost > 0 ? (
              <>
                <DollarSign className="w-4 h-4 text-green-600" />
                <span className="text-base sm:text-lg font-bold text-green-600">
                  {Number(vendor.total_cost).toLocaleString('de-DE')} €
                </span>
              </>
            ) : (
              <span className="text-sm text-[#999999]">Preis auf Anfrage</span>
            )}
          </div>

          {onCompare && (
            <button
              onClick={(e) => {
                e.stopPropagation();
                onCompare();
              }}
              className="px-3 py-1.5 bg-blue-500 text-white rounded-lg text-xs font-semibold hover:bg-blue-600 transition-all"
            >
              Vergleichen
            </button>
          )}
        </div>

        {(vendor.contract_sent || vendor.deposit_paid) && (
          <div className="flex flex-wrap items-center gap-2 mt-3 pt-3 border-t border-[#d4af37]/20">
            {vendor.contract_sent && (
              <div className="flex items-center gap-1 text-xs text-blue-600">
                <Receipt className="w-3 h-3" />
                Vertrag versendet
              </div>
            )}
            {vendor.deposit_paid && (
              <div className="flex items-center gap-1 text-xs text-green-600">
                <CheckCircle className="w-3 h-3" />
                Anzahlung erfolgt
              </div>
            )}
          </div>
        )}

        {vendor.next_follow_up && new Date(vendor.next_follow_up) > new Date() && (
          <div className="mt-3 p-2 bg-orange-50 rounded-lg border border-orange-200">
            <div className="flex items-center gap-2 text-xs text-orange-700">
              <Calendar className="w-3 h-3" />
              <span>Follow-up: {new Date(vendor.next_follow_up).toLocaleDateString('de-DE')}</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
