import { AlertTriangle, Link2, Trash2, Unlink } from 'lucide-react';
import { useLinkProtection, type DeleteOptions } from '../hooks/useLinkProtection';
import { useState } from 'react';
import StandardModal, { ModalFooter, ModalButton } from './StandardModal';

interface DeleteWithLinksDialogProps {
  isOpen: boolean;
  entityType: 'task' | 'budget' | 'vendor' | 'timeline';
  entityId: string | null;
  entityName: string;
  onClose: () => void;
  onConfirm: (options: DeleteOptions) => Promise<void>;
}

export default function DeleteWithLinksDialog({
  isOpen,
  entityType,
  entityId,
  entityName,
  onClose,
  onConfirm
}: DeleteWithLinksDialogProps) {
  const { linkedEntities, hasLinks, loading, getDeleteMessage } = useLinkProtection(entityType, entityId);
  const [deleteOption, setDeleteOption] = useState<'unlink' | 'cascade'>('unlink');
  const [isDeleting, setIsDeleting] = useState(false);

  const handleConfirm = async () => {
    setIsDeleting(true);
    try {
      await onConfirm({
        unlinkOnly: deleteOption === 'unlink',
        cascadeDelete: deleteOption === 'cascade'
      });
      onClose();
    } catch (error) {
      console.error('Error deleting:', error);
    } finally {
      setIsDeleting(false);
    }
  };

  const getEntityTypeLabel = () => {
    switch (entityType) {
      case 'task': return 'Aufgabe';
      case 'budget': return 'Budget-Posten';
      case 'vendor': return 'Dienstleister';
      case 'timeline': return 'Timeline-Event';
      default: return 'Element';
    }
  };

  return (
    <StandardModal
      isOpen={isOpen}
      onClose={onClose}
      title={`${getEntityTypeLabel()} löschen`}
      subtitle={entityName}
      icon={AlertTriangle}
      maxWidth="lg"
      footer={
        <ModalFooter>
          <ModalButton
            variant="secondary"
            onClick={onClose}
            disabled={isDeleting}
          >
            Abbrechen
          </ModalButton>
          <ModalButton
            variant={deleteOption === 'cascade' ? 'danger' : 'primary'}
            onClick={handleConfirm}
            disabled={isDeleting || loading}
            icon={deleteOption === 'cascade' ? Trash2 : Unlink}
          >
            {isDeleting ? 'Wird gelöscht...' : deleteOption === 'cascade' ? 'Alles löschen' : 'Nur diesen löschen'}
          </ModalButton>
        </ModalFooter>
      }
    >
      {loading ? (
        <div className="flex items-center justify-center py-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-[#d4af37]"></div>
        </div>
      ) : (
        <div className="space-y-4">
          {hasLinks && (
            <div className="bg-orange-500/20 border-2 border-orange-500/50 rounded-xl p-4 backdrop-blur-sm">
              <div className="flex items-start gap-3">
                <Link2 className="w-5 h-5 text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-semibold text-white mb-2">
                    Verknüpfte Einträge gefunden
                  </p>
                  <p className="text-sm text-white/80 mb-3">
                    {getDeleteMessage()}
                  </p>

                  <div className="space-y-2">
                    {linkedEntities.tasks.length > 0 && (
                      <div className="text-sm">
                        <p className="font-semibold text-white">Aufgaben:</p>
                        <ul className="list-disc list-inside text-white/70 ml-2">
                          {linkedEntities.tasks.slice(0, 3).map(task => (
                            <li key={task.id} className="truncate">{task.title}</li>
                          ))}
                          {linkedEntities.tasks.length > 3 && (
                            <li>und {linkedEntities.tasks.length - 3} weitere...</li>
                          )}
                        </ul>
                      </div>
                    )}

                    {linkedEntities.budgetItems.length > 0 && (
                      <div className="text-sm">
                        <p className="font-semibold text-white">Budget-Posten:</p>
                        <ul className="list-disc list-inside text-white/70 ml-2">
                          {linkedEntities.budgetItems.slice(0, 3).map(item => (
                            <li key={item.id} className="truncate">{item.item_name}</li>
                          ))}
                          {linkedEntities.budgetItems.length > 3 && (
                            <li>und {linkedEntities.budgetItems.length - 3} weitere...</li>
                          )}
                        </ul>
                      </div>
                    )}

                    {linkedEntities.payments.length > 0 && (
                      <div className="text-sm">
                        <p className="font-semibold text-white">
                          {linkedEntities.payments.length} Zahlung{linkedEntities.payments.length > 1 ? 'en' : ''}
                        </p>
                      </div>
                    )}

                    {linkedEntities.timelineEvents.length > 0 && (
                      <div className="text-sm">
                        <p className="font-semibold text-white">Timeline-Events:</p>
                        <ul className="list-disc list-inside text-white/70 ml-2">
                          {linkedEntities.timelineEvents.map(event => (
                            <li key={event.id} className="truncate">{event.title}</li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          <div className="space-y-3">
            <p className="font-semibold text-white/90">
              Wie möchten Sie fortfahren?
            </p>

            <label className={`block p-4 border-2 rounded-xl cursor-pointer transition-all backdrop-blur-sm ${
              deleteOption === 'unlink'
                ? 'border-blue-500 bg-blue-500/20'
                : 'border-white/20 bg-white/5 hover:border-white/30'
            }`}>
              <input
                type="radio"
                name="deleteOption"
                value="unlink"
                checked={deleteOption === 'unlink'}
                onChange={(e) => setDeleteOption(e.target.value as 'unlink' | 'cascade')}
                className="sr-only"
              />
              <div className="flex items-start gap-3">
                <Unlink className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                  deleteOption === 'unlink' ? 'text-blue-400' : 'text-white/40'
                }`} />
                <div>
                  <p className={`font-semibold mb-1 ${
                    deleteOption === 'unlink' ? 'text-white' : 'text-white/70'
                  }`}>
                    Verknüpfungen lösen
                  </p>
                  <p className={`text-sm ${
                    deleteOption === 'unlink' ? 'text-white/80' : 'text-white/60'
                  }`}>
                    Nur diesen {getEntityTypeLabel()} löschen. Verknüpfte Einträge bleiben erhalten.
                  </p>
                </div>
              </div>
            </label>

            {hasLinks && (
              <label className={`block p-4 border-2 rounded-xl cursor-pointer transition-all backdrop-blur-sm ${
                deleteOption === 'cascade'
                  ? 'border-red-500 bg-red-500/20'
                  : 'border-white/20 bg-white/5 hover:border-white/30'
              }`}>
                <input
                  type="radio"
                  name="deleteOption"
                  value="cascade"
                  checked={deleteOption === 'cascade'}
                  onChange={(e) => setDeleteOption(e.target.value as 'unlink' | 'cascade')}
                  className="sr-only"
                />
                <div className="flex items-start gap-3">
                  <Trash2 className={`w-5 h-5 flex-shrink-0 mt-0.5 ${
                    deleteOption === 'cascade' ? 'text-red-400' : 'text-white/40'
                  }`} />
                  <div>
                    <p className={`font-semibold mb-1 ${
                      deleteOption === 'cascade' ? 'text-white' : 'text-white/70'
                    }`}>
                      Alle verknüpften Einträge löschen
                    </p>
                    <p className={`text-sm ${
                      deleteOption === 'cascade' ? 'text-white/80' : 'text-white/60'
                    }`}>
                      <strong>Achtung:</strong> Dieser {getEntityTypeLabel()} und alle verknüpften Einträge werden dauerhaft gelöscht.
                    </p>
                  </div>
                </div>
              </label>
            )}
          </div>

          {deleteOption === 'cascade' && hasLinks && (
            <div className="bg-red-500/20 border-2 border-red-500/50 rounded-lg p-3 backdrop-blur-sm">
              <p className="text-sm font-semibold text-red-300">
                ⚠️ Diese Aktion kann nicht rückgängig gemacht werden!
              </p>
            </div>
          )}
        </div>
      )}
    </StandardModal>
  );
}
