import { useState, useEffect } from 'react';
import { Users, UsersRound, Grid, CheckCircle, Utensils, Gift, Mail, User, UserCheck, UserX, Clock } from 'lucide-react';
import { supabase, type Guest, type FamilyGroup } from '../lib/supabase';
import TabContainer, { type Tab } from './common/TabContainer';
import PageHeaderWithStats, { type StatCard } from './common/PageHeaderWithStats';
import GuestOverviewTab from './Guests/GuestOverviewTab';
import GuestFamiliesTab from './Guests/GuestFamiliesTab';
import GuestSeatingTab from './Guests/GuestSeatingTab';
import GuestRSVPTab from './Guests/GuestRSVPTab';
import GuestDietaryTab from './Guests/GuestDietaryTab';
import GuestGiftsTab from './Guests/GuestGiftsTab';
import GuestContactsTab from './Guests/GuestContactsTab';
import FamilyGuestForm from './FamilyGuestForm';
import { GUEST } from '../constants/terminology';

interface GuestManagerProps {
  weddingId: string;
  guests: Guest[];
  onUpdate: () => void;
}

export default function GuestManager({ weddingId, guests, onUpdate }: GuestManagerProps) {
  const [showAddGuestForm, setShowAddGuestForm] = useState(false);
  const [familyGroups, setFamilyGroups] = useState<FamilyGroup[]>([]);
  const [guestGroups, setGuestGroups] = useState<any[]>([]);

  useEffect(() => {
    loadFamilyGroups();
    loadGuestGroups();
  }, [weddingId]);

  const loadFamilyGroups = async () => {
    const { data } = await supabase
      .from('family_groups')
      .select('*')
      .eq('wedding_id', weddingId);

    if (data) {
      setFamilyGroups(data);
    }
  };

  const loadGuestGroups = async () => {
    const { data } = await supabase
      .from('guest_groups')
      .select('*')
      .eq('wedding_id', weddingId);

    if (data) {
      setGuestGroups(data);
    }
  };

  const totalGuests = guests.length;
  const acceptedGuests = guests.filter(g => g.rsvp_status === 'accepted').length;
  const pendingGuests = guests.filter(g => g.rsvp_status === 'invited' || g.rsvp_status === 'planned').length;
  const declinedGuests = guests.filter(g => g.rsvp_status === 'declined').length;
  const acceptanceRate = totalGuests > 0 ? Math.round((acceptedGuests / totalGuests) * 100) : 0;

  const stats: StatCard[] = [
    {
      icon: <User className="w-6 h-6 text-white" />,
      label: `Gesamt ${GUEST.PLURAL}`,
      value: totalGuests,
      subtitle: `${acceptanceRate}% zugesagt`,
      color: 'yellow'
    },
    {
      icon: <UserCheck className="w-6 h-6 text-white" />,
      label: 'Zugesagt',
      value: acceptedGuests,
      subtitle: totalGuests > 0 ? `${acceptanceRate}% Zusagerate` : '0%',
      color: 'green'
    },
    {
      icon: <Clock className="w-6 h-6 text-white" />,
      label: 'Ausstehend',
      value: pendingGuests,
      subtitle: totalGuests > 0 ? `${Math.round((pendingGuests/totalGuests)*100)}% offen` : '0%',
      color: 'blue'
    },
    {
      icon: <UserX className="w-6 h-6 text-white" />,
      label: 'Abgesagt',
      value: declinedGuests,
      subtitle: declinedGuests > 0 ? 'Haben abgesagt' : 'Keine Absagen',
      color: 'red'
    }
  ];

  const tabs: Tab[] = [
    {
      id: 'overview',
      label: 'Übersicht',
      icon: <Users className="w-4 h-4" />,
      badge: guests.length,
      content: (
        <GuestOverviewTab
          guests={guests}
          onUpdate={onUpdate}
          onAddGuest={() => setShowAddGuestForm(true)}
        />
      ),
    },
    {
      id: 'families',
      label: 'Familien',
      icon: <UsersRound className="w-4 h-4" />,
      content: <GuestFamiliesTab weddingId={weddingId} onUpdate={() => { onUpdate(); loadFamilyGroups(); }} />,
    },
    {
      id: 'seating',
      label: 'Tischplan',
      icon: <Grid className="w-4 h-4" />,
      content: <GuestSeatingTab weddingId={weddingId} />,
    },
    {
      id: 'rsvp',
      label: 'RSVP',
      icon: <CheckCircle className="w-4 h-4" />,
      badge: guests.filter(g => g.rsvp_status === 'accepted').length,
      content: <GuestRSVPTab guests={guests} onUpdate={onUpdate} />,
    },
    {
      id: 'dietary',
      label: 'Ernährung',
      icon: <Utensils className="w-4 h-4" />,
      badge: guests.filter(g => g.dietary_restrictions && g.dietary_restrictions.length > 0).length || undefined,
      content: <GuestDietaryTab guests={guests} />,
    },
    {
      id: 'gifts',
      label: 'Geschenke',
      icon: <Gift className="w-4 h-4" />,
      content: <GuestGiftsTab weddingId={weddingId} />,
    },
    {
      id: 'contacts',
      label: 'Kontakte',
      icon: <Mail className="w-4 h-4" />,
      content: <GuestContactsTab guests={guests} />,
    },
  ];

  return (
    <div className="space-y-6">
      <PageHeaderWithStats
        title={GUEST.MODULE_NAME}
        subtitle="Verwalte deine Gästeliste"
        stats={stats}
      />

      <TabContainer
        tabs={tabs}
        defaultTab="overview"
        storageKey={`guest-tab-${weddingId}`}
        urlParam="guestTab"
      />

      {showAddGuestForm && (
        <FamilyGuestForm
          weddingId={weddingId}
          groups={guestGroups}
          onClose={() => setShowAddGuestForm(false)}
          onSuccess={() => {
            setShowAddGuestForm(false);
            onUpdate();
            loadGuestGroups();
          }}
        />
      )}
    </div>
  );
}
