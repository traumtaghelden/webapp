import { useState, useEffect } from 'react';
import { Plus, Clock, MapPin, Trash2, Edit2, Save, X, GripVertical, Timer, LayoutGrid, Users, DollarSign, Building2, Receipt } from 'lucide-react';
import { supabase, type TimelineEvent } from '../lib/supabase';
import BlockPlanningModal from './BlockPlanningModal';
import EventGuestManagementModal from './EventGuestManagementModal';
import { TIMELINE, COMMON } from '../constants/terminology';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface WeddingTimelineEditorProps {
  weddingId: string;
}

interface SortableEventProps {
  event: TimelineEvent;
  onDelete: (id: string) => void;
  onEdit: (event: TimelineEvent) => void;
  onOpenPlanning: (event: TimelineEvent) => void;
  onManageGuests: (event: TimelineEvent) => void;
  attendingCount: number;
  totalGuestCount: number;
  budgetCost: number;
  vendorCost: number;
  vendorCount: number;
  totalCost: number;
}

function SortableEvent({ event, onDelete, onEdit, onOpenPlanning, onManageGuests, attendingCount, totalGuestCount, budgetCost, vendorCost, vendorCount, totalCost }: SortableEventProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: event.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const formatTime = (timeString: string) => {
    return timeString.substring(0, 5);
  };

  const calculateEndTime = (startTime: string, durationMinutes: number, endTime: string | null) => {
    if (endTime) {
      return formatTime(endTime);
    }

    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + durationMinutes;
    const endHours = Math.floor(totalMinutes / 60) % 24;
    const endMinutes = totalMinutes % 60;
    return `${String(endHours).padStart(2, '0')}:${String(endMinutes).padStart(2, '0')}`;
  };

  const isBuffer = event.event_type === 'buffer';
  const displayTitle = isBuffer && event.buffer_label ? event.buffer_label : event.title;
  const eventColor = event.color || '#d4af37';

  const lightenColor = (hex: string, opacity: number) => {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r}, ${g}, ${b}, ${opacity})`;
  };

  return (
    <div ref={setNodeRef} style={style} className="relative pl-4 sm:pl-32">
      <div className="absolute left-0 top-2 flex items-center gap-2 sm:gap-4">
        <div
          className="text-white px-2 py-1 sm:px-3 sm:py-2 rounded-lg sm:rounded-xl font-bold text-xs sm:text-sm min-w-[70px] sm:min-w-[100px] text-center shadow-lg"
          style={{
            background: `linear-gradient(135deg, ${eventColor} 0%, ${eventColor}dd 100%)`
          }}
        >
          <div className="leading-tight">
            {formatTime(event.time)}
            <div className="text-[10px] sm:text-xs opacity-90">bis</div>
            {calculateEndTime(event.time, event.duration_minutes, event.end_time)}
          </div>
        </div>
        <div
          className="w-3 h-3 sm:w-4 sm:h-4 rounded-full bg-white shadow-lg border-2 sm:border-4"
          style={{ borderColor: eventColor }}
        ></div>
      </div>

      <div
        className={`rounded-xl p-3 sm:p-6 transition-all group relative ${isBuffer ? 'border-2 border-dashed' : ''}`}
        style={{
          backgroundColor: lightenColor(eventColor, 0.08),
          borderColor: isBuffer ? lightenColor(eventColor, 0.3) : 'transparent',
        }}
      >
        <div
          className="absolute left-0 top-0 bottom-0 w-1 rounded-l-xl"
          style={{
            background: `repeating-linear-gradient(
              to bottom,
              ${eventColor} 0px,
              ${eventColor} 8px,
              transparent 8px,
              transparent 16px
            )`
          }}
        ></div>
        <div className="flex flex-col sm:flex-row items-start gap-3 sm:gap-4">
          <div
            {...attributes}
            {...listeners}
            className="cursor-grab active:cursor-grabbing p-2 sm:p-3 -ml-1 sm:-ml-2 rounded-lg transition-colors flex-shrink-0 self-start"
            style={{ backgroundColor: lightenColor(eventColor, 0.15) }}
          >
            <GripVertical className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: eventColor }} />
          </div>

          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 mb-2 flex-wrap">
              {isBuffer && (
                <>
                  <Timer className="w-4 h-4 sm:w-5 sm:h-5 text-gray-500" />
                  <span className="px-2 py-0.5 bg-gray-200 text-gray-700 text-xs font-bold rounded-full uppercase">
                    Puffer
                  </span>
                </>
              )}
              <h3 className="text-lg sm:text-xl font-bold text-[#0a253c] break-words">{displayTitle}</h3>
            </div>
            {event.description && <p className="text-sm sm:text-base text-[#333333] mb-3 break-words">{event.description}</p>}
            <div className="flex flex-wrap gap-2 sm:gap-4 text-xs sm:text-sm">
              <div className="flex items-center gap-1.5 sm:gap-2 text-[#333333]">
                <Clock className="w-3.5 h-3.5 sm:w-4 sm:h-4" style={{ color: eventColor }} />
                <span className="whitespace-nowrap">{event.duration_minutes} Min.</span>
              </div>
              {!isBuffer && (
                <>
                  <div
                    className={`flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm ${
                      attendingCount < totalGuestCount
                        ? 'bg-orange-100 text-orange-700'
                        : 'bg-green-100 text-green-700'
                    }`}
                    title={`${attendingCount} von ${totalGuestCount} Gästen nehmen teil`}
                  >
                    <Users className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                    <span className="whitespace-nowrap">{attendingCount}/{totalGuestCount}</span>
                  </div>
                  {budgetCost > 0 && (
                    <div
                      className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm bg-blue-100 text-blue-700 cursor-pointer hover:bg-blue-200 transition-colors"
                      title={`Budget-Kosten: ${budgetCost.toLocaleString('de-DE')} €`}
                      onClick={(e) => {
                        e.stopPropagation();
                        window.location.hash = `budget-event-${event.id}`;
                      }}
                    >
                      <DollarSign className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                      <span className="whitespace-nowrap">{budgetCost.toLocaleString('de-DE')} €</span>
                    </div>
                  )}
                  {vendorCount > 0 && (
                    <>
                      <div
                        className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm bg-cyan-100 text-cyan-700 cursor-pointer hover:bg-cyan-200 transition-colors"
                        title={`${vendorCount} Dienstleister`}
                        onClick={(e) => {
                          e.stopPropagation();
                          window.location.hash = `vendors-event-${event.id}`;
                        }}
                      >
                        <Building2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                        <span className="whitespace-nowrap">{vendorCount}</span>
                      </div>
                      {vendorCost > 0 && (
                        <div
                          className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm bg-cyan-100 text-cyan-700 cursor-pointer hover:bg-cyan-200 transition-colors"
                          title={`Dienstleister-Kosten: ${vendorCost.toLocaleString('de-DE')} €`}
                          onClick={(e) => {
                            e.stopPropagation();
                            window.location.hash = `vendors-event-${event.id}`;
                          }}
                        >
                          <Building2 className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                          <span className="whitespace-nowrap">{vendorCost.toLocaleString('de-DE')} €</span>
                        </div>
                      )}
                    </>
                  )}
                  {totalCost > 0 && (
                    <div
                      className="flex items-center gap-1.5 sm:gap-2 px-2 sm:px-3 py-1 rounded-full font-semibold text-xs sm:text-sm bg-green-100 text-green-700"
                      title={`Gesamtkosten dieses Events`}
                    >
                      <Receipt className="w-3.5 h-3.5 sm:w-4 sm:h-4" />
                      <span className="whitespace-nowrap">{totalCost.toLocaleString('de-DE')} €</span>
                    </div>
                  )}
                </>
              )}
              {event.location && (
                <div className="flex items-center gap-1.5 sm:gap-2 text-[#333333]">
                  <MapPin className="w-3.5 h-3.5 sm:w-4 sm:h-4" style={{ color: eventColor }} />
                  <span className="break-words">{event.location}</span>
                </div>
              )}
              {event.assigned_to && (
                <span
                  className="px-2 sm:px-3 py-1 rounded-full text-xs sm:text-sm text-[#0a253c] font-semibold break-words"
                  style={{ backgroundColor: lightenColor(eventColor, 0.2) }}
                >
                  {event.assigned_to}
                </span>
              )}
            </div>
          </div>

          <div className="flex flex-wrap sm:flex-nowrap gap-1.5 sm:gap-2 opacity-100 transition-opacity mt-3 sm:mt-0">
            {!isBuffer && (
              <>
                <button
                  onClick={() => onManageGuests(event)}
                  className="p-2 sm:p-3 rounded-lg transition-all active:scale-95 sm:hover:scale-110"
                  style={{ backgroundColor: lightenColor(eventColor, 0.15) }}
                  title="Gäste verwalten"
                >
                  <Users className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: eventColor }} />
                </button>
                <button
                  onClick={() => onOpenPlanning(event)}
                  className="p-2 sm:p-3 rounded-lg transition-all active:scale-95 sm:hover:scale-110"
                  style={{ backgroundColor: lightenColor(eventColor, 0.15) }}
                  title="Detailplanung öffnen"
                >
                  <LayoutGrid className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: eventColor }} />
                </button>
              </>
            )}
            <button
              onClick={() => onEdit(event)}
              className="p-3 rounded-lg transition-all hover:scale-110"
              style={{ backgroundColor: lightenColor(eventColor, 0.15) }}
            >
              <Edit2 className="w-5 h-5 sm:w-6 sm:h-6" style={{ color: eventColor }} />
            </button>
            <button
              onClick={() => onDelete(event.id)}
              className="p-3 rounded-lg transition-all hover:scale-110"
              style={{ backgroundColor: 'rgba(239, 68, 68, 0.1)' }}
            >
              <Trash2 className="w-5 h-5 sm:w-6 sm:h-6 text-red-500" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function WeddingTimelineEditor({ weddingId }: WeddingTimelineEditorProps) {
  const [events, setEvents] = useState<TimelineEvent[]>([]);
  const [showAddForm, setShowAddForm] = useState(false);
  const [showBufferForm, setShowBufferForm] = useState(false);
  const [editingEvent, setEditingEvent] = useState<TimelineEvent | null>(null);
  const [planningEvent, setPlanningEvent] = useState<TimelineEvent | null>(null);
  const [managingGuestsEvent, setManagingGuestsEvent] = useState<TimelineEvent | null>(null);
  const [guestAttendanceCounts, setGuestAttendanceCounts] = useState<Record<string, { attending: number; total: number }>>({});
  const [eventCosts, setEventCosts] = useState<Record<string, { budget: number; vendors: number; total: number; vendorCount: number }>>({});
  const [timeInputMode, setTimeInputMode] = useState<'duration' | 'timerange'>('duration');
  const [hasFormChanges, setHasFormChanges] = useState(false);
  const [newEvent, setNewEvent] = useState({
    time: '',
    endTime: '',
    title: '',
    description: '',
    location: '',
    duration_minutes: 30,
    assigned_to: '',
    color: '#d4af37',
  });
  const [newBuffer, setNewBuffer] = useState({
    label: '',
    duration: 15,
    customDuration: '',
    description: '',
    color: '#9ca3af',
  });

  const canAddTimelineEvent = () => true;

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  useEffect(() => {
    loadEvents();
    loadGuestCounts();
    loadEventCosts();
  }, [weddingId]);

  const loadEvents = async () => {
    try {
      const { data } = await supabase
        .from('wedding_timeline')
        .select('*')
        .eq('wedding_id', weddingId)
        .order('order_index', { ascending: true });
      if (data) setEvents(data);
    } catch (error) {
      console.error('Error loading timeline:', error);
    }
  };

  const loadGuestCounts = async () => {
    try {
      const { data: guestsData } = await supabase
        .from('guests')
        .select('id')
        .eq('wedding_id', weddingId);

      const totalGuestCount = guestsData?.length || 0;

      const { data: eventsData } = await supabase
        .from('wedding_timeline')
        .select('id')
        .eq('wedding_id', weddingId);

      if (!eventsData) return;

      const counts: Record<string, { attending: number; total: number }> = {};

      for (const event of eventsData) {
        const { data: attendanceData } = await supabase
          .from('timeline_event_guest_attendance')
          .select('is_attending')
          .eq('timeline_event_id', event.id);

        const attendingCount = attendanceData?.filter(a => a.is_attending).length || totalGuestCount;
        counts[event.id] = {
          attending: attendingCount,
          total: totalGuestCount
        };
      }

      setGuestAttendanceCounts(counts);
    } catch (error) {
      console.error('Error loading guest counts:', error);
    }
  };

  const loadEventCosts = async () => {
    try {
      const { data: eventsData } = await supabase
        .from('wedding_timeline')
        .select('id')
        .eq('wedding_id', weddingId);

      if (!eventsData) return;

      const costs: Record<string, { budget: number; vendors: number; total: number; vendorCount: number }> = {};

      for (const event of eventsData) {
        const [budgetRes, vendorRes] = await Promise.all([
          supabase
            .from('budget_items')
            .select('actual_cost')
            .eq('timeline_event_id', event.id),
          supabase
            .from('vendor_event_assignments')
            .select('allocated_cost')
            .eq('timeline_event_id', event.id)
        ]);

        const budgetTotal = budgetRes.data?.reduce((sum, item) => sum + (item.actual_cost || 0), 0) || 0;
        const vendorTotal = vendorRes.data?.reduce((sum, item) => sum + (item.allocated_cost || 0), 0) || 0;
        const vendorCount = vendorRes.data?.length || 0;

        costs[event.id] = {
          budget: budgetTotal,
          vendors: vendorTotal,
          total: budgetTotal + vendorTotal,
          vendorCount
        };
      }

      setEventCosts(costs);
    } catch (error) {
      console.error('Error loading event costs:', error);
    }
  };

  const calculateDurationFromTimeRange = (startTime: string, endTime: string): number => {
    const [startHours, startMinutes] = startTime.split(':').map(Number);
    const [endHours, endMinutes] = endTime.split(':').map(Number);

    const startTotalMinutes = startHours * 60 + startMinutes;
    const endTotalMinutes = endHours * 60 + endMinutes;

    let duration = endTotalMinutes - startTotalMinutes;
    if (duration < 0) {
      duration += 24 * 60;
    }

    return duration;
  };

  const recalculateAllTimes = async (updatedEvents: TimelineEvent[]) => {
    const recalculated = [...updatedEvents];

    for (let i = 1; i < recalculated.length; i++) {
      const prevEvent = recalculated[i - 1];
      const prevEndTime = calculateEndTimeString(prevEvent.time, prevEvent.duration_minutes, prevEvent.end_time);
      recalculated[i] = { ...recalculated[i], time: prevEndTime };
    }

    try {
      const updates = recalculated.map((event) => ({
        id: event.id,
        time: event.time,
        order_index: event.order_index,
      }));

      for (const update of updates) {
        await supabase
          .from('wedding_timeline')
          .update({ time: update.time, order_index: update.order_index })
          .eq('id', update.id);
      }

      setEvents(recalculated);
    } catch (error) {
      console.error('Error recalculating times:', error);
    }
  };

  const calculateEndTimeString = (startTime: string, durationMinutes: number, endTime: string | null): string => {
    if (endTime) {
      return endTime;
    }

    const [hours, minutes] = startTime.split(':').map(Number);
    const totalMinutes = hours * 60 + minutes + durationMinutes;
    const endHours = Math.floor(totalMinutes / 60) % 24;
    const endMinutes = totalMinutes % 60;
    return `${String(endHours).padStart(2, '0')}:${String(endMinutes).padStart(2, '0')}:00`;
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = events.findIndex((e) => e.id === active.id);
      const newIndex = events.findIndex((e) => e.id === over.id);

      const reordered = arrayMove(events, oldIndex, newIndex);
      const withUpdatedIndices = reordered.map((e, index) => ({
        ...e,
        order_index: index,
      }));

      setEvents(withUpdatedIndices);
      await recalculateAllTimes(withUpdatedIndices);
    }
  };

  const handleCloseEventForm = () => {
    if (hasFormChanges && editingEvent) {
      if (!confirm('Sie haben ungespeicherte Änderungen. Möchten Sie wirklich schließen ohne zu speichern?')) {
        return;
      }
    }
    handleCancelEdit();
    setHasFormChanges(false);
  };

  const handleAddEvent = async () => {
    if (!newEvent.time || !newEvent.title) return;

    if (!canAddTimelineEvent('regular')) {
      return;
    }

    let finalDuration = newEvent.duration_minutes;
    let finalEndTime = null;

    if (timeInputMode === 'timerange' && newEvent.endTime) {
      finalDuration = calculateDurationFromTimeRange(newEvent.time, newEvent.endTime);
      finalEndTime = newEvent.endTime + ':00';
    }

    try {
      await supabase.from('wedding_timeline').insert([
        {
          wedding_id: weddingId,
          time: newEvent.time + ':00',
          end_time: finalEndTime,
          title: newEvent.title,
          description: newEvent.description || null,
          location: newEvent.location || null,
          duration_minutes: finalDuration,
          assigned_to: newEvent.assigned_to || null,
          order_index: events.length,
          event_type: 'event',
          color: newEvent.color,
        },
      ]);

      setNewEvent({
        time: '',
        endTime: '',
        title: '',
        description: '',
        location: '',
        duration_minutes: 30,
        assigned_to: '',
        color: '#d4af37',
      });
      setShowAddForm(false);
      setHasFormChanges(false);
      await refetchLimits();
      loadEvents();
    } catch (error) {
      console.error('Error adding event:', error);
      const err = error as any;
      if (err?.code === '42501' || err?.message?.includes('limit')) {
        alert('Limit erreicht! Du hast das Maximum an Timeline-Events erreicht. Upgrade auf Premium für unbegrenzte Events.');
      } else {
        alert('Fehler beim Hinzufügen des Events.');
      }
    }
  };

  const handleAddBuffer = async () => {
    if (!newBuffer.label) return;

    if (!canAddTimelineEvent('buffer')) {
      return;
    }

    const duration = newBuffer.duration === 0
      ? parseInt(newBuffer.customDuration) || 15
      : newBuffer.duration;

    const lastEvent = events[events.length - 1];
    const bufferTime = lastEvent
      ? calculateEndTimeString(lastEvent.time, lastEvent.duration_minutes, lastEvent.end_time)
      : '00:00:00';

    try {
      await supabase.from('wedding_timeline').insert([
        {
          wedding_id: weddingId,
          time: bufferTime,
          title: 'Puffer',
          buffer_label: newBuffer.label,
          description: newBuffer.description || null,
          duration_minutes: duration,
          order_index: events.length,
          event_type: 'buffer',
          color: newBuffer.color,
        },
      ]);

      setNewBuffer({
        label: '',
        duration: 15,
        customDuration: '',
        description: '',
        color: '#9ca3af',
      });
      setShowBufferForm(false);
      await refetchLimits();
      loadEvents();
    } catch (error) {
      console.error('Error adding buffer:', error);
      const err = error as any;
      if (err?.code === '42501' || err?.message?.includes('limit')) {
        alert('Limit erreicht! Du hast das Maximum an Buffer-Events erreicht. Upgrade auf Premium für unbegrenzte Events.');
      } else {
        alert('Fehler beim Hinzufügen des Buffer-Events.');
      }
    }
  };

  const handleUpdateEvent = async () => {
    if (!editingEvent || !newEvent.time || !newEvent.title) return;

    let finalDuration = newEvent.duration_minutes;
    let finalEndTime = null;

    if (timeInputMode === 'timerange' && newEvent.endTime) {
      finalDuration = calculateDurationFromTimeRange(newEvent.time, newEvent.endTime);
      finalEndTime = newEvent.endTime + ':00';
    }

    try {
      await supabase
        .from('wedding_timeline')
        .update({
          time: newEvent.time + ':00',
          end_time: finalEndTime,
          title: newEvent.title,
          description: newEvent.description || null,
          location: newEvent.location || null,
          duration_minutes: finalDuration,
          assigned_to: newEvent.assigned_to || null,
          color: newEvent.color,
        })
        .eq('id', editingEvent.id);

      setEditingEvent(null);
      setNewEvent({
        time: '',
        endTime: '',
        title: '',
        description: '',
        location: '',
        duration_minutes: 30,
        assigned_to: '',
        color: '#d4af37',
      });
      setHasFormChanges(false);
      loadEvents();
    } catch (error) {
      console.error('Error updating event:', error);
    }
  };

  const handleEditEvent = (event: TimelineEvent) => {
    setEditingEvent(event);
    setNewEvent({
      time: event.time.substring(0, 5),
      endTime: event.end_time ? event.end_time.substring(0, 5) : '',
      title: event.event_type === 'buffer' ? (event.buffer_label || event.title) : event.title,
      description: event.description || '',
      location: event.location || '',
      duration_minutes: event.duration_minutes,
      assigned_to: event.assigned_to || '',
      color: event.color || '#d4af37',
    });
    setTimeInputMode(event.end_time ? 'timerange' : 'duration');
    setShowAddForm(true);
    setShowBufferForm(false);
  };

  const handleCancelEdit = () => {
    setEditingEvent(null);
    setShowAddForm(false);
    setHasFormChanges(false);
    setNewEvent({
      time: '',
      endTime: '',
      title: '',
      description: '',
      location: '',
      duration_minutes: 30,
      assigned_to: '',
      color: '#d4af37',
    });
  };

  const handleDeleteEvent = async (eventId: string) => {
    if (!confirm('Möchtest du diesen Timeline-Punkt wirklich löschen?')) return;

    try {
      await supabase.from('wedding_timeline').delete().eq('id', eventId);
      await refetchLimits();
      loadEvents();
    } catch (error) {
      console.error('Error deleting event:', error);
    }
  };

  return (
    <div className="space-y-4 sm:space-y-6">
      {/* HINWEIS: KPI-Panel für Timeline-Modul hinzufügen
          - Gesamtanzahl Events
          - Dauer der Hochzeit
          - Anzahl Puffer
          - Nächstes Event
          Design analog zu Gäste/Budget/Tasks/Vendor-KPIs */}

      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0a253c]">Hochzeitstag {TIMELINE.MODULE_NAME}</h2>
          <p className="text-sm sm:text-base text-[#333333] mt-1">Plane den Ablauf eures großen Tages</p>
        </div>
        <div className="flex gap-2 sm:gap-3 w-full sm:w-auto">
          <button
            onClick={() => {
              if (!canAddTimelineEvent('buffer')) {
                } else {
                setShowBufferForm(!showBufferForm);
                setShowAddForm(false);
                setEditingEvent(null);
              }
            }}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl text-sm sm:text-base font-bold transition-all ${
              canAddTimelineEvent('buffer')
                ? 'bg-gray-500 text-white hover:bg-gray-600'
                : 'bg-gray-300 text-gray-600 cursor-pointer hover:bg-gray-400'
            }`}
            title={!canAddTimelineEvent('buffer') ? 'Limit erreicht - Premium für unbegrenzte Puffer' : ''}
          >
            <Timer className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="sm:inline">Puffer</span>
          </button>
          <button
            onClick={() => {
              if (!canAddTimelineEvent('regular')) {
                } else {
                setShowAddForm(!showAddForm);
                setShowBufferForm(false);
                setEditingEvent(null);
              }
            }}
            className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 rounded-xl text-sm sm:text-base font-bold transition-all ${
              canAddTimelineEvent('regular')
                ? 'bg-[#d4af37] text-[#0a253c] hover:bg-[#c19a2e]'
                : 'bg-gray-300 text-gray-600 cursor-pointer hover:bg-gray-400'
            }`}
            title={!canAddTimelineEvent('regular') ? 'Limit erreicht - Premium für unbegrenzte Events' : ''}
          >
            <Plus className="w-4 h-4 sm:w-5 sm:h-5" />
            <span className="sm:inline">Event</span>
          </button>
        </div>
      </div>

      {showBufferForm && (
        <div className="bg-white rounded-2xl p-4 sm:p-8 shadow-lg border-2 border-gray-400">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <h3 className="text-xl sm:text-2xl font-bold text-[#0a253c]">Neuer Puffer-Block</h3>
            <button
              onClick={() => setShowBufferForm(false)}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              title="Schließen"
            >
              <X className="w-6 h-6 text-gray-600" />
            </button>
          </div>
          <div className="grid sm:grid-cols-2 gap-4 sm:gap-6">
            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-[#333333] mb-2">Bezeichnung*</label>
              <input
                type="text"
                value={newBuffer.label}
                onChange={(e) => setNewBuffer({ ...newBuffer, label: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-300 focus:border-gray-500 focus:outline-none"
                placeholder="z.B. Fotopause, Umbauzeit, Puffer"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Dauer*</label>
              <select
                value={newBuffer.duration}
                onChange={(e) => setNewBuffer({ ...newBuffer, duration: parseInt(e.target.value) })}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-300 focus:border-gray-500 focus:outline-none"
              >
                <option value="5">5 Minuten</option>
                <option value="10">10 Minuten</option>
                <option value="15">15 Minuten</option>
                <option value="30">30 Minuten</option>
                <option value="45">45 Minuten</option>
                <option value="60">60 Minuten</option>
                <option value="90">90 Minuten</option>
                <option value="120">120 Minuten</option>
                <option value="0">Benutzerdefiniert</option>
              </select>
            </div>

            {newBuffer.duration === 0 && (
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Benutzerdefinierte Dauer (Min.)</label>
                <input
                  type="number"
                  value={newBuffer.customDuration}
                  onChange={(e) => setNewBuffer({ ...newBuffer, customDuration: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-gray-300 focus:border-gray-500 focus:outline-none"
                  min="1"
                  placeholder="Minuten eingeben"
                />
              </div>
            )}

            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-[#333333] mb-2">Beschreibung</label>
              <textarea
                value={newBuffer.description}
                onChange={(e) => setNewBuffer({ ...newBuffer, description: e.target.value })}
                className="w-full px-4 py-3 rounded-xl border-2 border-gray-300 focus:border-gray-500 focus:outline-none"
                rows={2}
                placeholder="Optionale Details..."
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-[#333333] mb-2">Farbe</label>
              <div className="flex flex-wrap gap-3">
                {['#9ca3af', '#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#0891b2'].map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => setNewBuffer({ ...newBuffer, color })}
                    className={`w-12 h-12 rounded-lg border-4 transition-all hover:scale-110 ${
                      newBuffer.color === color ? 'border-[#0a253c] shadow-lg scale-110' : 'border-gray-200'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
                <div className="relative">
                  <input
                    type="color"
                    value={newBuffer.color}
                    onChange={(e) => setNewBuffer({ ...newBuffer, color: e.target.value })}
                    className="w-12 h-12 rounded-lg cursor-pointer border-2 border-gray-300"
                  />
                  <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-1 text-xs font-bold text-gray-600 shadow">+</div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-4 mt-6">
            <button
              onClick={handleAddBuffer}
              disabled={!newBuffer.label}
              className="flex-1 px-6 py-3 bg-gray-500 text-white rounded-xl font-bold hover:bg-gray-600 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              Puffer erstellen
            </button>
            <button
              onClick={() => setShowBufferForm(false)}
              className="px-6 py-3 border-2 border-gray-400 text-gray-600 rounded-xl font-semibold hover:bg-gray-100 transition-all"
            >
              Abbrechen
            </button>
          </div>
        </div>
      )}

      {showAddForm && (
        <div className="bg-white rounded-2xl p-4 sm:p-8 shadow-lg border-2 border-[#d4af37]">
          <div className="flex items-center justify-between mb-4 sm:mb-6">
            <h3 className="text-xl sm:text-2xl font-bold text-[#0a253c]">
              {editingEvent ? 'Event bearbeiten' : 'Neues Timeline-Event'}
            </h3>
            <button
              onClick={handleCloseEventForm}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
              title="Schließen"
            >
              <X className="w-6 h-6 text-gray-600" />
            </button>
          </div>

          <div className="mb-4 sm:mb-6">
            <label className="block text-sm font-semibold text-[#333333] mb-3">Zeiteingabe-Modus</label>
            <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  checked={timeInputMode === 'duration'}
                  onChange={() => setTimeInputMode('duration')}
                  className="w-4 h-4 text-[#d4af37]"
                />
                <span className="text-[#333333]">Dauer in Minuten</span>
              </label>
              <label className="flex items-center gap-2 cursor-pointer">
                <input
                  type="radio"
                  checked={timeInputMode === 'timerange'}
                  onChange={() => setTimeInputMode('timerange')}
                  className="w-4 h-4 text-[#d4af37]"
                />
                <span className="text-[#333333]">Von-Bis Zeitraum</span>
              </label>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 gap-4 sm:gap-6">
            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">
                {timeInputMode === 'duration' ? 'Startzeit*' : 'Von (Uhrzeit)*'}
              </label>
              <input
                type="time"
                value={newEvent.time}
                onChange={(e) => {
                  setNewEvent({ ...newEvent, time: e.target.value });
                  setHasFormChanges(true);
                }}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
              />
            </div>

            {timeInputMode === 'duration' ? (
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Dauer (Minuten)</label>
                <input
                  type="number"
                  value={newEvent.duration_minutes}
                  onChange={(e) => {
                    setNewEvent({ ...newEvent, duration_minutes: parseInt(e.target.value) || 30 });
                    setHasFormChanges(true);
                  }}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  min="5"
                  step="5"
                />
              </div>
            ) : (
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Bis (Uhrzeit)*</label>
                <input
                  type="time"
                  value={newEvent.endTime}
                  onChange={(e) => {
                    setNewEvent({ ...newEvent, endTime: e.target.value });
                    setHasFormChanges(true);
                  }}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                />
              </div>
            )}

            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-[#333333] mb-2">Titel*</label>
              <input
                type="text"
                value={newEvent.title}
                onChange={(e) => {
                  setNewEvent({ ...newEvent, title: e.target.value });
                  setHasFormChanges(true);
                }}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                placeholder="z.B. Trauung, Empfang, Hochzeitstanz"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-[#333333] mb-2">Beschreibung</label>
              <textarea
                value={newEvent.description}
                onChange={(e) => {
                  setNewEvent({ ...newEvent, description: e.target.value });
                  setHasFormChanges(true);
                }}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                rows={2}
                placeholder="Weitere Details..."
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Ort</label>
              <input
                type="text"
                value={newEvent.location}
                onChange={(e) => {
                  setNewEvent({ ...newEvent, location: e.target.value });
                  setHasFormChanges(true);
                }}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                placeholder="z.B. Kirche, Festsaal"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Verantwortlich</label>
              <input
                type="text"
                value={newEvent.assigned_to}
                onChange={(e) => {
                  setNewEvent({ ...newEvent, assigned_to: e.target.value });
                  setHasFormChanges(true);
                }}
                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                placeholder="Name der verantwortlichen Person"
              />
            </div>

            <div className="sm:col-span-2">
              <label className="block text-sm font-semibold text-[#333333] mb-2">Farbe</label>
              <div className="flex flex-wrap gap-3">
                {['#d4af37', '#ef4444', '#f59e0b', '#10b981', '#3b82f6', '#8b5cf6', '#ec4899', '#0891b2', '#14b8a6'].map((color) => (
                  <button
                    key={color}
                    type="button"
                    onClick={() => {
                      setNewEvent({ ...newEvent, color });
                      setHasFormChanges(true);
                    }}
                    className={`w-12 h-12 rounded-lg border-4 transition-all hover:scale-110 ${
                      newEvent.color === color ? 'border-[#0a253c] shadow-lg scale-110' : 'border-gray-200'
                    }`}
                    style={{ backgroundColor: color }}
                  />
                ))}
                <div className="relative">
                  <input
                    type="color"
                    value={newEvent.color}
                    onChange={(e) => {
                      setNewEvent({ ...newEvent, color: e.target.value });
                      setHasFormChanges(true);
                    }}
                    className="w-12 h-12 rounded-lg cursor-pointer border-2 border-gray-300"
                  />
                  <div className="absolute -bottom-1 -right-1 bg-white rounded-full p-1 text-xs font-bold text-gray-600 shadow">+</div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex gap-4 mt-6">
            <button
              onClick={editingEvent ? handleUpdateEvent : handleAddEvent}
              disabled={!newEvent.time || !newEvent.title || (timeInputMode === 'timerange' && !newEvent.endTime)}
              className="flex-1 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
            >
              {editingEvent ? 'Event aktualisieren' : 'Event erstellen'}
            </button>
            <button
              onClick={handleCancelEdit}
              className="px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-semibold hover:bg-[#d4af37]/10 transition-all"
            >
              Abbrechen
            </button>
          </div>
        </div>
      )}

      <div className="bg-white rounded-2xl p-4 sm:p-8 shadow-lg">
        {events.length === 0 ? (
          <div className="text-center py-12">
            <Clock className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
            <p className="text-[#333333] text-lg">Noch keine Timeline-Events erstellt</p>
          </div>
        ) : (
          <div className="relative">
            <div className="hidden sm:block absolute left-[118px] top-0 bottom-0 w-1 bg-gradient-to-b from-[#d4af37] via-[#f4d03f] to-[#d4af37]/30 rounded-full"></div>

            <DndContext
              sensors={sensors}
              collisionDetection={closestCenter}
              onDragEnd={handleDragEnd}
            >
              <SortableContext
                items={events.map((e) => e.id)}
                strategy={verticalListSortingStrategy}
              >
                <div className="space-y-4 sm:space-y-6">
                  {events.map((event) => {
                    const counts = guestAttendanceCounts[event.id] || { attending: 0, total: 0 };
                    const costs = eventCosts[event.id] || { budget: 0, vendors: 0, total: 0, vendorCount: 0 };
                    return (
                      <SortableEvent
                        key={event.id}
                        event={event}
                        onDelete={handleDeleteEvent}
                        onEdit={handleEditEvent}
                        onOpenPlanning={(e) => setPlanningEvent(e)}
                        onManageGuests={(e) => setManagingGuestsEvent(e)}
                        attendingCount={counts.attending}
                        totalGuestCount={counts.total}
                        budgetCost={costs.budget}
                        vendorCost={costs.vendors}
                        vendorCount={costs.vendorCount}
                        totalCost={costs.total}
                      />
                    );
                  })}
                </div>
              </SortableContext>
            </DndContext>
          </div>
        )}
      </div>

      {planningEvent && (
        <BlockPlanningModal
          event={planningEvent}
          weddingId={weddingId}
          onClose={() => setPlanningEvent(null)}
          onUpdate={() => {
            loadEvents();
            loadEventCosts();
          }}
        />
      )}

      {managingGuestsEvent && (
        <EventGuestManagementModal
          eventId={managingGuestsEvent.id}
          eventTitle={managingGuestsEvent.title}
          weddingId={weddingId}
          onClose={() => setManagingGuestsEvent(null)}
          onUpdate={() => {
            loadGuestCounts();
            setManagingGuestsEvent(null);
          }}
        />
      )}

      </div>
  );
}
