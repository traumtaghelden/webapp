import { useState, useEffect } from 'react';
import { Building2, CheckCircle, Clock, AlertCircle, TrendingUp, DollarSign } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { VENDOR, COMMON } from '../constants/terminology';

interface VendorStats {
  total: number;
  signed: number;
  pending: number;
  overdue_payments: number;
  total_cost: number;
  total_paid: number;
  avg_rating: number;
}

interface VendorStatsWidgetProps {
  weddingId: string;
}

export default function VendorStatsWidget({ weddingId }: VendorStatsWidgetProps) {
  const [stats, setStats] = useState<VendorStats>({
    total: 0,
    signed: 0,
    pending: 0,
    overdue_payments: 0,
    total_cost: 0,
    total_paid: 0,
    avg_rating: 0,
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, [weddingId]);

  const loadStats = async () => {
    try {
      setLoading(true);

      const { data: vendors } = await supabase
        .from('vendors')
        .select('*')
        .eq('wedding_id', weddingId);

      if (!vendors) return;

      const { data: payments } = await supabase
        .from('vendor_payments')
        .select('*')
        .in('vendor_id', vendors.map(v => v.id));

      const today = new Date().toISOString().split('T')[0];
      const overduePayments = payments?.filter(
        p => p.status === 'pending' && p.due_date < today
      ).length || 0;

      const totalCost = vendors.reduce((sum, v) => sum + (v.total_cost || 0), 0);
      const totalPaid = vendors.reduce((sum, v) => sum + (v.paid_amount || 0), 0);

      const ratingsCount = vendors.filter(v => v.rating !== null).length;
      const avgRating = ratingsCount > 0
        ? vendors.reduce((sum, v) => sum + (v.rating || 0), 0) / ratingsCount
        : 0;

      setStats({
        total: vendors.length,
        signed: vendors.filter(v => v.contract_status === 'signed').length,
        pending: vendors.filter(v => v.contract_status === 'pending').length,
        overdue_payments: overduePayments,
        total_cost: totalCost,
        total_paid: totalPaid,
        avg_rating: avgRating,
      });
    } catch (error) {
      console.error('Error loading vendor stats:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="bg-white rounded-2xl p-6 shadow-lg">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-200 rounded w-1/3"></div>
          <div className="h-24 bg-gray-200 rounded"></div>
        </div>
      </div>
    );
  }

  const paymentProgress = stats.total_cost > 0 ? (stats.total_paid / stats.total_cost) * 100 : 0;

  return (
    <div className="bg-gradient-to-br from-white to-[#f7f2eb] rounded-2xl p-6 shadow-lg border-2 border-[#d4af37]/20">
      <div className="flex items-center justify-between mb-6">
        <h3 className="text-xl font-bold text-[#0a253c] flex items-center gap-2">
          <Building2 className="w-6 h-6 text-[#d4af37]" />
          {VENDOR.MODULE_NAME} {COMMON.OVERVIEW}
        </h3>
        <div className="px-3 py-1 bg-[#d4af37] text-[#0a253c] rounded-full text-sm font-bold">
          {stats.total}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 gap-4 mb-6">
        <div className="bg-white rounded-xl p-4 border-2 border-green-200">
          <div className="flex items-center gap-2 mb-2">
            <CheckCircle className="w-5 h-5 text-green-600" />
            <span className="text-sm font-semibold text-gray-700">Verträge</span>
          </div>
          <p className="text-2xl font-bold text-green-600">{stats.signed}</p>
          <p className="text-xs text-gray-600 mt-1">unterschrieben</p>
        </div>

        <div className="bg-white rounded-xl p-4 border-2 border-yellow-200">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-yellow-600" />
            <span className="text-sm font-semibold text-gray-700">In Arbeit</span>
          </div>
          <p className="text-2xl font-bold text-yellow-600">{stats.pending}</p>
          <p className="text-xs text-gray-600 mt-1">in Verhandlung</p>
        </div>
      </div>

      {/* Financial Overview */}
      <div className="bg-white rounded-xl p-4 border-2 border-blue-200 mb-4">
        <div className="flex items-center gap-2 mb-3">
          <DollarSign className="w-5 h-5 text-blue-600" />
          <span className="text-sm font-semibold text-gray-700">Finanzübersicht</span>
        </div>
        <div className="space-y-3">
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Gesamtkosten</span>
            <span className="font-bold text-[#0a253c]">
              {stats.total_cost.toLocaleString('de-DE')} €
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Bereits bezahlt</span>
            <span className="font-bold text-green-600">
              {stats.total_paid.toLocaleString('de-DE')} €
            </span>
          </div>
          <div className="flex items-center justify-between text-sm">
            <span className="text-gray-600">Noch offen</span>
            <span className="font-bold text-orange-600">
              {(stats.total_cost - stats.total_paid).toLocaleString('de-DE')} €
            </span>
          </div>
        </div>
        <div className="mt-4">
          <div className="flex items-center justify-between text-xs text-gray-600 mb-1">
            <span>Fortschritt</span>
            <span>{paymentProgress.toFixed(0)}%</span>
          </div>
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-green-500 to-emerald-500 h-full rounded-full transition-all"
              style={{ width: `${Math.min(paymentProgress, 100)}%` }}
            />
          </div>
        </div>
      </div>

      {/* Alerts */}
      {stats.overdue_payments > 0 && (
        <div className="bg-red-50 border-2 border-red-200 rounded-xl p-4 mb-4">
          <div className="flex items-center gap-2 mb-2">
            <AlertCircle className="w-5 h-5 text-red-600" />
            <span className="font-bold text-red-900">Überfällige Zahlungen</span>
          </div>
          <p className="text-sm text-red-800">
            {stats.overdue_payments} Zahlung{stats.overdue_payments > 1 ? 'en' : ''} überfällig
          </p>
        </div>
      )}

      {/* Average Rating */}
      {stats.avg_rating > 0 && (
        <div className="bg-white rounded-xl p-4 border-2 border-[#d4af37]/30">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-[#d4af37]" />
            <span className="text-sm font-semibold text-gray-700">Durchschnittsbewertung</span>
          </div>
          <div className="flex items-center gap-2">
            <p className="text-3xl font-bold text-[#d4af37]">{stats.avg_rating.toFixed(1)}</p>
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((star) => (
                <span
                  key={star}
                  className={`text-lg ${
                    star <= Math.round(stats.avg_rating) ? 'text-[#d4af37]' : 'text-gray-300'
                  }`}
                >
                  ★
                </span>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Empty State */}
      {stats.total === 0 && (
        <div className="text-center py-8">
          <Building2 className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-600 text-sm">
            Noch keine Dienstleister hinzugefügt
          </p>
        </div>
      )}
    </div>
  );
}
