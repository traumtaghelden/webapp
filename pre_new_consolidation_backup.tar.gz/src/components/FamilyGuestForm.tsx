import { useState } from 'react';
import { X, Plus, Trash2, Users, User, ChevronDown, ChevronRight, Crown, Lock } from 'lucide-react';
import { supabase } from '../lib/supabase';
import DietaryRestrictionsSelector from './DietaryRestrictionsSelector';

interface FamilyMember {
  id: string;
  name: string;
  age_group: 'adult' | 'child' | 'infant';
  dietary_restrictions: string;
  relationship: string;
  email: string;
  phone: string;
}

interface FamilyGuestFormProps {
  weddingId: string;
  groups: any[];
  onClose: () => void;
  onSuccess: () => void;
}

type GuestType = 'single' | 'family' | null;

export default function FamilyGuestForm({ weddingId, groups, onClose, onSuccess }: FamilyGuestFormProps) {
  const [step, setStep] = useState<'type' | 'form'>('type');
  const [guestType, setGuestType] = useState<GuestType>(null);
  const [loading, setLoading] = useState(false);
  const [showAddressSingle, setShowAddressSingle] = useState(false);
  const [showDietarySingle, setShowDietarySingle] = useState(false);
  const [showAddressFamily, setShowAddressFamily] = useState(false);
  const [expandedDietaryMembers, setExpandedDietaryMembers] = useState<Set<string>>(new Set());

  const [familyData, setFamilyData] = useState({
    family_name: '',
    group_id: '',
    address: '',
    city: '',
    postal_code: '',
    country: 'Deutschland',
    table_number: '',
    notes: '',
  });

  const [familyMembers, setFamilyMembers] = useState<FamilyMember[]>([
    {
      id: crypto.randomUUID(),
      name: '',
      age_group: 'adult',
      dietary_restrictions: '',
      relationship: 'Elternteil',
      email: '',
      phone: '',
    },
  ]);

  const [singleGuest, setSingleGuest] = useState({
    name: '',
    email: '',
    phone: '',
    dietary_restrictions: '',
    group_id: '',
    age_group: 'adult',
    relationship: '',
    address: '',
    city: '',
    postal_code: '',
    country: 'Deutschland',
  });

  const handleSelectType = (type: GuestType) => {
    setGuestType(type);
    setStep('form');
  };

  const addFamilyMember = () => {
    setFamilyMembers([
      ...familyMembers,
      {
        id: crypto.randomUUID(),
        name: '',
        age_group: 'adult',
        dietary_restrictions: '',
        relationship: '',
        email: '',
        phone: '',
      },
    ]);
  };

  const removeFamilyMember = (id: string) => {
    if (familyMembers.length > 1) {
      setFamilyMembers(familyMembers.filter((m) => m.id !== id));
    }
  };

  const updateFamilyMember = (id: string, field: string, value: any) => {
    setFamilyMembers(
      familyMembers.map((m) => (m.id === id ? { ...m, [field]: value } : m))
    );
  };

  const toggleDietaryMember = (id: string) => {
    setExpandedDietaryMembers(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const handleSubmitFamily = async () => {
    if (!familyData.family_name.trim()) {
      alert('Bitte geben Sie einen Familiennamen ein');
      return;
    }

    if (familyMembers.length === 0 || !familyMembers[0].name.trim()) {
      alert('Bitte fügen Sie mindestens eine Person hinzu');
      return;
    }

    setLoading(true);

    try {
      const { data: familyGroup, error: familyError } = await supabase
        .from('family_groups')
        .insert({
          wedding_id: weddingId,
          family_name: familyData.family_name,
          notes: familyData.notes || null,
        })
        .select()
        .single();

      if (familyError) throw familyError;

      const guestsToInsert = familyMembers
        .filter((member) => member.name.trim())
        .map((member, index) => ({
          wedding_id: weddingId,
          name: member.name,
          email: member.email || null,
          phone: member.phone || null,
          age_group: member.age_group,
          dietary_restrictions: member.dietary_restrictions || null,
          relationship: member.relationship || null,
          family_group_id: familyGroup.id,
          is_family_head: index === 0,
          family_role: member.relationship || (index === 0 ? 'Hauptperson' : null),
          group_id: familyData.group_id || null,
          address: familyData.address || null,
          city: familyData.city || null,
          postal_code: familyData.postal_code || null,
          country: familyData.country,
          table_number: familyData.table_number ? parseInt(familyData.table_number) : null,
          rsvp_status: 'planned',
          invitation_status: 'not_sent',
          gift_received: false,
          checked_in: false,
        }));

      const { error: guestsError } = await supabase.from('guests').insert(guestsToInsert);

      if (guestsError) throw guestsError;

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error creating family:', error);
      alert('Fehler beim Erstellen der Familie');
    } finally {
      setLoading(false);
    }
  };

  const handleSubmitSingle = async () => {
    if (!singleGuest.name.trim()) {
      alert('Bitte geben Sie einen Namen ein');
      return;
    }

    setLoading(true);

    try {
      const { error } = await supabase.from('guests').insert({
        wedding_id: weddingId,
        name: singleGuest.name,
        email: singleGuest.email || null,
        phone: singleGuest.phone || null,
        dietary_restrictions: singleGuest.dietary_restrictions || null,
        group_id: singleGuest.group_id || null,
        age_group: singleGuest.age_group,
        relationship: singleGuest.relationship || null,
        address: singleGuest.address || null,
        city: singleGuest.city || null,
        postal_code: singleGuest.postal_code || null,
        country: singleGuest.country,
        rsvp_status: 'planned',
        invitation_status: 'not_sent',
        is_family_head: false,
        family_group_id: null,
        family_role: null,
        gift_received: false,
        checked_in: false,
      });

      if (error) throw error;

      onSuccess();
      onClose();
    } catch (error) {
      console.error('Error creating guest:', error);
      alert('Fehler beim Erstellen des Gastes');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-2xl shadow-2xl border-2 border-[#d4af37] max-w-5xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b-2 border-[#d4af37]/20 px-8 py-6 flex items-center justify-between">
          <h3 className="text-2xl font-bold text-[#0a253c]">
            {step === 'type' ? 'Gast hinzufügen' : guestType === 'family' ? 'Familie hinzufügen' : 'Einzelperson hinzufügen'}
          </h3>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#d4af37]/10 rounded-lg transition-all"
          >
            <X className="w-6 h-6 text-[#0a253c]" />
          </button>
        </div>

        <div className="p-8">
          {step === 'type' && (
            <div className="grid md:grid-cols-2 gap-6">
              <button
                onClick={() => handleSelectType('single')}
                className="group relative bg-gradient-to-br from-[#f7f2eb] to-white rounded-2xl p-8 border-2 border-[#d4af37]/30 hover:border-[#d4af37] transition-all hover:shadow-xl"
              >
                <div className="flex flex-col items-center text-center gap-4">
                  <div className="w-20 h-20 rounded-full bg-[#d4af37] flex items-center justify-center group-hover:scale-110 transition-transform">
                    <User className="w-10 h-10 text-white" />
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-[#0a253c] mb-2">Einzelperson</h4>
                    <p className="text-sm text-[#666666]">
                      Eine einzelne Person zur Gästeliste hinzufügen
                    </p>
                  </div>
                </div>
              </button>

              <button
                onClick={() => handleSelectType('family')}
                className="group relative bg-gradient-to-br from-[#f7f2eb] to-white rounded-2xl p-8 border-2 border-[#d4af37]/30 hover:border-[#d4af37] transition-all hover:shadow-xl cursor-pointer"
              >
                
                <div className="flex flex-col items-center text-center gap-4">
                  <div className="w-20 h-20 rounded-full bg-[#d4af37] flex items-center justify-center group-hover:scale-110 transition-transform">
                    
                  </div>
                  <div>
                    <h4 className="text-xl font-bold text-[#0a253c] mb-2">
                      Familie </h4>
                    <p className="text-sm text-[#666666]">
                      Mehrere Personen als Familie hinzufügen (inkl. Kinder)
                    </p>
                  </div>
                </div>
              </button>
            </div>
          )}

          {step === 'form' && guestType === 'single' && (
            <div className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="md:col-span-2">
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                  <input
                    type="text"
                    value={singleGuest.name}
                    onChange={(e) => setSingleGuest({ ...singleGuest, name: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    placeholder="z.B. Maria Schmidt"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">E-Mail</label>
                  <input
                    type="email"
                    value={singleGuest.email}
                    onChange={(e) => setSingleGuest({ ...singleGuest, email: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    placeholder="maria@example.com"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Telefon</label>
                  <input
                    type="tel"
                    value={singleGuest.phone}
                    onChange={(e) => setSingleGuest({ ...singleGuest, phone: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    placeholder="+49 123 456789"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Altersgruppe</label>
                  <select
                    value={singleGuest.age_group}
                    onChange={(e) => setSingleGuest({ ...singleGuest, age_group: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  >
                    <option value="adult">Erwachsener</option>
                    <option value="child">Kind</option>
                    <option value="infant">Kleinkind</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Beziehung</label>
                  <input
                    type="text"
                    value={singleGuest.relationship}
                    onChange={(e) => setSingleGuest({ ...singleGuest, relationship: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    placeholder="z.B. Freund, Arbeitskollege"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Gruppe (optional)</label>
                  <select
                    value={singleGuest.group_id}
                    onChange={(e) => setSingleGuest({ ...singleGuest, group_id: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  >
                    <option value="">Keine Gruppe</option>
                    {(groups || []).map((group) => (
                      <option key={group.id} value={group.id}>
                        {group.name}
                      </option>
                    ))}
                  </select>
                </div>

                <div className="md:col-span-2">
                  <button
                    type="button"
                    onClick={() => setShowDietarySingle(!showDietarySingle)}
                    className="w-full flex items-center justify-between p-4 bg-[#f7f2eb] hover:bg-[#f0e8d5] rounded-xl transition-colors border-2 border-[#d4af37]/20"
                  >
                    <span className="text-sm font-semibold text-[#0a253c]">Diätwünsche / Allergien</span>
                    {showDietarySingle ? (
                      <ChevronDown className="w-5 h-5 text-[#d4af37]" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                    )}
                  </button>
                  {showDietarySingle && (
                    <div className="mt-4 p-4 bg-white rounded-xl border-2 border-[#d4af37]/20">
                      <DietaryRestrictionsSelector
                        value={singleGuest.dietary_restrictions}
                        onChange={(value) => setSingleGuest({ ...singleGuest, dietary_restrictions: value })}
                      />
                    </div>
                  )}
                </div>

                <div className="md:col-span-2">
                  <button
                    type="button"
                    onClick={() => setShowAddressSingle(!showAddressSingle)}
                    className="w-full flex items-center justify-between p-4 bg-[#f7f2eb] hover:bg-[#f0e8d5] rounded-xl transition-colors border-2 border-[#d4af37]/20"
                  >
                    <span className="text-sm font-semibold text-[#0a253c]">Adresse für Einladungen</span>
                    {showAddressSingle ? (
                      <ChevronDown className="w-5 h-5 text-[#d4af37]" />
                    ) : (
                      <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                    )}
                  </button>
                </div>

                {showAddressSingle && (
                  <>
                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Straße & Hausnummer</label>
                      <input
                        type="text"
                        value={singleGuest.address}
                        onChange={(e) => setSingleGuest({ ...singleGuest, address: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                        placeholder="Musterstraße 123"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">PLZ</label>
                      <input
                        type="text"
                        value={singleGuest.postal_code}
                        onChange={(e) => setSingleGuest({ ...singleGuest, postal_code: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                        placeholder="12345"
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Stadt</label>
                      <input
                        type="text"
                        value={singleGuest.city}
                        onChange={(e) => setSingleGuest({ ...singleGuest, city: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                        placeholder="Musterstadt"
                      />
                    </div>

                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-[#333333] mb-2">Land</label>
                      <input
                        type="text"
                        value={singleGuest.country}
                        onChange={(e) => setSingleGuest({ ...singleGuest, country: e.target.value })}
                        className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                        placeholder="Deutschland"
                      />
                    </div>
                  </>
                )}

              </div>

              <div className="flex gap-4 pt-6 border-t border-[#d4af37]/20">
                <button
                  onClick={() => setStep('type')}
                  className="px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-semibold hover:bg-[#d4af37]/10 transition-all"
                >
                  Zurück
                </button>
                <button
                  onClick={handleSubmitSingle}
                  disabled={!singleGuest.name || loading}
                  className="flex-1 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  {loading ? 'Wird gespeichert...' : 'Gast hinzufügen'}
                </button>
              </div>
            </div>
          )}

          {step === 'form' && guestType === 'family' && (
            <div className="space-y-6">
              <div className="bg-[#f7f2eb] rounded-xl p-6 space-y-4">
                <h4 className="text-lg font-bold text-[#0a253c]">Familiendaten</h4>

                <div className="grid md:grid-cols-2 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-[#333333] mb-2">Familienname*</label>
                    <input
                      type="text"
                      value={familyData.family_name}
                      onChange={(e) => setFamilyData({ ...familyData, family_name: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      placeholder="z.B. Familie Schmidt"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#333333] mb-2">Gruppe (optional)</label>
                    <select
                      value={familyData.group_id}
                      onChange={(e) => setFamilyData({ ...familyData, group_id: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    >
                      <option value="">Keine Gruppe</option>
                      {(groups || []).map((group) => (
                        <option key={group.id} value={group.id}>
                          {group.name}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-[#333333] mb-2">Tischnummer</label>
                    <input
                      type="number"
                      value={familyData.table_number}
                      onChange={(e) => setFamilyData({ ...familyData, table_number: e.target.value })}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                      placeholder="z.B. 5"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <label className="block text-sm font-semibold text-[#333333] mb-2">Notizen</label>
                    <textarea
                      value={familyData.notes}
                      onChange={(e) => setFamilyData({ ...familyData, notes: e.target.value })}
                      rows={2}
                      className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none resize-none"
                      placeholder="Optionale Notizen zur Familie"
                    />
                  </div>

                  <div className="md:col-span-2">
                    <button
                      type="button"
                      onClick={() => setShowAddressFamily(!showAddressFamily)}
                      className="w-full flex items-center justify-between p-4 bg-white hover:bg-[#f7f2eb] rounded-xl transition-colors border-2 border-[#d4af37]/30"
                    >
                      <span className="text-sm font-semibold text-[#0a253c]">Adresse für Einladungen</span>
                      {showAddressFamily ? (
                        <ChevronDown className="w-5 h-5 text-[#d4af37]" />
                      ) : (
                        <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                      )}
                    </button>
                  </div>

                  {showAddressFamily && (
                    <>
                      <div className="md:col-span-2">
                        <label className="block text-sm font-semibold text-[#333333] mb-2">Straße & Hausnummer</label>
                        <input
                          type="text"
                          value={familyData.address}
                          onChange={(e) => setFamilyData({ ...familyData, address: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                          placeholder="Musterstraße 123"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-[#333333] mb-2">PLZ</label>
                        <input
                          type="text"
                          value={familyData.postal_code}
                          onChange={(e) => setFamilyData({ ...familyData, postal_code: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                          placeholder="12345"
                        />
                      </div>

                      <div>
                        <label className="block text-sm font-semibold text-[#333333] mb-2">Stadt</label>
                        <input
                          type="text"
                          value={familyData.city}
                          onChange={(e) => setFamilyData({ ...familyData, city: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                          placeholder="Musterstadt"
                        />
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-sm font-semibold text-[#333333] mb-2">Land</label>
                        <input
                          type="text"
                          value={familyData.country}
                          onChange={(e) => setFamilyData({ ...familyData, country: e.target.value })}
                          className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                          placeholder="Deutschland"
                        />
                      </div>
                    </>
                  )}
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h4 className="text-lg font-bold text-[#0a253c]">Familienmitglieder ({familyMembers.length})</h4>
                  <button
                    onClick={addFamilyMember}
                    className="flex items-center gap-2 px-4 py-2 bg-[#d4af37] text-[#0a253c] rounded-xl font-semibold hover:bg-[#c19a2e] transition-all"
                  >
                    <Plus className="w-4 h-4" />
                    Person hinzufügen
                  </button>
                </div>

                <div className="space-y-4">
                  {familyMembers.map((member, index) => (
                    <div key={member.id} className="bg-white rounded-xl p-6 border-2 border-[#d4af37]/30">
                      <div className="flex items-center justify-between mb-4">
                        <span className="text-sm font-bold text-[#0a253c]">
                          {index === 0 ? 'Hauptperson' : `Person ${index + 1}`}
                        </span>
                        {index > 0 && (
                          <button
                            onClick={() => removeFamilyMember(member.id)}
                            className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                          >
                            <Trash2 className="w-4 h-4 text-red-500" />
                          </button>
                        )}
                      </div>

                      <div className="grid md:grid-cols-2 gap-4">
                        <div className="md:col-span-2">
                          <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                          <input
                            type="text"
                            value={member.name}
                            onChange={(e) => updateFamilyMember(member.id, 'name', e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                            placeholder="z.B. Maria Schmidt"
                          />
                        </div>

                        {index === 0 && (
                          <>
                            <div>
                              <label className="block text-sm font-semibold text-[#333333] mb-2">E-Mail</label>
                              <input
                                type="email"
                                value={member.email}
                                onChange={(e) => updateFamilyMember(member.id, 'email', e.target.value)}
                                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                                placeholder="maria@example.com"
                              />
                            </div>

                            <div>
                              <label className="block text-sm font-semibold text-[#333333] mb-2">Telefon</label>
                              <input
                                type="tel"
                                value={member.phone}
                                onChange={(e) => updateFamilyMember(member.id, 'phone', e.target.value)}
                                className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                                placeholder="+49 123 456789"
                              />
                            </div>
                          </>
                        )}

                        <div>
                          <label className="block text-sm font-semibold text-[#333333] mb-2">Altersgruppe</label>
                          <select
                            value={member.age_group}
                            onChange={(e) => updateFamilyMember(member.id, 'age_group', e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                          >
                            <option value="adult">Erwachsener</option>
                            <option value="child">Kind</option>
                            <option value="infant">Kleinkind</option>
                          </select>
                        </div>

                        <div>
                          <label className="block text-sm font-semibold text-[#333333] mb-2">Rolle in Familie</label>
                          <input
                            type="text"
                            value={member.relationship}
                            onChange={(e) => updateFamilyMember(member.id, 'relationship', e.target.value)}
                            className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                            placeholder="z.B. Elternteil, Kind"
                          />
                        </div>

                        <div className="md:col-span-2">
                          <button
                            type="button"
                            onClick={() => toggleDietaryMember(member.id)}
                            className="w-full flex items-center justify-between p-3 bg-[#f7f2eb] hover:bg-[#f0e8d5] rounded-xl transition-colors border-2 border-[#d4af37]/20"
                          >
                            <span className="text-sm font-semibold text-[#0a253c]">Diätwünsche / Allergien</span>
                            {expandedDietaryMembers.has(member.id) ? (
                              <ChevronDown className="w-4 h-4 text-[#d4af37]" />
                            ) : (
                              <ChevronRight className="w-4 h-4 text-[#d4af37]" />
                            )}
                          </button>
                          {expandedDietaryMembers.has(member.id) && (
                            <div className="mt-3 p-4 bg-white rounded-xl border-2 border-[#d4af37]/20">
                              <DietaryRestrictionsSelector
                                value={member.dietary_restrictions}
                                onChange={(value) => updateFamilyMember(member.id, 'dietary_restrictions', value)}
                              />
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex gap-4 pt-6 border-t border-[#d4af37]/20">
                <button
                  onClick={() => setStep('type')}
                  className="px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-semibold hover:bg-[#d4af37]/10 transition-all"
                >
                  Zurück
                </button>
                <button
                  onClick={handleSubmitFamily}
                  disabled={!familyData.family_name || !familyMembers[0]?.name || loading}
                  className="flex-1 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  {loading ? 'Wird gespeichert...' : 'Familie hinzufügen'}
                </button>
              </div>
            </div>
          )}
        </div>
      </div>

      </div>
  );
}
