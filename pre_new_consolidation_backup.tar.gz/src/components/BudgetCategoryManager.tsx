import { useState, useEffect } from 'react';
import { X, Plus, Edit2, Trash2, Save, DollarSign, Folder, TrendingUp, PieChart, Crown, Lock } from 'lucide-react';
import { supabase, type BudgetCategory, type BudgetItem } from '../lib/supabase';
import { DndContext, closestCenter, PointerSensor, useSensor, useSensors, DragEndEvent } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, useSortable, arrayMove } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { BUDGET, COMMON } from '../constants/terminology';

interface BudgetCategoryManagerProps {
  weddingId: string;
  totalBudget: number;
  onClose: () => void;
  onUpdate: () => void;
}

const getCategoryTranslation = (category: string): string => {
  const translations: Record<string, string> = {
    venue: 'Location',
    catering: 'Catering',
    decoration: 'Dekoration',
    music: 'Musik',
    photography: 'Fotografie',
    flowers: 'Blumen',
    dress: 'Kleid',
    rings: 'Ringe',
    invitations: 'Einladungen',
    other: 'Sonstiges',
  };
  return translations[category.toLowerCase()] || category;
};

const availableIcons = [
  { name: 'DollarSign', label: 'Geld' },
  { name: 'Folder', label: 'Ordner' },
  { name: 'TrendingUp', label: 'Trend' },
  { name: 'PieChart', label: 'Diagramm' },
];

const colorOptions = [
  '#d4af37', '#3b82f6', '#10b981', '#f59e0b', '#8b5cf6',
  '#ec4899', '#14b8a6', '#f97316', '#ef4444', '#06b6d4',
];

interface SortableCategoryProps {
  category: BudgetCategory;
  budgetItems: BudgetItem[];
  totalBudget: number;
  onEdit: (category: BudgetCategory) => void;
  onDelete: (categoryId: string) => void;
}

function SortableCategory({ category, budgetItems, totalBudget, onEdit, onDelete }: SortableCategoryProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
  } = useSortable({ id: category.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
  };

  const categoryItems = budgetItems.filter(item => item.category === category.name.toLowerCase());
  const totalSpent = categoryItems.reduce((sum, item) => sum + (item.actual_cost || 0), 0);
  const percentage = category.budget_limit > 0 ? (totalSpent / category.budget_limit) * 100 : 0;
  const overBudget = totalSpent > category.budget_limit && category.budget_limit > 0;

  return (
    <div
      ref={setNodeRef}
      style={style}
      {...attributes}
      className="p-6 rounded-2xl bg-white border-2 border-[#d4af37]/30 hover:border-[#d4af37] transition-all group"
    >
      <div className="flex items-start justify-between mb-4">
        <div className="flex items-center gap-3 flex-1">
          <div
            {...listeners}
            className="cursor-grab active:cursor-grabbing p-2 rounded-lg hover:bg-[#f7f2eb] transition-colors"
          >
            <div className="w-2 h-2 bg-[#333333] rounded-full mb-1"></div>
            <div className="w-2 h-2 bg-[#333333] rounded-full mb-1"></div>
            <div className="w-2 h-2 bg-[#333333] rounded-full"></div>
          </div>
          <div
            className="w-12 h-12 rounded-xl flex items-center justify-center shadow-md"
            style={{ backgroundColor: `${category.color}20`, border: `2px solid ${category.color}` }}
          >
            <DollarSign className="w-6 h-6" style={{ color: category.color }} />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-[#0a253c]">{category.name}</h3>
            <p className="text-sm text-[#666666]">{categoryItems.length} Posten</p>
          </div>
        </div>
        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
          <button
            onClick={() => onEdit(category)}
            className="p-2 hover:bg-[#d4af37]/10 rounded-lg transition-colors"
          >
            <Edit2 className="w-4 h-4 text-[#d4af37]" />
          </button>
          {!category.is_default && (
            <button
              onClick={() => onDelete(category.id)}
              className="p-2 hover:bg-red-50 rounded-lg transition-colors"
            >
              <Trash2 className="w-4 h-4 text-red-500" />
            </button>
          )}
        </div>
      </div>

      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-sm text-[#666666]">Budget-Limit</span>
          <span className="text-lg font-bold text-[#0a253c]">
            {category.budget_limit.toLocaleString('de-DE')} €
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-[#666666]">Tatsächliche Kosten</span>
          <span className={`text-lg font-bold ${overBudget ? 'text-red-600' : 'text-green-600'}`}>
            {totalSpent.toLocaleString('de-DE')} €
          </span>
        </div>

        <div className="flex items-center justify-between">
          <span className="text-sm text-[#666666]">Verbleibend</span>
          <span className={`text-lg font-bold ${overBudget ? 'text-red-600' : 'text-green-600'}`}>
            {(category.budget_limit - totalSpent).toLocaleString('de-DE')} €
          </span>
        </div>

        <div className="mt-4">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-[#666666]">Ausschöpfung</span>
            <span className={`text-xs font-bold ${overBudget ? 'text-red-600' : 'text-[#d4af37]'}`}>
              {Math.round(percentage)}%
            </span>
          </div>
          <div className="w-full bg-[#f7f2eb] rounded-full h-3 overflow-hidden">
            <div
              className={`h-full rounded-full transition-all duration-500 ${
                overBudget ? 'bg-red-500' : 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f]'
              }`}
              style={{ width: `${Math.min(percentage, 100)}%` }}
            />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function BudgetCategoryManager({ weddingId, totalBudget, onClose, onUpdate }: BudgetCategoryManagerProps) {
  const [categories, setCategories] = useState<BudgetCategory[]>([]);
  const [budgetItems, setBudgetItems] = useState<BudgetItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingCategory, setEditingCategory] = useState<BudgetCategory | null>(null);

  const [formData, setFormData] = useState({
    name: '',
    icon: 'DollarSign',
    color: '#d4af37',
    budget_limit: 0,
  });

  const sensors = useSensors(useSensor(PointerSensor));

  const defaultCategorySuggestions = [
    { name: 'Location', color: '#3b82f6', budget_limit: totalBudget * 0.25 },
    { name: 'Catering', color: '#f97316', budget_limit: totalBudget * 0.30 },
    { name: 'Dekoration', color: '#ec4899', budget_limit: totalBudget * 0.15 },
    { name: 'Fotografie', color: '#8b5cf6', budget_limit: totalBudget * 0.15 },
    { name: 'Musik', color: '#10b981', budget_limit: totalBudget * 0.10 },
  ];

  const handleAddAllSuggestions = async () => {
    try {
      const maxOrder = categories.length > 0 ? Math.max(...categories.map(c => c.order_index)) : -1;
      const newCategories = defaultCategorySuggestions.map((suggestion, index) => ({
        wedding_id: weddingId,
        name: suggestion.name,
        icon: 'DollarSign',
        color: suggestion.color,
        budget_limit: suggestion.budget_limit,
        order_index: maxOrder + index + 1,
        is_default: false,
      }));

      await supabase.from('budget_categories').insert(newCategories);
      loadData();
      onUpdate();
    } catch (error) {
      console.error('Error adding all categories:', error);
    }
  };

  const handleAddSingleSuggestion = async (suggestion: typeof defaultCategorySuggestions[0]) => {
    try {
      const maxOrder = categories.length > 0 ? Math.max(...categories.map(c => c.order_index)) : -1;
      await supabase.from('budget_categories').insert([{
        wedding_id: weddingId,
        name: suggestion.name,
        icon: 'DollarSign',
        color: suggestion.color,
        budget_limit: suggestion.budget_limit,
        order_index: maxOrder + 1,
        is_default: false,
      }]);
      loadData();
      onUpdate();
    } catch (error) {
      console.error('Error adding category:', error);
    }
  };

  useEffect(() => {
    loadData();
  }, [weddingId]);

  const loadData = async () => {
    try {
      const [categoriesData, itemsData] = await Promise.all([
        supabase.from('budget_categories').select('*').eq('wedding_id', weddingId).order('order_index'),
        supabase.from('budget_items').select('*').eq('wedding_id', weddingId),
      ]);

      if (categoriesData.data) setCategories(categoriesData.data);
      if (itemsData.data) setBudgetItems(itemsData.data);
    } catch (error) {
      console.error('Error loading categories:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveCategory = async () => {
    if (!formData.name.trim()) return;

    try {
      if (editingCategory) {
        await supabase
          .from('budget_categories')
          .update(formData)
          .eq('id', editingCategory.id);
      } else {
        const maxOrder = categories.length > 0 ? Math.max(...categories.map(c => c.order_index)) : -1;
        await supabase.from('budget_categories').insert([{
          wedding_id: weddingId,
          ...formData,
          order_index: maxOrder + 1,
          is_default: false,
        }]);
      }

      setFormData({ name: '', icon: 'DollarSign', color: '#d4af37', budget_limit: 0 });
      setShowAddForm(false);
      setEditingCategory(null);
      loadData();
      onUpdate();
    } catch (error) {
      console.error('Error saving category:', error);
    }
  };

  const handleEditCategory = (category: BudgetCategory) => {
    setEditingCategory(category);
    setFormData({
      name: category.name,
      icon: category.icon,
      color: category.color,
      budget_limit: category.budget_limit,
    });
    setShowAddForm(true);
  };

  const handleDeleteCategory = async (categoryId: string) => {
    if (!confirm('Kategorie wirklich löschen? Zugeordnete Budget-Posten bleiben erhalten.')) return;

    try {
      await supabase.from('budget_categories').delete().eq('id', categoryId);
      loadData();
      onUpdate();
    } catch (error) {
      console.error('Error deleting category:', error);
    }
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (!over || active.id === over.id) return;

    const oldIndex = categories.findIndex(c => c.id === active.id);
    const newIndex = categories.findIndex(c => c.id === over.id);

    const reorderedCategories = arrayMove(categories, oldIndex, newIndex);
    setCategories(reorderedCategories);

    try {
      await Promise.all(
        reorderedCategories.map((cat, index) =>
          supabase.from('budget_categories').update({ order_index: index }).eq('id', cat.id)
        )
      );
    } catch (error) {
      console.error('Error reordering categories:', error);
      loadData();
    }
  };

  const totalAllocated = categories.reduce((sum, cat) => sum + cat.budget_limit, 0);
  const totalSpent = budgetItems.reduce((sum, item) => sum + (item.actual_cost || 0), 0);
  const unallocated = totalBudget - totalAllocated;

  if (loading) {
    return (
      <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999]">
        <div className="bg-white rounded-3xl p-8">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#d4af37] mx-auto"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
      <div className="bg-white rounded-3xl shadow-2xl max-w-6xl w-full max-h-[90vh] flex flex-col">
        <div className="p-6 border-b border-[#d4af37]/20">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="bg-gradient-to-r from-[#d4af37] to-[#f4d03f] w-12 h-12 rounded-xl flex items-center justify-center shadow-lg">
                <Folder className="w-6 h-6 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold text-[#0a253c]">Budget-Kategorien verwalten</h2>
                <p className="text-sm text-[#666666]">Organisiere dein Budget nach Kategorien</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-2 hover:bg-[#f7f2eb] rounded-full transition-colors"
            >
              <X className="w-6 h-6 text-[#333333]" />
            </button>
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div className="bg-gradient-to-br from-[#d4af37]/10 to-[#f4d03f]/10 rounded-xl p-4 border-2 border-[#d4af37]/30">
              <p className="text-sm text-[#666666] mb-1">Gesamtbudget</p>
              <p className="text-2xl font-bold text-[#0a253c]">{totalBudget.toLocaleString('de-DE')} €</p>
            </div>

            <div className="bg-gradient-to-br from-blue-50 to-blue-100 rounded-xl p-4 border-2 border-blue-300">
              <p className="text-sm text-[#666666] mb-1">Zugeteilt</p>
              <p className="text-2xl font-bold text-blue-600">{totalAllocated.toLocaleString('de-DE')} €</p>
              <p className="text-xs text-blue-600 mt-1">{Math.round((totalAllocated / totalBudget) * 100)}% des Budgets</p>
            </div>

            <div className={`bg-gradient-to-br rounded-xl p-4 border-2 ${
              unallocated < 0 ? 'from-red-50 to-red-100 border-red-300' : 'from-green-50 to-green-100 border-green-300'
            }`}>
              <p className="text-sm text-[#666666] mb-1">Nicht zugeteilt</p>
              <p className={`text-2xl font-bold ${unallocated < 0 ? 'text-red-600' : 'text-green-600'}`}>
                {unallocated.toLocaleString('de-DE')} €
              </p>
            </div>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-6 relative">

          {showAddForm && (
            <div className="mb-6 p-6 rounded-2xl bg-[#f7f2eb] border-2 border-[#d4af37]">
              <h3 className="text-xl font-bold text-[#0a253c] mb-4">
                {editingCategory ? 'Kategorie bearbeiten' : 'Neue Kategorie erstellen'}
              </h3>
              <div className="grid md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Name*</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    placeholder="z.B. Dekoration"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Budget-Limit (€)</label>
                  <input
                    type="number"
                    value={formData.budget_limit}
                    onChange={(e) => setFormData({ ...formData, budget_limit: parseFloat(e.target.value) })}
                    className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                    placeholder="0.00"
                    step="0.01"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-[#333333] mb-2">Farbe</label>
                  <div className="flex gap-2 flex-wrap">
                    {colorOptions.map(color => (
                      <button
                        key={color}
                        onClick={() => setFormData({ ...formData, color })}
                        className={`w-10 h-10 rounded-full transition-all ${
                          formData.color === color ? 'ring-4 ring-offset-2 ring-[#d4af37]' : 'hover:scale-110'
                        }`}
                        style={{ backgroundColor: color }}
                      />
                    ))}
                  </div>
                </div>
              </div>

              <div className="flex gap-3 mt-6">
                <button
                  onClick={handleSaveCategory}
                  disabled={!formData.name.trim()}
                  className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                  <Save className="w-4 h-4" />
                  {editingCategory ? 'Speichern' : 'Erstellen'}
                </button>
                <button
                  onClick={() => {
                    setShowAddForm(false);
                    setEditingCategory(null);
                    setFormData({ name: '', icon: 'DollarSign', color: '#d4af37', budget_limit: 0 });
                  }}
                  className="px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-bold hover:bg-[#d4af37]/10 transition-all"
                >
                  Abbrechen
                </button>
              </div>
            </div>
          )}

          {!showAddForm && categories.length === 0 && (
            <div className="mb-6 p-6 rounded-2xl bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200">
              <h3 className="text-xl font-bold text-[#0a253c] mb-3">Empfohlene Standard-Kategorien</h3>
              <p className="text-sm text-[#666666] mb-4">
                Füge die gängigsten Hochzeitskategorien mit einem Klick hinzu
              </p>
              <div className="grid md:grid-cols-2 gap-3 mb-4">
                {defaultCategorySuggestions.map((suggestion) => (
                  <button
                    key={suggestion.name}
                    onClick={() => handleAddSingleSuggestion(suggestion)}
                    className="p-4 rounded-xl bg-white border-2 border-blue-200 hover:border-blue-400 transition-all text-left group"
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className="w-12 h-12 rounded-xl flex items-center justify-center shadow-md"
                        style={{ backgroundColor: `${suggestion.color}20`, border: `2px solid ${suggestion.color}` }}
                      >
                        <DollarSign className="w-6 h-6" style={{ color: suggestion.color }} />
                      </div>
                      <div className="flex-1">
                        <p className="font-bold text-[#0a253c] group-hover:text-blue-600 transition-colors">{suggestion.name}</p>
                        <p className="text-sm text-[#666666]">{suggestion.budget_limit.toLocaleString('de-DE')} €</p>
                      </div>
                      <Plus className="w-5 h-5 text-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  </button>
                ))}
              </div>
              <button
                onClick={handleAddAllSuggestions}
                className="w-full flex items-center justify-center gap-2 px-6 py-3 bg-gradient-to-r from-blue-500 to-indigo-500 text-white rounded-xl font-bold hover:shadow-lg transition-all"
              >
                <Plus className="w-5 h-5" />
                Alle hinzufügen
              </button>
            </div>
          )}

          {!showAddForm && (
            <button
              onClick={() => setShowAddForm(true)}
              className="w-full mb-6 flex items-center justify-center gap-2 px-6 py-4 bg-gradient-to-r from-[#d4af37] to-[#f4d03f] text-[#0a253c] rounded-xl font-bold hover:shadow-lg transition-all"
            >
              <Plus className="w-5 h-5" />
              Neue Kategorie erstellen
            </button>
          )}

          <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
            <SortableContext items={categories.map(c => c.id)} strategy={verticalListSortingStrategy}>
              <div className="grid md:grid-cols-2 gap-4">
                {categories.map(category => (
                  <SortableCategory
                    key={category.id}
                    category={category}
                    budgetItems={budgetItems}
                    totalBudget={totalBudget}
                    onEdit={handleEditCategory}
                    onDelete={handleDeleteCategory}
                  />
                ))}
              </div>
            </SortableContext>
          </DndContext>

          {categories.length === 0 && (
            <div className="text-center py-16">
              <Folder className="w-20 h-20 text-[#d4af37] mx-auto mb-4 opacity-50" />
              <p className="text-[#333333] text-lg mb-2">Noch keine Kategorien erstellt</p>
              <p className="text-sm text-[#666666]">Erstelle Kategorien, um dein Budget besser zu organisieren</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
