import { useState } from 'react';
import { X, Plus, GripVertical, Save, Trash2, Package, FileText, Sparkles } from 'lucide-react';
import { supabase } from '../lib/supabase';
import { COMMON } from '../constants/terminology';
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from '@dnd-kit/core';
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

interface Category {
  id: string;
  category_name: string;
  icon?: string;
  is_default: boolean;
  order_index: number;
}

interface CategoryManagerProps {
  categories: Category[];
  onCategoriesChange: () => void;
  type: 'checklist' | 'items';
  weddingId: string;
}

const ICON_OPTIONS = [
  { name: 'Package', icon: Package },
  { name: 'FileText', icon: FileText },
  { name: 'Sparkles', icon: Sparkles },
];

function SortableCategoryItem({
  category,
  onEdit,
  onDelete,
}: {
  category: Category;
  onEdit: (category: Category) => void;
  onDelete: (id: string) => void;
}) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: category.id,
  });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  const IconComponent = ICON_OPTIONS.find((opt) => opt.name === category.icon)?.icon || Package;

  return (
    <div
      ref={setNodeRef}
      style={style}
      className="flex items-center gap-3 p-3 bg-white rounded-lg border border-gray-200 hover:border-gray-300"
    >
      <div {...attributes} {...listeners} className="cursor-grab active:cursor-grabbing">
        <GripVertical className="w-5 h-5 text-gray-400" />
      </div>

      {category.icon && <IconComponent className="w-5 h-5 text-gray-600" />}

      <span className="flex-1 font-medium text-gray-900">{category.category_name}</span>

      {category.is_default && (
        <span className="px-2 py-1 text-xs bg-blue-100 text-blue-700 rounded">Standard</span>
      )}

      <button
        onClick={() => onEdit(category)}
        className="p-1.5 text-gray-600 hover:bg-gray-100 rounded"
      >
        <Save className="w-4 h-4" />
      </button>

      {!category.is_default && (
        <button
          onClick={() => onDelete(category.id)}
          className="p-1.5 text-red-600 hover:bg-red-50 rounded"
        >
          <Trash2 className="w-4 h-4" />
        </button>
      )}
    </div>
  );
}

export default function CategoryManager({
  categories,
  onCategoriesChange,
  type,
  weddingId,
}: CategoryManagerProps) {
  const [showAddModal, setShowAddModal] = useState(false);
  const [editingCategory, setEditingCategory] = useState<Category | null>(null);
  const [newCategoryName, setNewCategoryName] = useState('');
  const [selectedIcon, setSelectedIcon] = useState('Package');
  const [sortedCategories, setSortedCategories] = useState(categories);

  const sensors = useSensors(
    useSensor(PointerSensor),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  const tableName =
    type === 'checklist'
      ? 'timeline_block_checklist_categories'
      : 'timeline_block_item_categories';

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      const oldIndex = sortedCategories.findIndex((cat) => cat.id === active.id);
      const newIndex = sortedCategories.findIndex((cat) => cat.id === over.id);

      const newOrder = arrayMove(sortedCategories, oldIndex, newIndex);
      setSortedCategories(newOrder);

      for (let i = 0; i < newOrder.length; i++) {
        await supabase
          .from(tableName)
          .update({ order_index: i })
          .eq('id', newOrder[i].id);
      }

      onCategoriesChange();
    }
  };

  const handleAddCategory = async () => {
    if (!newCategoryName.trim()) return;

    const newCategory = {
      wedding_id: weddingId,
      category_name: newCategoryName.trim(),
      is_default: false,
      order_index: categories.length,
      ...(type === 'items' && { icon: selectedIcon }),
    };

    const { error } = await supabase.from(tableName).insert(newCategory);

    if (!error) {
      setShowAddModal(false);
      setNewCategoryName('');
      setSelectedIcon('Package');
      onCategoriesChange();
    }
  };

  const handleEditCategory = async (category: Category) => {
    setEditingCategory(category);
    setNewCategoryName(category.category_name);
    setSelectedIcon(category.icon || 'Package');
    setShowAddModal(true);
  };

  const handleUpdateCategory = async () => {
    if (!editingCategory || !newCategoryName.trim()) return;

    const updates: any = {
      category_name: newCategoryName.trim(),
    };

    if (type === 'items') {
      updates.icon = selectedIcon;
    }

    const { error } = await supabase
      .from(tableName)
      .update(updates)
      .eq('id', editingCategory.id);

    if (!error) {
      setShowAddModal(false);
      setEditingCategory(null);
      setNewCategoryName('');
      setSelectedIcon('Package');
      onCategoriesChange();
    }
  };

  const handleDeleteCategory = async (id: string) => {
    if (!confirm('Diese Kategorie wirklich löschen? Items werden "Sonstiges" zugeordnet.')) return;

    const { error } = await supabase.from(tableName).delete().eq('id', id);

    if (!error) {
      onCategoriesChange();
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-gray-900">Kategorien verwalten</h3>
        <button
          onClick={() => {
            setEditingCategory(null);
            setNewCategoryName('');
            setShowAddModal(true);
          }}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
        >
          <Plus className="w-4 h-4" />
          Kategorie hinzufügen
        </button>
      </div>

      <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
        <SortableContext items={sortedCategories.map((c) => c.id)} strategy={verticalListSortingStrategy}>
          <div className="space-y-2">
            {sortedCategories.map((category) => (
              <SortableCategoryItem
                key={category.id}
                category={category}
                onEdit={handleEditCategory}
                onDelete={handleDeleteCategory}
              />
            ))}
          </div>
        </SortableContext>
      </DndContext>

      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg font-semibold text-gray-900">
                {editingCategory ? 'Kategorie bearbeiten' : 'Neue Kategorie'}
              </h3>
              <button
                onClick={() => {
                  setShowAddModal(false);
                  setEditingCategory(null);
                  setNewCategoryName('');
                }}
                className="text-gray-400 hover:text-gray-600"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Kategorie-Name
                </label>
                <input
                  type="text"
                  value={newCategoryName}
                  onChange={(e) => setNewCategoryName(e.target.value)}
                  placeholder="z.B. Dokumente, Dekoration..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  autoFocus
                />
              </div>

              {type === 'items' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Icon auswählen
                  </label>
                  <div className="flex gap-2">
                    {ICON_OPTIONS.map((option) => {
                      const Icon = option.icon;
                      return (
                        <button
                          key={option.name}
                          onClick={() => setSelectedIcon(option.name)}
                          className={`flex items-center justify-center w-12 h-12 border-2 rounded-lg ${
                            selectedIcon === option.name
                              ? 'border-blue-500 bg-blue-50'
                              : 'border-gray-300 hover:border-gray-400'
                          }`}
                        >
                          <Icon className="w-6 h-6 text-gray-700" />
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="flex gap-3 pt-4">
                <button
                  onClick={() => {
                    setShowAddModal(false);
                    setEditingCategory(null);
                    setNewCategoryName('');
                  }}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50"
                >
                  Abbrechen
                </button>
                <button
                  onClick={editingCategory ? handleUpdateCategory : handleAddCategory}
                  disabled={!newCategoryName.trim()}
                  className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  {editingCategory ? 'Speichern' : 'Hinzufügen'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
