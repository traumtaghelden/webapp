import { useState, useEffect } from 'react';
import { Plus, Users, Trash2, Mail, Phone, Tag, X, Search, Filter, Download, Grid, List, ChevronDown, ChevronRight, Eye, UserPlus, Gift, MapPin, AlertCircle, Check, Clock, Star, ArrowUpDown, ArrowUp, ArrowDown, FileText, Printer, User, Edit, Calendar, Home, Crown } from 'lucide-react';
import { DndContext, DragEndEvent, DragOverEvent, DragOverlay, closestCenter, closestCorners, PointerSensor, useSensor, useSensors, useDroppable } from '@dnd-kit/core';
import { SortableContext, useSortable, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { supabase, type Guest, type GuestGroup, type FamilyGroup } from '../lib/supabase';
import GuestDetailModal from './GuestDetailModal';
import FamilyGuestForm from './FamilyGuestForm';
import FamilyEditModal from './FamilyEditModal';
import FamilyDetailModal from './FamilyDetailModal';
import DietaryRequirementsModal from './DietaryRequirementsModal';
import ModalConfirm from './ModalConfirm';
import GuestSummaryBanner from './GuestSummaryBanner';
import StatusDropdown from './StatusDropdown';
import ContactListModal from './ContactListModal';
import { useModal } from '../contexts/ModalContext';
import { GUEST, COMMON, SUBSCRIPTION } from '../constants/terminology';

interface GuestManagerProps {
  weddingId: string;
  guests: Guest[];
  onUpdate: () => void;
}

type ViewMode = 'table' | 'cards' | 'kanban';
type SortColumn = 'name' | 'rsvp_status' | 'group_id' | 'table_number';
type SortDirection = 'asc' | 'desc';
type GuestStatus = 'planned' | 'invited' | 'accepted' | 'declined';

const getStatusLabel = (status: string): string => {
  switch (status) {
    case 'planned': return 'Geplant';
    case 'invited': return 'Einladung versendet';
    case 'accepted': return 'Zugesagt';
    case 'declined': return 'Abgesagt';
    default: return status;
  }
};

const getStatusColor = (status: string): string => {
  switch (status) {
    case 'planned': return 'bg-gray-100 text-gray-700';
    case 'invited': return 'bg-blue-100 text-blue-700';
    case 'accepted': return 'bg-green-100 text-green-700';
    case 'declined': return 'bg-red-100 text-red-700';
    default: return 'bg-gray-100 text-gray-700';
  }
};

const statusOptions = [
  { value: 'planned', label: 'Geplant', color: 'text-gray-700', bgColor: 'bg-gray-100', borderColor: 'border-gray-300' },
  { value: 'invited', label: 'Einladung versendet', color: 'text-blue-700', bgColor: 'bg-blue-100', borderColor: 'border-blue-300' },
  { value: 'accepted', label: 'Zugesagt', color: 'text-green-700', bgColor: 'bg-green-100', borderColor: 'border-green-300' },
  { value: 'declined', label: 'Abgesagt', color: 'text-red-700', bgColor: 'bg-red-100', borderColor: 'border-red-300' },
];

const familyStatusOptions = [
  { value: 'planned', label: 'Alle geplant', color: 'text-gray-700', bgColor: 'bg-gray-100', borderColor: 'border-gray-300' },
  { value: 'invited', label: 'Alle Einladung versendet', color: 'text-blue-700', bgColor: 'bg-blue-100', borderColor: 'border-blue-300' },
  { value: 'accepted', label: 'Alle zusagen', color: 'text-green-700', bgColor: 'bg-green-100', borderColor: 'border-green-300' },
  { value: 'declined', label: 'Alle absagen', color: 'text-red-700', bgColor: 'bg-red-100', borderColor: 'border-red-300' },
];

interface FilterState {
  searchQuery: string;
  groups: string[];
  rsvpStatus: string[];
  ageGroups: string[];
  invitationStatus: string[];
  hasDietaryRestrictions: boolean | null;
  hasAddress: boolean | null;
  hasFamilyGroup: boolean | null;
}

interface SortableKanbanCardProps {
  id: string;
  children: React.ReactNode;
}

function SortableKanbanCard({ id, children }: SortableKanbanCardProps) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div ref={setNodeRef} style={style} {...attributes} {...listeners}>
      {children}
    </div>
  );
}

interface DroppableColumnProps {
  id: string;
  children: React.ReactNode;
}

function DroppableColumn({ id, children }: DroppableColumnProps) {
  const { setNodeRef, isOver } = useDroppable({ id });

  return (
    <div
      ref={setNodeRef}
      className={`p-6 space-y-3 max-h-[600px] overflow-y-auto transition-colors ${
        isOver ? 'bg-[#d4af37]/5' : ''
      }`}
    >
      {children}
    </div>
  );
}

export default function GuestManager({ weddingId, guests, onUpdate }: GuestManagerProps) {
  const { showConfirm } = useModal();
  const [viewMode, setViewMode] = useState<ViewMode>('table');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showGroupForm, setShowGroupForm] = useState(false);
  const [showFilters, setShowFilters] = useState(false);
  const [selectedGuest, setSelectedGuest] = useState<string | null>(null);
  const [selectedFamilyForView, setSelectedFamilyForView] = useState<string | null>(null);
  const [editingFamilyId, setEditingFamilyId] = useState<string | null>(null);
  const [showDietaryModal, setShowDietaryModal] = useState(false);
  const [showContactListModal, setShowContactListModal] = useState(false);
  const [groups, setGroups] = useState<GuestGroup[]>([]);
  const [guestTags, setGuestTags] = useState<any[]>([]);
  const [sortColumn, setSortColumn] = useState<SortColumn | null>(null);
  const [sortDirection, setSortDirection] = useState<SortDirection>('asc');
  const [activeQuickFilter, setActiveQuickFilter] = useState<string | null>(null);
  const [expandedStats, setExpandedStats] = useState(false);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [expandedKanbanCards, setExpandedKanbanCards] = useState<Set<string>>(new Set());
  const [expandedCardsView, setExpandedCardsView] = useState<Set<string>>(new Set());
  const [guestEventRestrictions, setGuestEventRestrictions] = useState<Record<string, boolean>>({});
  const [familyEventRestrictions, setFamilyEventRestrictions] = useState<Record<string, boolean>>({});

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );
  const [familyGroups, setFamilyGroups] = useState<FamilyGroup[]>([]);
  const [expandedFamilies, setExpandedFamilies] = useState<Set<string>>(new Set());

  const [filters, setFilters] = useState<FilterState>({
    searchQuery: '',
    groups: [],
    rsvpStatus: [],
    ageGroups: [],
    invitationStatus: [],
    hasDietaryRestrictions: null,
    hasAddress: null,
    hasFamilyGroup: null,
  });

  const [deleteGroupModal, setDeleteGroupModal] = useState<{
    isOpen: boolean;
    groupId: string | null;
    groupName: string | null;
    isDefaultGroup: boolean;
  }>({
    isOpen: false,
    groupId: null,
    groupName: null,
    isDefaultGroup: false,
  });

  const [newGroup, setNewGroup] = useState({
    name: '',
    color: '#d4af37',
    description: '',
  });

  useEffect(() => {
    loadGroups();
    loadTags();
    loadFamilyGroups();
    loadEventAttendanceStatus();
  }, [weddingId, guests]);

  const loadEventAttendanceStatus = async () => {
    if (guests.length === 0) return;

    try {
      const { data: eventsData } = await supabase
        .from('wedding_timeline')
        .select('id')
        .eq('wedding_id', weddingId);

      if (!eventsData || eventsData.length === 0) return;

      const totalEventCount = eventsData.length;
      const guestRestrictions: Record<string, boolean> = {};
      const familyRestrictions: Record<string, boolean> = {};

      for (const guest of guests) {
        const { data: attendanceData } = await supabase
          .from('timeline_event_guest_attendance')
          .select('is_attending')
          .eq('guest_id', guest.id);

        const attendingCount = attendanceData?.filter(a => a.is_attending).length || totalEventCount;
        guestRestrictions[guest.id] = attendingCount < totalEventCount;
      }

      const familyGroupIds = [...new Set(guests.filter(g => g.family_group_id).map(g => g.family_group_id!))];
      for (const familyId of familyGroupIds) {
        const familyMembers = guests.filter(g => g.family_group_id === familyId);
        const hasRestriction = familyMembers.some(member => guestRestrictions[member.id]);
        familyRestrictions[familyId] = hasRestriction;
      }

      setGuestEventRestrictions(guestRestrictions);
      setFamilyEventRestrictions(familyRestrictions);
    } catch (error) {
      console.error('Error loading event attendance status:', error);
    }
  };

  const handleDragStart = (event: any) => {
    setActiveId(event.active.id);
  };

  const handleDragOver = (event: DragOverEvent) => {
    // This helps with collision detection
  };

  const handleDragEnd = async (event: DragEndEvent) => {
    const { active, over } = event;
    setActiveId(null);

    if (!over) return;

    const guestId = active.id as string;
    let newStatus: GuestStatus;

    // Check if dropped over a column or another guest
    const validStatuses = ['planned', 'invited', 'accepted', 'declined'];
    if (validStatuses.includes(over.id as string)) {
      // Dropped directly on a column
      newStatus = over.id as GuestStatus;
    } else {
      // Dropped on another guest - find that guest's status
      const targetGuest = guests.find(g => g.id === over.id);
      if (!targetGuest) return;
      newStatus = targetGuest.rsvp_status;
    }

    // Check if it's a family
    const guest = guests.find(g => g.id === guestId);
    if (!guest) return;

    // Don't update if status is the same
    if (guest.rsvp_status === newStatus) return;

    try {
      if (guest.family_group_id) {
        // Update all family members
        const familyMembers = guests.filter(g => g.family_group_id === guest.family_group_id);
        const updates = familyMembers.map(member =>
          supabase
            .from('guests')
            .update({ rsvp_status: newStatus })
            .eq('id', member.id)
        );
        await Promise.all(updates);
      } else {
        // Update single guest
        await supabase
          .from('guests')
          .update({ rsvp_status: newStatus })
          .eq('id', guestId);
      }
      onUpdate();
    } catch (error) {
      console.error('Error updating guest status:', error);
    }
  };

  const handleDragCancel = () => {
    setActiveId(null);
  };

  const loadGroups = async () => {
    try {
      const { data } = await supabase
        .from('guest_groups')
        .select('*')
        .eq('wedding_id', weddingId)
        .order('created_at', { ascending: true });

      if (data) {
        if (data.length === 0) {
          await createDefaultGroups();
          return;
        }
        setGroups(data);
      }
    } catch (error) {
      console.error('Error loading groups:', error);
    }
  };

  const createDefaultGroups = async () => {
    try {
      const { data: existingGroups } = await supabase
        .from('guest_groups')
        .select('name')
        .eq('wedding_id', weddingId)
        .in('name', ['A-Liste', 'B-Liste', 'C-Liste']);

      if (existingGroups && existingGroups.length > 0) {
        const { data } = await supabase
          .from('guest_groups')
          .select('*')
          .eq('wedding_id', weddingId)
          .order('created_at', { ascending: true });
        if (data) setGroups(data);
        return;
      }

      const defaultGroups = [
        { name: 'A-Liste', color: '#10b981', description: 'Primäre Gästeliste', wedding_id: weddingId },
        { name: 'B-Liste', color: '#3b82f6', description: 'Sekundäre Gästeliste', wedding_id: weddingId },
        { name: 'C-Liste', color: '#8b5cf6', description: 'Tertiäre Gästeliste', wedding_id: weddingId }
      ];

      const { data, error } = await supabase
        .from('guest_groups')
        .insert(defaultGroups)
        .select();

      if (error) throw error;
      if (data) setGroups(data);
    } catch (error) {
      console.error('Error creating default groups:', error);
    }
  };

  const loadTags = async () => {
    try {
      const { data } = await supabase
        .from('guest_tags')
        .select('*')
        .eq('wedding_id', weddingId);
      if (data) setGuestTags(data);
    } catch (error) {
      console.error('Error loading tags:', error);
    }
  };

  const loadFamilyGroups = async () => {
    try {
      const { data } = await supabase
        .from('family_groups')
        .select('*')
        .eq('wedding_id', weddingId);
      if (data) setFamilyGroups(data);
    } catch (error) {
      console.error('Error loading family groups:', error);
    }
  };

  const toggleFamilyExpansion = (familyId: string) => {
    const newExpanded = new Set(expandedFamilies);
    if (newExpanded.has(familyId)) {
      newExpanded.delete(familyId);
    } else {
      newExpanded.add(familyId);
    }
    setExpandedFamilies(newExpanded);
  };

  const getFamilyMembers = (familyGroupId: string) => {
    return guests.filter(g => g.family_group_id === familyGroupId);
  };

  const getFamilyStats = (familyGroupId: string) => {
    const members = getFamilyMembers(familyGroupId);
    const accepted = members.filter(m => m.rsvp_status === 'accepted').length;
    const planned = members.filter(m => m.rsvp_status === 'planned').length;
    const invited = members.filter(m => m.rsvp_status === 'invited').length;
    const declined = members.filter(m => m.rsvp_status === 'declined').length;
    return { total: members.length, accepted, planned, invited, declined };
  };

  const handleDeleteFamily = async (familyGroupId: string) => {
    const members = getFamilyMembers(familyGroupId);
    const confirmed = await showConfirm({
      title: 'Familie löschen',
      message: `Möchten Sie die gesamte Familie mit ${members.length} Personen wirklich löschen?`,
      confirmText: 'Familie löschen',
      type: 'danger'
    });
    if (!confirmed) return;

    try {
      await supabase.from('family_groups').delete().eq('id', familyGroupId);
      onUpdate();
      loadFamilyGroups();
    } catch (error) {
      console.error('Error deleting family:', error);
    }
  };

  const handleUpdateFamilyRSVP = async (familyGroupId: string, status: GuestStatus) => {
    const members = getFamilyMembers(familyGroupId);
    try {
      await Promise.all(
        members.map(member =>
          supabase.from('guests').update({ rsvp_status: status }).eq('id', member.id)
        )
      );
      onUpdate();
    } catch (error) {
      console.error('Error updating family RSVP:', error);
    }
  };

  const handleAddGroup = async () => {
    if (!newGroup.name.trim()) return;

    try {
      await supabase.from('guest_groups').insert([
        {
          wedding_id: weddingId,
          name: newGroup.name.trim(),
          color: newGroup.color,
          description: newGroup.description.trim() || null,
        },
      ]);

      setNewGroup({
        name: '',
        color: '#d4af37',
        description: '',
      });
      setShowGroupForm(false);
      loadGroups();
    } catch (error) {
      console.error('Error adding group:', error);
    }
  };

  const isDefaultGroup = (groupName: string) => {
    return ['A-Liste', 'B-Liste', 'C-Liste'].includes(groupName);
  };

  const handleDeleteGroup = async (groupId: string) => {
    const group = groups.find(g => g.id === groupId);
    if (!group) return;

    setDeleteGroupModal({
      isOpen: true,
      groupId: groupId,
      groupName: group.name,
      isDefaultGroup: isDefaultGroup(group.name),
    });
  };

  const confirmDeleteGroup = async () => {
    if (!deleteGroupModal.groupId) return;

    try {
      await supabase.from('guest_groups').delete().eq('id', deleteGroupModal.groupId);
      loadGroups();
      onUpdate();
    } catch (error) {
      console.error('Error deleting group:', error);
    }
  };

  const handleDeleteGuest = async (guestId: string) => {
    const confirmed = await showConfirm({
      title: 'Gast entfernen',
      message: 'Möchtest du diesen Gast wirklich entfernen?',
      confirmText: 'Gast entfernen',
      type: 'danger'
    });
    if (!confirmed) return;

    try {
      await supabase.from('guests').delete().eq('id', guestId);
      onUpdate();
    } catch (error) {
      console.error('Error deleting guest:', error);
    }
  };

  const handleUpdateRSVP = async (guestId: string, status: GuestStatus) => {
    try {
      await supabase.from('guests').update({
        rsvp_status: status,
        rsvp_date: new Date().toISOString().split('T')[0]
      }).eq('id', guestId);
      onUpdate();
    } catch (error) {
      console.error('Error updating RSVP:', error);
    }
  };

  const applyFilters = (guestsToFilter: Guest[]) => {
    let filtered = [...guestsToFilter];

    if (activeQuickFilter) {
      switch (activeQuickFilter) {
        case 'accepted':
          filtered = filtered.filter(g => g.rsvp_status === 'accepted');
          break;
        case 'planned':
          filtered = filtered.filter(g => g.rsvp_status === 'planned');
          break;
        case 'invited':
          filtered = filtered.filter(g => g.rsvp_status === 'invited');
          break;
        case 'declined':
          filtered = filtered.filter(g => g.rsvp_status === 'declined');
          break;
        case 'dietary':
          filtered = filtered.filter(g => g.dietary_restrictions && g.dietary_restrictions.trim() !== '');
          break;
        case 'no_address':
          filtered = filtered.filter(g => !g.address);
          break;
        case 'children':
          filtered = filtered.filter(g => g.age_group === 'child' || g.age_group === 'infant');
          break;
        case 'families':
          filtered = filtered.filter(g => g.family_group_id !== null);
          break;
        case 'single':
          filtered = filtered.filter(g => g.family_group_id === null);
          break;
      }
    }

    if (filters.searchQuery) {
      const query = filters.searchQuery.toLowerCase();
      filtered = filtered.filter(g =>
        g.name.toLowerCase().includes(query) ||
        (g.email && g.email.toLowerCase().includes(query)) ||
        (g.phone && g.phone.toLowerCase().includes(query))
      );
    }

    if (filters.groups.length > 0) {
      filtered = filtered.filter(g => g.group_id && filters.groups.includes(g.group_id));
    }

    if (filters.rsvpStatus.length > 0) {
      filtered = filtered.filter(g => filters.rsvpStatus.includes(g.rsvp_status));
    }

    if (filters.ageGroups.length > 0) {
      filtered = filtered.filter(g => filters.ageGroups.includes(g.age_group));
    }

    if (filters.hasDietaryRestrictions !== null) {
      if (filters.hasDietaryRestrictions) {
        filtered = filtered.filter(g => g.dietary_restrictions && g.dietary_restrictions.trim() !== '');
      } else {
        filtered = filtered.filter(g => !g.dietary_restrictions || g.dietary_restrictions.trim() === '');
      }
    }

    if (filters.hasAddress !== null) {
      if (filters.hasAddress) {
        filtered = filtered.filter(g => g.address && g.address.trim() !== '');
      } else {
        filtered = filtered.filter(g => !g.address || g.address.trim() === '');
      }
    }

    if (filters.hasFamilyGroup !== null) {
      if (filters.hasFamilyGroup) {
        filtered = filtered.filter(g => g.family_group_id !== null);
      } else {
        filtered = filtered.filter(g => g.family_group_id === null);
      }
    }

    return filtered;
  };

  const applySorting = (guestsToSort: Guest[]) => {
    if (!sortColumn) return guestsToSort;

    return [...guestsToSort].sort((a, b) => {
      let aValue: any = a[sortColumn];
      let bValue: any = b[sortColumn];

      if (sortColumn === 'name') {
        aValue = aValue.toLowerCase();
        bValue = bValue.toLowerCase();
      }

      if (aValue === null) aValue = '';
      if (bValue === null) bValue = '';

      if (aValue < bValue) return sortDirection === 'asc' ? -1 : 1;
      if (aValue > bValue) return sortDirection === 'asc' ? 1 : -1;
      return 0;
    });
  };

  const handleSort = (column: SortColumn) => {
    if (sortColumn === column) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortColumn(column);
      setSortDirection('asc');
    }
  };

  const getSortIcon = (column: SortColumn) => {
    if (sortColumn !== column) {
      return <ArrowUpDown className="w-4 h-4 opacity-40" />;
    }
    return sortDirection === 'asc' ? (
      <ArrowUp className="w-4 h-4 text-[#d4af37]" />
    ) : (
      <ArrowDown className="w-4 h-4 text-[#d4af37]" />
    );
  };

  const exportToCSV = () => {
    const headers = ['Name', 'E-Mail', 'Telefon', 'RSVP Status', 'Gruppe', 'Plus One', 'Diätwünsche', 'Tischnummer', 'Altersgruppe', 'Beziehung', 'VIP', 'Adresse', 'Stadt', 'PLZ', 'Land'];

    const rows = filteredAndSortedGuests.map(guest => {
      const group = groups.find(g => g.id === guest.group_id);
      return [
        guest.name,
        guest.email || '',
        guest.phone || '',
        getStatusLabel(guest.rsvp_status),
        group ? group.name : '',
        guest.plus_one ? 'Ja' : 'Nein',
        guest.dietary_restrictions || '',
        guest.table_number || '',
        guest.age_group === 'adult' ? 'Erwachsener' : guest.age_group === 'child' ? 'Kind' : 'Kleinkind',
        guest.relationship || '',
        guest.is_vip ? 'Ja' : 'Nein',
        guest.address || '',
        guest.city || '',
        guest.postal_code || '',
        guest.country || '',
      ];
    });

    const csvContent = [
      headers.join(','),
      ...rows.map(row => row.map(cell => `"${cell}"`).join(',')),
      '',
      '=== ZUSAMMENFASSUNG ===',
      `Gesamt,${guests.length}`,
      `Zugesagt,${acceptedCount}`,
      `Geplant,${plannedCount}`,
      `Einladung versendet,${invitedCount}`,
      `Abgesagt,${declinedCount}`,
      `Mit Plus One,${plusOneCount}`,
      `Kinder,${childrenCount}`,
      `VIP-Gäste,${vipCount}`,
      '',
      `Exportiert am,${new Date().toLocaleString('de-DE')}`,
    ].join('\n');

    const blob = new Blob(['\uFEFF' + csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    const url = URL.createObjectURL(blob);
    link.setAttribute('href', url);
    link.setAttribute('download', `gaesteliste-${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const exportAddressLabels = () => {
    const guestsWithAddress = filteredAndSortedGuests.filter(g => g.address && g.city);

    let html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Adressetiketten</title>
        <style>
          @page { size: A4; margin: 10mm; }
          body { font-family: Arial, sans-serif; }
          .label {
            width: 70mm;
            height: 36mm;
            padding: 5mm;
            display: inline-block;
            vertical-align: top;
            page-break-inside: avoid;
            border: 1px dashed #ccc;
          }
          .name { font-weight: bold; font-size: 14pt; margin-bottom: 3mm; }
          .address { font-size: 11pt; line-height: 1.4; }
        </style>
      </head>
      <body>
    `;

    guestsWithAddress.forEach(guest => {
      html += `
        <div class="label">
          <div class="name">${guest.name}</div>
          <div class="address">
            ${guest.address}<br>
            ${guest.postal_code} ${guest.city}<br>
            ${guest.country || 'Deutschland'}
          </div>
        </div>
      `;
    });

    html += '</body></html>';

    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const newWindow = window.open(url);
    if (newWindow) {
      newWindow.onload = () => {
        newWindow.print();
      };
    }
  };

  const exportNameCards = () => {
    let html = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <title>Namensschilder</title>
        <style>
          @page { size: A4; margin: 10mm; }
          body { font-family: 'Georgia', serif; }
          .card {
            width: 90mm;
            height: 50mm;
            padding: 10mm;
            display: inline-block;
            vertical-align: top;
            page-break-inside: avoid;
            border: 2px solid #d4af37;
            text-align: center;
            margin: 5mm;
            background: linear-gradient(135deg, #ffffff 0%, #f7f2eb 100%);
          }
          .name {
            font-size: 20pt;
            font-weight: bold;
            color: #0a253c;
            margin-top: 8mm;
          }
          .table {
            font-size: 12pt;
            color: #666;
            margin-top: 5mm;
          }
          .vip {
            background: linear-gradient(135deg, #fff9e6 0%, #ffe9a6 100%);
            border-color: #f4d03f;
          }
        </style>
      </head>
      <body>
    `;

    filteredAndSortedGuests.forEach(guest => {
      html += `
        <div class="card ${guest.is_vip ? 'vip' : ''}">
          <div class="name">${guest.name}</div>
          ${guest.table_number ? `<div class="table">Tisch ${guest.table_number}</div>` : ''}
        </div>
      `;
    });

    html += '</body></html>';

    const blob = new Blob([html], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const newWindow = window.open(url);
    if (newWindow) {
      newWindow.onload = () => {
        newWindow.print();
      };
    }
  };

  const toggleKanbanCard = (id: string) => {
    setExpandedKanbanCards(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const toggleCardsViewCard = (id: string) => {
    setExpandedCardsView(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) {
        newSet.delete(id);
      } else {
        newSet.add(id);
      }
      return newSet;
    });
  };

  const filteredAndSortedGuests = applySorting(applyFilters(guests));

  const acceptedCount = guests.filter(g => g.rsvp_status === 'accepted').length;
  const plannedCount = guests.filter(g => g.rsvp_status === 'planned').length;
  const invitedCount = guests.filter(g => g.rsvp_status === 'invited').length;
  const declinedCount = guests.filter(g => g.rsvp_status === 'declined').length;
  const childrenCount = guests.filter(g => g.age_group === 'child' || g.age_group === 'infant').length;
  const dietaryCount = guests.filter(g => g.dietary_restrictions && g.dietary_restrictions.trim() !== '').length;
  const noAddressCount = guests.filter(g => !g.address).length;
  const familyCount = familyGroups.length;
  const singleGuestsCount = guests.filter(g => !g.family_group_id).length;

  const getGroupStats = (groupId: string) => {
    const groupGuests = guests.filter(g => g.group_id === groupId);
    const accepted = groupGuests.filter(g => g.rsvp_status === 'accepted').length;
    return { accepted, total: groupGuests.length };
  };

  const getFamilyAcceptedCount = () => {
    return familyGroups.reduce((count, family) => {
      const familyMembers = guests.filter(g => g.family_group_id === family.id);
      const accepted = familyMembers.filter(g => g.rsvp_status === 'accepted').length;
      return count + accepted;
    }, 0);
  };

  const getSingleAcceptedCount = () => {
    const singleGuests = guests.filter(g => !g.family_group_id);
    return singleGuests.filter(g => g.rsvp_status === 'accepted').length;
  };

  const hasActiveFilters =
    filters.searchQuery !== '' ||
    filters.groups.length > 0 ||
    filters.rsvpStatus.length > 0 ||
    filters.ageGroups.length > 0 ||
    filters.hasDietaryRestrictions !== null;

  const clearFilters = () => {
    setFilters({
      searchQuery: '',
      groups: [],
      rsvpStatus: [],
      ageGroups: [],
      invitationStatus: [],
      hasDietaryRestrictions: null,
    });
    setActiveQuickFilter(null);
  };

  const predefinedColors = [
    '#d4af37', '#3b82f6', '#10b981', '#f59e0b',
    '#8b5cf6', '#ec4899', '#14b8a6', '#f97316',
  ];

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 sm:gap-4">
        <h2 className="text-2xl sm:text-3xl font-bold text-[#0a253c]">{GUEST.MODULE_NAME}liste</h2>
        <div className="flex gap-2 sm:gap-3 flex-wrap w-full sm:w-auto">
          <div className="relative group">
            <button
              className="flex items-center gap-1 sm:gap-2 px-3 sm:px-6 py-2 sm:py-3 bg-white border-2 border-[#d4af37] text-[#d4af37] rounded-xl text-sm sm:text-base font-bold active:bg-[#d4af37]/10 transition-all touch-manipulation"
            >
              <Download className="w-4 h-4 sm:w-5 sm:h-5" />
              <span className="hidden xs:inline">Export</span>
            </button>
            <div className="absolute right-0 top-full mt-2 bg-white rounded-xl shadow-2xl border-2 border-[#d4af37]/30 p-2 min-w-[200px] opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-all z-10">
              <button
                onClick={exportToCSV}
                className="w-full text-left px-4 py-2 hover:bg-[#f7f2eb] rounded-lg transition-all flex items-center gap-2"
              >
                <FileText className="w-4 h-4" />
                CSV Export
              </button>
              <button
                onClick={() => exportAddressLabels()}
                className="w-full text-left px-4 py-2 hover:bg-[#f7f2eb] rounded-lg transition-all flex items-center gap-2 cursor-pointer relative"
              >
                <MapPin className="w-4 h-4" />
                Adressetiketten
              </button>
              <button
                onClick={() => exportNameCards()}
                className="w-full text-left px-4 py-2 hover:bg-[#f7f2eb] rounded-lg transition-all flex items-center gap-2 cursor-pointer relative"
              >
                <Printer className="w-4 h-4" />
                Namensschilder
              </button>
            </div>
          </div>

          <button
            onClick={() => setShowDietaryModal(true)}
            className="flex items-center gap-2 px-6 py-3 bg-white border-2 border-orange-500 text-orange-500 rounded-xl font-bold hover:bg-orange-50 transition-all h-[46px]"
          >
            <AlertCircle className="w-5 h-5" />
            Allergien
          </button>
          <button
            onClick={() => setShowContactListModal(true)}
            className="flex items-center gap-2 px-6 py-3 bg-white border-2 border-blue-500 text-blue-500 rounded-xl font-bold hover:bg-blue-50 transition-all h-[46px]"
          >
            <User className="w-5 h-5" />
            Kontaktdaten
          </button>
          <button
            onClick={() => setShowGroupForm(!showGroupForm)}
            className="flex items-center gap-2 px-6 py-3 bg-white border-2 border-[#d4af37] text-[#d4af37] hover:bg-[#d4af37]/10 rounded-xl font-bold transition-all h-[46px]"
          >
            <Tag className="w-5 h-5" />
            Gruppe
          </button>
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="flex items-center gap-2 px-6 py-3 bg-[#d4af37] text-[#0a253c] hover:bg-[#c19a2e] hover:scale-105 rounded-xl font-bold transition-all transform h-[46px]"
          >
            <Plus className="w-5 h-5" />
            Gast hinzufügen
          </button>
        </div>
      </div>

      <GuestSummaryBanner guests={guests} familyGroups={familyGroups} />

      <div className="bg-white rounded-2xl shadow-lg">
        <button
          onClick={() => setExpandedStats(!expandedStats)}
          className="w-full p-6 flex items-center justify-between hover:bg-[#f7f2eb]/30 transition-all"
        >
          <h3 className="text-lg font-bold text-[#0a253c]">Übersicht</h3>
          {expandedStats ? (
            <ChevronDown className="w-5 h-5 text-[#0a253c]" />
          ) : (
            <ChevronRight className="w-5 h-5 text-[#0a253c]" />
          )}
        </button>

        {expandedStats && (
          <div className="px-6 pb-6 space-y-6 border-t border-[#d4af37]/20">
            <div className="pt-6">
              <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
                <button
                  onClick={() => {
                    setActiveQuickFilter(activeQuickFilter === 'all' ? null : 'all');
                    clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-[#d4af37] hover:shadow-lg transition-all text-left ${
                    !activeQuickFilter ? 'ring-2 ring-[#d4af37]' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Users className="w-5 h-5 text-[#d4af37]" />
                    <span className="text-[#333333] font-semibold text-xs">Gesamt</span>
                  </div>
                  <p className="text-xl font-bold text-[#0a253c]">{guests.length}</p>
                </button>

                <button
                  onClick={() => {
                    const newFilter = activeQuickFilter === 'accepted' ? null : 'accepted';
                    setActiveQuickFilter(newFilter);
                    if (newFilter) clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-green-500 hover:shadow-lg transition-all text-left ${
                    activeQuickFilter === 'accepted' ? 'ring-2 ring-green-500' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Check className="w-5 h-5 text-green-500" />
                    <span className="text-[#333333] font-semibold text-xs">Zugesagt</span>
                  </div>
                  <p className="text-xl font-bold text-green-600">{acceptedCount}</p>
                </button>

                <button
                  onClick={() => {
                    const newFilter = activeQuickFilter === 'planned' ? null : 'planned';
                    setActiveQuickFilter(newFilter);
                    if (newFilter) clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-gray-500 hover:shadow-lg transition-all text-left ${
                    activeQuickFilter === 'planned' ? 'ring-2 ring-gray-500' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <FileText className="w-5 h-5 text-gray-500" />
                    <span className="text-[#333333] font-semibold text-xs">Geplant</span>
                  </div>
                  <p className="text-xl font-bold text-gray-600">{plannedCount}</p>
                </button>

                <button
                  onClick={() => {
                    const newFilter = activeQuickFilter === 'invited' ? null : 'invited';
                    setActiveQuickFilter(newFilter);
                    if (newFilter) clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-blue-500 hover:shadow-lg transition-all text-left ${
                    activeQuickFilter === 'invited' ? 'ring-2 ring-blue-500' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Mail className="w-5 h-5 text-blue-500" />
                    <span className="text-[#333333] font-semibold text-xs">Eingeladen</span>
                  </div>
                  <p className="text-xl font-bold text-blue-600">{invitedCount}</p>
                </button>

                <button
                  onClick={() => {
                    const newFilter = activeQuickFilter === 'declined' ? null : 'declined';
                    setActiveQuickFilter(newFilter);
                    if (newFilter) clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-red-500 hover:shadow-lg transition-all text-left ${
                    activeQuickFilter === 'declined' ? 'ring-2 ring-red-500' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <X className="w-5 h-5 text-red-500" />
                    <span className="text-[#333333] font-semibold text-xs">Abgesagt</span>
                  </div>
                  <p className="text-xl font-bold text-red-600">{declinedCount}</p>
                </button>

                <button
                  onClick={() => {
                    const newFilter = activeQuickFilter === 'children' ? null : 'children';
                    setActiveQuickFilter(newFilter);
                    if (newFilter) clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-purple-500 hover:shadow-lg transition-all text-left ${
                    activeQuickFilter === 'children' ? 'ring-2 ring-purple-500' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Users className="w-5 h-5 text-purple-500" />
                    <span className="text-[#333333] font-semibold text-xs">Kinder</span>
                  </div>
                  <p className="text-xl font-bold text-purple-600">{childrenCount}</p>
                </button>

                <button
                  onClick={() => {
                    const newFilter = activeQuickFilter === 'dietary' ? null : 'dietary';
                    setActiveQuickFilter(newFilter);
                    if (newFilter) clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-orange-500 hover:shadow-lg transition-all text-left ${
                    activeQuickFilter === 'dietary' ? 'ring-2 ring-orange-500' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <AlertCircle className="w-5 h-5 text-orange-500" />
                    <span className="text-[#333333] font-semibold text-xs">Diät</span>
                  </div>
                  <p className="text-xl font-bold text-orange-600">{dietaryCount}</p>
                </button>

                <button
                  onClick={() => {
                    const newFilter = activeQuickFilter === 'families' ? null : 'families';
                    setActiveQuickFilter(newFilter);
                    if (newFilter) clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-[#d4af37] hover:shadow-lg transition-all text-left ${
                    activeQuickFilter === 'families' ? 'ring-2 ring-[#d4af37]' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <Users className="w-5 h-5 text-[#d4af37]" />
                    <span className="text-[#333333] font-semibold text-xs">Familien</span>
                  </div>
                  <p className="text-xl font-bold text-[#0a253c]">
                    {getFamilyAcceptedCount()}/{familyCount > 0 ? guests.filter(g => g.family_group_id).length : 0}
                  </p>
                </button>

                <button
                  onClick={() => {
                    const newFilter = activeQuickFilter === 'single' ? null : 'single';
                    setActiveQuickFilter(newFilter);
                    if (newFilter) clearFilters();
                  }}
                  className={`bg-white rounded-xl p-3 shadow-md border-l-4 border-teal-500 hover:shadow-lg transition-all text-left ${
                    activeQuickFilter === 'single' ? 'ring-2 ring-teal-500' : ''
                  }`}
                >
                  <div className="flex items-center gap-2 mb-1">
                    <User className="w-5 h-5 text-teal-500" />
                    <span className="text-[#333333] font-semibold text-xs">Einzel</span>
                  </div>
                  <p className="text-xl font-bold text-teal-600">
                    {getSingleAcceptedCount()}/{singleGuestsCount}
                  </p>
                </button>
              </div>
            </div>

            {groups.length > 0 && (
              <div className="border-t border-[#d4af37]/20 pt-6">
                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3">
                  {groups.map((group) => {
                    const stats = getGroupStats(group.id);
                    return (
                      <button
                        key={group.id}
                        onClick={() => {
                          if (filters.groups.includes(group.id)) {
                            setFilters({ ...filters, groups: filters.groups.filter(g => g !== group.id) });
                          } else {
                            setFilters({ ...filters, groups: [...filters.groups, group.id] });
                          }
                        }}
                        className={`bg-[#f7f2eb] rounded-xl p-3 hover:shadow-md transition-all text-left border-l-4 ${
                          filters.groups.includes(group.id) ? 'ring-2 ring-offset-2' : ''
                        }`}
                        style={{
                          borderLeftColor: group.color,
                          ...(filters.groups.includes(group.id) ? { ringColor: group.color } : {}),
                        }}
                      >
                        <div className="flex items-center gap-2 mb-1">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{ backgroundColor: group.color }}
                          />
                          <span className="text-[#333333] font-semibold text-xs">{group.name}</span>
                        </div>
                        <p className="text-lg font-bold text-[#0a253c]">
                          {stats.accepted}/{stats.total}
                        </p>
                      </button>
                    );
                  })}
                </div>
              </div>
            )}
          </div>
        )}
      </div>

      {showGroupForm && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[9999] p-4">
          <div className="bg-white rounded-3xl shadow-2xl max-w-2xl w-full p-8">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-2xl font-bold text-[#0a253c]">Neue Gruppe erstellen</h3>
              <button
                onClick={() => setShowGroupForm(false)}
                className="p-2 hover:bg-[#f7f2eb] rounded-full transition-colors"
              >
                <X className="w-6 h-6 text-[#666666]" />
              </button>
            </div>

            <div className="space-y-6">
              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Gruppenname*</label>
                <input
                  type="text"
                  value={newGroup.name}
                  onChange={(e) => setNewGroup({ ...newGroup, name: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  placeholder="z.B. Familie Braut, Arbeitskollegen"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Farbe</label>
                <div className="flex gap-2 flex-wrap">
                  {predefinedColors.map((color) => (
                    <button
                      key={color}
                      onClick={() => setNewGroup({ ...newGroup, color })}
                      className={`w-10 h-10 rounded-full transition-all ${
                        newGroup.color === color ? 'ring-4 ring-offset-2 ring-[#d4af37]' : 'hover:scale-110'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-sm font-semibold text-[#333333] mb-2">Beschreibung (optional)</label>
                <input
                  type="text"
                  value={newGroup.description}
                  onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })}
                  className="w-full px-4 py-3 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
                  placeholder="Kurze Beschreibung der Gruppe"
                />
              </div>
            </div>

            <div className="flex gap-4 mt-8">
              <button
                onClick={handleAddGroup}
                disabled={!newGroup.name.trim()}
                className="flex-1 px-6 py-3 bg-[#d4af37] text-[#0a253c] rounded-xl font-bold hover:bg-[#c19a2e] disabled:opacity-50 disabled:cursor-not-allowed transition-all"
              >
                Gruppe erstellen
              </button>
              <button
                onClick={() => setShowGroupForm(false)}
                className="px-6 py-3 border-2 border-[#d4af37] text-[#d4af37] rounded-xl font-semibold hover:bg-[#d4af37]/10 transition-all"
              >
                Abbrechen
              </button>
            </div>
          </div>
        </div>
      )}

      {showAddForm && (
        <FamilyGuestForm
          weddingId={weddingId}
          groups={groups}
          onClose={() => setShowAddForm(false)}
          onSuccess={() => {
            setShowAddForm(false);
            onUpdate();
            loadFamilyGroups();
          }}
        />
      )}

      <div className="bg-white rounded-2xl p-6 shadow-lg">
        <div className="flex items-center justify-between gap-4 mb-4 flex-wrap">
          <div className="flex items-center gap-3 flex-1">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className="flex items-center gap-2 px-4 py-2 bg-[#f7f2eb] rounded-xl font-semibold text-[#0a253c] hover:bg-[#d4af37]/10 transition-all"
            >
              <Filter className="w-5 h-5" />
              Filter {hasActiveFilters && `(aktiv)`}
            </button>
            <div className="relative flex-1 max-w-md">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#333333]" />
              <input
                type="text"
                value={filters.searchQuery}
                onChange={(e) => setFilters({ ...filters, searchQuery: e.target.value })}
                placeholder="Gäste durchsuchen..."
                className="w-full pl-10 pr-4 py-2 rounded-xl border-2 border-[#d4af37]/30 focus:border-[#d4af37] focus:outline-none"
              />
            </div>
          </div>
          {(hasActiveFilters || activeQuickFilter) && (
            <button
              onClick={clearFilters}
              className="flex items-center gap-2 px-4 py-2 text-[#d4af37] hover:text-[#c19a2e] transition-all"
            >
              <X className="w-4 h-4" />
              Alle Filter entfernen
            </button>
          )}
        </div>

        {groups.length > 0 && (
          <div className="pt-4 border-t border-[#d4af37]/20">
            <div className="flex items-center gap-3 mb-3">
              <Tag className="w-5 h-5 text-[#d4af37]" />
              <label className="text-sm font-semibold text-[#333333]">Gruppen:</label>
            </div>
            <div className="flex flex-wrap gap-2">
              {groups.map((group) => {
                const groupCount = guests.filter((g) => g.group_id === group.id).length;
                return (
                  <div key={group.id} className="relative group/item">
                    <button
                      onClick={() => {
                        if (filters.groups.includes(group.id)) {
                          setFilters({ ...filters, groups: filters.groups.filter(g => g !== group.id) });
                        } else {
                          setFilters({ ...filters, groups: [...filters.groups, group.id] });
                        }
                      }}
                      className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                        filters.groups.includes(group.id) ? 'text-white ring-2 ring-offset-2' : 'hover:opacity-80'
                      }`}
                      style={{
                        backgroundColor: filters.groups.includes(group.id) ? group.color : `${group.color}20`,
                        color: filters.groups.includes(group.id) ? 'white' : group.color,
                        borderColor: group.color,
                        border: '2px solid',
                      }}
                    >
                      {group.name} ({groupCount})
                    </button>
                    {!isDefaultGroup(group.name) && (
                      <button
                        onClick={() => handleDeleteGroup(group.id)}
                        className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full opacity-0 group-hover/item:opacity-100 transition-opacity flex items-center justify-center"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {showFilters && (
          <div className="space-y-4 pt-4 border-t border-[#d4af37]/20">
            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Status</label>
              <div className="flex flex-wrap gap-2">
                {['planned', 'invited', 'accepted', 'declined'].map(status => (
                  <button
                    key={status}
                    onClick={() => {
                      const newStatus = filters.rsvpStatus.includes(status)
                        ? filters.rsvpStatus.filter(s => s !== status)
                        : [...filters.rsvpStatus, status];
                      setFilters({ ...filters, rsvpStatus: newStatus });
                    }}
                    className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                      filters.rsvpStatus.includes(status)
                        ? 'bg-[#d4af37] text-[#0a253c]'
                        : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                    }`}
                  >
                    {getStatusLabel(status)}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Altersgruppe</label>
              <div className="flex flex-wrap gap-2">
                {['adult', 'child', 'infant'].map(age => (
                  <button
                    key={age}
                    onClick={() => {
                      const newAges = filters.ageGroups.includes(age)
                        ? filters.ageGroups.filter(a => a !== age)
                        : [...filters.ageGroups, age];
                      setFilters({ ...filters, ageGroups: newAges });
                    }}
                    className={`px-4 py-2 rounded-xl font-semibold transition-all ${
                      filters.ageGroups.includes(age)
                        ? 'bg-[#d4af37] text-[#0a253c]'
                        : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                    }`}
                  >
                    {age === 'adult' ? 'Erwachsene' : age === 'child' ? 'Kinder' : 'Kleinkinder'}
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[#333333] mb-2">Weitere Filter</label>
              <div className="flex flex-wrap gap-2">
                <button
                  onClick={() => setFilters({ ...filters, hasDietaryRestrictions: filters.hasDietaryRestrictions === true ? null : true })}
                  className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
                    filters.hasDietaryRestrictions === true
                      ? 'bg-[#d4af37] text-[#0a253c]'
                      : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                  }`}
                >
                  <AlertCircle className="w-4 h-4" />
                  Mit Diätwünschen
                </button>
                <button
                  onClick={() => setFilters({ ...filters, hasAddress: filters.hasAddress === true ? null : true })}
                  className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
                    filters.hasAddress === true
                      ? 'bg-[#d4af37] text-[#0a253c]'
                      : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                  }`}
                >
                  <Home className="w-4 h-4" />
                  Mit Adresse
                </button>
                <button
                  onClick={() => setFilters({ ...filters, hasAddress: filters.hasAddress === false ? null : false })}
                  className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
                    filters.hasAddress === false
                      ? 'bg-[#d4af37] text-[#0a253c]'
                      : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                  }`}
                >
                  <Home className="w-4 h-4" />
                  Ohne Adresse
                </button>
                <button
                  onClick={() => setFilters({ ...filters, hasFamilyGroup: filters.hasFamilyGroup === true ? null : true })}
                  className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
                    filters.hasFamilyGroup === true
                      ? 'bg-[#d4af37] text-[#0a253c]'
                      : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                  }`}
                >
                  <Users className="w-4 h-4" />
                  In Familie
                </button>
                <button
                  onClick={() => setFilters({ ...filters, hasFamilyGroup: filters.hasFamilyGroup === false ? null : false })}
                  className={`px-4 py-2 rounded-xl font-semibold transition-all flex items-center gap-2 ${
                    filters.hasFamilyGroup === false
                      ? 'bg-[#d4af37] text-[#0a253c]'
                      : 'bg-[#f7f2eb] text-[#333333] hover:bg-[#d4af37]/20'
                  }`}
                >
                  <User className="w-4 h-4" />
                  Einzelgast
                </button>
              </div>
            </div>
          </div>
        )}

        <div className="flex gap-1 bg-[#f7f2eb] rounded-2xl p-2 mt-4">
          <button
            onClick={() => setViewMode('table')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              viewMode === 'table' ? 'bg-[#d4af37] text-[#0a253c]' : 'text-[#333333] hover:bg-white'
            }`}
            title="Tabellenansicht"
          >
            <List className="w-5 h-5" />
            Tabelle
          </button>
          <button
            onClick={() => setViewMode('cards')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              viewMode === 'cards' ? 'bg-[#d4af37] text-[#0a253c]' : 'text-[#333333] hover:bg-white'
            }`}
            title="Kartenansicht"
          >
            <Grid className="w-5 h-5" />
            Karten
          </button>
          <button
            onClick={() => setViewMode('kanban')}
            className={`flex items-center gap-2 px-6 py-3 rounded-xl font-bold transition-all ${
              viewMode === 'kanban' ? 'bg-[#d4af37] text-[#0a253c]' : 'text-[#333333] hover:bg-white'
            }`}
            title="Kanban-Ansicht"
          >
            <Grid className="w-5 h-5" />
            Kanban
          </button>
        </div>
      </div>

      {viewMode === 'table' && (
        <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-[#0a253c] text-white">
                <tr>
                  <th className="px-6 py-4 text-left">
                    <button
                      onClick={() => handleSort('name')}
                      className="flex items-center gap-2 font-semibold hover:text-[#d4af37] transition-colors"
                    >
                      Name
                      {getSortIcon('name')}
                    </button>
                  </th>
                  <th className="px-6 py-4 text-left">
                    <button
                      onClick={() => handleSort('group_id')}
                      className="flex items-center gap-2 font-semibold hover:text-[#d4af37] transition-colors"
                    >
                      Gruppe
                      {getSortIcon('group_id')}
                    </button>
                  </th>
                  <th className="px-6 py-4 text-left font-semibold">Kontakt</th>
                  <th className="px-6 py-4 text-left">
                    <button
                      onClick={() => handleSort('rsvp_status')}
                      className="flex items-center gap-2 font-semibold hover:text-[#d4af37] transition-colors"
                    >
                      Status
                      {getSortIcon('rsvp_status')}
                    </button>
                  </th>
                  <th className="px-6 py-4 text-left font-semibold">Details</th>
                  <th className="px-6 py-4 text-center font-semibold">Aktionen</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#f7f2eb]">
                {(() => {
                  const renderedFamilies = new Set<string>();
                  const rows: JSX.Element[] = [];

                  filteredAndSortedGuests.forEach((guest) => {
                    if (guest.family_group_id && !renderedFamilies.has(guest.family_group_id)) {
                      renderedFamilies.add(guest.family_group_id);
                      const familyGroup = familyGroups.find(f => f.id === guest.family_group_id);
                      const familyMembers = filteredAndSortedGuests.filter(g => g.family_group_id === guest.family_group_id);
                      const stats = getFamilyStats(guest.family_group_id);
                      const isExpanded = expandedFamilies.has(guest.family_group_id);

                      rows.push(
                        <tr
                          key={`family-${guest.family_group_id}`}
                          className="bg-[#f7f2eb]/30 hover:bg-[#f7f2eb] transition-colors cursor-pointer border-l-4 border-[#d4af37]"
                          onClick={() => setSelectedFamilyForView(guest.family_group_id!)}
                        >
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  toggleFamilyExpansion(guest.family_group_id!);
                                }}
                                className="p-1 hover:bg-white rounded transition-colors"
                              >
                                {isExpanded ? (
                                  <ChevronDown className="w-5 h-5 text-[#d4af37]" />
                                ) : (
                                  <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                                )}
                              </button>
                              <Users className="w-6 h-6 text-[#d4af37]" />
                              <div>
                                <div className="flex items-center gap-2">
                                  <p className="font-bold text-[#0a253c]">{familyGroup?.family_name || 'Familie'}</p>
                                  {familyEventRestrictions[guest.family_group_id] && (
                                    <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs font-semibold flex items-center gap-1">
                                      <AlertCircle className="w-3 h-3" />
                                      Teilnahme eingeschränkt
                                    </span>
                                  )}
                                </div>
                                <p className="text-sm text-[#666666]">{stats.total} {stats.total === 1 ? 'Person' : 'Personen'}</p>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-[#666666]">-</span>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-[#666666]">-</span>
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex flex-col gap-2">
                              <div className="flex gap-2 flex-wrap">
                                {stats.planned > 0 && (
                                  <span className="px-2 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-semibold">
                                    {stats.planned} 📋
                                  </span>
                                )}
                                {stats.invited > 0 && (
                                  <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                                    {stats.invited} ✉️
                                  </span>
                                )}
                                {stats.accepted > 0 && (
                                  <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full text-xs font-semibold">
                                    {stats.accepted} ✓
                                  </span>
                                )}
                                {stats.declined > 0 && (
                                  <span className="px-2 py-1 bg-red-100 text-red-700 rounded-full text-xs font-semibold">
                                    {stats.declined} ✗
                                  </span>
                                )}
                              </div>
                              <div className="mt-2">
                                <StatusDropdown
                                  value={stats.accepted === stats.total ? 'accepted' : stats.declined === stats.total ? 'declined' : stats.invited === stats.total ? 'invited' : 'planned'}
                                  onChange={(value) => handleUpdateFamilyRSVP(guest.family_group_id!, value as any)}
                                  options={familyStatusOptions}
                                  size="sm"
                                  onClick={(e) => e.stopPropagation()}
                                />
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            <span className="text-sm text-[#666666]">-</span>
                          </td>
                          <td className="px-6 py-4 text-center">
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setEditingFamilyId(guest.family_group_id!);
                                }}
                                className="p-2 hover:bg-[#d4af37]/10 rounded-lg transition-colors inline-flex"
                                title="Familie bearbeiten"
                              >
                                <Edit className="w-4 h-4 text-[#d4af37]" />
                              </button>
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  handleDeleteFamily(guest.family_group_id!);
                                }}
                                className="p-2 hover:bg-red-100 rounded-lg transition-colors inline-flex"
                                title="Familie löschen"
                              >
                                <Trash2 className="w-4 h-4 text-red-500" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );

                      if (isExpanded) {
                        familyMembers.forEach((member) => {
                          const guestGroup = groups.find((g) => g.id === member.group_id);
                          rows.push(
                            <tr
                              key={member.id}
                              className="hover:bg-[#f7f2eb]/50 transition-colors cursor-pointer bg-white"
                              onClick={() => setSelectedGuest(member.id)}
                            >
                              <td className="px-6 py-4 pl-16">
                                <div className="flex items-center gap-3">
                                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-white text-sm font-bold ${
                                    member.is_vip ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' : 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f]'
                                  }`}>
                                    {member.name.charAt(0).toUpperCase()}
                                  </div>
                                  <div>
                                    <p className="text-sm font-semibold text-[#0a253c] flex items-center gap-2">
                                      {member.name}
                                      <span className={`text-xs px-2 py-0.5 rounded ${
                                        member.age_group === 'adult' ? 'bg-blue-100 text-blue-700' :
                                        member.age_group === 'child' ? 'bg-purple-100 text-purple-700' :
                                        'bg-pink-100 text-pink-700'
                                      }`}>
                                        {member.age_group === 'adult' ? 'Erwachsener' :
                                         member.age_group === 'child' ? 'Kind' : 'Kleinkind'}
                                      </span>
                                      {member.is_vip && <Star className="w-3 h-3 text-yellow-500 fill-current" />}
                                      {guestEventRestrictions[member.id] && (
                                        <span className="px-1.5 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs font-semibold flex items-center gap-1">
                                          <AlertCircle className="w-2.5 h-2.5" />
                                          Events
                                        </span>
                                      )}
                                    </p>
                                    {member.family_role && (
                                      <span className="text-xs text-[#666666]">{member.family_role}</span>
                                    )}
                                  </div>
                                </div>
                              </td>
                              <td className="px-6 py-4">
                                {guestGroup ? (
                                  <span
                                    className="px-2 py-1 rounded-full text-xs font-semibold"
                                    style={{
                                      backgroundColor: `${guestGroup.color}20`,
                                      color: guestGroup.color,
                                      border: `1px solid ${guestGroup.color}`,
                                    }}
                                  >
                                    {guestGroup.name}
                                  </span>
                                ) : (
                                  <span className="text-[#999999] text-sm">-</span>
                                )}
                              </td>
                              <td className="px-6 py-4">
                                <div className="space-y-1 text-xs text-[#333333]">
                                  {member.email && (
                                    <div className="flex items-center gap-2">
                                      <Mail className="w-3 h-3" />
                                      <span className="truncate max-w-[150px]">{member.email}</span>
                                    </div>
                                  )}
                                  {member.phone && (
                                    <div className="flex items-center gap-2">
                                      <Phone className="w-3 h-3" />
                                      <span>{member.phone}</span>
                                    </div>
                                  )}
                                  {!member.email && !member.phone && <span className="text-[#999999]">-</span>}
                                </div>
                              </td>
                              <td className="px-6 py-4" onClick={(e) => e.stopPropagation()}>
                                <StatusDropdown
                                  value={member.rsvp_status}
                                  onChange={(value) => handleUpdateRSVP(member.id, value as any)}
                                  options={statusOptions}
                                  size="sm"
                                />
                              </td>
                              <td className="px-6 py-4">
                                <div className="flex flex-wrap gap-1">
                                  {member.age_group !== 'adult' && (
                                    <span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs font-semibold">
                                      {member.age_group === 'child' ? 'Kind' : 'Kleinkind'}
                                    </span>
                                  )}
                                  {member.dietary_restrictions && member.dietary_restrictions.trim() !== '' && (
                                    <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs font-semibold" title={member.dietary_restrictions}>
                                      Diät
                                    </span>
                                  )}
                                </div>
                              </td>
                              <td className="px-6 py-4 text-center" onClick={(e) => e.stopPropagation()}>
                                <div className="flex items-center justify-center gap-2">
                                  <button
                                    onClick={() => setSelectedGuest(member.id)}
                                    className="p-1 hover:bg-[#d4af37]/20 rounded transition-colors"
                                    title="Details"
                                  >
                                    <Eye className="w-3 h-3 text-[#d4af37]" />
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        });
                      }
                    } else if (!guest.family_group_id) {
                      const guestGroup = groups.find((g) => g.id === guest.group_id);
                      rows.push(
                        <tr
                          key={guest.id}
                          className="hover:bg-[#f7f2eb] transition-colors cursor-pointer"
                          onClick={() => setSelectedGuest(guest.id)}
                        >
                          <td className="px-6 py-4">
                            <div className="flex items-center gap-3">
                              <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
                                guest.is_vip ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' : 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f]'
                              }`}>
                                {guest.name.charAt(0).toUpperCase()}
                              </div>
                              <div>
                                <p className="font-semibold text-[#0a253c] flex items-center gap-2">
                                  {guest.name}
                                  {guest.is_vip && <Star className="w-4 h-4 text-yellow-500 fill-current" />}
                                  {guestEventRestrictions[guest.id] && (
                                    <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs font-semibold flex items-center gap-1">
                                      <AlertCircle className="w-3 h-3" />
                                      Teilnahme eingeschr\u00e4nkt
                                    </span>
                                  )}
                                </p>
                                {guest.plus_one && (
                                  <span className="text-xs text-[#666666]">+ Begleitperson</span>
                                )}
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4">
                            {guestGroup ? (
                              <span
                                className="px-3 py-1 rounded-full text-sm font-semibold"
                                style={{
                                  backgroundColor: `${guestGroup.color}20`,
                                  color: guestGroup.color,
                                  border: `2px solid ${guestGroup.color}`,
                                }}
                              >
                                {guestGroup.name}
                              </span>
                            ) : (
                              <span className="text-[#999999]">-</span>
                            )}
                          </td>
                          <td className="px-6 py-4">
                            <div className="space-y-1 text-sm text-[#333333]">
                              {guest.email && (
                                <div className="flex items-center gap-2">
                                  <Mail className="w-4 h-4" />
                                  <span className="truncate max-w-[200px]">{guest.email}</span>
                                </div>
                              )}
                              {guest.phone && (
                                <div className="flex items-center gap-2">
                                  <Phone className="w-4 h-4" />
                                  <span>{guest.phone}</span>
                                </div>
                              )}
                              {!guest.email && !guest.phone && <span className="text-[#999999]">-</span>}
                            </div>
                          </td>
                          <td className="px-6 py-4" onClick={(e) => e.stopPropagation()}>
                            <StatusDropdown
                              value={guest.rsvp_status}
                              onChange={(value) => handleUpdateRSVP(guest.id, value as any)}
                              options={statusOptions}
                              size="sm"
                            />
                          </td>
                          <td className="px-6 py-4">
                            <div className="flex flex-wrap gap-1">
                              {guest.age_group !== 'adult' && (
                                <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded-full text-xs font-semibold">
                                  {guest.age_group === 'child' ? 'Kind' : 'Kleinkind'}
                                </span>
                              )}
                              {guest.dietary_restrictions && guest.dietary_restrictions.trim() !== '' && (
                                <span className="px-2 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-semibold" title={guest.dietary_restrictions}>
                                  Diät
                                </span>
                              )}
                              {guest.table_number && (
                                <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                                  Tisch {guest.table_number}
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="px-6 py-4 text-center" onClick={(e) => e.stopPropagation()}>
                            <div className="flex items-center justify-center gap-2">
                              <button
                                onClick={() => setSelectedGuest(guest.id)}
                                className="p-2 hover:bg-[#d4af37]/20 rounded-lg transition-colors"
                                title="Details"
                              >
                                <Eye className="w-4 h-4 text-[#d4af37]" />
                              </button>
                              <button
                                onClick={() => handleDeleteGuest(guest.id)}
                                className="p-2 hover:bg-red-100 rounded-lg transition-colors"
                                title="Löschen"
                              >
                                <Trash2 className="w-4 h-4 text-red-500" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    }
                  });

                  return rows;
                })()}
              </tbody>
            </table>
          </div>

          {filteredAndSortedGuests.length === 0 && (
            <div className="p-12 text-center">
              <Users className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
              <p className="text-[#333333] text-lg">
                {hasActiveFilters || activeQuickFilter ? 'Keine Gäste gefunden' : 'Noch keine Gäste hinzugefügt'}
              </p>
            </div>
          )}
        </div>
      )}

      {viewMode === 'cards' && (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {(() => {
            const renderedFamilies = new Set<string>();
            const cards: JSX.Element[] = [];

            filteredAndSortedGuests.forEach((guest) => {
              if (guest.family_group_id && !renderedFamilies.has(guest.family_group_id)) {
                renderedFamilies.add(guest.family_group_id);
                const familyGroup = familyGroups.find(f => f.id === guest.family_group_id);
                const familyMembers = filteredAndSortedGuests.filter(g => g.family_group_id === guest.family_group_id);
                const stats = getFamilyStats(guest.family_group_id);
                const isExpanded = expandedFamilies.has(guest.family_group_id);

                const isCardExpanded = expandedCardsView.has(guest.family_group_id);

                cards.push(
                  <div
                    key={`family-${guest.family_group_id}`}
                    className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all border-2 border-[#d4af37]"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div
                        className="flex items-center gap-3 flex-1 cursor-pointer"
                        onClick={() => setSelectedFamilyForView(guest.family_group_id!)}
                      >
                        <div className="w-14 h-14 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex items-center justify-center text-white">
                          <Users className="w-7 h-7" />
                        </div>
                        <div>
                          <h3 className="text-lg font-bold text-[#0a253c]">{familyGroup?.family_name || 'Familie'}</h3>
                          <p className="text-sm text-[#666666]">{stats.total} {stats.total === 1 ? 'Person' : 'Personen'}</p>
                        </div>
                      </div>
                      <div className="flex gap-1">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setEditingFamilyId(guest.family_group_id!);
                          }}
                          className="p-1 hover:bg-[#f7f2eb] rounded transition-colors"
                          title="Familie bearbeiten"
                        >
                          <Edit className="w-4 h-4 text-[#d4af37]" />
                        </button>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleCardsViewCard(guest.family_group_id);
                          }}
                          className="p-1 hover:bg-[#f7f2eb] rounded transition-colors"
                        >
                          {isCardExpanded ? (
                            <ChevronDown className="w-5 h-5 text-[#d4af37]" />
                          ) : (
                            <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                          )}
                        </button>
                      </div>
                    </div>

                    <div className="flex gap-2 mb-4">
                      {stats.planned > 0 && (
                        <span className="px-3 py-1 bg-gray-100 text-gray-700 rounded-full text-xs font-semibold">
                          {stats.planned} 📋
                        </span>
                      )}
                      {stats.invited > 0 && (
                        <span className="px-3 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                          {stats.invited} ✉️
                        </span>
                      )}
                      {stats.accepted > 0 && (
                        <span className="px-3 py-1 bg-green-100 text-green-700 rounded-full text-xs font-semibold">
                          {stats.accepted} ✓
                        </span>
                      )}
                      {stats.declined > 0 && (
                        <span className="px-3 py-1 bg-red-100 text-red-700 rounded-full text-xs font-semibold">
                          {stats.declined} ✗
                        </span>
                      )}
                    </div>

                    {isCardExpanded && (
                      <div className="space-y-3 pt-3 border-t border-[#d4af37]/20">
                        {familyGroup?.notes && (
                          <div className="p-3 bg-[#f7f2eb]/50 rounded-lg">
                            <p className="text-xs font-semibold text-[#666666] mb-1">Notizen</p>
                            <p className="text-sm text-[#0a253c]">{familyGroup.notes}</p>
                          </div>
                        )}
                        {familyMembers.map((member) => (
                          <div
                            key={member.id}
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedGuest(member.id);
                            }}
                            className="flex items-center gap-3 p-3 bg-[#f7f2eb]/50 rounded-xl hover:bg-[#f7f2eb] cursor-pointer transition-colors"
                          >
                            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex items-center justify-center text-white font-bold text-sm">
                              {member.name.charAt(0).toUpperCase()}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-[#0a253c] text-sm truncate flex items-center gap-2">
                                {member.name}
                                <span className={`text-xs px-2 py-0.5 rounded ${
                                  member.age_group === 'adult' ? 'bg-blue-100 text-blue-700' :
                                  member.age_group === 'child' ? 'bg-purple-100 text-purple-700' :
                                  'bg-pink-100 text-pink-700'
                                }`}>
                                  {member.age_group === 'adult' ? 'Erw.' :
                                   member.age_group === 'child' ? 'Kind' : 'Klein'}
                                </span>
                              </p>
                              {member.family_role && (
                                <p className="text-xs text-[#666666]">{member.family_role}</p>
                              )}
                            </div>
                            <span className={`px-2 py-1 rounded-full text-xs font-semibold ${
                              member.rsvp_status === 'accepted' ? 'bg-green-100 text-green-700' :
                              member.rsvp_status === 'declined' ? 'bg-red-100 text-red-700' :
                              'bg-yellow-100 text-yellow-700'
                            }`}>
                              {member.rsvp_status === 'accepted' ? '✓' :
                               member.rsvp_status === 'declined' ? '✗' : '⏱'}
                            </span>
                          </div>
                        ))}
                      </div>
                    )}

                    <div className="mt-4">
                      <StatusDropdown
                        value={stats.accepted === stats.total ? 'accepted' : stats.declined === stats.total ? 'declined' : stats.invited === stats.total ? 'invited' : 'planned'}
                        onChange={(value) => handleUpdateFamilyRSVP(guest.family_group_id!, value as any)}
                        options={familyStatusOptions}
                        size="md"
                        onClick={(e) => e.stopPropagation()}
                      />
                    </div>
                  </div>
                );
              } else if (!guest.family_group_id) {
                const guestGroup = groups.find((g) => g.id === guest.group_id);
                const isCardExpanded = expandedCardsView.has(guest.id);

                cards.push(
                  <div
                    key={guest.id}
                    className={`bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all border-2 ${
                      guest.is_vip ? 'border-yellow-400' : 'border-[#d4af37]/30'
                    } hover:border-[#d4af37]`}
                  >
                    <div className="flex items-start justify-between mb-4">
                      <div
                        onClick={() => setSelectedGuest(guest.id)}
                        className={`w-14 h-14 rounded-full flex items-center justify-center text-xl font-bold text-white cursor-pointer ${
                          guest.is_vip ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' : 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f]'
                        }`}
                      >
                        {guest.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex gap-1">
                        {guest.is_vip && <Star className="w-5 h-5 text-yellow-500 fill-current" />}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleCardsViewCard(guest.id);
                          }}
                          className="p-1 hover:bg-[#f7f2eb] rounded transition-colors"
                        >
                          {isCardExpanded ? (
                            <ChevronDown className="w-5 h-5 text-[#d4af37]" />
                          ) : (
                            <ChevronRight className="w-5 h-5 text-[#d4af37]" />
                          )}
                        </button>
                      </div>
                    </div>

                    <h3 className="text-lg font-bold text-[#0a253c] mb-2">{guest.name}</h3>

                    {guestGroup && (
                      <span
                        className="inline-block px-3 py-1 rounded-full text-xs font-semibold mb-3"
                        style={{
                          backgroundColor: `${guestGroup.color}20`,
                          color: guestGroup.color,
                          border: `2px solid ${guestGroup.color}`,
                        }}
                      >
                        {guestGroup.name}
                      </span>
                    )}

                    {!isCardExpanded && (
                      <div className="space-y-2 mb-4">
                        {guest.email && (
                          <div className="flex items-center gap-2 text-sm text-[#666666]">
                            <Mail className="w-4 h-4 flex-shrink-0" />
                            <span className="truncate">{guest.email}</span>
                          </div>
                        )}
                        {guest.phone && (
                          <div className="flex items-center gap-2 text-sm text-[#666666]">
                            <Phone className="w-4 h-4 flex-shrink-0" />
                            <span>{guest.phone}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {isCardExpanded && (
                      <div className="space-y-2 mb-4 p-3 bg-[#f7f2eb]/50 rounded-lg">
                        {guest.email && (
                          <div className="flex items-center gap-2 text-sm text-[#666666]">
                            <Mail className="w-4 h-4 flex-shrink-0" />
                            <span className="truncate">{guest.email}</span>
                          </div>
                        )}
                        {guest.phone && (
                          <div className="flex items-center gap-2 text-sm text-[#666666]">
                            <Phone className="w-4 h-4 flex-shrink-0" />
                            <span>{guest.phone}</span>
                          </div>
                        )}
                        {guest.address && (
                          <div className="flex items-start gap-2 text-sm text-[#666666]">
                            <Home className="w-4 h-4 flex-shrink-0 mt-0.5" />
                            <div>
                              <p>{guest.address}</p>
                              {guest.city && <p>{guest.postal_code} {guest.city}</p>}
                              {guest.country && <p>{guest.country}</p>}
                            </div>
                          </div>
                        )}
                        {guest.dietary_restrictions && (
                          <div className="flex items-start gap-2 text-sm text-[#666666] pt-2 border-t border-[#d4af37]/20">
                            <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="font-semibold text-[#0a253c] text-xs mb-1">Diätwünsche</p>
                              <p>{guest.dietary_restrictions}</p>
                            </div>
                          </div>
                        )}
                        {guest.notes && (
                          <div className="flex items-start gap-2 text-sm text-[#666666] pt-2 border-t border-[#d4af37]/20">
                            <FileText className="w-4 h-4 flex-shrink-0 mt-0.5" />
                            <div>
                              <p className="font-semibold text-[#0a253c] text-xs mb-1">Notizen</p>
                              <p>{guest.notes}</p>
                            </div>
                          </div>
                        )}
                      </div>
                    )}

                    <div className="flex items-center justify-between gap-3 mt-3">
                      <div className="flex-1">
                        <StatusDropdown
                          value={guest.rsvp_status}
                          onChange={(value) => handleUpdateRSVP(guest.id, value as any)}
                          options={statusOptions}
                          size="sm"
                        />
                      </div>
                      {guest.plus_one && (
                        <span className="text-sm font-semibold text-[#d4af37] whitespace-nowrap">+1</span>
                      )}
                    </div>

                    {(guest.dietary_restrictions || guest.table_number) && (
                      <div className="flex flex-wrap gap-2 mt-3">
                        {guest.dietary_restrictions && guest.dietary_restrictions.trim() !== '' && (
                          <span className="px-2 py-1 bg-orange-100 text-orange-700 rounded-full text-xs font-semibold">
                            Diät
                          </span>
                        )}
                        {guest.table_number && (
                          <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full text-xs font-semibold">
                            Tisch {guest.table_number}
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                );
              }
            });

            return cards;
          })()}

          {filteredAndSortedGuests.length === 0 && (
            <div className="col-span-full p-12 text-center">
              <Users className="w-16 h-16 text-[#d4af37] mx-auto mb-4 opacity-50" />
              <p className="text-[#333333] text-lg">
                {hasActiveFilters || activeQuickFilter ? 'Keine Gäste gefunden' : 'Noch keine Gäste hinzugefügt'}
              </p>
            </div>
          )}
        </div>
      )}

      {viewMode === 'kanban' && (
        <DndContext
          sensors={sensors}
          collisionDetection={closestCorners}
          onDragStart={handleDragStart}
          onDragOver={handleDragOver}
          onDragEnd={handleDragEnd}
          onDragCancel={handleDragCancel}
        >
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {['planned', 'invited', 'accepted', 'declined'].map(status => {
            const renderKanbanCards = () => {
              const renderedFamilies = new Set<string>();
              const cards: JSX.Element[] = [];
              const statusGuests = filteredAndSortedGuests.filter(g => g.rsvp_status === status);

              statusGuests.forEach(guest => {
                if (guest.family_group_id && !renderedFamilies.has(guest.family_group_id)) {
                  renderedFamilies.add(guest.family_group_id);
                  const familyGroup = familyGroups.find(f => f.id === guest.family_group_id);
                  const familyMembers = filteredAndSortedGuests.filter(g => g.family_group_id === guest.family_group_id);
                  const stats = getFamilyStats(guest.family_group_id);
                  const isExpanded = expandedFamilies.has(guest.family_group_id);
                  const allSameStatus = familyMembers.every(m => m.rsvp_status === status);

                  if (allSameStatus) {
                    const isKanbanExpanded = expandedKanbanCards.has(guest.family_group_id);

                    cards.push(
                      <SortableKanbanCard key={`family-${guest.family_group_id}`} id={guest.id}>
                      <div
                        className="p-4 rounded-xl bg-[#f7f2eb] hover:bg-[#d4af37]/10 transition-all border-2 border-[#d4af37]/30 cursor-move"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div
                            className="flex items-center gap-3 flex-1 cursor-pointer"
                            onClick={(e) => {
                              e.stopPropagation();
                              setSelectedFamilyForView(guest.family_group_id!);
                            }}
                          >
                            <div className="w-10 h-10 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex items-center justify-center text-white">
                              <Users className="w-5 h-5" />
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="font-semibold text-[#0a253c] truncate">{familyGroup?.family_name || 'Familie'}</p>
                              <p className="text-xs text-[#666666]">{stats.total} {stats.total === 1 ? 'Person' : 'Personen'}</p>
                            </div>
                          </div>
                          <div className="flex gap-1">
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                setSelectedFamilyForView(guest.family_group_id!);
                              }}
                              className="p-1 hover:bg-white rounded transition-colors"
                              title="Familie bearbeiten"
                            >
                              <Edit className="w-3 h-3 text-[#d4af37]" />
                            </button>
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                toggleKanbanCard(guest.family_group_id);
                              }}
                              className="p-1 hover:bg-white rounded transition-colors"
                            >
                              {isKanbanExpanded ? (
                                <ChevronDown className="w-4 h-4 text-[#d4af37]" />
                              ) : (
                                <ChevronRight className="w-4 h-4 text-[#d4af37]" />
                              )}
                            </button>
                          </div>
                        </div>

                        {isKanbanExpanded && (
                          <div className="space-y-2 pt-2 border-t border-[#d4af37]/20 mt-2">
                            {familyGroup?.notes && (
                              <div className="p-2 bg-white rounded-lg mb-2">
                                <p className="text-xs font-semibold text-[#666666] mb-1">Notizen</p>
                                <p className="text-xs text-[#0a253c]">{familyGroup.notes}</p>
                              </div>
                            )}
                            {familyMembers.map(member => (
                              <div
                                key={member.id}
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setSelectedGuest(member.id);
                                }}
                                className="flex items-center gap-2 p-2 bg-white rounded-lg hover:bg-[#f7f2eb] cursor-pointer transition-colors"
                              >
                                <div className="w-8 h-8 rounded-full bg-gradient-to-r from-[#d4af37] to-[#f4d03f] flex items-center justify-center text-white font-bold text-xs">
                                  {member.name.charAt(0).toUpperCase()}
                                </div>
                                <div className="flex-1 min-w-0">
                                  <p className="text-sm font-semibold text-[#0a253c] truncate flex items-center gap-1">
                                    {member.name}
                                    <span className={`text-xs px-1 py-0.5 rounded ${
                                      member.age_group === 'adult' ? 'bg-blue-100 text-blue-700' :
                                      member.age_group === 'child' ? 'bg-purple-100 text-purple-700' :
                                      'bg-pink-100 text-pink-700'
                                    }`}>
                                      {member.age_group === 'adult' ? 'E' :
                                       member.age_group === 'child' ? 'K' : 'Kl'}
                                    </span>
                                  </p>
                                  {member.family_role && (
                                    <p className="text-xs text-[#666666] truncate">{member.family_role}</p>
                                  )}
                                </div>
                              </div>
                            ))}
                          </div>
                        )}
                      </div>
                      </SortableKanbanCard>
                    );
                  }
                } else if (!guest.family_group_id) {
                  const guestGroup = groups.find(g => g.id === guest.group_id);
                  const isKanbanExpanded = expandedKanbanCards.has(guest.id);

                  cards.push(
                    <SortableKanbanCard key={guest.id} id={guest.id}>
                    <div
                      className={`p-4 rounded-xl bg-[#f7f2eb] hover:bg-[#d4af37]/10 transition-all cursor-move border-2 ${
                        guest.is_vip ? 'border-yellow-400' : 'border-transparent'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedGuest(guest.id);
                          }}
                          className="flex items-center gap-3 flex-1 cursor-pointer"
                        >
                          <div className={`w-10 h-10 rounded-full flex items-center justify-center text-sm font-bold text-white ${
                            guest.is_vip ? 'bg-gradient-to-r from-yellow-400 to-yellow-600' : 'bg-gradient-to-r from-[#d4af37] to-[#f4d03f]'
                          }`}>
                            {guest.name.charAt(0).toUpperCase()}
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="font-semibold text-[#0a253c] truncate flex items-center gap-1">
                              {guest.name}
                              {guest.is_vip && <Star className="w-3 h-3 text-yellow-500 fill-current flex-shrink-0" />}
                            </p>
                            {guestGroup && (
                              <p className="text-xs truncate" style={{ color: guestGroup.color }}>
                                {guestGroup.name}
                              </p>
                            )}
                          </div>
                        </div>
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            toggleKanbanCard(guest.id);
                          }}
                          className="p-1 hover:bg-white rounded transition-colors"
                        >
                          {isKanbanExpanded ? (
                            <ChevronDown className="w-4 h-4 text-[#d4af37]" />
                          ) : (
                            <ChevronRight className="w-4 h-4 text-[#d4af37]" />
                          )}
                        </button>
                      </div>
                      {guest.plus_one && !isKanbanExpanded && (
                        <span className="text-xs font-semibold text-[#d4af37]">+ Begleitperson</span>
                      )}
                      {isKanbanExpanded && (
                        <div className="space-y-2 pt-2 border-t border-[#d4af37]/20 mt-2">
                          <div className="p-2 bg-white rounded-lg space-y-1">
                            {guest.email && (
                              <div className="flex items-center gap-2 text-xs text-[#666666]">
                                <Mail className="w-3 h-3 flex-shrink-0" />
                                <span className="truncate">{guest.email}</span>
                              </div>
                            )}
                            {guest.phone && (
                              <div className="flex items-center gap-2 text-xs text-[#666666]">
                                <Phone className="w-3 h-3 flex-shrink-0" />
                                <span>{guest.phone}</span>
                              </div>
                            )}
                            {guest.address && (
                              <div className="flex items-start gap-2 text-xs text-[#666666] pt-1 border-t border-[#d4af37]/10">
                                <Home className="w-3 h-3 flex-shrink-0 mt-0.5" />
                                <div>
                                  <p>{guest.address}</p>
                                  {guest.city && <p>{guest.postal_code} {guest.city}</p>}
                                </div>
                              </div>
                            )}
                            {guest.dietary_restrictions && (
                              <div className="flex items-start gap-2 text-xs text-[#666666] pt-1 border-t border-[#d4af37]/10">
                                <AlertCircle className="w-3 h-3 flex-shrink-0 mt-0.5" />
                                <p className="text-xs">{guest.dietary_restrictions}</p>
                              </div>
                            )}
                            {guest.plus_one && (
                              <div className="pt-1 border-t border-[#d4af37]/10">
                                <span className="text-xs font-semibold text-[#d4af37]">+ Begleitperson</span>
                              </div>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                    </SortableKanbanCard>
                  );
                }
              });

              return cards;
            };

            const kanbanCards = renderKanbanCards();
            const statusGuests = filteredAndSortedGuests.filter(g => g.rsvp_status === status);
            const guestIds = statusGuests.map(g => g.id);

            return (
              <div key={status} className="bg-white rounded-2xl shadow-lg">
                <div className="p-6 border-b border-[#d4af37]/20">
                  <h3 className="text-xl font-bold text-[#0a253c] flex items-center gap-2">
                    {status === 'planned' && <><FileText className="w-5 h-5 text-gray-500" />Geplant</>}
                    {status === 'invited' && <><Mail className="w-5 h-5 text-blue-500" />Einladung versendet</>}
                    {status === 'accepted' && <><Check className="w-5 h-5 text-green-500" />Zugesagt</>}
                    {status === 'declined' && <><X className="w-5 h-5 text-red-500" />Abgesagt</>}
                    <span className="ml-2 text-sm">({kanbanCards.length})</span>
                  </h3>
                </div>
                <SortableContext items={guestIds} strategy={verticalListSortingStrategy}>
                  <DroppableColumn id={status}>
                    {kanbanCards}
                    {kanbanCards.length === 0 && (
                      <p className="text-center text-[#999999] py-8">
                        Keine Gäste
                      </p>
                    )}
                  </DroppableColumn>
                </SortableContext>
              </div>
            );
          })}
        </div>
        </DndContext>
      )}

      {selectedGuest && (
        <GuestDetailModal
          guestId={selectedGuest}
          weddingId={weddingId}
          onClose={() => setSelectedGuest(null)}
          onUpdate={() => {
            setSelectedGuest(null);
            onUpdate();
          }}
        />
      )}

      {selectedFamilyForView && (
        <FamilyDetailModal
          familyGroupId={selectedFamilyForView}
          weddingId={weddingId}
          groups={groups}
          onClose={() => setSelectedFamilyForView(null)}
          onEdit={(familyId) => {
            setSelectedFamilyForView(null);
            setEditingFamilyId(familyId);
          }}
          onUpdate={onUpdate}
        />
      )}

      {editingFamilyId && (
        <FamilyEditModal
          familyGroupId={editingFamilyId}
          weddingId={weddingId}
          groups={groups}
          onClose={() => setEditingFamilyId(null)}
          onSuccess={() => {
            setEditingFamilyId(null);
            onUpdate();
            loadFamilyGroups();
          }}
        />
      )}

      {showDietaryModal && (
        <DietaryRequirementsModal
          weddingId={weddingId}
          onClose={() => setShowDietaryModal(false)}
        />
      )}

      {showContactListModal && (
        <ContactListModal
          guests={guests}
          familyGroups={familyGroups}
          onClose={() => setShowContactListModal(false)}
          onEditGuest={(guestId) => setSelectedGuest(guestId)}
        />
      )}

      <ModalConfirm
        isOpen={deleteGroupModal.isOpen}
        onClose={() => setDeleteGroupModal({ isOpen: false, groupId: null, groupName: null, isDefaultGroup: false })}
        onConfirm={deleteGroupModal.isDefaultGroup ? () => {} : confirmDeleteGroup}
        title={deleteGroupModal.isDefaultGroup ? 'Gruppe kann nicht gelöscht werden' : 'Gruppe löschen'}
        message={
          deleteGroupModal.isDefaultGroup
            ? `Standard-Gruppen (A-Liste, B-Liste, C-Liste) können nicht gelöscht werden. Diese Gruppen sind fest in der Anwendung verankert.`
            : `Möchtest du die Gruppe "${deleteGroupModal.groupName}" wirklich löschen? Alle Gäste bleiben erhalten und können anderen Gruppen zugeordnet werden.`
        }
        confirmText={deleteGroupModal.isDefaultGroup ? 'Verstanden' : 'Gruppe löschen'}
        cancelText={deleteGroupModal.isDefaultGroup ? '' : 'Abbrechen'}
        type={deleteGroupModal.isDefaultGroup ? 'info' : 'danger'}
      />

      </div>
  );
}
