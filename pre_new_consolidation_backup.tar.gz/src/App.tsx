/* CAROUSEL_UPDATE_V2 */
import { useState, useEffect } from 'react';
import LandingPage from './components/LandingPage';
import Auth from './components/Auth';
import OnboardingFlow from './components/OnboardingFlow';
import PostOnboardingLoader from './components/PostOnboardingLoader';
import PostLoginLoader from './components/PostLoginLoader';
import Dashboard from './components/Dashboard';
import { supabase } from './lib/supabase';
import { ModalProvider } from './contexts/ModalContext';
import { ToastProvider } from './contexts/ToastContext';
import { closeModal } from './lib/modalManager';
import { logger } from './utils/logger';
import { ErrorBoundary } from './components/ErrorBoundary';

type Screen = 'landing' | 'auth' | 'onboarding' | 'postOnboardingLoading' | 'postLoginLoading' | 'dashboard';

interface OnboardingData {
  weddingId: string;
  partner1Name: string;
  partner2Name: string;
  partner1HeroType: string;
  partner2HeroType: string;
  weddingDate: string;
  ceremonyType: string;
}

function App() {
  const [currentScreen, setCurrentScreen] = useState<Screen>('landing');
  const [weddingId, setWeddingId] = useState<string | null>(null);
  const [userId, setUserId] = useState<string | null>(null);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [onboardingData, setOnboardingData] = useState<OnboardingData | null>(null);
  const [hasInitialized, setHasInitialized] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setIsAuthenticated(!!session);
      if (session) {
        setUserId(session.user.id);
        checkUserProfile(session.user.id, true, false);
      } else {
        setCurrentScreen('landing');
      }
      setHasInitialized(true);
    });

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, session) => {
      logger.debug('Auth state change', 'App', { event, hasSession: !!session });

      if (event === 'SIGNED_OUT') {
        setIsAuthenticated(false);
        setCurrentScreen('landing');
        setWeddingId(null);
        setUserId(null);
        setOnboardingData(null);
        return;
      }

      if (event === 'TOKEN_REFRESHED') {
        return;
      }

      if (session) {
        setIsAuthenticated(true);
        setUserId(session.user.id);
        if (event === 'SIGNED_IN') {
          checkUserProfile(session.user.id, true, true);
        } else if (event === 'INITIAL_SESSION') {
          checkUserProfile(session.user.id, true, false);
        }
      } else {
        setIsAuthenticated(false);
        if (hasInitialized) {
          setCurrentScreen('landing');
        }
        setWeddingId(null);
        setUserId(null);
      }
    });

    const handleAuthLogin = (event: Event) => {
      const customEvent = event as CustomEvent;
      const { email, password } = customEvent.detail;
      handleLogin(email, password);
    };

    const handleAuthRegister = (event: Event) => {
      const customEvent = event as CustomEvent;
      const { email, password } = customEvent.detail;
      handleRegister(email, password);
    };

    window.addEventListener('auth:login', handleAuthLogin);
    window.addEventListener('auth:register', handleAuthRegister);

    return () => {
      subscription.unsubscribe();
      window.removeEventListener('auth:login', handleAuthLogin);
      window.removeEventListener('auth:register', handleAuthRegister);
    };
  }, []);

  const checkUserProfile = async (userId: string, shouldRedirect: boolean = true, showLoginLoader: boolean = false) => {
    try {
      const { data: profileData, error: profileError } = await supabase
        .from('user_profiles')
        .select('event_name, onboarding_completed')
        .eq('id', userId)
        .maybeSingle();

      if (profileError) {
        logger.error('Error fetching profile', 'App.checkUserProfile', profileError);
        if (shouldRedirect) {
          setCurrentScreen('onboarding');
        }
        return;
      }

      if (!profileData) {
        logger.debug('No profile found, redirecting to onboarding', 'App.checkUserProfile');
        if (shouldRedirect) {
          setCurrentScreen('onboarding');
        }
        return;
      }

      if (profileData.onboarding_completed) {
        const { data: weddingData, error: weddingError } = await supabase
          .from('weddings')
          .select('id')
          .eq('user_id', userId)
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (weddingError) {
          logger.error('Error fetching wedding', 'App.checkUserProfile', weddingError);
          if (shouldRedirect) {
            setCurrentScreen('onboarding');
          }
          return;
        }

        if (weddingData) {
          logger.debug('User has completed onboarding and has wedding data', 'App.checkUserProfile');
          setWeddingId(weddingData.id);
          if (shouldRedirect) {
            if (showLoginLoader) {
              logger.debug('Showing login loader for returning user', 'App.checkUserProfile');
              setCurrentScreen('postLoginLoading');
            } else {
              logger.debug('Going directly to dashboard', 'App.checkUserProfile');
              setCurrentScreen('dashboard');
            }
          }
        } else {
          logger.warn('User marked as completed but no wedding data found', 'App.checkUserProfile');
          if (shouldRedirect) {
            setCurrentScreen('onboarding');
          }
        }
      } else {
        logger.debug('User has not completed onboarding', 'App.checkUserProfile');
        if (shouldRedirect) {
          setCurrentScreen('onboarding');
        }
      }
    } catch (error) {
      logger.error('Unexpected error in checkUserProfile', 'App.checkUserProfile', error);
      if (shouldRedirect) {
        setCurrentScreen('landing');
        setIsAuthenticated(false);
      }
    }
  };

  const handleStartOnboarding = () => {
    setCurrentScreen('auth');
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      if (data.session) {
        setIsAuthenticated(true);
        setUserId(data.session.user.id);
        closeModal();
      }
    } catch (error) {
      logger.error('Login error', 'App.handleLogin', error);
      throw error;
    }
  };

  const handleRegister = async (email: string, password: string) => {
    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) throw error;

      if (data.session) {
        setIsAuthenticated(true);
        setUserId(data.session.user.id);
        closeModal();
      }
    } catch (error) {
      logger.error('Register error', 'App.handleRegister', error);
      throw error;
    }
  };

  const handleAuthSuccess = () => {
    setIsAuthenticated(true);
  };

  const handleOnboardingComplete = (data: OnboardingData) => {
    setOnboardingData(data);
    setWeddingId(data.weddingId);
    setCurrentScreen('postOnboardingLoading');
  };

  const handlePostLoadingComplete = async () => {
    if (!weddingId) return;

    try {
      const weddingDateObj = new Date(onboardingData?.weddingDate || '');
      const today = new Date();
      const monthsUntilWedding = Math.floor(
        (weddingDateObj.getTime() - today.getTime()) / (1000 * 60 * 60 * 24 * 30)
      );

      const starterTasks = [
        {
          title: 'Location für die Hochzeit finden',
          description: 'Recherchiert passende Locations und vereinbart Besichtigungstermine',
          priority: 'high',
          category: 'venue',
          wedding_id: weddingId,
          due_date: monthsUntilWedding >= 12 ? new Date(today.setMonth(today.getMonth() + 2)).toISOString() : null,
        },
        {
          title: 'Budget-Kategorien festlegen',
          description: 'Legt fest, wie viel ihr für Location, Catering, Dekoration etc. ausgeben möchtet',
          priority: 'high',
          category: 'budget',
          wedding_id: weddingId,
        },
        {
          title: 'Gästeliste erstellen',
          description: 'Erstellt eine erste Liste mit allen Gästen, die ihr einladen möchtet',
          priority: 'medium',
          category: 'guests',
          wedding_id: weddingId,
        },
        {
          title: 'Save-the-Date Karten vorbereiten',
          description: 'Plant und gestaltet eure Save-the-Date Karten',
          priority: 'medium',
          category: 'planning',
          wedding_id: weddingId,
        },
      ];

      const budgetCategories = [
        { name: 'Location', category: 'venue', wedding_id: weddingId, estimated_cost: 0 },
        { name: 'Catering', category: 'catering', wedding_id: weddingId, estimated_cost: 0 },
        { name: 'Dekoration', category: 'decor', wedding_id: weddingId, estimated_cost: 0 },
        { name: 'Fotograf', category: 'photography', wedding_id: weddingId, estimated_cost: 0 },
        { name: 'Musik & DJ', category: 'entertainment', wedding_id: weddingId, estimated_cost: 0 },
        { name: 'Blumen', category: 'flowers', wedding_id: weddingId, estimated_cost: 0 },
      ];

      await Promise.all([
        supabase.from('tasks').insert(starterTasks),
        supabase.from('budget_items').insert(budgetCategories),
      ]);
    } catch (error) {
      logger.error('Error initializing data', 'App.handlePostLoadingComplete', error);
    }

    setCurrentScreen('dashboard');
  };

  return (
    <ErrorBoundary>
      <ToastProvider>
        <ModalProvider>
          <div className="min-h-screen bg-[#f7f2eb]">
          {currentScreen === 'landing' && (
            <ErrorBoundary>
              <LandingPage onGetStarted={handleStartOnboarding} />
            </ErrorBoundary>
          )}
          {currentScreen === 'auth' && (
            <ErrorBoundary>
              <Auth onAuthSuccess={handleAuthSuccess} />
            </ErrorBoundary>
          )}
          {currentScreen === 'onboarding' && isAuthenticated && (
            <ErrorBoundary>
              <OnboardingFlow onComplete={handleOnboardingComplete} />
            </ErrorBoundary>
          )}
          {currentScreen === 'postOnboardingLoading' && onboardingData && (
            <ErrorBoundary>
              <PostOnboardingLoader
                weddingId={onboardingData.weddingId}
                partner1Name={onboardingData.partner1Name}
                partner2Name={onboardingData.partner2Name}
                partner1HeroType={onboardingData.partner1HeroType}
                partner2HeroType={onboardingData.partner2HeroType}
                weddingDate={onboardingData.weddingDate}
                ceremonyType={onboardingData.ceremonyType}
                onComplete={handlePostLoadingComplete}
              />
            </ErrorBoundary>
          )}
          {currentScreen === 'postLoginLoading' && weddingId && userId && isAuthenticated && (
            <ErrorBoundary>
              <PostLoginLoader
                weddingId={weddingId}
                userId={userId}
                onComplete={() => setCurrentScreen('dashboard')}
              />
            </ErrorBoundary>
          )}
          {currentScreen === 'dashboard' && weddingId && isAuthenticated && (
            <ErrorBoundary>
              <Dashboard weddingId={weddingId} />
            </ErrorBoundary>
          )}
          </div>
        </ModalProvider>
      </ToastProvider>
    </ErrorBoundary>
  );
}

export default App;
